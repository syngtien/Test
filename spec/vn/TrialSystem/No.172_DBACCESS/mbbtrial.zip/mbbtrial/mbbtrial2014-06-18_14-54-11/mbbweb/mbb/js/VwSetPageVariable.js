/**
 * VwSetPageVariable
 * ページ保存
 */
LAST_MODIFIED('2004.12.21', '1.0.30');

/** alert()の最大行数 */
var MAXMESSAGELINES = 20;

/* alertの親window (「保存中ダイアログ」のwindow) */
var m_alertFunctionOwner = window;

/* このファイル内で使う関数群 */
var utilSetPageVariable;
// setPageVariable()で毎回作成
// utilSetPageVariable = new UtilSetPageVariable();

var errSetPageVariable = new DummyErrorSearchDialogObject();


/**
 * 概要  画面に放置されたオブジェクトの情報を編集して、
 *       サーバに送れる形に変換する
 * 引数  pageobj ：page変数
 *        winobj ：ダイアログの親window
 * 戻り値 整形済みHTML文
 */
function setPageVariable(pageobj, winobj, errorSearchDialogObject){
  ////var dt1 = (new Date()).toString();
  
  errSetPageVariable = errorSearchDialogObject;
  
  utilSetPageVariable = new UtilSetPageVariable();

  // ファイルがあった場合にフォームエンコードタイプを'multipart/form-data'に自動設定する  
  utilSetPageVariable.isFileExists = false;


  // エラーオブジェクト一覧の初期化
  errSetPageVariable.init();

  // 戻り値オブジェクト
  var sp_objInfo = new Object();
  sp_objInfo.isOk = false;
  sp_objInfo.html = '';
  sp_objInfo.id = '';
  sp_objInfo.message = '';
  sp_objInfo.errorObject = null;
  sp_objInfo.param = '';

  // ダイアログの親windowを設定
  if(winobj) {
    m_alertFunctionOwner = winobj;
  } else {
    m_alertFunctionOwner = window;
  }
  
  // フォームオブジェクト
  var formarea = getAreaInfo(pageobj.pageItems[ELEMENTID_FIRSTFORM], pageobj.pageItems);

  // 項目ID重複チェックオブジェクト
  var uniqueCheck = new UniqueCheckReferer();

  // オブジェクトの階層を構築するためのループ
  for(var i in pageobj.pageItems) {
    var pageItem = pageobj.pageItems[i];
    var areainfo = getAreaInfo(pageItem, pageobj.pageItems);
    if(areainfo == formarea) {
      continue;
    }
    var adopter = formarea.getAdopter(areainfo);
    if(!adopter) {
      // フォームの外
      if(pageobj.editStatus != '2') {
        var prm = new Array();
        prm[0] = areainfo.pageItem.pageItemId;
        prm[1] = areainfo.getTypeLiteral();
        prm[2] = utilSetPageVariable.getStringValue(areainfo.pageItem.properties, 'name');
        utilSetPageVariable.addError('V0004', prm);
      }
    } else if(adopter.isTable){
      // テーブルの子供はすでにchildrenに追加されている

    } else {
      if(!areainfo.isWithin(adopter)) {
        // はみ出ている

        var prm = new Array();
        prm[0] = areainfo.pageItem.pageItemId;
        prm[1] = areainfo.getTypeLiteral();
        prm[2] = utilSetPageVariable.getStringValue(areainfo.pageItem.properties, 'name');
        prm[3] = adopter.pageItem.pageItemId;
        utilSetPageVariable.addError('V0005', prm);

      }
      adopter.adoptChildren(areainfo);
    }
    var name = utilSetPageVariable.getStringValue(pageItem.properties, 'name');
    if('' != name && !areainfo.isCell && pageobj.editStatus != '2' && name.charAt(0) != '@') {
      uniqueCheck.setObjectByName(name, pageItem);
    }
    
    if(areainfo.type == 'file') {
      utilSetPageVariable.isFileExists = true;
    }
  }

  // 内部エラー
  if(!utilSetPageVariable.confirm('')) {
    return sp_objInfo;
  }

  // formの外に配置チェック
  if(!utilSetPageVariable.confirm('V0004')) {
    sp_objInfo.isOk = true;
    sp_objInfo.id = utilSetPageVariable.errors['V0004'][0][0];
    sp_objInfo.errorObject = errSetPageVariable;
    return sp_objInfo;
  }

  // 親からはみ出ているかチェック
  if(!utilSetPageVariable.confirm('V0005')) {
    sp_objInfo.isOk = true;
    sp_objInfo.id = utilSetPageVariable.errors['V0005'][0][0];
    sp_objInfo.errorObject = errSetPageVariable;
    return sp_objInfo;
  }

  // 項目ID重複チェック
  if(!uniqueCheck.confirm()) {
    sp_objInfo.isOk = true;
    sp_objInfo.id = uniqueCheck.firstPageItemId();
    sp_objInfo.errorObject = errSetPageVariable;
    return sp_objInfo;
  }

  // オブジェクト重なりチェック
  var overlapCheck = new OverlapCheck(formarea, pageobj);
  if(!overlapCheck.confirm()) {
    sp_objInfo.isOk = true;
    sp_objInfo.id = overlapCheck.firstPageItemId();
    sp_objInfo.errorObject = errSetPageVariable;
    return sp_objInfo;
  }

  // カスタマイズ時の親オブジェクトチェック
  var parentCheck = new CustomizedParentCheck();

  ////var dt2 = (new Date()).toString();

  // ? 2004.02.19
  // 保存用に属性値を再設定するためのループ
  /*
  for(var i in pageobj.pageItems) {
    var pageItem = pageobj.pageItems[i];
    var areainfo = getAreaInfo(pageItem, pageobj.pageItems);
  }
  */
  
  ////var dt200 = (new Date()).toString();

  // 保存用に属性値を再設定するためのループ
  for(var i in pageobj.pageItems) {
    var pageItem = pageobj.pageItems[i];
    var areainfo = getAreaInfo(pageItem, pageobj.pageItems);

    // 属性値を保存用に変換
    convertToSaveData(areainfo, pageobj);
  }

  ////var dt201 = (new Date()).toString();

  // 保存用に属性値を再設定するためのループ
  for(var i in pageobj.pageItems) {
    var pageItem = pageobj.pageItems[i];

    if(pageobj.editStatus == '2') {

      // 親オブジェクトチェック
      parentCheck.checkParent(pageItem);

      // タグ属性作成
      makeTagProperties(pageItem, PROPERTYIDPREFIX_TAGCUSTOM);

    } else {

      // タグ属性作成
      makeTagProperties(pageItem, PROPERTYIDPREFIX_TAG)

      //pageinfo += createPageItemHDinfo(pageItem);

    }

  }

  ////var dt202 = (new Date()).toString();

  // 保存用に属性値を再設定するためのループ
  for(var i in pageobj.pageItems) {
    var pageItem = pageobj.pageItems[i];
    // リテラル属性値設定
    makeLiteralProperties(pageItem, pageobj.pageName);
  }

  ////var dt203 = (new Date()).toString();

  // 親オブジェクトチェック
  if(!parentCheck.alert()) {
    sp_objInfo.isOk = true;
    sp_objInfo.id = parentCheck.firstPageItemId();
    sp_objInfo.errorObject = errSetPageVariable;
    return sp_objInfo;
  }

  // widthの値チェック
  if(!utilSetPageVariable.confirm('V0006')) {
    sp_objInfo.isOk = true;
    sp_objInfo.id = utilSetPageVariable.errors['V0006'][0][0];
    sp_objInfo.errorObject = errSetPageVariable;
    return sp_objInfo;
  }

  // widthの値チェック
  if(!utilSetPageVariable.confirm('V0007')) {
    sp_objInfo.isOk = true;
    sp_objInfo.id = utilSetPageVariable.errors['V0007'][0][0];
    sp_objInfo.errorObject = errSetPageVariable;
    return sp_objInfo;
  }

  ////var dt3 = (new Date()).toString();
  
  try{

    if(pageobj.editStatus != '2'){
      sp_objInfo.html = createSavingPageData(pageobj);
    }else{
      CustomInit(pageobj);
      sp_objInfo.html = createSavingPageDataCustom(pageobj);
    }

    sp_objInfo.isOk = true;

  } catch(e){

    sp_objInfo.isOk = false;
    sp_objInfo.html = '';
    sp_objInfo.error = e;
  }

  ////var dt4 = (new Date()).toString();

  ////alert('dt1:' + dt1 + '\ndt2:' + dt2 + '\ndt200:' + dt200 + '\ndt201:' + dt201 + '\ndt202:' + dt202 + '\ndt203:' + dt203 + '\ndt3:' + dt3 + '\ndt4:' + dt4)
  return sp_objInfo;
}

/**
 * _pageItemからAreaInfoを取得。なければ作成
 * @param  _pageItem  object
 *         _pageItems object
 * @return AreaInfo
 */
function getAreaInfo(_pageItem, _pageItems) {

  if(!_pageItem.areaInfo) {

    // ない場合、生成する
    _pageItem.areaInfo = new AreaInfo(_pageItem, _pageItems);
  }

  return _pageItem.areaInfo;
}

/**
 * pageItemの絶対位置・サイズを取得するラッパオブジェクト
 * @param  _pageItem  object
 *         _pageItems object
 */
function AreaInfo(_pageItem, _pageItems) {

  AreaInfo.prototype.adoptChildren = _adoptChildren;
  AreaInfo.prototype.getAdopter = _getAdopter;
  AreaInfo.prototype.isChildOf = _isChildOf;
  AreaInfo.prototype.isWithin = _isWithin;
  AreaInfo.prototype.isOverlapped = _isOverlapped;
  AreaInfo.prototype.containPoint = _containPoint;
  AreaInfo.prototype.getCellRowHeight = _getCellRowHeight;
  AreaInfo.prototype.getCellWidth = _getCellWidth;
  AreaInfo.prototype.prepareCellInfo = _prepareCellInfo;
  AreaInfo.prototype.preparePosition = _preparePosition;
  AreaInfo.prototype.prepareSize = _prepareSize;
  AreaInfo.prototype.getRowTop = _getRowTop;
  AreaInfo.prototype.getLeft = _getLeft;
  AreaInfo.prototype.getRowHeight = _getRowHeight;
  AreaInfo.prototype.getWidth = _getWidth;
  AreaInfo.prototype.getReference = _getReference;
  AreaInfo.prototype.getTypeLiteral = _getTypeLiteral;

  // 対象の画面項目オブジェクト
  this.pageItem = _pageItem;

  // 項目タイプ
  this.type = _pageItem.pageItemTypeId;

  // 位置・サイズ
  this.rowTop = 0;
  this.rowHeight = 1;
  this.left = 0;
  this.width = 1;

  if(this.type == 'table') {
    this.isTable = true;
    this.childPageItems = new Object();
    var cellcnt = 0;
    for(var i in _pageItems) {
      if(_pageItems[i].parentPageItemTypeId == 'table') {
        if(_pageItems[i].parentPageItemId == _pageItem.pageItemId) {
          this.childPageItems[i] = _pageItems[i];
          cellcnt++;
        }
      }
    }

    if(cellcnt == 0) {
      // セルが存在しない
      var msg = 'Table ' + _pageItem.pageItemId + ' is broken.\nPlease delete the table and add one.';
      utilSetPageVariable.addError('', new Array(msg));
    }

  } else if(this.type == 'hide') {

  } else {

    if(this.type == 'panel' || this.type == 'form') {
      this.isContainer = true;
    }

    // rowHeight と width は決定している
    this.sizeDefinite = true;

    // rowHeight設定
    if(_pageItem.properties['height'] && _pageItem.properties['height'].value != '') {
      this.rowHeight = pxToRow(_pageItem.properties['height'].value);
    } else if(_pageItem.properties['offsetheight'] && _pageItem.properties['offsetheight'].value != '') {
      this.rowHeight = pxToRow(_pageItem.properties['offsetheight'].value);
    }
    if(this.rowHeight < 1) {
      this.rowHeight = 1;
    }

    // width設定
    if(_pageItem.properties['width'] && _pageItem.properties['width'].value != '') {
      this.width = utilSetPageVariable.getIntValue(_pageItem.properties, 'width');
    } else if(_pageItem.properties['offsetwidth'] && _pageItem.properties['offsetwidth'].value != '') {
      switch(this.type) {
      case 'string':
      //case 'label':
        // OFFSETWIDTHを使わない
        break;
      default:
        this.width = utilSetPageVariable.getIntValue(_pageItem.properties, 'offsetwidth');
        this.usingOffsetWidth = true;
      }
    }
    if(this.width < 1) {
      this.width = 1;
    }


  }

  if(_pageItem.parentPageItemTypeId == 'table') {
    if(!_pageItem.parentPageItemId) {
      // parentPageItemが存在しないとき、エラー
      utilSetPageVariable.addError('', new Array('parentPageItemIdが存在しない.',_pageItem.pageItemId));
    }

    this.isCell = true;
    this.parent = null;
    this.colIndex = 0;
    this.rowIndex = 0;

    // parent設定
    if(_pageItems[_pageItem.parentPageItemId]) {
      this.parent = getAreaInfo(_pageItems[_pageItem.parentPageItemId], _pageItems);
    } else {
      // parentPageItemに該当するオブジェクトが存在しないとき、エラー
      utilSetPageVariable.addError('', new Array('該当するpageItemが存在しない.',_pageItem.pageItemId,_pageItem.parentPageItemId));
    }

    // colIndex設定
    if(_pageItem.properties['col']) {
      this.colIndex = parseInt(_pageItem.properties['col'].value);
    } else {
      // COLが存在しないとき、エラー
      utilSetPageVariable.addError('', new Array('セルにcol属性が存在しない.', _pageItem.pageItemId));
    }

    // rowIndex設定
    if(this.parent) {
      var modeProperty = this.parent.pageItem.properties['mode'];
      if(modeProperty) {
        var rowProperty = _pageItem.properties['row'];
        if(rowProperty) {
          this.rowIndex = parseInt(rowProperty.value);
        } else {
          // ROWが存在しないとき、エラー
          utilSetPageVariable.addError('', new Array('セルにrow属性が存在しない.'));
        }
      } else {
        // MODEが存在しないとき、エラー
        utilSetPageVariable.addError('', new Array('テーブルにmode属性が存在しない.',this.parent.pageItem.pageItemId));
      }
    }

  } else {

    // rowTopとleftは決定している
    this.positionDefinite = true;

    // rowTop設定
    if(_pageItem.properties['top']) {
      this.rowTop = pxToRow(_pageItem.properties['top'].value);
      if(this.rowTop < 0) {
        this.rowTop = 0;
      }
    }

    // left設定
    if(_pageItem.properties['left']) {
      this.left = utilSetPageVariable.getIntValue(_pageItem.properties ,'left');
      if(this.left < 0) {
        this.left = 0;
      }
    }
  }


  /* 子供にする。もともといた子供のうち、孫になるものがいる
   * @param  cobj object 子供にするオブジェクト
   */
  function _adoptChildren(cobj) {

    if(this.isTable) {
      // もともと子供（cell）である
      for(var i in this.children) {
        if(this.children[i] == cobj) {
          return true;
        }
      }
      return false;
    }

    if(!this.isContainer) {
      // 子供にできない
      return false;
    }

    if(!this.children) {
      // 初めての子供
      this.children = new Object();
      this.children[cobj.pageItem.pageItemId] = cobj;
      cobj.parent = this;

      return true;
    }

    if(!cobj.isContainer && !cobj.isTable) {
      // 孫になる子供はいない
      this.children[cobj.pageItem.pageItemId] = cobj;
      cobj.parent = this;
      return true;
    }

    if(!cobj.children) {
      cobj.children = new Object();
    }

    // 新しい子供の配列（孫の取り除かれた）
    var newChildren = new Object();
    newChildren[cobj.pageItem.pageItemId] = cobj;
    cobj.parent = this;

    // 孫になる子供を捜す
    for(var i in this.children) {
      var child = this.children[i];
      var adopter = cobj.getAdopter(child);
      if(adopter == null) {

        // 子供のまま
        newChildren[child.pageItem.pageItemId] = child;

      } else {

        if(!child.isWithin(adopter)) {
          // はみ出ている

          var prm = new Array();
          prm[0] = child.pageItem.pageItemId;
          prm[1] = child.getTypeLiteral();
          prm[2] = utilSetPageVariable.getStringValue(child.pageItem.properties, 'name');
          prm[3] = adopter.pageItem.pageItemId;
          utilSetPageVariable.addError('V0005', prm);

        }

        // 孫になる
        if(!adopter.children) {
          adopter.children = new Object();
        }
        adopter.children[child.pageItem.pageItemId] = child;
        child.parent = adopter;
      }
    }

    // 孫の取り除かれた配列を設定しなおす
    this.children = newChildren;

    return true;
  }

  /* 親になってくれるオブジェクトを返す
   * @param  cobj object 親を探す子オブジェクト
   * @return 親となるオブジェクト
   */
  function _getAdopter(cobj) {

    if(this == cobj) {
      return null;
    }

    if(!this.isContainer && !this.isTable) {
      // form,panel,table以外は子供をもてない
      return null;
    }

    if(this.isTable) {
      if(!this.children) {
        // 配下のcellの情報を作成
        this.prepareCellInfo();
      }
    }

    if(!cobj.isChildOf(this)) {
      // cobjが自分の子（or孫）の範囲に配置されていない
      return null;
    }

    if(cobj.isCell) {
      return cobj.parent;
    }
    
    if(cobj.isTable) {
      if(!cobj.children) {
        // 配下のcellの情報を作成
        cobj.prepareCellInfo();
      }
      if(this.isCell) {
        if(cobj.children) {
          for(var i in cobj.children) {
            if(cobj.children[i] == this) {

              // 自分はcobj の子(cell)のだった
              return null;
            }
          }
        }
      }
    }

    if(!this.isTable) {
      if(this.getRowTop() == cobj.getRowTop() && this.getLeft() == cobj.getLeft()) {
        if(cobj.isContainer || cobj.isTable) {
          if(this.getWidth() < cobj.getWidth()) {
            return null;
          } else if(this.getWidth() > cobj.getWidth()) {

          } else if(this.getRowHeight() < cobj.getRowHeight()) {
            return null;
          } else if(this.getRowHeight() > cobj.getRowHeight()) {

          } else {
            //同じ大きさ
          }
        }
      }
    }

    // 孫かどうか
    if(this.children) {
      for(var i in this.children) {
        if(this.children[i] == cobj) {

          // cobj は自分の子(cell)のことだった
          return this;
        }

        var adopter = this.children[i].getAdopter(cobj);
        if(adopter) {

          // 孫だった
          return adopter;

        }
      }
    }

    if(this.isTable) {
      // テーブルは最初から決まっているcell以外の子供を持たない
      return null;
    }

    return this;
  }

  /* 親かどうか判定
   * @param  _parent object 親と仮定するオブジェクト
   * @return _parentが自分を含んでいるとき true
   */
  function _isChildOf(_parent) {
    var x = this.getLeft();
    var y = this.getRowTop();
    return _parent.containPoint(x, y);
  }

  /* 親からはみでてないか判定
   * @param  _parent object 親と仮定するオブジェクト
   * @return _parent内に自分がおさまっているとき true
   */
  function _isWithin(_parent) {
    var x = this.getLeft() + this.getWidth() - 1;
    var y = this.getRowTop() + this.getRowHeight() - 1;
    return _parent.containPoint(x, y);
  }

  /* 重なっているか判定
   * @param  _object object 重なっているか調べる対象オブジェクト
   * @return 重なっているとき true
   */
  function _isOverlapped(_object) {
    var x  = _object.getLeft();
    var y  = _object.getRowTop();
    var x2 = x + _object.getWidth();
    var y2 = y + _object.getRowHeight();

    var thisX  = this.getLeft();
    var thisY  = this.getRowTop();
    var thisX2 = thisX + this.getWidth();
    var thisY2 = thisY + this.getRowHeight();

    if(x2 <= thisX) {
      return false;
    }

    if(y2 <= thisY) {
      return false;
    }

    if(thisX2 <= x) {
      return false;
    }

    if(thisY2 <= y) {
      return false;
    }
    
    log.debug('overlaped : ' + this.pageItem.pageItemId);
    log.debug('this   : ' + thisX + '/' + thisY + '/' + thisX2 + '/' + thisY2);
    log.debug('target : ' + x + '/' + y + '/' + x2 + '/' + y2);
    return true;
  }

  /* 座標が内側かどうか判定
   * @param  _x int 判定する点のx座標
   *         _y int 判定する点のy座標
   * @return 判定する点が内側にあるとき true
   */
  function _containPoint(_x, _y) {

    if(_x < this.getLeft()) {
      return false;
    }

    if(_y < this.getRowTop()) {
      return false;
    }

    if(this.getLeft() + this.getWidth() <= _x) {
      return false;
    }

    if(this.getRowTop() + this.getRowHeight() <= _y) {
      return false;
    }

    return true;
  }

  /* 指定されたrowIndexのcellのrowHeightを返す
   * @param  rowIndex int cellのrow番号
   * @return 指定されたrowIndexのcellのrowHeight
   */
  function _getCellRowHeight(rowIndex) {
    if(!this.cellRowHeights) {
      // cellの情報をまだ作成していなかったので作成
      this.prepareCellInfo();
    }

    if(this.cellRowHeights[rowIndex]) {
      // cellのrowHeightを返す
      return this.cellRowHeights[rowIndex];
    }

    return 0;
  }

  /* 指定されたcolIndexのcellのwidthを返す
   * @param  colIndex int cellのcol番号
   * @return 指定されたcolIndexのcellのwidth
   */
  function _getCellWidth(colIndex) {
    if(!this.cellWidths) {
      // cellの情報をまだ作成していなかったので作成
      this.prepareCellInfo();
    }

    if(this.cellWidths[colIndex]) {
      // cellのwidthを返す
      return this.cellWidths[colIndex];
    }

    return 0;
  }

  /*
   * セルの情報を作成
   */
  function _prepareCellInfo() {

    // 各セルのrowHeight
    this.cellRowHeights = new Array();

    // 各セルのwidth
    this.cellWidths = new Array();

    if(!this.isTable) {
      return;
    }

    if(!this.childPageItems) {
      return;
    }

    // children配列を作成, cellRowHeights, cellWidths の値を設定
    this.children = new Object();
    for(var i in this.childPageItems) {
      var areainfo = getAreaInfo(this.childPageItems[i], _pageItems);
      this.children[areainfo.pageItem.pageItemId] = areainfo;
      this.cellRowHeights[areainfo.rowIndex] = areainfo.rowHeight;
      this.cellWidths[areainfo.colIndex] = areainfo.width;
    }
  }

  /*
   * セルの絶対位置(this.rowTop, this.left)を作成
   */
  function _preparePosition() {
    if(this.isCell) {

      // rowTop 作成
      this.rowTop = this.parent.getRowTop();
      for(var i = 1 ; i < this.rowIndex; i++) {
        this.rowTop += this.parent.getCellRowHeight(i);
      }

      // left 作成
      this.left = this.parent.getLeft();
      for(var i = 1 ; i < this.colIndex; i++) {
        this.left += this.parent.getCellWidth(i);
      }
    }

    // 情報作成済み
    this.positionDefinite = true;

    return;
  }

  /*
   * テーブルのサイズ(rowHeight, width)を作成
   */
  function _prepareSize() {
    if(this.isTable) {

      if(!this.cellRowHeights) {
        // まだセルの情報がなかったので作成
        this.prepareCellInfo();
      }

      // rowHeight作成
      this.rowHeight = 0;
      for(var i in this.cellRowHeights) {
        this.rowHeight += this.cellRowHeights[i];
      }

      // width作成
      this.width = 0;
      for(var i in this.cellWidths) {
        this.width += this.cellWidths[i];
      }
    }

    // 情報作成済み
    this.sizeDefinite = true;
    return;
  }

  /**
   * rowTop取得（作成されていなければ作成）
   * @return int rowTop
   */
  function _getRowTop() {
    if(!this.positionDefinite) {
      this.preparePosition();
    }
    return this.rowTop;
  }

  /**
   * left取得（作成されていなければ作成）
   * @return int left
   */
  function _getLeft() {
    if(!this.positionDefinite) {
      this.preparePosition();
    }
    return this.left;
  }

  /**
   * rowHeight取得（作成されていなければ作成）
   * @return int rowHeight
   */
  function _getRowHeight() {
    if(!this.sizeDefinite) {
      this.prepareSize();
    }
    return this.rowHeight;
  }

  /**
   * width取得（作成されていなければ作成）
   * @return int width
   */
  function _getWidth() {
    if(!this.sizeDefinite) {
      this.prepareSize();
    }
    return this.width;
  }

  /**
   * debug用メソッド：階層構造を確認するため
   */
  function _getReference() {
    var obj = new Object();
    if(this.children) {
      for(var i in this.children) {
        obj[i] = this.children[i].getReference();
      }
    }
    return obj;
  }

  /**
   * 項目タイプのリテラルを返す
   */
  function _getTypeLiteral() {
    return getLiteral('pageitemtype.' + this.type);
  }

  /**
   * 概要  px単位をrow単位に変換する
   * 引数   num : px単位数値
   * 戻り値  row単位数値
   */
  function pxToRow(num){
    if(num == ''){
        return 0;
    }
    if(num == '0'){
        return 0;
    }
    if(isNaN(num)){
        return 0;
    }

    var roundBorder = (DISPLAYROWHEIGHT / 2);

    return parseInt((parseInt(num) + roundBorder) / DISPLAYROWHEIGHT);
  }
}

/**
 * 項目タイプのリテラルを返す
 */
function getTypeLiteral(_pageItem) {
  return getLiteral('pageitemtype.' + _pageItem.pageItemTypeId);
}

/**
 * 項目IDの重複チェック用オブジェクト
 */
function UniqueCheckReferer() {

  this.name = getLiteral('dialog.errorobject.V0001');

  // 重複をチェックする配列
  this.objects = new Object();

  // 重複した名前のあったオブジェクト
  this.ununiqueObjects = new Object();

  // 重複している個数
  this.ununiqueCount = 0;

  /* 重複をチェックする登録
   * @param name string 重複チェックする名前
   *        obj  object 重複チェックするオブジェクト
   */
  UniqueCheckReferer.prototype.setObjectByName = function(name, obj) {
    if(this.objects[name]) {
      // 同じ名前がある
      this.ununiqueCount++;

      // 重複しているオブジェクト配列に追加
      if(!this.ununiqueObjects[name]) {

        // 同じ名前のペア登録
        this.ununiqueObjects[name] = new Array();
        this.ununiqueObjects[name][0] = this.objects[name];
        this.ununiqueObjects[name][1] = obj;

      } else {

        // 同じ名前の3オブジェクトめ以降
        this.ununiqueObjects[name][this.ununiqueObjects[name].length] = obj;

      }

    } else {
      // チェック用に登録
      this.objects[name] = obj;
    }
  }

  /* 重複があって良いか確認する
   * @param win object ダイアログの親window
   */
  UniqueCheckReferer.prototype.confirm = function() {

    // confirmに表示するメッセージ
    var msg = '';
    
    var cnt = 0;
    
    // 重複した名前がある
    if(0 < this.ununiqueCount) {

      // メッセージ作成
      msg += getMessage('V0001');
      for(var name in this.ununiqueObjects) {
        msg += '\n\n' + getMessage('V0001_1', new Array(name));
        for(var i in this.ununiqueObjects[name]) {
          var pageItem = this.ununiqueObjects[name][i];
          msg += '\n' + getMessage('V0001_2', new Array(pageItem.pageItemId, getTypeLiteral(pageItem)));

          // エラーオブジェクト一覧に追加
          errSetPageVariable.add(pageItem.pageItemId, getTypeLiteral(pageItem), this.name + '(' + name + ')');

          cnt++;
        }
      }
      if(cnt > MAXMESSAGELINES) {
        msg = getMessage('V0001_OV', new Array(cnt.toString()));
      }
      return m_alertFunctionOwner.confirm(msg);
    }

    return true;
  }

  /*
   * エラーのあった最初のオブジェクトIDを返す
   * @return エラーのあった最初のオブジェクトID
   */
  UniqueCheckReferer.prototype.firstPageItemId = function() {
    for(var name in this.ununiqueObjects) {
      for(var i in this.ununiqueObjects[name]) {
        return this.ununiqueObjects[name][i].pageItemId;
      }
    }
    return '';
  }
}

/**
 * かさなりチェック用オブジェクト
 */
function OverlapCheck(_root, pageobj) {

  this.name = getLiteral('dialog.errorobject.V0002');

  // 重なっているオブジェクト 添え字:childrenのindex=オブジェクトID, 値:checkid
  this.overlaps = new Object();

  // 重なりチェックID（aとbが重なっていたらaとbは同じID）
  this.checkid = 0;

  /* 重なりチェック。子階層を再起呼び出しする
   * @param pobj object 最上位オブジェクト
   */
  OverlapCheck.prototype.chkChildrenOverlapped = function(pobj) {

    // チェック対象
    var checking = new Object();

    // すべての子供をチェックする
    for(var i in pobj.children) {
      var obj = pobj.children[i];

      // チェック対象との重なりチェック
      for(var j in checking) {
        if(checking[j].isOverlapped(obj)) {

          if(this.overlaps[j]) {

            // 他とも重なっているオブジェクトと重なっていた
            this.overlaps[i] = this.overlaps[j];

          } else if(this.overlaps[i]) {

            // 自分は他とも重なっている
            this.overlaps[j] = this.overlaps[i];

          } else {

            // 両方とも他と重なっていない
            this.checkid++;
            this.overlaps[j] = this.checkid;
            this.overlaps[i] = this.checkid;

          }
        }
      }

      // 自分をチェック対象に追加
      checking[i] = pobj.children[i];

      // form,panelの場合、子階層の重なりチェック
      if(obj.isContainer && obj.children) {
        this.chkChildrenOverlapped(obj);
      }

      // tableの場合、子階層の重なりチェック
      if(obj.isTable && obj.children) {
        this.chkChildrenOverlapped(obj);
      }
    }
  }

  /* 重なっているのがあれば確認
   * @return boolean 処理を続けるか (OK,重なっていない → true ／キャンセル → false)
   */
  OverlapCheck.prototype.confirm = function() {

    // confirmに表示するメッセージ
    var msg = '';
    var cnt = 0;
    if(0 < this.checkid) {
      // 重なっているオブジェクトがある

      // メッセージ作成
      msg += getMessage('V0002');
      for(var i = 1; i <= this.checkid; i++) {
        msg += '\n';
        for(var obj in this.overlaps) {
          var pageItem = pageobj.pageItems[obj];
          var name = '';
          if(pageItem.properties['name']) {
            name = pageItem.properties['name'].value;
          }

          if(this.overlaps[obj] == i) {
            var prm = new Array();
            prm[0] = obj;
            prm[1] = getTypeLiteral(pageItem);
            prm[2] = name;
            msg += '\n' + getMessage('V0002_2', prm);

            // エラーオブジェクト一覧に追加
            errSetPageVariable.add(obj, prm[1], this.name);

            cnt++;
          }
        }
      }

      if(cnt > MAXMESSAGELINES) {
        msg = getMessage('V0002_OV', new Array(cnt.toString()));
      }
      return m_alertFunctionOwner.confirm(msg);
    }

    return true;
  }

  /*
   * エラーのあった最初のオブジェクトIDを返す
   * @return エラーのあった最初のオブジェクトID
   */
  OverlapCheck.prototype.firstPageItemId = function() {
    var pageItemId = '';
    for(var obj in this.overlaps) {
      if(this.overlaps[obj] == 1) {
        pageItemId = pageobj.pageItems[obj].pageItemId;
        break;
      }
    }
    return pageItemId;
  }

  // オブジェクト生成時にチェックをおこなう
  this.chkChildrenOverlapped(_root);

}

/**
 * カスタマイズ時、親オブジェクトが同じかチェック
 */
function CustomizedParentCheck() {

  this.name = getLiteral('dialog.errorobject.V0003');

  // 親が違っているオブジェクト
  this.errors = new Array();

  /* 親が違っているかチェックする
   * @param obj object チェックするオブジェクト
   * @return boolean 違っている→false
   */
  CustomizedParentCheck.prototype.checkParent = function(obj) {
    if(!obj.originalParentId) {
      return true;
    }
    if(obj.parentPageItemId != obj.originalParentId){
      this.errors[this.errors.length] = obj;
      return false;
    }
    return true;
  }

  /*
   * 親の違っているオブジェクトがあればメッセージを表示
   * @return 処理を続けるか (親の違っているオブジェクトがある → false)
   */
  CustomizedParentCheck.prototype.alert = function() {

    if(this.errors.length == 0) {
      return true;
    }

    var msg = '';
    var cnt = 0;
    
    msg += getMessage('V0003') + '\n';
    for(var i in this.errors){
      var pageItem = this.errors[i];
      var name = '';
      if(pageItem.properties['name']) {
        name = pageItem.properties['name'].value;
      }
      var prm = new Array();
      prm[0] = pageItem.pageItemId;
      prm[1] = getTypeLiteral(pageItem);
      prm[2] = name;
      prm[3] = pageItem.originalParentId;
      msg += '\n' + getMessage('V0003_1', prm);

      // エラーオブジェクト一覧に追加
      errSetPageVariable.add(prm[0], prm[1], this.name);

      cnt++;
    }

    if(cnt > MAXMESSAGELINES) {
      msg = getMessage('V0002_OV', new Array(cnt.toString()));
    }
    m_alertFunctionOwner.alert(msg);
    return false;
  }

  /*
   * エラーのあった最初のオブジェクトIDを返す
   * @return エラーのあった最初のオブジェクトID
   */
  CustomizedParentCheck.prototype.firstPageItemId = function() {
    var pageItemId = '';
    for(var i in this.errors){
      pageItemId = this.errors[i].pageItemId;
      break;
    }
    return pageItemId;
  }
}

/**
 * このファイル内で使用する関数
 */
function UtilSetPageVariable() {

  // エラー
  this.errors = new Object();

  UtilSetPageVariable.prototype.hasArrayValue = function(propertyId) {
    return isArrayValue(propertyId);
  }

  UtilSetPageVariable.prototype.addError = UtilSetPageVariable_addError;
  UtilSetPageVariable.prototype.confirm = UtilSetPageVariable_confirm;
  UtilSetPageVariable.prototype.getStringValue = UtilSetPageVariable_getStringValue;
  UtilSetPageVariable.prototype.getIntValue = UtilSetPageVariable_getIntValue;
  UtilSetPageVariable.prototype.addDefaultProperty = UtilSetPageVariable_addDefaultProperty;
  UtilSetPageVariable.prototype.removeProperty = UtilSetPageVariable_removeProperty;
  UtilSetPageVariable.prototype.setProperty = UtilSetPageVariable_setProperty;
  UtilSetPageVariable.prototype.updateProperty = UtilSetPageVariable_updateProperty;
  UtilSetPageVariable.prototype.setUnspecifiedProperty = UtilSetPageVariable_setUnspecifiedProperty;

  /**
   * エラーメッセージ
   * @param  _id   string messageId
   *         _prms Array  messageIdの付加情報
   */
  function UtilSetPageVariable_addError(_id, _prms) {
    if(!this.errors[_id]) {
      this.errors[_id] = new Array();
    }
    var errs = this.errors[_id];

    switch(_id) {
    case 'V0004':
    case 'V0005':
    case 'V0006':
    case 'V0007':
      errs[errs.length] = _prms;

      // エラーオブジェクト一覧に追加
      errSetPageVariable.add(_prms[0], _prms[1], getLiteral('dialog.errorobject.' + _id));
      break;

    case '':
      errs[errs.length] = _prms;
      break;

    default:
      m_alertFunctionOwner.alert(getMessage(_id, _prms));
    }
  }

  /**
   * エラーメッセージ
   * @param  _id   string messageId
   *         _prms Array  messageIdの付加情報
   */
  function UtilSetPageVariable_confirm(_id) {
    if(!this.errors[_id]) {
      return true;
    }
    var errs = this.errors[_id];
    var msg = '';
    var cnt = 0;
    
    switch(_id) {
    case 'V0004':
    case 'V0005':
    case 'V0006':
    case 'V0007':
      msg += getMessage(_id) + '\n';
      for(var i = 0; i < errs.length; i++) {
        msg += '\n ';
        msg += getMessage(_id + '_1', errs[i]);
        cnt++;
      }

      if(cnt > MAXMESSAGELINES) {
        msg = getMessage(_id + '_OV', new Array(cnt.toString()));
      }
      return m_alertFunctionOwner.confirm(msg);

      break;

    case '':
      for(var i = 0; i < errs.length; i++) {
        msg += '\n ';
        msg += getMessage('', errs[i]);
        cnt++;
      }

      return m_alertFunctionOwner.alert(msg);
      return false;
      break;

    default:
    }
    return true;
  }

  /**
   * propertyからString値を取得
   * @param  _props        object プロパティ
   *         _propId       string プロパティID
   *         _defaultValue string 既定値
   * @return 属性値。設定がない場合_defaultValue又は ''
   */
  function UtilSetPageVariable_getStringValue(_props, _propId, _defaultValue) {
    if(_props[_propId]) {
      if(_props[_propId].value != '') {

        // string型で値を返す
        try {
          return _props[_propId].value.toString();
        } catch(e) {
          alert('property:' + _propId + '=(' + typeof(_props[_propId].value) + ')' + _props[_propId].value + '\n\n\n' + e);
        }
      }
    }

    if(_defaultValue) {
      // デフォルト値が指定されていればデフォルト値を返す
      return _defaultValue.toString();
    }
    return '';
  }

  /**
   * propertyからint値を取得
   * @param  _props        object プロパティ
   *         _propId       string プロパティID
   *         _defaultValue string 既定値
   * @return 属性値。設定がない場合_defaultValue又は 0
   */
  function UtilSetPageVariable_getIntValue(_props, _propId, _defaultValue) {

    if(_props[_propId]) {
      if(_props[_propId].value != '' && !isNaN(_props[_propId].value)) {

        // Int型で値を返す
        return parseInt(_props[_propId].value);
      }
    }

    if(_defaultValue) {
      // デフォルト値が指定されていればデフォルト値を返す
      return _defaultValue;
    }

    return 0;
  }

  /**
   * 値が存在しなかったときだけ初期値を作成
   */
  function UtilSetPageVariable_addDefaultProperty(_pageItem, _propertyId, _value, _enable) {
    if(!_pageItem.properties[_propertyId]) {
      UtilSetPageVariable_setProperty(_pageItem, _propertyId, _value, _enable);
    }
  }

  /**
   * 属性を削除
   */
  function UtilSetPageVariable_removeProperty(_pageItem, _propertyId) {
    if(_pageItem.properties[_propertyId]) {
      delete _pageItem.properties[_propertyId];
    }
  }

  /**
   * 属性を作成
   */
  function UtilSetPageVariable_setProperty(_pageItem, _propertyId, _value, _enable) {
    _pageItem.properties[_propertyId] = new Object();
    if(_value) {
      _pageItem.properties[_propertyId].value = _value.toString();
    } else {
      _pageItem.properties[_propertyId].value = '';
    }

    if(_enable) {
      _pageItem.properties[_propertyId].enable = _enable.toString();
    } else {
      _pageItem.properties[_propertyId].enable = '0';
    }

  }

  /**
   * 属性を更新。なければ作成
   */
  function UtilSetPageVariable_updateProperty(_pageItem, _propertyId, _value, _enable) {
    if(!_pageItem.properties[_propertyId]) {
      UtilSetPageVariable_setProperty(_pageItem, _propertyId, _value, _enable);
    } else {
      if(_value) {
        _pageItem.properties[_propertyId].value = _value.toString();
      } else {
        _pageItem.properties[_propertyId].value = '';
      }
      if(_enable) {
        _pageItem.properties[_propertyId].enable = _enable.toString();
      }
    }
  }

  /**
   * View表示専用の値を設定。ツール用の値をspecified-xxxに保存
   */
  function UtilSetPageVariable_setUnspecifiedProperty(_pageItem, _propertyId, _value, _enable) {
    var specifiedPropertyId = 'specified-' + _propertyId;
    var specifiedValue = UtilSetPageVariable_getStringValue(_pageItem.properties, _propertyId);

    if(specifiedValue != '') {
      specifiedValue = _pageItem.properties[_propertyId].value;
    } else {
      specifiedValue = 'empty';
    }
    UtilSetPageVariable_setProperty(_pageItem, _propertyId, _value, _enable);
    UtilSetPageVariable_setProperty(_pageItem, specifiedPropertyId, specifiedValue);
  }
}

/*
var borderStyleConvert = new Object();
borderStyleConvert['none']   = 'BORDERFSTYLE_NONE';
borderStyleConvert['dotted'] = 'BORDERFSTYLE_DOTTED';
borderStyleConvert['dashed'] = 'BORDERFSTYLE_DASHED';
borderStyleConvert['solid']  = 'BORDERFSTYLE_SOLID';
borderStyleConvert['double'] = 'BORDERFSTYLE_DOUBLE';
borderStyleConvert['groove'] = 'BORDERFSTYLE_GROOVE';
borderStyleConvert['ridge']  = 'BORDERFSTYLE_RIDGE';
borderStyleConvert['inset']  = 'BORDERFSTYLE_INSET';
borderStyleConvert['outset'] = 'BORDERFSTYLE_OUTSET';
*/

/**
 *
 */
function convertToSaveData(areainfo , pageobj) {
  var pageItem = areainfo.pageItem;

  if(areainfo.parent) {
    if(areainfo.parent.pageItem) {
      if(areainfo.parent.pageItem.pageItemId) {
        pageItem.parentPageItemId = areainfo.parent.pageItem.pageItemId;
      }
    }

    if(!areainfo.isCell) {
      var customizeLocationEnabled = '0';
      if('enabled' == utilSetPageVariable.getStringValue(pageItem.properties, 'customize-mobility')) {
        customizeLocationEnabled = '1';
      }

      var row = areainfo.getRowTop() - areainfo.parent.getRowTop();
      if(row > 0) {
        utilSetPageVariable.updateProperty(pageItem, 'row', row, customizeLocationEnabled);
      } else {
        utilSetPageVariable.removeProperty(pageItem, 'row');
      }
      
      var left = areainfo.getLeft() - areainfo.parent.getLeft();
      if(left > 0) {
        utilSetPageVariable.updateProperty(pageItem, 'left', left, customizeLocationEnabled);
      } else {
        utilSetPageVariable.removeProperty(pageItem, 'left');
      }
    }
    
    var locationfixing = utilSetPageVariable.getStringValue(pageItem.properties, 'locationfixing');
    if(locationfixing) {
      var lim = 0;
      var isParentFixRightChecked = false;
      for(var ai = areainfo.parent; ai.parent; ai = ai.parent) {
        var parentlocationfixing = utilSetPageVariable.getStringValue(ai.pageItem.properties, 'locationfixing');
        if(parentlocationfixing == 'pageright') {
          isParentFixRightChecked = true;
        }
      }
      if(!isParentFixRightChecked) {
        for(var ai = areainfo; ai.parent; ai = ai.parent) {
          var left = ai.getLeft() - ai.parent.getLeft();
          var exleft = utilSetPageVariable.getStringValue(ai.parent.pageItem.properties, 'expandableleft');
          if(exleft != '' && left > parseInt(exleft)) {
          } else {
            utilSetPageVariable.updateProperty(ai.parent.pageItem, 'expandableleft', '' + left);
          }
          utilSetPageVariable.updateProperty(ai.pageItem, 'selfalign', 'right');
          if(ai.parent.type == 'form') {
            break;
          }
          if(++lim > 10) {
            break;
          }
        } // for(var ai = areainfo; ai.parent; ai = ai.parent) {
      } // if(!isParentFixRightChecked) {
      if(areainfo.type == 'panel' && !areainfo.isCell) {
        utilSetPageVariable.updateProperty(pageItem, 'contentwidth', areainfo.getWidth());
      }
      utilSetPageVariable.updateProperty(pageItem, 'selfalign', 'right');
    }
    utilSetPageVariable.removeProperty(pageItem, 'top');

  } else {
    pageItem.parentPageItemId = '';
  }

  utilSetPageVariable.removeProperty(pageItem, 'type');

   switch(areainfo.type){
   case  'form':
    utilSetPageVariable.setProperty(pageItem, 'seq', '1');
    utilSetPageVariable.setProperty(pageItem, 'top', '0');

    utilSetPageVariable.removeProperty(pageItem, 'row');
    utilSetPageVariable.removeProperty(pageItem, 'left');
    if(utilSetPageVariable.isFileExists) {
      if(utilSetPageVariable.getStringValue(pageItem.properties, 'enctype') == '') {
        utilSetPageVariable.setUnspecifiedProperty(pageItem, 'enctype', 'multipart/form-data');
      }
    }
    break;

  case  'table':

    // そのまま保存
    //var borderStyle = utilSetPageVariable.getStringValue(pageItem.properties, 'borderstyle');
    //if(borderStyleConvert[borderStyle]) {
    //  utilSetPageVariable.updateProperty(pageItem, 'borderstyle', borderStyleConvert[borderStyle]);
    //} else {
    //  utilSetPageVariable.updateProperty(pageItem, 'borderstyle', borderStyleConvert['none']);
    //}

    utilSetPageVariable.updateProperty(pageItem, 'width', areainfo.getWidth());
    utilSetPageVariable.updateProperty(pageItem, 'height', areainfo.getRowHeight() * DISPLAYROWHEIGHT);

    var maxcols = 1;
    for(var i in areainfo.cellWidths) {
      if(maxcols < parseInt(i)) {
        maxcols = parseInt(i);
      }
      utilSetPageVariable.setProperty(pageItem, 'colwidth-' + i, areainfo.cellWidths[i]);
    }

    var maxrows = 1;
    for(var i in areainfo.cellRowHeights) {
      if(maxrows < parseInt(i)) {
        maxrows = parseInt(i);
      }
    }

    if(pageItem.properties['mode']) {
      var mode = pageItem.properties['mode'].value;
      if(useTableRows(mode)) {
        utilSetPageVariable.addDefaultProperty(pageItem, 'maxrows', maxrows);
      } else {
        utilSetPageVariable.removeProperty(pageItem, 'maxrows');
        utilSetPageVariable.removeProperty(pageItem, 'height');
      }
      if(!useTitleRowVanishing(mode)) {
        utilSetPageVariable.removeProperty(pageItem, 'titlerowvanishing');
      }
    } else {
      //error
    }

    //if(pageItem.properties['BORDERWIDTH'].value == '0'){
    //  utilSetPageVariable.removeProperty(pageItem, 'BORDERWIDTH');
    //}

    break;


   case  'hide':
//    utilSetPageVariable.setProperty(pageItem, 'width', 1);
//    utilSetPageVariable.setProperty(pageItem, 'height', 10);

    utilSetPageVariable.removeProperty(pageItem, 'width');
    utilSetPageVariable.removeProperty(pageItem, 'height');

    break;

   case  'panel':
    utilSetPageVariable.updateProperty(pageItem, 'width', areainfo.getWidth());
    utilSetPageVariable.updateProperty(pageItem, 'height', areainfo.getRowHeight() * DISPLAYROWHEIGHT);

    if(areainfo.isCell) {

      utilSetPageVariable.removeProperty(pageItem, 'left');
      
      var parentTablemode = utilSetPageVariable.getStringValue(areainfo.parent.pageItem.properties, 'mode');
      if(isTableRowsGenerative(parentTablemode)) {
        var titlerows = Number(utilSetPageVariable.getStringValue(areainfo.parent.pageItem.properties, 'titlerows'));
        var row = Number(utilSetPageVariable.getStringValue(pageItem.properties, 'row'))
        if(titlerows < row) {
          //log.debug('panel titlerows:' + utilSetPageVariable.getStringValue(areainfo.parent.pageItem.properties, 'titlerows') + ' row:' + row);
          utilSetPageVariable.updateProperty(pageItem, 'row', '0');
        }
      }
    }

    break;

  case  'list':
    var maxrows = pageItem.properties['cell'].values.length;
    utilSetPageVariable.updateProperty(pageItem, 'maxrows', maxrows);

    if(utilSetPageVariable.getStringValue(pageItem.properties, 'width') == ''){
      utilSetPageVariable.setUnspecifiedProperty(pageItem, 'width', areainfo.getWidth());
    }

    break;

  case  'combo':
    var maxrows = pageItem.properties['cell'].values.length;
    utilSetPageVariable.updateProperty(pageItem, 'maxrows', maxrows);

    if(utilSetPageVariable.getStringValue(pageItem.properties, 'width') == ''){
      utilSetPageVariable.setUnspecifiedProperty(pageItem, 'width', areainfo.getWidth());
    }

    break;

  case  'radio':

    if('' != utilSetPageVariable.getStringValue(pageItem.properties, 'width')){
      if(parseInt(pageItem.properties['width'].value) < parseInt(pageItem.properties['offsetwidth'].value)){
        if(pageobj.editStatus != '2') {
          var prm = new Array();
          prm[0] = pageItem.pageItemId;
          prm[1] = getTypeLiteral(pageItem);
          prm[2] = utilSetPageVariable.getStringValue(pageItem.properties, 'name');
          prm[3] = utilSetPageVariable.getStringValue(pageItem.properties, 'width');
          prm[4] = utilSetPageVariable.getStringValue(pageItem.properties, 'offsetwidth');
          utilSetPageVariable.addError('V0006', prm);
        }
      }
    } else {
      utilSetPageVariable.setUnspecifiedProperty(pageItem, 'width', areainfo.getWidth());
    }

    //var bgcolor = utilSetPageVariable.getStringValue(pageItem.properties, 'bgcolor');
    //utilSetPageVariable.updateProperty(pageItem, 'bgcolorr', bgcolor);
    //utilSetPageVariable.updateProperty(pageItem, 'bgcolort', bgcolor);

    //var fontsize = utilSetPageVariable.getStringValue(pageItem.properties, 'fontsize');
    //utilSetPageVariable.updateProperty(pageItem, 'fontsizet', fontsize);

    var option = pageItem.properties['cell'].values;
    if(hasListTag(option)) {
      utilSetPageVariable.removeProperty(pageItem, 'maxrows');
    } else {
      var optioncols = Number(utilSetPageVariable.getStringValue(pageItem.properties, 'maxcols'));
      var maxrows = 1;
      if(option.length > optioncols) {
        maxrows = parseInt((optioncols + option.length - 1) / optioncols);
      }
      utilSetPageVariable.updateProperty(pageItem, 'maxrows', maxrows);
    }

    break;

  case 'string':

    if('' != utilSetPageVariable.getStringValue(pageItem.properties, 'width')){
      if(parseInt(pageItem.properties['width'].value) < parseInt(pageItem.properties['offsetwidth'].value)){
        var prm = new Array();
        prm[0] = pageItem.pageItemId;
        prm[1] = getTypeLiteral(pageItem);
        prm[2] = utilSetPageVariable.getStringValue(pageItem.properties, 'name');
        prm[3] = utilSetPageVariable.getStringValue(pageItem.properties, 'width');
        prm[4] = utilSetPageVariable.getStringValue(pageItem.properties, 'offsetwidth');
        utilSetPageVariable.addError('V0006', prm);
      }
    } else {
      //utilSetPageVariable.setUnspecifiedProperty(pageItem, 'width', areainfo.getWidth());
      if(pageobj.editStatus != '2') {
        var prm = new Array();
        prm[0] = pageItem.pageItemId;
        prm[1] = getTypeLiteral(pageItem);
        prm[2] = utilSetPageVariable.getStringValue(pageItem.properties, 'name');
        utilSetPageVariable.addError('V0007', prm);
      }
    }

    break;

  case 'label':

    if('' != utilSetPageVariable.getStringValue(pageItem.properties, 'width')){
      if(parseInt(pageItem.properties['width'].value) < parseInt(pageItem.properties['offsetwidth'].value)){
        if(pageobj.editStatus != '2') {
          var prm = new Array();
          prm[0] = pageItem.pageItemId;
          prm[1] = getTypeLiteral(pageItem);
          prm[2] = utilSetPageVariable.getStringValue(pageItem.properties, 'name');
          prm[3] = utilSetPageVariable.getStringValue(pageItem.properties, 'width');
          prm[4] = utilSetPageVariable.getStringValue(pageItem.properties, 'offsetwidth');
          utilSetPageVariable.addError('V0006', prm);
        }
      }
    } else {
      utilSetPageVariable.setUnspecifiedProperty(pageItem, 'width', areainfo.getWidth());
      /*
      var prm = new Array();
      prm[0] = pageItem.pageItemId;
      prm[1] = getTypeLiteral(pageItem);
      prm[2] = utilSetPageVariable.getStringValue(pageItem.properties, 'name');
      utilSetPageVariable.addError('V0007', prm);
      */
    }

    if(utilSetPageVariable.getStringValue(pageItem.properties, 'bgcolor') == '') {
      utilSetPageVariable.setUnspecifiedProperty(pageItem, 'bgcolor', 'transparent');
    }

    break;

  case  'check':
    if('' != utilSetPageVariable.getStringValue(pageItem.properties, 'width')){
      if(parseInt(pageItem.properties['width'].value) < parseInt(pageItem.properties['offsetwidth'].value)){
        if(pageobj.editStatus != '2') {
          var prm = new Array();
          prm[0] = pageItem.pageItemId;
          prm[1] = getTypeLiteral(pageItem);
          prm[2] = utilSetPageVariable.getStringValue(pageItem.properties, 'name');
          prm[3] = utilSetPageVariable.getStringValue(pageItem.properties, 'width');
          prm[4] = utilSetPageVariable.getStringValue(pageItem.properties, 'offsetwidth');
          utilSetPageVariable.addError('V0006', prm);
        }
      }
    } else {
      utilSetPageVariable.setUnspecifiedProperty(pageItem, 'width', areainfo.getWidth());
    }

    var width = utilSetPageVariable.getStringValue(pageItem.properties, 'width');
    if('' != width) {
      if(15 < parseInt(width)) {
        utilSetPageVariable.updateProperty(pageItem, 'widtht', parseInt(width) - 14);
      } else {
        utilSetPageVariable.updateProperty(pageItem, 'widtht', 1);
      }
    }

    var height = utilSetPageVariable.getStringValue(pageItem.properties, 'height');
    //utilSetPageVariable.updateProperty(pageItem, 'heightt', height);

    break;

  default:
    // button, submit, reset,
    // applet, embed, object, image,
    // text, textarea, password, file

    if(utilSetPageVariable.getStringValue(pageItem.properties, 'width') == ''){
      utilSetPageVariable.setUnspecifiedProperty(pageItem, 'width', areainfo.getWidth());
    }
  }

  if(pageobj.editStatus != '2') {
    if(areainfo.isCell) {
      /*
      if(pageItem.parentPageItemId) {
        var name = getCellName(pageItem.parentPageItemId, areainfo.rowIndex.toString(), areainfo.colIndex.toString());
      } else {
        var name = getCellName('', areainfo.rowIndex.toString(), areainfo.colIndex.toString());
      }
      utilSetPageVariable.setProperty(pageItem, 'name', name);
      */
      if(utilSetPageVariable.getStringValue(pageItem.properties, 'name') == ''){
        utilSetPageVariable.setUnspecifiedProperty(pageItem, 'name', pageItem.pageItemId);
      }

    } else {
      // @@ 2003.10.07 nameが必須のもの
      switch(areainfo.type){
      //case  'panel':
      case  'image':
      case  'applet':
      case  'object':
      case  'embed':
      case  'iframe':
      case  'hr':
        break;
      default:
        if(utilSetPageVariable.getStringValue(pageItem.properties, 'name') == ''){
          utilSetPageVariable.setUnspecifiedProperty(pageItem, 'name', pageItem.pageItemId);
        }
      }
    }
  }

  if(utilSetPageVariable.getStringValue(pageItem.properties, 'customize-visibility') == 'disabled'){
    utilSetPageVariable.removeProperty(pageItem, 'customize-visibility');
    // @visible
    //if(utilSetPageVariable.getStringValue(pageItem.properties, 'visibility') == 'visible'){
    //  utilSetPageVariable.removeProperty(pageItem, 'visibility');
    //}
  }
        
  if(utilSetPageVariable.getStringValue(pageItem.properties, 'customize-mobility') == 'disabled'){
    utilSetPageVariable.removeProperty(pageItem, 'customize-mobility');
  }
        
  if(utilSetPageVariable.getStringValue(pageItem.properties, 'customize-defaultvalue') == 'disabled'){
    utilSetPageVariable.removeProperty(pageItem, 'customize-defaultvalue');
  }
        
  if(utilSetPageVariable.getStringValue(pageItem.properties, 'customize-maxlines') == 'disabled'){
    utilSetPageVariable.removeProperty(pageItem, 'customize-maxlines');
  }
        
  utilSetPageVariable.removeProperty(pageItem, 'offsetwidth');
  utilSetPageVariable.removeProperty(pageItem, 'offsetheight');

  if(1 < areainfo.getRowHeight()) {
    utilSetPageVariable.setProperty(pageItem, 'rows', areainfo.getRowHeight());
  } else {
    utilSetPageVariable.removeProperty(pageItem, 'rows');
  }

}

var TAGIN       = '<%';
var TAGOUT      = '%>';
var TAGVALUEIN  = '%';
var TAGVALUEOUT = '%';
var propTagAvailable = new Object();
propTagAvailable.onclick = true;
propTagAvailable.lnk = true;
propTagAvailable.text = true;
propTagAvailable.textid = true;
propTagAvailable.bgcolor = true;
propTagAvailable.tooltip = true;
propTagAvailable.value = true;
propTagAvailable.src = true;
propTagAvailable['framesrc-0'] = true;
propTagAvailable['framesrc-1'] = true;
propTagAvailable['framesrc-2'] = true;
propTagAvailable['framesrc-3'] = true;
propTagAvailable.action = true;
propTagAvailable.fontcolor = true;
propTagAvailable.framesrc = true;
propTagAvailable.alt = true;
propTagAvailable.style = true;
propTagAvailable.caption = true;
propTagAvailable.background = true;
propTagAvailable.bordercolor = true;
propTagAvailable.selvalue = true;
propTagAvailable.target = true;
propTagAvailable.hrcolor = true;
propTagAvailable.textcolor = true;
propTagAvailable.linkcolor = true;
propTagAvailable.alinkcolor = true;
propTagAvailable.vlinkcolor = true;
propTagAvailable.archive = true;
propTagAvailable.classid = true;
propTagAvailable.code = true;
propTagAvailable.codebase = true;
propTagAvailable.embedsrc = true;
propTagAvailable.title = true;

var propTagAvailableArr = new Object();
propTagAvailableArr.cell = true;
propTagAvailableArr.embedotherparams = true;
propTagAvailableArr.embedparams = true;
propTagAvailableArr.jsfilename = true;
propTagAvailableArr.otherparams = true;
propTagAvailableArr.params = true;
propTagAvailableArr.meta = true;

var propTagNotAvailable = new Object();
propTagNotAvailable.top = true;
propTagNotAvailable.left = true;
propTagNotAvailable.width = true;
propTagNotAvailable.height = true;
propTagNotAvailable.visibility = true;
propTagNotAvailable.name = true;
propTagNotAvailable.row = true;
propTagNotAvailable.col = true;
propTagNotAvailable.fontfamily = true;
propTagNotAvailable.fontsize = true;
propTagNotAvailable.fontstyle = true;
propTagNotAvailable.fontweight = true;
propTagNotAvailable.accesskey = true;
propTagNotAvailable.acckey = true;
propTagNotAvailable.align = true;
propTagNotAvailable.border = true;
propTagNotAvailable.borderstyle = true;
propTagNotAvailable.borderwidth = true;
propTagNotAvailable.captionalign = true;
propTagNotAvailable.cellpadding = true;
propTagNotAvailable.cellspacing = true;
propTagNotAvailable.colsrows = true;
propTagNotAvailable['customize-defaultvalue'] = true;
propTagNotAvailable['customize-maxlines'] = true;
propTagNotAvailable['customize-mobility'] = true;
propTagNotAvailable['customize-visibility'] = true;
propTagNotAvailable.direction = true;
propTagNotAvailable.editmode = true;
propTagNotAvailable.enctype = true;
propTagNotAvailable.frameflag = true;
propTagNotAvailable['frameflag-0'] = true;
propTagNotAvailable['frameflag-1'] = true;
propTagNotAvailable['frameflag-2'] = true;
propTagNotAvailable['frameflag-3'] = true;
propTagNotAvailable.framename = true;
propTagNotAvailable['framename-0'] = true;
propTagNotAvailable['framename-1'] = true;
propTagNotAvailable['framename-2'] = true;
propTagNotAvailable['framename-3'] = true;
propTagNotAvailable.frameresize = true;
propTagNotAvailable['frameresize-0'] = true;
propTagNotAvailable['frameresize-1'] = true;
propTagNotAvailable['frameresize-2'] = true;
propTagNotAvailable['frameresize-3'] = true;
propTagNotAvailable.framescrolling = true;
propTagNotAvailable['framescrolling-0'] = true;
propTagNotAvailable['framescrolling-1'] = true;
propTagNotAvailable['framescrolling-2'] = true;
propTagNotAvailable['framescrolling-3'] = true;
propTagNotAvailable.maxcols = true;
propTagNotAvailable.maxlen = true;
propTagNotAvailable.maxlines = true;
propTagNotAvailable.maxrows = true;
propTagNotAvailable.method = true;
propTagNotAvailable.mode = true;
propTagNotAvailable.rows = true;
propTagNotAvailable.scrolling = true;
propTagNotAvailable.selectmode = true;
propTagNotAvailable.shade = true;
propTagNotAvailable.size = true;
propTagNotAvailable.textcols = true;
propTagNotAvailable.textrows = true;
propTagNotAvailable.underline = true;

/**
 * tag属性作成
 * @param obj object tag属性を作成するオブジェクト
 *        tagReplaceName string tag属性のプロパティIDのprefix 'tag' or 'tag-custom'
 */
function makeTagProperties(obj , tagReplaceName) {
  //tag変換
  //オブジェクト属性の値には<%TABLE/FIELD%>のように設定されたものを
  //PROPERTIES[属性] = '%tag0%'
  //PROPERTIES['tag0'] = 'TABLE/FIELD' に変換
  var tags = new Array();
  var tagNames = new Object();
  tagNames.length = 0;
  
  for (var j in obj.properties){

    if(!propTagAvailable[j]) {
      if(propTagNotAvailable[j]) {
        // tag設定不可の属性
        continue;
      } else if(propTagAvailableArr[j]) {
        // 値が配列の属性

        var property = obj.properties[j];
        for (var r in obj.properties[j].values){
          var protag = setTags(property, property.values[r], tags, tagReplaceName, tagNames);
          if (property.values[r] != protag){
            property.values[r] = protag;
          }
        }
        continue;
      }
    }
    
    var property = obj.properties[j];
    if(property.value == '') {
      continue;
    }

    var protag = setTags(property, property.value, tags, tagReplaceName, tagNames);
    if (property.value != protag){
      property.value = protag;
    }

  }// for

  // tag属性追加
  for(var h in tags){
    obj.properties[h] = new Object();
    obj.properties[h].value = tags[h].value;
    obj.properties[h].enable = tags[h].enable;
  }

  /**
   * 概要   タグが入っている属性値を置き換える
   * 引数   var : 属性値
   * 戻り値  ret : 処理済み属性値
   */
  function setTags(prop, val, tags, tagReplaceName, tagNames){

    var TAG = tagReplaceName;
    
    // 戻り値（ <%xxx%> が %tag#% に変換された文字列）
    var ret = val;

    switch(typeof(val)) {
    case 'string':
      break;
    case 'function':
      ret = val.toString();
      break;
    default:
      return val;
    }
    
    // tag#文字列
    var tagnm;

    if(ret.indexOf('<%') == -1) {
      return ret;
    }

    // <%と%>で囲まれた文字列の配列
    var arr = getTagName(ret);
    if(arr.length == 0) {
      return ret;
    }
    
    // 参照する%tag#%
    prop.tags = new Object();

    //タグ以外の部分の文字列
    var leftover = ret;
    if(prop.leftover) {
      leftover += prop.leftover;
    }

    for(var i=0; i<arr.length; i++){
      if(tagNames[arr[i]]) {
        tagnm = tagNames[arr[i]];
        if(tags[tagnm].enable == '0') {
          if(prop.enable && prop.enable == '1') {
            tags[tagnm].enable = '1';
          }
        }
      } else {
        tagnm = TAG + tagNames.length;
        tagNames.length++;
        tagNames[arr[i]] = tagnm;

        tags[tagnm] = new Object();
        tags[tagnm].value = arr[i];
        if(prop.enable && prop.enable == '1') {
          tags[tagnm].enable = '1';
        } else {
          tags[tagnm].enable = '0';
        }
        prop.tags[tagnm] = arr[i];
      }

      leftover = stringReplace(leftover, TAGIN + arr[i] + TAGOUT,'');
      ret = stringReplace(ret, TAGIN + arr[i] + TAGOUT,TAGVALUEIN + tagnm + TAGVALUEOUT);
    }
    prop.leftover = leftover;
    return ret.toString();
  }

  /*
   * 概要　　　囲まれた文字列を取り出す
   * 引数　　　str   ：取り出す文字列を含む文字列
   * 引数　　　strin ：取り出す文字列の開始を示す文字列
   * 引数　　　strout：取り出す文字列の開始を示す文字列
   * 戻り値　　取り出された文字列のArray
   */
  function getTagName(str) {
    var restOfStr = str;
    var retArr = new Array();
    var soeji = 0;
    var idx;

    if(typeof(restOfStr) != 'string'){
        return retArr;
    }

    while(0 < restOfStr.length){

      idx = restOfStr.indexOf(TAGIN);
      if(idx<0){
          break;
      }
      restOfStr = restOfStr.substring(idx + TAGIN.length,restOfStr.length);

      idx = restOfStr.indexOf(TAGOUT);
      if(idx<0){
          break;
      }

      retArr[soeji] = restOfStr.substring(0, idx);
      soeji++;

      restOfStr = restOfStr.substring(idx + TAGOUT.length,restOfStr.length);

    }

    return retArr;
  }

  /*
   * 概要　　　文字列を置き換える
   * 引数　　　str   ：置き換え対象文字列
   * 引数　　　strbef：置き換えまえ文字列部分
   * 引数　　　straft：置き換えあと文字列部分
   * 戻り値　　置き換えられた文字列
   */
  function stringReplace(str,strbef,straft) {
      var ret = '';
      var left;
      var right = str;
      var idx;

      while(0<right.length){

          idx = right.indexOf(strbef);
          if(idx<0){
              break;
          }
          left = right.substring(0, idx);
          right = right.substring(idx + strbef.length,right.length);

          ret = ret + left + straft;

      }
      ret = ret + right;

      return ret;
  }
}

/**
 * リテラル属性（言語別の値を持つ）を作成
 */
function makeLiteralProperties(obj, pageName) {
  
  // 無条件にliteralpropertyにする
  literalValue('text')
  literalValue('caption')
  literalValue('alt')
  literalValue('fontfamily')
  arrayLiteralValue('cell');

  /*
  // asciiでない文字を含むならliteralpropertyにする
  for(var i in obj.properties) {
    var property = obj.properties[i];
    if(isArrayValue(i)) {
      arrayLiteralValue(i, true);
    } else {
      literalValue(i, true);
    }
  }
  */
  
  function arrayLiteralValue(i, nonAscii) {
    if(obj.properties[i]) {
      var property = obj.properties[i];

      if(nonAscii) {
        var asc = true;
        for (var m in property.values){
          if(!isAscii(String(property.values[m]))) {
            asc = false;
          }
        }
        if(asc) {
          return;
        }
      }

      if(typeof(property.leftover) == 'string' && property.leftover == '') {
        return;
      }
      for (var m in property.values){

        if(property.values[m] != ''){

          if(!obj.literalProperties) {
            obj.literalProperties = new Object();
          }

          if(!obj.literalProperties[i]) {
            obj.literalProperties[i] = new Object();
            obj.literalProperties[i].langIds = new Object();
            obj.literalProperties[i].enable  = property.enable;
            obj.literalProperties[i].tags  = property.tags;
          }

          var litProperty = obj.literalProperties[i];

          for (var l in pageName){
            if(!litProperty.langIds[l]) {
              litProperty.langIds[l] = new Object();
              litProperty.langIds[l].values = new Object();
            }
            litProperty.langIds[l].values[m] = property.values[m];
          }

          delete property.values[m];
        }
      }
    }
  }

  function literalValue(i, nonAscii) {
    if(obj.properties[i]) {
      var property = obj.properties[i];

      if(nonAscii) {
        if(isAscii(String(property.value))) {
          return;
        }
      }
      
      if(typeof(property.leftover) && property.leftover == '') {
        return;
      }

      if(property.value != ''){

        if(!obj.literalProperties) {
          obj.literalProperties = new Object();
        }

        if(!obj.literalProperties[i]) {
          obj.literalProperties[i] = new Object();
          obj.literalProperties[i].langIds = new Object();
          obj.literalProperties[i].enable  = property.enable;
          obj.literalProperties[i].tags  = property.tags;
        }

        var litProperty = obj.literalProperties[i];

        for (var l in pageName){
          if(!litProperty.langIds[l]) {
            litProperty.langIds[l] = new Object();
          }
          litProperty.langIds[l].value = property.value;
        }

        delete obj.properties[i];
      }
    }
  }
}

/**
 *ダブルクォーテーションを'&quot;'に変える
 *
 */
function quotchange(val){

  if(typeof(val) == 'undefined'){
    return '';
  }

  if(val == ''){
    return '';
  }

  var ret = val.toString();

  ret = ret.replace(/&/g, '&amp;');
  ret = ret.replace(/"/g, '&quot;');
  return ret;
}

function makeInput(name, value){
  var sStr = '<input type="hidden" name="';
  var mStr = '" value="';
  var eStr = '" >\n';
  var str = sStr + name + mStr + value + eStr;
  return str;
}

var savePageVariable_pageItemPartD = new Object();
/**
 * ※文字列の連結回数を極力すくなくした
 */
function createPageItemHDinfo(obj){

  var strPageItemId = obj.pageItemId;
  var strPageitemdata = '<input type="hidden" name="PAGELAYOUT.PAGEITEMID" value="' + strPageItemId
                  + '">\n<input type="hidden" name="PAGELAYOUT.PAGEITEMTYPEID" value="' + obj.pageItemTypeId
                  + '">\n<input type="hidden" name="PAGELAYOUT.PARENTPAGEITEMID" value="' + obj.parentPageItemId;

  var strAllPropertydata='';
  // enableの値ごとに文字列を用意しておく
  var pageItemPartE = new Object();
  pageItemPartE['0'] = '">\n<input type="hidden" name="PAGEITEMPROPERTY.PAGEITEMID" value="' + strPageItemId
                     + '">\n<input type="hidden" name="PAGEITEMPROPERTY.ENABLE" value="0'
                     + '">\n<input type="hidden" name="PAGEITEMPROPERTY.PROPERTYID" value="';
  pageItemPartE['1'] = '">\n<input type="hidden" name="PAGEITEMPROPERTY.PAGEITEMID" value="' + strPageItemId
                     + '">\n<input type="hidden" name="PAGEITEMPROPERTY.ENABLE" value="1'
                     + '">\n<input type="hidden" name="PAGEITEMPROPERTY.PROPERTYID" value="';
  
  var propId;
  for (var j in obj.properties){
    var strPropertyData = '';
    var propertyObj = obj.properties[j];
    if(!utilSetPageVariable.hasArrayValue(j)) {

      if ((propertyObj.value != '' || propertyObj.enable != "0")){

        strPropertyData += pageItemPartE[propertyObj.enable] + j
          + '">\n<input type="hidden" name="PAGEITEMPROPERTY.VALUE" value="' + quotchange(propertyObj.value);
      }

    } else {
      if(j == 'acckey') {
        propId = 'accesskey';
      } else {
        propId = j;
      }
      for (var m in propertyObj.values){
        var valueObj = propertyObj.values[m];
        if (valueObj.indexOf("%tag") > -1) {
          if (valueObj.value != '' || propertyObj.enable != "0"){
            
            strPropertyData += pageItemPartE[propertyObj.enable] + propId + "-" + m
              + '">\n<input type="hidden" name="PAGEITEMPROPERTY.VALUE" value="' + quotchange(valueObj);
          }
        }else{
          if (valueObj.value != '' || propertyObj.enable != "0"){

            strPropertyData += pageItemPartE[propertyObj.enable] + propId + "-" + m
              + '">\n<input type="hidden" name="PAGEITEMPROPERTY.VALUE" value="' + quotchange(valueObj);
          }
        }
      }
    }
    strAllPropertydata += strPropertyData;
  }

  var strAllLiteralPropertyData = "";
  pageItemPartE['0'] = '">\n<input type="hidden" name="PAGEITEMLITERALPROPERTY.PAGEITEMID" value="' + strPageItemId
                     + '">\n<input type="hidden" name="PAGEITEMLITERALPROPERTY.ENABLE" value="0'
                     + '">\n<input type="hidden" name="PAGEITEMLITERALPROPERTY.PROPERTYID" value="';
  pageItemPartE['1'] = '">\n<input type="hidden" name="PAGEITEMLITERALPROPERTY.PAGEITEMID" value="' + strPageItemId
                     + '">\n<input type="hidden" name="PAGEITEMLITERALPROPERTY.ENABLE" value="1'
                     + '">\n<input type="hidden" name="PAGEITEMLITERALPROPERTY.PROPERTYID" value="';
  for (var r in obj.literalProperties){
    var literalObj = obj.literalProperties[r];
    var strLiteralPropertyData = "";
    for (var n in literalObj.langIds){
      if(!savePageVariable_pageItemPartD[n]) {
        savePageVariable_pageItemPartD[n] = '">\n<input type="hidden" name="PAGEITEMLITERALPROPERTY.DISPLANGID" value="' + n
                                          + '">\n<input type="hidden" name="PAGEITEMLITERALPROPERTY.VALUE" value="';
      }

      var ltrlValueObj = literalObj.langIds[n];
      if(!utilSetPageVariable.hasArrayValue(r)) {
        if (ltrlValueObj.value != ""){

          strLiteralPropertyData += pageItemPartE[literalObj.enable] + r + savePageVariable_pageItemPartD[n] + quotchange(ltrlValueObj.value);
        }
      }else{
        for (var p in ltrlValueObj.values){
          if (ltrlValueObj.values[p].value != ""){
            propId = r + "-" + p;
            strLiteralPropertyData += pageItemPartE[literalObj.enable] + propId + savePageVariable_pageItemPartD[n] + quotchange(ltrlValueObj.values[p]);
          }
        }
      }
    }
    strAllLiteralPropertyData += strLiteralPropertyData;
  }
  
  return strPageitemdata + strAllPropertydata + strAllLiteralPropertyData + '">\n';
}

/**
 * page変数からサーバに送る情報を編集
 *   フォーマット：<input type="hidden" name="PAGE.SAMPLE" value="pagesample">
 * 引数    pageobj object
 * 戻り値  pageinfo   : HIDDEN文字列
 */
function createSavingPageData(pageobj){
  //debugger

  var pageinfo = '';
   var strPageMaster = '';

  strPageMaster += makeInput("DELETEKEYS.PAGEID", pageobj.pageId);
  //2003/08/18 timestampValue追加(更新チェック用)
  strPageMaster += makeInput("DELETEKEYS.TIMESTAMPVALUE", pageobj.timestampValue);

  strPageMaster += makeInput("PAGE.PAGEID", pageobj.pageId);
  strPageMaster += makeInput("PAGE.PACKAGEID", pageobj.packageId);
  strPageMaster += makeInput("PAGE.PAGECLASS", pageobj.pageClass);

  var strPageName = "";
  for (var i in pageobj.pageName){
    strPageName += makeInput("PAGENAME.DISPLANGID", i);
    strPageName += makeInput("PAGENAME.PROPERTYID", pageobj.pageName[i].propertyId);
    strPageName += makeInput("PAGENAME.NAMEVALUE", pageobj.pageName[i].value);
  }

  var strState = '';
  strState += makeInput("STATEGROUP.EDITSTATE", pageobj.editStatus);

  for (var i in pageobj.pageItems){
    pageinfo += createPageItemHDinfo(pageobj.pageItems[i]);
  }
  pageinfo = strPageMaster + '\n' + strPageName + '\n' + strState + '\n' + pageinfo + '\n';

  //log.debug('createSavingPageData:\n' + pageinfo);
  
  return pageinfo;
}

/**
 *カスタマイズ可能のオブジェクトのカスタマイズ関連属性だけ出力するため
 *
 *
 *
 */
function CustomInit(pageobj){

  for (var i in pageobj.pageItems){
    var obj = pageobj.pageItems[i];
    if ((!obj.properties['customize-mobility'] || obj.properties['customize-mobility'].value !='enabled' )
       && (!obj.properties['customize-visibility'] || obj.properties['customize-visibility'].value !='enabled')
       && (!obj.properties['customize-maxlines'] || obj.properties['customize-maxlines'].value !='enabled')
       && (!obj.properties['customize-defaultvalue'] || obj.properties['customize-defaultvalue'].value !='enabled')){
      delete pageobj.pageItems[i];
    }else{
      if (obj.properties['customize-mobility'] && obj.properties['customize-mobility'].value =='enabled' ){
        if (obj.properties['row']) {
          obj.properties['row'].customized = '1';
        }

        if (obj.properties['left']) {
          obj.properties['left'].customized = '1';
        }
      }

      if (obj.properties['customize-visibility'] && obj.properties['customize-visibility'].value =='enabled' ){
        if (obj.properties['visibility']) {
          obj.properties['visibility'].customized = '1';
        }
      }

      if (obj.properties['customize-maxlines'] && obj.properties['customize-maxlines'].value =='enabled' ){
         if (obj.properties['maxlines']) {
          obj.properties['maxlines'].customized = '1';
         }
      }

      if (obj.properties['customize-defaultvalue'] && obj.properties['customize-defaultvalue'].value =='enabled' ){
        CustomSetDefaultValue(obj);
      }

      for (var j in obj.properties){
        if(!utilSetPageVariable.hasArrayValue(j)) {
            if ( !obj.properties[j].customized  || obj.properties[j].customized != '1' ){
              delete obj.properties[j];
            }
        }else{
          delete obj.properties[j];
        }

      }
      for (var r in obj.literalProperties){
       if ( !obj.literalProperties[r].customized || obj.literalProperties[r].customized != '1' ){
         delete obj.literalProperties[r];
       }
      }
    }
  }
}

function validateCustomTag(properties, property){
  if(property.tags) {
    for(var i in property.tags) {
      if(properties[i]) {
        properties[i].customized = '1';
      }
    }
  }
}

function CustomSetDefaultValue(obj){
  if (!obj) return ;
  var protype = obj.pageItemTypeId;

  if ((protype == 'text') || (protype == 'password') || (protype == 'textarea')){

     if(obj.literalProperties && obj.literalProperties['text']){
        obj.literalProperties['text'].customized = '1';
        validateCustomTag(obj.properties, obj.literalProperties['text']);
     }else if(obj.properties && obj.properties['text']){
        obj.properties['text'].customized = '1';
        validateCustomTag(obj.properties, obj.properties['text']);
    }

  }

  if ((protype == 'list') || (protype == 'combo') || (protype == 'radio') || (protype == 'hide')){
     if(obj.properties['value']){
        obj.properties['value'].customized = '1';
        validateCustomTag(obj.properties, obj.properties['value']);
    }
  }

  if (protype == 'check'){
     if(obj.properties['selvalue']){
        obj.properties['selvalue'].customized = '1';
        validateCustomTag(obj.properties, obj.properties['selvalue']);
    }
  }
}
/*
 * 概要   page変数からサーバに送る情報を編集   カスタマイズの時
 * フォーマット：<input type="hidden" name="pageobj.pageItemId" value="pagesample">
 * 引数    pageobj
 * 戻り値  pageinfo   : HIDDEN文字列
 */
function createSavingPageDataCustom(pageobj){
  //debugger

  var pageinfo = '';
  var strPageMaster = '';

  strPageMaster += makeInput("DELETEKEYS.PAGEID", pageobj.pageId);
  //2003/08/18 timestampValue追加(更新チェック用)
  strPageMaster += makeInput("DELETEKEYS.TIMESTAMPVALUE", pageobj.timestampValue);

  strPageMaster += makeInput("PAGE.PAGEID", pageobj.pageId);
  strPageMaster += makeInput("PAGE.PACKAGEID", pageobj.packageId);
  strPageMaster += makeInput("PAGE.PAGECLASS", pageobj.pageClass);

  var strPageName = '';
  for (var i in pageobj.pageName){
    strPageName += makeInput("PAGENAME.DISPLANGID", i);
    strPageName += makeInput("PAGENAME.PROPERTYID", pageobj.pageName[i].propertyId);
    strPageName += makeInput("PAGENAME.NAMEVALUE", pageobj.pageName[i].value);
  }

  var strState = '';
  strState += makeInput("STATEGROUP.EDITSTATE", pageobj.editStatus);

  for (var i in pageobj.pageItems){
    var obj = pageobj.pageItems[i];
    var strPageItemId = obj.pageItemId;
    var strPageitemdata = '';

    strPageitemdata += makeInput("CUSTOMPAGELAYOUT.PAGEITEMID", strPageItemId);

    var strAllPropertydata='';
    for (var j in obj.properties){
      var strPropertyData = '';
      var propertyObj = obj.properties[j];

      if(!utilSetPageVariable.hasArrayValue(j)) {
        if ((propertyObj.value != '') || ((j == 'left') ||  (j == 'width')||  (j == 'row') )){
            strPropertyData += makeInput("CUSTOMPAGEITEMPROPERTY.PAGEITEMID", strPageItemId);
            strPropertyData += makeInput("CUSTOMPAGEITEMPROPERTY.PROPERTYID", j);
            strPropertyData += makeInput("CUSTOMPAGEITEMPROPERTY.VALUE", quotchange(propertyObj.value));
        }
      } else {
        for (var m in propertyObj.values){
          if (propertyObj.values[m].indexOf("%tag") > -1) {
            if (propertyObj.values[m].value != ''){
              strPropertyData += makeInput("CUSTOMPAGEITEMPROPERTY.PAGEITEMID", strPageItemId);
              strPropertyData += makeInput("CUSTOMPAGEITEMPROPERTY.PROPERTYID", j + "-" + m);
              strPropertyData += makeInput("CUSTOMPAGEITEMPROPERTY.VALUE", quotchange(propertyObj.values[m]));
            }
          }else{
            if (propertyObj.values[m] != ''){
              strPropertyData += makeInput("CUSTOMPAGEITEMPROPERTY.PAGEITEMID", strPageItemId);
              strPropertyData += makeInput("CUSTOMPAGEITEMPROPERTY.PROPERTYID", j + "-" + m);
              strPropertyData += makeInput("CUSTOMPAGEITEMPROPERTY.VALUE", quotchange(propertyObj.values[m]));
            }
          }
        }
      }
      strAllPropertydata += strPropertyData;
    }

    var strAllLiteralPropertyData = "";
    for (var r in obj.literalProperties){
      var literalObj = obj.literalProperties[r];
      var strLiteralPropertyData = "";
      for (var n in literalObj.langIds){
        if(!utilSetPageVariable.hasArrayValue(r)) {
          if (literalObj.langIds[n].value != ""){
            strLiteralPropertyData += makeInput("CUSTOMPAGEITEMLITERALPROPERTY.PAGEITEMID", strPageItemId);
            strLiteralPropertyData += makeInput("CUSTOMPAGEITEMLITERALPROPERTY.PROPERTYID", r.toLowerCase());
            strLiteralPropertyData += makeInput("CUSTOMPAGEITEMLITERALPROPERTY.DISPLANGID", n);
            strLiteralPropertyData += makeInput("CUSTOMPAGEITEMLITERALPROPERTY.VALUE"
                            , quotchange(literalObj.langIds[n].value));
          }
        }else{
          for (var p in literalObj.langIds[n].values){
            if (literalObj.langIds[n].values[p].value != ""){
              strLiteralPropertyData += makeInput("CUSTOMPAGEITEMLITERALPROPERTY.PAGEITEMID", strPageItemId);
              strLiteralPropertyData += makeInput("CUSTOMPAGEITEMLITERALPROPERTY.PROPERTYID", r.toLowerCase() + "-" + p);
              strLiteralPropertyData += makeInput("CUSTOMPAGEITEMLITERALPROPERTY.DISPLANGID", n);
              strLiteralPropertyData += makeInput("CUSTOMPAGEITEMLITERALPROPERTY.VALUE"
                          , quotchange(literalObj.langIds[n].values[p].value));
            }
          }
        }
      }
      strAllLiteralPropertyData+=strLiteralPropertyData;
    }
   pageinfo += strPageitemdata + strAllPropertydata + strAllLiteralPropertyData + "\n";
  }
  pageinfo = strPageMaster + "\n" + strPageName + "\n" + strState + "\n" + pageinfo + "\n";

  //log.debug('createSavingPageDataCustom:\n' + pageinfo);

  return pageinfo;
}

/**
 * エラーオブジェクト一覧ダイアログ
 * @param  :
 * @return :
 */
function DummyErrorSearchDialogObject(){
  /**
   * 追加されたエラーオブジェクトをクリアする 
   */
  DummyErrorSearchDialogObject.prototype.init = function(){}; //初期化

  /**
   * エラーオブジェクトを追加する 
   */
  DummyErrorSearchDialogObject.prototype.add  = function(_objectId, _fieldId, _errorName){}; //項目追加
}
