/**
 * VwInit
 * 画面ロード
 */
LAST_MODIFIED('2005.02.08', '1.0.33');

//////
//global

/**
 * 編集画面更新ステータス(null:初期値,0:新規,1:更新,2:カスタマイズ) 数値型
 */
var m_monitorEditStatus = null;

/**
 * getPageVariableで作成される読込時のpage変数 オブジェクト
 */
var m_loadPageVariable = null;

/**
 * メニューバー インスタンス
 */
var m_menuBar = null;

/**
 * 項目IDオブジェクト オブジェクト
 * 項目ID有無の属性値 ブール値 true：無し false：有り
 */
var m_itemDefinitionObject = new Object();
    m_itemDefinitionObject.empty = true;

/**
 * 画面ID 文字型
 */
var m_monitorId = '';

/**
 * 画面名称 文字型
 */
var m_moitorName = '';

/**
 * ページのプロパティID 文字型
 */
var m_monitorPropertyId = '';

/**
 * モード名称 文字型
 */
var m_monitorModeString = '';

/**
 * ユーザー定義カラーパレット保存変数 配列
 */
var m_userColors = new Array();

/**
 * スレッドID 文字型
 */
var m_threadId = '';

/**
 *  ページタイプ 0:通常のページ／ 1:フレーム
 */
var m_pageClass = '0';

/**
 *  undo/redo管理
 */
var m_undoManager = new UndoManager(pref.operation.get('maxundo'));

/**
 * プロパティテーブルの幅 数値型
 */
var m_propTblWidth;

//////
//function

/**
 * body-onloadで実行される画面初期化処理
 * @param  :
 * @return :
 */
function init() {

  //
  window.status = getMessage('S0003');

  document.body.onunload = funcOnUnload;

  //バッファリング
  addImageFileBuffer(IMAGEURL_APPLET);
  addImageFileBuffer(IMAGEURL_OBJECT);
  addImageFileBuffer(IMAGEURL_EMBED);
  addImageFileBuffer(IMAGEURL_COMBO);
  addImageFileBuffer(IMAGEURL_IMAGE);
  addImageFileBuffer(IMAGEURL_IMAGETP);
  addImageFileBuffer(IMAGEURL_COLORTIPBG);
  addImageFileBuffer(IMAGEURL_NEW);
  addImageFileBuffer(IMAGEURL_OPEN);
  addImageFileBuffer(IMAGEURL_SAVE);
  addImageFileBuffer(IMAGEURL_CUT);
  addImageFileBuffer(IMAGEURL_COPY);
  addImageFileBuffer(IMAGEURL_PASTE);
  addImageFileBuffer(IMAGEURL_CLEAR);
  addImageFileBuffer(IMAGEURL_ADD);
  addImageFileBuffer(IMAGEURL_DISABLEDNEW);
  addImageFileBuffer(IMAGEURL_DISABLEDOPEN);
  addImageFileBuffer(IMAGEURL_DISABLEDSAVE);
  addImageFileBuffer(IMAGEURL_DISABLEDCUT);
  addImageFileBuffer(IMAGEURL_DISABLEDCOPY);
  addImageFileBuffer(IMAGEURL_DISABLEDPASTE);
  addImageFileBuffer(IMAGEURL_DISABLEDCLEAR);
  addImageFileBuffer(IMAGEURL_DISABLEDADD);

  // 保存中のフォーカス
  window.onfocus = funcOnFocus; 

  //データ部分非表示
  var formdata = getDocumentElementById('PAGEDATA');
  formdata.style.visibility = 'hidden';

  //画面オブジェクト作成
  monitor = new objMonitor('FORMSCREEN');
  monitor.init();

  // undo,redo時のメニューの状態を変更するメソッドをバインド
  m_undoManager.stateChanged = undoStateChanged;

  //ウィンドウ制御
  ctrlWindow();

  //propertyエリアのスタイル指定
  var tmpPropNodeStyle = getDocumentElementById('fld_property_tbl').style;
  tmpPropNodeStyle.borderTop = '1pt solid white';
  tmpPropNodeStyle.borderRight = '1pt solid black';
  tmpPropNodeStyle.borderBottom = '1pt solid black';
  tmpPropNodeStyle.borderLeft = '1pt solid white';
  tmpPropNodeStyle.fontSize = '8pt';

  //page変数作成
  var page = null;
  try{
    page = getPageVariable();
    
    m_pageClass = page.pageClass;
  }catch(e){
    var errMessageArray = new Array('VwInit.js','init',getMessage('A0001'),'getPageVariable()');
    printHandlingError(e, errMessageArray);
    return;
  }

  m_loadPageVariable = page;
  var pageStatus;
  try{
    pageStatus = page.editStatus;
  }catch(e){
    pageStatus = '';
  }

  if(page.fieldIdSourceClass == '1') {

    m_itemDefinitionObject.empty = false;
    m_itemDefinitionObject.itemDefine = page.fieldIdSource;
    replaceItemDefinitionList(page.fields);
  }

  //ThredId取得
  m_threadId = getSessionData('THREADID');

  if(m_pageClass == '1') {

    // フレームのとき使用しないメニュー
    m_menuBar.lockMenuItem('FILE', 'LOADFIELDS');
    m_menuBar.lockMenuItem('EDIT','CUT');
    m_menuBar.lockMenuItem('EDIT','COPY');
    m_menuBar.lockMenuItem('EDIT','PASTE');
    m_menuBar.lockMenuItem('EDIT','DELETE');
    m_menuBar.lockMenuItem('EDIT','SELECTALL');
    m_menuBar.lockMenuItem('EDIT','ADD');
    
    // 検索処理呼び出しにフレーム用の処理をバインド
    doCommandFind = doCommandFind_frame;

    // 保存処理呼び出しにフレーム用の処理をバインド
    doCommandSave = doCommandSave_frame;

    // 新規保存処理呼び出しにフレーム用の処理をバインド
    doCommandSaveAs = doCommandSaveAs_frame;

    // 属性値更新時にイベントハンドラから呼ばれる関数を設定
    onChangeProperty = onChangeProperty_frame;

    // 属性値更新時に setPropertyされるオブジェクト
    addDataSet(ELEMENTID_FIRSTFORM, new FramePageDataSet());
    m_selection.front = ELEMENTID_FIRSTFORM;

  }

  if(parseInt(pageStatus) == 0){
    //新規編集時
    m_monitorEditStatus = 0;
    //画面表示文字列
    m_monitorId         = '';
    m_moitorName        = '';
    m_monitorModeString = getLiteral('editormode.new');

    if(m_pageClass == '0') {
      //新規編集画面準備処理
      createNewMonitorData();
    } else if(m_pageClass == '1') {
      //フレーム新規
      loadFrameData(page);
    }

  }else if(parseInt(pageStatus) == 1 || parseInt(pageStatus) == 2){

    //読込編集時、カスタマイズ編集時
    if(parseInt(pageStatus) == 1){
      m_monitorEditStatus = 1;
      m_monitorModeString = getLiteral('editormode.edit');

    }else{
      
      m_monitorEditStatus = 2;
      m_monitorModeString = getLiteral('editormode.customize');

      // カスタマイズのとき使用しないメニュー
      m_menuBar.lockMenuItem('FILE','NEW');
      m_menuBar.lockMenuItem('FILE', 'SAVEAS');
      m_menuBar.lockMenuItem('FILE', 'LOADFIELDS');

      m_menuBar.lockMenuItem('EDIT','CUT');
      m_menuBar.lockMenuItem('EDIT','COPY');
      m_menuBar.lockMenuItem('EDIT','PASTE');
      m_menuBar.lockMenuItem('EDIT','DELETE');
      m_menuBar.lockMenuItem('EDIT','SELECTALL');
      m_menuBar.lockMenuItem('EDIT','ADD');
  
      // 属性欄はカスタマイズ用表示  
      pref.editarea = pref.customize;
      
    }
    //画面表示文字列
    m_monitorId           = page.pageId;
    m_moitorName = '';
    m_monitorPropertyId = '';
    for(var i in page.pageName){
      m_moitorName        = page.pageName[i].value;
      m_monitorPropertyId = page.pageName[i].propertyId;
      break;
    }
    
    //カスタマイズ時にpageIdが取得できない時はページ選択ダイアログに遷移
    if(parseInt(pageStatus) == 2 && page.pageId.length == 0){
      doCommandOpen();
    } else {
    
      //読込処理
      //try{
        if(m_pageClass == '0') {
          loadPageData(page);

        } else if(m_pageClass == '1') {
          //フレーム
          loadFrameData(page);
        }
      //}catch(e){
        //読込エラー
        //var errMessageArray = new Array('VwInit.js','init',getMessage('A0002'),'loadPageData()');
        //printHandlingError(e, errMessageArray);
        //return;
      //}
    }
  }else{
    //初期時
    m_monitorEditStatus = null;
  }
  
  //画面のステータス表示
  setPropertyMonitorStatus(m_monitorId, m_moitorName, m_monitorModeString);

  // 2003.09.22
  if(m_pageClass == '0') {

    //editエリアにイベント設定
    setMouseEvent();

    //log.debug('updating property area. [VwInit.js/init]');
    m_selection.updatePropertyArea();
  

  } else {

    //キーイベント設定
    //getDocumentElementById(ELEMENTID_FIRSTFORM).onkeydown = funcOnKeyDown;

    var body = document.body;
    if(body) {
      body.onkeydown = funcOnKeyDown;
      body.onselectstart = function() {return false};
      body.style.cursor = 'default';
    }    
  }

  // プロパティ変更時に保存が使えるようにする
  getDefaultDataSetEventHandler().propertyChanged = function(elementid, propertyid) {
    m_menuBar.enableSave();
  };

  //ステータスバー初期化
  window.status = '';

  //FORMにFORCUS設定
  if(m_monitorEditStatus != 2){
    itemFocusSetter(ELEMENTID_FIRSTFORM);
  }
}

/**
 * onunload
 */
function funcOnUnload() {
/*
  if(m_menuBar.documentDirty) {
    //保存確認
  }
*/
}

/**
 * 保存中のフォーカス制御
 */
function funcOnFocus() {
  if(window.saveObject && window.saveObject.savingMessage) {
    window.saveObject.savingMessage.focus();
  }
}

/**
 * ウィンドウ制御
 * @param  :
 * @return :
 */
function ctrlWindow(){
  document.body.style.margin = '0';
  /*
  var monitorWidth = window.screen.width;
  var monitorHeight = window.screen.height - 27;
  window.resizeTo(monitorWidth,monitorHeight);
  window.moveTo(0,0);
  */
}

/**
 * 画面の状態表示
 * @param  :strId   文字型  画面ID文字列
 *          strName 文字型  画面名称文字列
 *          strMode 文字型  モード文字列
 * @return :
 */
function setPropertyMonitorStatus(strId, strName, strMode){
  //getDocumentElementById('fld_monitorId').innerHTML   = strId;
  //getDocumentElementById('fld_monitorName').innerHTML = strName;
  //getDocumentElementById('fld_modeName').innerHTML    = strMode;
  
  getDocumentElementById('fld_monitorId').value   = strId;
  getDocumentElementById('fld_monitorName').value = strName;
  getDocumentElementById('fld_modeName').value    = strMode;
  
  if(strId != '') {
    document.title = 'ViewEditor(' + strId + ')';
  } else {
    document.title = 'ViewEditor';
  }

  if(m_monitorEditStatus == 0) {
    m_menuBar.enableSave();
    m_menuBar.enableMenuItem('FILE', 'SAVEAS');
    m_menuBar.enableMenuItem('EDIT', 'ADD');
    m_menuBar.disableMenuItem('FILE', 'PREVIEW');
    
  } else if(m_monitorEditStatus == 1) {
    m_menuBar.enableMenuItem('FILE', 'SAVEAS');
    m_menuBar.enableMenuItem('FILE', 'PREVIEW');
    m_menuBar.enableMenuItem('EDIT', 'ADD');
    m_menuBar.disableSave();
    m_undoManager.justSaved();
  } else if(m_monitorEditStatus == 2) {
    m_menuBar.enableMenuItem('FILE', 'PREVIEW');
    m_menuBar.disableSave();
    m_undoManager.justSaved();
  }
}

/**
 * submit用formクリア
 * @param  :
 * @return :
 */
function clearSubmitForm(){
  getDocumentElementById('NEWPAGE').innerHTML = '';
}

/**
 * submit用form設定
 * @param  :strHtml 文字型 フォームにセットするHTML文字列
 * @return :
 */
function appendSubmitForm(strHtml){
  getDocumentElementById('NEWPAGE').innerHTML = strHtml;
}

if(m_browserType.gecko && 20040000 < m_browserType.gecko) {

  // プロパティ表示領域の配置情報
  var m_propertyLocation = new LocationProperties(0, 0, 224, pref.env.baseheight);

  // レイアウト表示領域の配置情報
  var m_editorLocation = new LocationProperties(0, 224, pref.init.form.pagewidth, pref.init.form.pageheight);

} else {

  // プロパティ表示領域の配置情報
  var m_propertyLocation = new LocationProperties(0, 0, 220, pref.env.baseheight);

  // レイアウト表示領域の配置情報
  var m_editorLocation = new LocationProperties(0, 220, pref.init.form.pagewidth, pref.init.form.pageheight);
}

/**
 * 配置情報
 */
function LocationProperties(top,left,width,height) {
  this.top = top;
  this.left = left;
  this.width = width;
  this.height = height;
  
  LocationProperties.prototype.w = function (offset) {
    return minusToZero(this.width + offset);
  }
  
  LocationProperties.prototype.h = function (offset) {
    return minusToZero(this.height + offset);
  }
  
  function minusToZero(num) {
    if(num < 0) return 0;
    return num;
  }
}

//////
//class

/**
 * 画面全体のHTMLを作成
 * @param  :objId 文字型 画面作成用FORM ID
 * @return :
 */
function objMonitor(objId){
  //@:property
  this.id      = objId;
  this.element = getDocumentElementById(objId);

  //@:public method
  objMonitor.prototype.init       = fnInit;

  function fnInit(){
    //編集画面作成
    this.element.innerHTML = createTableBegin() + createPropertyHtml() + createTableEnd() + createEditHtml();

    // メニューバー、ツールバー作成
    m_menuBar = createMenuBar();


    if(m_browserType.isNN) {
      m_menuBar.useSetTimeout('m_menuBar');
    }

    //プロパティテーブルの幅を保持
    m_propTblWidth = getDocumentElementById('fld_property_tbl').offsetWidth;

  }

  //@:private method
  function createTableBegin(){
    return '<TABLE border="0" cellpadding="0" cellspacing="0" style="margin:0px;" width="220px"><TR><TD valign="top">';
  }

  function createPropertyHtml(){

    var menuclassname = '';
    var menustyle = '';
    if(pref.env.menucolor) {
      menustyle = 'background-color:' + pref.env.menucolor + ';'
    } else {
      menuclassname = CLASSNAME_BASEBACKGROUNDCOLOR;
    }

    var menubarHTML = '<div id="DIV_MENUBAR" class="' + menuclassname + '" style="' + menustyle + 'position:absolute; top:' 
        + (m_propertyLocation.top + 1)
        + 'px; left:' + (m_propertyLocation.left + 2) 
        + 'px; z-index:100000;" onkeydown="funcOnKeyDown(event);"></div>';

    var toolbarHTML = '<div id="DIV_TOOLBAR" class="' + menuclassname + '" style="' + menustyle + 'position:absolute; top:' 
        + (m_propertyLocation.top + 27) 
        + 'px; left:' + (m_propertyLocation.left + 2) 
        + 'px;" onmousedown="m_menuBar.close();" onkeydown="funcOnKeyDown(event);"></div>';
    
    var bgclassname = '';
    var borderclassname = '';
    var bgstyle = '';
    var borderstyle = '';
    if(pref.env.basecolor) {
      bgstyle = 'background-color:' + pref.env.basecolor + ';'
      borderstyle = 'border-color:' + pref.env.basecolor + ';'
    } else {
      bgclassname = CLASSNAME_BASEBACKGROUNDCOLOR;
      borderclassname = CLASSNAME_BASEBORDERCOLOR;
    }

    var rtnHTML = '<div class="' +  bgclassname
        + '" id="fld_property_tbl" style="' + bgstyle + 'width:' + m_propertyLocation.width 
        + 'px; height:' + m_propertyLocation.height 
        + 'px; font-size: 8pt;cursor:default;" onmousedown="m_menuBar.close();">'
        +  '<br>'
        +  '<div onkeydown="funcOnKeyDown(event);" class="' + borderclassname + '"'
        +      ' style="' + borderstyle + 'overflow:hidden;position:absolute;top:60;left:3;width:' + m_propertyLocation.w(-10) + ';height:54;border-style:solid;border-width:1px;">'
        +    '<table border="0" cellpadding="0" cellspacing="0" width="210" style="font-size: 8pt;">'
        +     '<tr><td width="2"></td><td width="50" height="18" style="font-size: 8pt;"><nobr>' + getLiteral('editor.pageid')     + '</nobr></td><td width="8" align="center" valign="top">:</td><td width="150" valign="bottom"><input id="fld_monitorId"   value="" style="width:150;height:16;border:none;background-color:transparent;font-size:8pt;font-family:serif;" readonly onselectstart="onSelectStartEnableSelect(event)" onkeydown="funcOnKeyDown(event,\'selectcopy\');"></td></tr>'
        +     '<tr><td width="2"></td><td width="50" height="18" style="font-size: 8pt;"><nobr>' + getLiteral('editor.pagename')   + '</nobr></td><td width="8" align="center" valign="top">:</td><td width="150" valign="bottom"><input id="fld_monitorName" value="" style="width:150;height:16;border:none;background-color:transparent;font-size:8pt;font-family:serif;" readonly onselectstart="onSelectStartEnableSelect(event)" onkeydown="funcOnKeyDown(event,\'selectcopy\');"></td></tr>'
        +     '<tr><td width="2"></td><td width="50" height="18" style="font-size: 8pt;"><nobr>' + getLiteral('editor.editormode') + '</nobr></td><td width="8" align="center" valign="top">:</td><td width="150" valign="bottom"><input id="fld_modeName"    value="" style="width:150;height:16;border:none;background-color:transparent;font-size:8pt;font-family:serif;cursor:default;" readonly></td></tr>'
        +    '</table>'
        +  '</div>'
        +  '<div style="position:absolute;top:105;left:0;width:' + m_propertyLocation.w(-2) + ';overflow:hidden;" onkeydown="funcOnKeyDown(event,\'property\');">'
        +    '<table>'
        +      '<tr><td id="fld_property_head_td"valign="bottom" style="font-size: 8pt;"><nobr>' + getLiteral('propertyarea.caption') + '</nobr></td><td width="100" align="right" height="40px"></td></tr>'
        +    '</table>'
        +    '<div style="position:relative;width:' + m_propertyLocation.w(-2) + 'px; height:' + m_propertyLocation.h(-150) + 'px; overflow:auto; overflow-x:hidden;">'
        +      '<div id="fld_showPropertyTable_div" style="width:200px;"></div>'
        +      '<div id="fld_showPropertyTable_div_type" style="width:200px;"></div>'
        +    '</div>'
        +  '</div>'
        + '</div>';

    return rtnHTML + menubarHTML + toolbarHTML;
  }

  function createTableEnd(){
    return '</TD></TR></TABLE>';
  }

  function createEditHtml(){
    var rtnHTML;
    if(m_browserType.isIE) {
      rtnHTML  = '<table cellspacing="0" cellpadding="0" style="margin:0px; padding:0px;position:absolute; top:' 
          + m_editorLocation.top + 'px; left:' 
          + m_editorLocation.left 
          + 'px; z-index:1;"><tr><td>'
          + '<div style="margin:0px; padding:0px; border:1px black solid;position:relative;top:0px;left:0px;width:' 
          + m_editorLocation.width + 'px; height:'
          + m_editorLocation.height + 'px;"  id="' + ELEMENTID_FIRSTFORM + '"></div></td><td width="10px">&nbsp;</td></tr>' 
          + '</table>';

    } else {
      rtnHTML  = '<div style="margin:0px 4px 0px 4px; padding:0px; border:1px black solid;position:absolute; width:' 
          + m_editorLocation.width + 'px; height:' 
          + m_editorLocation.height + 'px; top:' 
          + m_editorLocation.top + 'px; left:' 
          + m_editorLocation.left 
          + 'px; background-color:white; z-index:1;" id="' + ELEMENTID_FIRSTFORM + '"></div>';
    }
    return rtnHTML;
  }

  function ifIE(prmIE, prmNN) {
    if(navigator.appName == 'Microsoft Internet Explorer'){
      return prmIE;
    }
    return prmNN;
  }

  function createMenuBar() {

    var fileMenu = new VwMenu('FILE', getLiteral('menuitem.file'));
    fileMenu.addMenuItem(new VwMenuItem('NEW',  getLiteral('menuitem.new') + '...',   ifIE('Ctrl+N','')));
    fileMenu.addMenuItem(new VwMenuItem('OPEN', getLiteral('menuitem.open') + '...',  ifIE('Ctrl+O','')));
    fileMenu.addSeparator();
    fileMenu.addMenuItem(new VwMenuItem('SAVE',   getLiteral('menuitem.save'),        ifIE('Ctrl+S','')));
    fileMenu.addMenuItem(new VwMenuItem('SAVEAS', getLiteral('menuitem.saveas') + '...'));
    fileMenu.addSeparator();
    fileMenu.addMenuItem(new VwMenuItem('LOADFIELDS', getLiteral('menuitem.loadfields') + '...'));
    fileMenu.addMenuItem(new VwMenuItem('PREVIEWSETTINGS', getLiteral('menuitem.previewsettings') + '...'));
    fileMenu.addMenuItem(new VwMenuItem('PREVIEW', getLiteral('menuitem.preview')));

    var editMenu = new VwMenu('EDIT', getLiteral('menuitem.edit'));
    if(pref.operation.get('maxundo') != 0) {
      editMenu.addMenuItem(new VwMenuItem('UNDO',     getLiteral('menuitem.undo'), ifIE('Ctrl+Z','')));
      editMenu.addMenuItem(new VwMenuItem('REDO',     getLiteral('menuitem.redo'), ifIE('Ctrl+Y','')));
      editMenu.addSeparator();
    }
    editMenu.addMenuItem(new VwMenuItem('CUT',     getLiteral('menuitem.cut'),    ifIE('Ctrl+X','')));
    editMenu.addMenuItem(new VwMenuItem('COPY',    getLiteral('menuitem.copy'),   ifIE('Ctrl+C','')));
    editMenu.addMenuItem(new VwMenuItem('PASTE',   getLiteral('menuitem.paste'),  ifIE('Ctrl+V','')));
    editMenu.addMenuItem(new VwMenuItem('DELETE',  getLiteral('menuitem.delete'), ifIE('Delete','')));
    editMenu.addMenuItem(new VwMenuItem('SELECTALL',  getLiteral('menuitem.selectall'), ifIE('Ctrl+A','')));
    editMenu.addSeparator();
    editMenu.addMenuItem(new VwMenuItem('ADD', getLiteral('menuitem.add') + '...'));
    editMenu.addSeparator();
    editMenu.addMenuItem(new VwMenuItem('SEARCH', getLiteral('menuitem.find') + '...', ifIE('Ctrl+F','')));
    //editMenu.addSeparator();
    //editMenu.addMenuItem(new VwMenuItem('SELECTALL', 'すべて選択'));

    var helpMenu = new VwMenu('HELP', getLiteral('menuitem.help'));
    helpMenu.addMenuItem(new VwMenuItem('VERSION',     getLiteral('menuitem.versioninfo') + '...'));

    var menuBar =  new VwMenuBar('DIV_MENUBAR');
    menuBar.setListener(new MenuItemListener());

    menuBar.addMenu(fileMenu, 10);
    menuBar.addMenu(editMenu, 60);
    menuBar.addMenu(helpMenu, 100);

    menuBar.width = m_propertyLocation.w(-4);

    var menuItemColor = '';
    if(pref.env.menucolor) {
      menuItemColor = pref.env.menucolor;
    } else {
      var className = CLASSNAME_BASEBACKGROUNDCOLOR + ' ' + CLASSNAME_BASEBORDERCOLOR;
      fileMenu.className = className;
      editMenu.className = className;
      helpMenu.className = className;
    }
    if(pref.env.menubarcolor) {
      menuBar.color = pref.env.menubarcolor;
    } else if(pref.env.basecolor) {
      menuBar.color = pref.env.basecolor;
    }
    
    fileMenu.color = menuItemColor;
    editMenu.color = menuItemColor;
    helpMenu.color = menuItemColor;
    
    fileMenu.activeColor = '#666666';
    editMenu.activeColor = '#666666';
    helpMenu.activeColor = '#666666';
    
    var toolbar = new VwToolBar('DIV_TOOLBAR');
    toolbar.addToolIcon(new VwToolIcon('FILE','NEW',  IMAGEURL_NEW,  getLiteral('menuitem.new'),       IMAGEURL_DISABLEDNEW));
    toolbar.addToolIcon(new VwToolIcon('FILE','OPEN', IMAGEURL_OPEN, getLiteral('menuitem.open'),      IMAGEURL_DISABLEDOPEN));
    toolbar.addToolIcon(new VwToolIcon('FILE','SAVE', IMAGEURL_SAVE, getLiteral('menuitem.save'),      IMAGEURL_DISABLEDSAVE));
    toolbar.addSeparator();
    toolbar.addToolIcon(new VwToolIcon('EDIT','CUT',    IMAGEURL_CUT,   getLiteral('menuitem.cut'),    IMAGEURL_DISABLEDCUT));
    toolbar.addToolIcon(new VwToolIcon('EDIT','COPY',   IMAGEURL_COPY,  getLiteral('menuitem.copy'),   IMAGEURL_DISABLEDCOPY));
    toolbar.addToolIcon(new VwToolIcon('EDIT','PASTE',  IMAGEURL_PASTE, getLiteral('menuitem.paste'),  IMAGEURL_DISABLEDPASTE));
    toolbar.addToolIcon(new VwToolIcon('EDIT','DELETE', IMAGEURL_CLEAR, getLiteral('menuitem.delete'), IMAGEURL_DISABLEDCLEAR));
    toolbar.addToolIcon(new VwToolIcon('EDIT','ADD',    IMAGEURL_ADD,   getLiteral('menuitem.add'),    IMAGEURL_DISABLEDADD));
    toolbar.setListener(menuBar.listener);
    toolbar.width = menuBar.width;
    toolbar.color = menuBar.color;
    toolbar.className = menuBar.className;

    menuBar.toolBar = toolbar;
    menuBar.disableMenuItem('EDIT','UNDO');
    menuBar.disableMenuItem('EDIT','REDO');
    menuBar.disableMenuItem('EDIT','CUT');
    menuBar.disableMenuItem('EDIT','COPY');
    if(!canUseSystemClipboard()) {
      menuBar.disableMenuItem('EDIT','PASTE');
    }
    menuBar.disableMenuItem('EDIT','DELETE');
    menuBar.show();
    toolbar.show();

    return menuBar;
  }
  
  /**
   *  メニューバーとツールバーのイベント処理
   */
  function MenuItemListener() {
    MenuItemListener.prototype.keyDown = function(_event) {
      return funcOnKeyDown(_event);
    }
    MenuItemListener.prototype.action = function(menuId, menuItemId) {
      if(menuId == 'FILE') {
        if(menuItemId == 'NEW') {
          doCommandNew();
        } else if(menuItemId == 'OPEN') {
          doCommandOpen();
        } else if(menuItemId == 'SAVE') {
          doCommandSave();
        } else if(menuItemId == 'SAVEAS') {
          doCommandSaveAs();
        } else if(menuItemId == 'LOADFIELDS') {
          doCommandLoadFields();
        } else if(menuItemId == 'PREVIEW') {
          doCommandPreview()
        } else if(menuItemId == 'PREVIEWSETTINGS') {
          doCommandPreviewSettings()
        }
       
      } else if(menuId == 'EDIT') {
        if(menuItemId == 'UNDO') {
          doCommandUndo();
        } else if(menuItemId == 'REDO') {
          doCommandRedo();
        } else if(menuItemId == 'CUT') {
          doCommandCut();
        } else if(menuItemId == 'COPY') {
          doCommandCopy();
        } else if(menuItemId == 'PASTE') {
          doCommandPaste();
        } else if(menuItemId == 'DELETE') {
          doCommandDelete();
        } else if(menuItemId == 'ADD') {
          doCommandAdd();
        } else if(menuItemId == 'SEARCH') {
          doCommandFind();
        } else if(menuItemId == 'SELECTALL') {
          doCommandSelectAll();
        } 
      } else if(menuId == 'HELP') {
        if(menuItemId == 'VERSION') {
          openVersionDialog(m_versionInfo);
        }
      }
    }
  }
}

/**
 * 新規に画面作成時の初期化処理
 * @param  :
 * @return :
 */
function createNewMonitorData(){
  //トップレベルのFORMのIDを保存
  m_addElementArray[m_addElementArray.length] = ELEMENTID_FIRSTFORM;

  //トップレベルのFORM-DataSet作成
  //DataSet作成
  var ds = createDataSet(ELEMENTID_FIRSTFORM, 'form');

  //デフォルトプロパティをセット
  initDataSetByType(ds);

  // 背景色・背景画像・スタイルを表示に反映
  initFormByDataSet(ds);
}

/**
 * ロードデータのpage変数から画面作成
 * @param  :page オブジェクト getPageVariableの戻り値
 * @return :
 */
function loadPageData(page){
  // window.status 表示用のカウント
  var pageItemCount = 0;
  var pageItemMax = 0;
  var msg = getMessage('S0002');
  //log.open();
  for(var i in page.pageItems){
    //log.debug(new DescriptionObject(page.pageItems[i], i, 4));
    pageItemMax++;
  }

  //編集画面にインサートするHTML文字列
  var strInsertHtml = '';

  //page.pageItem数、全page.pageItemを取り出す
  //FORM,TABLE,PANEL読込
  // 2003/04/16 読込用ループを１回に修正
  for(var i in page.pageItems){
    pageItemCount++;
    window.status = msg + '(' + pageItemCount + '/' + pageItemMax + ')';
    var tmpAddId = getPageItem(page.pageItems[i], page);
    //FORM(page)以外のHTML文字列作成
    if(tmpAddId != ''){
      strInsertHtml += getElementHtml(getDataSet(tmpAddId));
    }
  }

  //編集画面にインサート
  getDocumentElementById(ELEMENTID_FIRSTFORM).innerHTML = strInsertHtml;

  //画面生成後z-indexの調整
  for(var i in page.pageItems){
    checkZindex(page.pageItems[i]);
  }

  //ステータスバークリア
  window.status = '';
}

/**
 * pageItem毎のデータを取得しセット
 * @param  :objPageItem オブジェクト page.pageItems１ノード
 * @return :
 * @todo   :カスタマイズ時の特殊属性をobjDataSetにセット
 */
function getPageItem(objPageItem, page){

  //tableセル対応
  if(objPageItem.pageItemTypeId == 'panel'){
    if(objPageItem.parentPageItemTypeId == 'table'){
      //CELLは別途作成する
      return '';
    }
  }

  //トップレベルのFORM時、IDを定数に変換
  if(objPageItem.parentPageItemId.length == 0){
    var formId = objPageItem.pageItemId;
    var workId = ELEMENTID_FIRSTFORM;
    var typeId = TYPE.FORM;
    var workName = '';
  
    // タイプの情報を作成しておく
    getTypeInfoDef(typeId);
  
  }else{
    var formId = '';
    var workId = objPageItem.pageItemId;
    var typeId = toTypeCase(objPageItem.pageItemTypeId);
    var workName = getLoadDataProperty(objPageItem, 'name');
  }
  
  
  //DataSet作成
  var objDS = createDataSet(workId, typeId, workName);

  //追加したIDを保存
  m_addElementArray[m_addElementArray.length] = workId;

  //プロパティを取得しDataSetにセット
  //ページ用プロパティ
  if(workId == ELEMENTID_FIRSTFORM){

    // @@
    objDS.setProperty('originalitemid', formId);

    //page(トップレベルのFORM)にサイズが設定されていない時対応
    try{
      var tmpSize = getLoadDataProperty(objPageItem, 'height');
    }catch(e){
      var tmpSize = '';
    }
    if(tmpSize == ''){
      try{
        tmpSize = getLoadDataProperty(objPageItem, 'rows') * DISPLAYROWHEIGHT;
      }catch(e){
        tmpSize = 600;
      }
    }
    objDS.setProperty('pageheight', tmpSize);

    var tmpSize = getLoadDataProperty(objPageItem, 'width');
    if(tmpSize == ''){
      
      //tmpSize = 800;
      if(!objPageItem.properties.width) {
        objPageItem.properties.width = {value:pref.init.form.pagewidth};
      } else {
        objPageItem.properties.width.value = pref.init.form.pagewidth;
      }
    }

    var tmpMethod = getLoadDataProperty(objPageItem, 'method');
    if(tmpMethod != ''){
      
      if(!objPageItem.properties.method) {
        objPageItem.properties.method = {value:tmpMethod};
      } else {
        objPageItem.properties.method.value = tmpMethod;
      }
    }
    
    for(var i in objPageItem.properties){
      //プロパティ変換
      var convertedProperty = convertToViewEditorPropertyId(i, objPageItem.pageItemTypeId);
      if(isArrayValue(convertedProperty)){

        objDS.setProperty(convertedProperty, objPageItem.properties[i].values);
      }else{
        objDS.setProperty(convertedProperty, getLoadDataProperty(objPageItem, i));
      }
    }
    
    //画面反映
    initFormByDataSet(objDS);
    
  }else{

    //共通プロパティ(トップレベルのFORM以外)
    objDS.setProperty('top', getLoadDataProperty(objPageItem, 'top'));
    objDS.setProperty('left', getLoadDataProperty(objPageItem, 'left'));

    objDS.setProperty('originalparentitemid', objPageItem.parentPageItemId);

    for(var i in objPageItem.properties){
      //プロパティ変換
      var convertedProperty = convertToViewEditorPropertyId(i, objPageItem.pageItemTypeId);
      if(isArrayValue(convertedProperty)){

        objDS.setProperty(convertedProperty, objPageItem.properties[i].values);
      }else{
        objDS.setProperty(convertedProperty, getLoadDataProperty(objPageItem, i));

        // 2003.05.20 通常編集時：カスタマイズ属性の読み込みデータをoriginalvalueに保存しておく(削除時のダイアログ選択で使用)
        if(m_monitorEditStatus != 2){
          if(i == 'customize-visibility'   || 
             i == 'customize-mobility'     || 
             i == 'customize-defaultvalue' || 
             i == 'customize-maxlines'){
            var tmpCustomOrgValue = getLoadDataProperty(objPageItem, i);
            objDS.setCustomProperty(convertedProperty, 'originalvalue', tmpCustomOrgValue);
          }
        }

        //カスタマイズ時、カスタマイズデータ読込(customized, customizable, originalValue)
        if(m_monitorEditStatus == 2){
          try{
            var tmpCustomized = objPageItem.properties[i].customized;
            if(!tmpCustomized) tmpCustomized = false;
          }catch(e){
            var tmpCustomized = false;
          }
          try{
            var tmpCustomizable = objPageItem.properties[i].customizable;
            if(!tmpCustomizable) tmpCustomizable = false;
          }catch(e){
            var tmpCustomizable = false;
          }
          try{
            var tmpOriginalvalue = objPageItem.properties[i].originalValue;
            //2003/04/11 プロパティ値が数値のゼロ時、ブランクに置き換わっていたバグを対処
            if(tmpOriginalvalue == 0) tmpOriginalvalue = tmpOriginalvalue.toString();
            if(!tmpOriginalvalue) tmpOriginalvalue = '';
          }catch(e){
            var tmpOriginalvalue = '';
          }
          objDS.setCustomProperty(convertedProperty, 'customized', tmpCustomized);
          objDS.setCustomProperty(convertedProperty, 'customizable', tmpCustomizable);
          objDS.setCustomProperty(convertedProperty, 'originalvalue', tmpOriginalvalue);
        }
      }
    }
    //visibilityを付加(上書き)
    if(objPageItem.pageItemTypeId != 'hide'){
      var tmpVisibility = getLoadDataProperty(objPageItem, 'visibility');
      // @visible if(tmpVisibility == '') tmpVisibility = 'visible';
      objDS.setProperty('visibility', tmpVisibility);
    }

    //カスタマイズ属性設定(登録データ無時はdisabled)
    //カスタマイズ時は読込の時点では全てdisabled
    var tmpObjType = getCustomizeInfo(toTypeCase(objPageItem.pageItemTypeId));
    var customProp = tmpObjType.customProperties;
    if(m_monitorEditStatus != 2){
      for(var j=0; j<customProp.length; j++){
        var tmpCustomProp = getLoadDataProperty(objPageItem, customProp[j]);
        if(tmpCustomProp == '') tmpCustomProp = 'disabled';
        objDS.setProperty(customProp[j], tmpCustomProp);
      }
    }else{
      for(var j=0; j<customProp.length; j++){
        //visibility
        if(customProp[j] == 'customize-visibility'){
          var tmpCurVisibility = objDS.getProperty('visibility');
          // @visible if(tmpCurVisibility == '') tmpCurVisibility = 'visible';
          var tmpOrgVisibility = objDS.getCustomProperty('visibility', 'originalvalue');
          // @visible if(tmpOrgVisibility == '') tmpOrgVisibility = 'visible';

          if(tmpCurVisibility != tmpOrgVisibility){
            objDS.setProperty(customProp[j], 'enabled');
          }else{
            objDS.setProperty(customProp[j], 'disabled');
          }
        }
        //mobility
        if(customProp[j] == 'customize-mobility'){
          if(objDS.getProperty('top') != objDS.getCustomProperty('top', 'originalvalue') || 
             objDS.getProperty('left') != objDS.getCustomProperty('left', 'originalvalue')){
            objDS.setProperty(customProp[j], 'enabled');
          }else{
            objDS.setProperty(customProp[j], 'disabled');
          }
        }
        //defaultvalue
        if(customProp[j] == 'customize-defaultvalue'){
          if(objDS.getProperty(objDS.getDefaultPropName()) != objDS.getCustomProperty(objDS.getDefaultPropName(), 'originalvalue')){
            objDS.setProperty(customProp[j], 'enabled');
          }else{
            objDS.setProperty(customProp[j], 'disabled');
          }
        }
        //maxlines
        if(customProp[j] == 'customize-maxlines'){
          if(objDS.getProperty('maxlines') != objDS.getCustomProperty('maxlines', 'originalvalue')){
            objDS.setProperty(customProp[j], 'enabled');
          }else{
            objDS.setProperty(customProp[j], 'disabled');
          }
        }
      }
    }
  }

  //TABLE時、TDPANELのm_DataSetのみ作成する
  if(objPageItem.pageItemTypeId == 'table'){
    createLoadTableHtml(page, objPageItem.pageItemId);
  }

  //FORM以外はIDをreturn
  if(formId.length == 0){
    return workId;
  }else{
    return '';
  }

}

/**
 *
 */
function initFormByDataSet(dataset) {
  //画面反映
  var formElement = getDocumentElementById(ELEMENTID_FIRSTFORM);
  var formElementStyle = formElement.style;
  formElementStyle.width = dataset.getProperty('pagewidth');
  formElementStyle.height = dataset.getProperty('pageheight');
  setElementStyleBackgroundColor(formElement, dataset.getProperty('backgroundcolor'));
  
  if(pref.view.get('usebackgroundimage')) {
    var url = getImageSrcUrl(dataset.getProperty('backgroundimage'));
    formElementStyle.backgroundImage = url;
  }

  formElement.className = 'vw-form ' + getNonTextElementClassProperty(dataset);
}

/**
 * page変数から指定したプロパティ値を取得
 * @param  :objPageItem オブジェクト page.pageItem１ノード
 *          strProperty 文字型       値を取得するプロパティの文字列
 * @return :strPropertyで指定したプロパティ値
 */
function getLoadDataProperty(objPageItem, strProperty){
  var rtnValue;
  try{
    rtnValue = objPageItem.properties[strProperty].value.toString();
  }catch(e){
    rtnValue = '';
  }
  if(!rtnValue) rtnValue = '';
  return rtnValue;
}

/**
 * 読み込んだデータから作成したHTMLにz-indexを付加し、前後関係を修正
 * @param  :objPageItem オブジェクト page.pageItem１ノード
 * @return :
 */
function checkZindex(objPageItem){
  //TABLEのセルはzIndex不要(parentPageItemTypeIdがtableと設定されているものがセル)
  var workParentType = '';
  try{
    workParentType = objPageItem.parentPageItemTypeId;
    if(!workParentType){
      workParentType = '';
    }
  }catch(e){}
  if(workParentType == 'table') return;

  //トップレベルのFORMはzIndex不要(parentPageItemTypeIdが空のものがpage)
  var workParentId = '';
  try{
    workParentId = objPageItem.parentPageItemId;
    if(!workParentId){
      workParentId = '';
    }
  }catch(e){}
  if(workParentId.length == 0) return;

  //オブジェクトID
  var workId   = objPageItem.pageItemId;
  //項目TYPE
  var workType = toTypeCase(objPageItem.pageItemTypeId);

  //table、panelは1～10000、その他のエレメントは10000～
  if(workType == TYPE.TABLE || workType == TYPE.PANEL){
    getDocumentElementById(workId + '_span').style.zIndex = parseInt(objPageItem.properties['top'].value) + parseInt(objPageItem.properties['left'].value) + parseInt(objPageItem.level);
  }else{
    getDocumentElementById(workId + '_span').style.zIndex = 10000 + parseInt(objPageItem.level);
  }
}

/**
 * 画面ロード時にTABLEとセルのHTML及びデータを作成する
 * @param  :page オブジェクト ロードデータから作成したpage変数
 * @return :id   テーブルのID文字列
 */
function createLoadTableHtml(page, tableId){

  //page.pageItems[tableId]のキャッシュ
  var workPageItem = page.pageItems[tableId];

  //作成するテーブルの行数、列数取得
  var createCols = workPageItem.properties['maxcols'].value;
  if(useTableRows(workPageItem.properties['mode'].value)){
    var createRows = workPageItem.properties['maxrows'].value;
  }else{
    if(workPageItem.properties['titlerows']) {
      var createRows = Number(workPageItem.properties['titlerows'].value) + 1;
    } else {
      var createRows = 1;
    }
  }

  //セルの全IDを取得
  for(var i in page.pageItems){
    var cell = page.pageItems[i];
    if(cell.parentPageItemId == tableId){
      try {
        var cellRow = cell.properties['row'].value;
        if(!useTableRows(workPageItem.properties['mode'].value)){
          if(0 == cellRow) {
            cellRow = createRows;
          }
        }
        var cellCol  = cell.properties['col'].value;
      } catch(e) {
        throw createError('cell "' + i + '" has no "row" or "col" property.', 'VwInit.js', 'createLoadTableHtml');
      }
      var workId   = getCellId(tableId, cellRow, cellCol);

      //DataSet作成
      var objDS = createDataSet(workId, TYPE.CELL);

      for(var p in pref.edit.table.enumerator()) {
        if(isCellPropertyId(p)) {
          var property = cell.properties[convertToViewPropertyId(p, TYPE.CELL)];
          if(property) {
            objDS.setProperty(p, property.value);
          }
        }
      }

      // 幅の値無しのとき
      if(!objDS.getProperty('cellwidth')) {
        objDS.setProperty('cellwidth', '100');
      }
      
      // 高さの値無しのとき
      if(!objDS.getProperty('cellheight')) {
        try{
          var rows = Number(cell.properties['rows'].value);
          if(rows > 1) {
            objDS.setProperty('cellheight', rows * DISPLAYROWHEIGHT);
          } else {
            objDS.setProperty('cellheight', DISPLAYROWHEIGHT);
          }
        }catch(e){
          objDS.setProperty('cellheight', DISPLAYROWHEIGHT);
        }
      }
      
      objDS.setProperty('cellrow', cellRow);
      objDS.setProperty('cellcol', cellCol);
      //オリジナルID付加
      objDS.setProperty('originalitemid', i);
      objDS.setProperty('parenttableid', tableId);
      objDS.setProperty('originalparentitemid', tableId);

      //追加したIDを保存
      m_addElementArray[m_addElementArray.length] = workId;
    }
  }
}

/**
 * ページ項目データ初期化
 */
function clearPageData() {
  var element = getDocumentElementById('fld_showPropertyTable_div');
  if(element) {
    element.innerHTML = '';
  }
  
  element = getDocumentElementById('fld_showPropertyTable_div_type');
  if(element) {
    element.innerHTML = '';
  }
  
  element = getDocumentElementById(ELEMENTID_FIRSTFORM);
  if(element) {
    element.innerHTML = '<table><tr><td style="width:' + pref.init.form.pagewidth 
      + ';height:' + pref.init.form.pageheight + ';border:1px solid black;" align="center">&nbsp;</td></tr></table>';
  }
    
  _defaultPageDefinition.pageItems = new Object();
}

