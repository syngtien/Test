/**
 * VwMasterDataSet
 * 項目タイプ・属性定義
 */
LAST_MODIFIED('2005.11.30', '1.0.36');

// 属性を使用（編集）する
var USE      = 'use';

// 属性を表示する
var READONLY = 'readonly';

// 属性を表示しない（値は保持する）
var HIDDEN   = 'hidden';

// 属性を使用しない（値を保持しない）
var DISUSE   = '';

// 属性編集タイプ
var EDITTYPE = {
  TYPE            : 'type',
  TEXT            : 'text',
  NUMBER          : 'number',
  ASCII           : 'ascii',
  LONGTEXT        : 'longtext',
  LONGASCII       : 'longascii',
  SELECT          : 'select',
  CHECK           : 'check',
  EVENT           : 'event',
  LINK            : 'link',
  COLOR           : 'color',
  IMAGE           : 'image',
  JSFILE          : 'jsfile',
  META            : 'meta',
  OPTION          : 'option',
  PARAMETER       : 'parameter',
  CUSTOMIZE       : 'customize',
  TEXT_READONLY   : 'text/readonly',
  NUMBER_READONLY : 'number/readonly',
  CHECK_READONLY  : 'check/readonly',
  COLOR_READONLY  : 'color/readonly'
}

/*
 * 初期設定
 */
var pref = new Preference;

function Preference() {
  Properties.prototype.get = get;
  Properties.prototype.isProperty = isProperty;
  Properties.prototype.enumerator = enumerator;

  // 分類作成
  this.env       = new Properties;
  this.operation = new Properties;
  this.view      = createAllObjects();
  this.init      = createAllObjects();
  this.edit      = createAllObjects();
  this.customize = createAllObjects();
  this.valueoption = new Properties;
  this.onkeypress = new Properties;
  this.init.titledtext = new Properties;
  this.init.listtable = new Properties;
  this.init.itemrows = new Properties;
  
  // 設定値のデフォルト値設定
  initPreference(this);

  // pref.editareaのデフォルト設定。通常画面での属性表示
  this.editarea = this.edit;

  /*
   * 初期値取得用オブジェクト
   */
  function Properties(parent) {
    this.parent = parent;
  }

  /*
   * 初期値取得関数
   */
  function get(p) {
    var value = this[p];
    if(value == undefined) {
      if(this.parent) {
        value = this.parent.get(p);
      }
    }
    if(value == undefined) {
      return '';
    }
    return value;
  }

  /*
   * プロパティか
   */
  function isProperty(p) {
    if(p == 'isProperty' ||
       p == 'parent' ||
       p == 'get' ||
       p == 'enumerator') {
      return false;
    }
    return true;
  }
  
  /*
   * プロパティか
   * @param editflg trueを指定すると属性欄に表示する属性のみ
   * @param keeporder trueを指定すると属性欄に表示しない属性をfalseで返す
   */
  function enumerator(editflg, keeporder) {
    var en;
    if(this.parent && this.parent.enumerator) {
      en = this.parent.enumerator(editflg, true);
    } else {
      en = {type:true};
    }
    for(var i in this) {
      if(!this.isProperty(i)) continue;
      if(i == 'type') continue;
      if(editflg) {
        if(!this.get(i)) {
          en[i] = false;
          continue;
        }
      }
      if(en[i]) continue;
      en[i] = true;
    }
    if(!keeporder) {
      for(var i in en) {
        if(!en[i]) {
          delete en[i];
        }
      }
    }
    return en;
  }
  
  /*
   *
   */
  function createAllObjects() {
    var objs = new Properties;
    objs.page       = new Properties;
    objs.form       = new Properties(objs.page);
    objs.frame      = new Properties(objs.page);
    objs.container  = new Properties;
    objs.table      = new Properties(objs.container);
    objs.panel      = new Properties(objs.container);
    objs.component  = new Properties;
    objs.string     = new Properties(objs.component);
    objs.label      = new Properties(objs.component);
    objs.text       = new Properties(objs.component);
    objs.password   = new Properties(objs.text);
    objs.textarea   = new Properties(objs.component);
    objs.file       = new Properties(objs.component);
    objs.combo      = new Properties(objs.component);
    objs.list       = new Properties(objs.component);
    objs.radio      = new Properties(objs.component);
    objs.check      = new Properties(objs.component);
    objs.button     = new Properties(objs.component);
    objs.submit     = new Properties(objs.button);
    objs.reset      = new Properties(objs.button);
    objs.image      = new Properties(objs.component);
    objs.hide       = new Properties(objs.component);
    objs.embed      = new Properties(objs.component);
    objs.applet     = new Properties(objs.component);
    objs.object     = new Properties(objs.component);
    objs.iframe     = new Properties(objs.component);
    objs.hr         = new Properties(objs.component);
    return objs;
  }
}

/*
 * 初期設定のデフォルト値を設定する
 */
function initPreference(pref) {

  // View定義ツール操作環境の設定
  pref.env.baseheight             = 600;
  pref.env.basecolor              = '#d2d0cc';
  pref.env.menucolor              = '#d2d0cc';
  pref.env.framedesignwidth       = 800;
  pref.env.framedesignheight      = 600;

  // 操作の設定
  pref.operation.snap             = 5;
  pref.operation.play             = 1;
  pref.operation.arrow            = 1;
  pref.operation.ctrlarrow        = 10;
  pref.operation.maxundo          = 10;
  pref.operation.pastelocation    = true;
  pref.operation.pasteshift       = {row:1, left:10};

  // 表示の設定
  pref.view.defaultresize         = false;
  pref.view.usebackgroundimage    = true;
  pref.view.selectionborder       = '1px red dotted';
  pref.view.selectedareaborder    = '1px red dotted';
  pref.view.customizableborder    = '2px #0000ff inset';
  pref.view.customizedborder      = '2px #00ff00 inset'; 
  pref.view.hiddencolor           = '#bbbdc4';
  pref.view.taggedtablecolor      = 'transparent';
  pref.view.popupbuttoncolor      = '#d2d0cc';

  // ツールチップ
  pref.view.table.tooltip         = '%name%';
  pref.view.panel.tooltip         = '';
  pref.view.component.tooltip     = '%itemname%[\n]%name%[\n]%fieldvalue%';
  pref.view.string.tooltip        = '%itemname%[\n]%name%[\n]%fieldvalue%[\n]%link%';
  pref.view.image.tooltip         = '%alt%[\n]%src%[\n]%link%';
  pref.view.iframe.tooltip        = '%framename%[\n]%src%';
  pref.view.button.tooltip        = '%labeltext%[\n]%onclick%';
  pref.view.applet.tooltip        = '%alt%[\n]%code%';
  pref.view.object.tooltip        = '%alt%[\n]%classid%';
  pref.view.embed.tooltip         = '%alt%[\n]%src%';
  pref.view.hr.tooltip            = '';


  // 属性の初期値
  pref.init.frame.colsrows        = '100,*';
  pref.init.frame.direction       = 'rows';
  pref.init.form.pagewidth        = 800;
  pref.init.form.pageheight       = 600;
  pref.init.form.action           = 'appcontroller';
  pref.init.form.method           = 'post';
  pref.init.form.jsfilename       = ['commonutil.js', 'common_JA.js', 'openhelp.js', 'calendar_JA.js'];
  pref.init.form.meta             = [];
  pref.init.container.visibility  = 'visible';
  pref.init.container.rows        = 5;
  pref.init.container.left        = 10;
  pref.init.container.right       = -10;
  pref.init.container.width       = '';
  pref.init.table.tablemode       = 'MODE_SIMPLE';
  pref.init.table.corner          = 'CORNER_ROW';
  pref.init.table.borderwidth     = 1;
  pref.init.table.borderstyle     = 'none';
  //pref.init.table.cellwidth       = 20;
  //pref.init.table.cellrows        = 1;
  pref.init.table.titlerows        = 1;
  pref.init.panel.bordercolor     = '#000000';
  pref.init.component.visibility  = 'visible';
  pref.init.component.top         = 40;
  pref.init.component.left        = 40;
  pref.init.string.width          = 100;
  pref.init.label.width           = 100;
  pref.init.text.width            = 150;
  pref.init.password.width        = 150;
  pref.init.textarea.width        = 200;
  pref.init.file.width            = 200;
  pref.init.list.width            = 100;
  pref.init.list.listsize         = 2;
  pref.init.combo.width           = 100;
  pref.init.radio.width           = 200;
  pref.init.radio.optioncols      = 1;
  pref.init.check.width           = 100;
  pref.init.embed.width           = 150;
  pref.init.embed.height          = 150;
  pref.init.applet.width          = 150;
  pref.init.applet.height         = 150;
  pref.init.object.width          = 150;
  pref.init.object.height         = 150;
  pref.init.iframe.width          = 300;
  pref.init.iframe.height         = 150;
  pref.init.iframe.scrolling      = 'auto';
  pref.init.hr.width              = 400;
  pref.init.hide.width            = 15;
  
  pref.init.container['customize-visibility']  = 'disabled';
  pref.init.table['customize-maxlines']        = 'disabled';
  pref.init.component['customize-visibility']  = 'disabled';
  pref.init.component['customize-mobility']    = 'disabled';
  pref.init.text['customize-defaultvalue']     = 'disabled';
  pref.init.textarea['customize-defaultvalue'] = 'disabled';
  pref.init.hide['customize-defaultvalue']     = 'disabled';
  pref.init.combo['customize-defaultvalue']    = 'disabled';
  pref.init.list['customize-defaultvalue']     = 'disabled';
  pref.init.radio['customize-defaultvalue']    = 'disabled';
  pref.init.check['customize-defaultvalue']    = 'disabled';

  pref.init.titledtext.top        = 40;
  pref.init.titledtext.left       = 40;
  pref.init.titledtext.titlewidth = 100;
  pref.init.titledtext.textwidth  = 150;
  pref.init.titledtext.titlealign = '';
  pref.init.titledtext.interval   = 5;

  pref.init.listtable.top         = 40;
  pref.init.listtable.left        = 10;
  pref.init.listtable.cellwidth   = 100;
  pref.init.listtable.hardpadding = 5;
  pref.init.listtable.titlealign  = 'center';

  pref.init.itemrows.textarea     = 2;
  pref.init.itemrows.list         = 2;

  // 編集画面に表示する属性欄

  // frameは読み込み時のチェックのみ
  pref.edit.frame.type           = HIDDEN;
  pref.edit.frame.name           = USE;
  pref.edit.frame.method         = HIDDEN;
  pref.edit.frame.caption        = USE;
  pref.edit.frame.border         = USE;
  pref.edit.frame.bordercolor    = USE;
  pref.edit.frame.onload         = USE;
  pref.edit.frame.onunload       = USE;
  pref.edit.frame.jsfilename     = USE;
  pref.edit.frame.meta           = USE;
  pref.edit.frame.colsrows       = HIDDEN;
  pref.edit.frame.direction      = HIDDEN;
  pref.edit.frame.frameflag      = USE;
  pref.edit.frame.framename      = USE;
  pref.edit.frame.frameresize    = USE;
  pref.edit.frame.framescrolling = USE;
  pref.edit.frame.framesrc       = USE;

  //
  pref.edit.form.type              = USE;
  pref.edit.form.name              = USE;
  pref.edit.form.groupid           = DISUSE;
  pref.edit.form.fieldid           = DISUSE;
  pref.edit.form.pagetitle         = USE;
  pref.edit.form.pagewidth         = USE;
  pref.edit.form.pageheight        = USE;
  pref.edit.form.backgroundcolor   = USE;
  pref.edit.form.backgroundimage   = USE;
  pref.edit.form.action            = USE;
  pref.edit.form.method            = USE;
  pref.edit.form.target            = USE;
  pref.edit.form.enctype           = USE;
  pref.edit.form.textcolor         = USE;
  pref.edit.form.linkcolor         = USE;
  pref.edit.form.vlinkcolor        = USE;
  pref.edit.form.alinkcolor        = USE;
  pref.edit.form.style             = USE;
  pref.edit.form.onload            = USE;
  pref.edit.form.onunload          = USE;
  pref.edit.form.onsubmit          = USE;
  pref.edit.form.onreset           = USE;
  pref.edit.form.jsfilename        = USE;
  pref.edit.form.meta              = USE;
  pref.edit.form[PREVIEWPROPERTYID] = HIDDEN;

  // panel,table共通
  pref.edit.container.type         = USE;
  pref.edit.container.name         = USE;
  pref.edit.container.visibility   = USE;
  pref.edit.container.top          = USE;
  pref.edit.container.left         = USE;

  // pref.edit.containerとの差分設定
  pref.edit.panel.width            = USE;
  pref.edit.panel.height           = USE;
  pref.edit.panel.locationfixing   = USE;
  pref.edit.panel.bordercolor      = USE;
  pref.edit.panel.backgroundcolor  = USE;
  pref.edit.panel.backgroundimage  = USE;
  pref.edit.panel.style            = USE;

  // pref.edit.containerとの差分設定
  pref.edit.table.locationfixing       = DISUSE;
  pref.edit.table.tablemode            = USE;
  pref.edit.table.titlerows            = USE;
  pref.edit.table.titlerowvanishing    = USE;
  pref.edit.table.titlecols            = DISUSE;
  pref.edit.table.corner               = DISUSE;
  pref.edit.table.tablecols            = USE;
  pref.edit.table.tablerows            = USE;
  pref.edit.table.maxlines             = USE;
  pref.edit.table.caption              = DISUSE;
  pref.edit.table.captionfontsize      = DISUSE;
  pref.edit.table.captionfontcolor     = DISUSE;
  pref.edit.table.captionalign         = DISUSE;
  pref.edit.table.cellspacing          = DISUSE;
  pref.edit.table.cellpadding          = DISUSE;
  pref.edit.table.borderwidth          = USE;
  pref.edit.table.borderstyle          = USE;
  pref.edit.table.bordercolor          = USE;
  pref.edit.table.backgroundcolor      = USE;
  pref.edit.table.backgroundimage      = USE;
  pref.edit.table.style                = USE;
  pref.edit.table.titlerowborderwidth  = DISUSE;
  pref.edit.table.titlerowborderstyle  = DISUSE;
  pref.edit.table.titlerowbordercolor  = DISUSE;
  pref.edit.table.titlerowcolor        = DISUSE;
  pref.edit.table.titlerowstyle        = USE; 
  pref.edit.table.titlecolborderwidth  = DISUSE;
  pref.edit.table.titlecolborderstyle  = DISUSE;
  pref.edit.table.titlecolbordercolor  = DISUSE;
  pref.edit.table.titlecolcolor        = DISUSE;
  pref.edit.table.titlecolstyle        = DISUSE;
  pref.edit.table.tdborderwidth        = DISUSE;
  pref.edit.table.tdborderstyle        = DISUSE;
  pref.edit.table.tdbordercolor        = DISUSE;
  pref.edit.table.tdstyle              = DISUSE;
  pref.edit.table.cellrow              = USE;
  pref.edit.table.cellcol              = USE;
  pref.edit.table.cellvisibility       = DISUSE;
  pref.edit.table.cellwidth            = USE;
  pref.edit.table.cellheight           = USE;
  pref.edit.table.cellbordercolor      = USE;
  pref.edit.table.cellbackgroundcolor  = USE;
  pref.edit.table.cellbackgroundimage  = USE;
  pref.edit.table.cellstyle            = DISUSE;
  pref.edit.table.onclick              = DISUSE;
  pref.edit.table.ondblclick           = DISUSE;
  pref.edit.table.onmousedown          = DISUSE;
  pref.edit.table.onmouseup            = DISUSE;
  pref.edit.table.onmouseover          = DISUSE;
  pref.edit.table.onmouseout           = DISUSE;
  pref.edit.table.onmousemove          = DISUSE;
  pref.edit.table.onkeypress           = DISUSE;
  pref.edit.table.onkeydown            = DISUSE;
  pref.edit.table.onkeyup              = DISUSE;

  // component(form,panel,table以外共通) で使用できる属性すべて
  pref.edit.component.type             = USE;
  pref.edit.component.name             = USE;
  pref.edit.component.groupid          = DISUSE;
  pref.edit.component.fieldid          = DISUSE;
  pref.edit.component.visibility       = USE;
  pref.edit.component.top              = USE;
  pref.edit.component.left             = USE;
  pref.edit.component.width            = USE;
  pref.edit.component.height           = USE;
  pref.edit.component.locationfixing   = DISUSE;
  pref.edit.component.thickness        = DISUSE;
  pref.edit.component.textcols         = DISUSE;
  pref.edit.component.textrows         = DISUSE;
  pref.edit.component.maxlength        = DISUSE;
  pref.edit.component.framename        = DISUSE;
  pref.edit.component.src              = DISUSE;
  pref.edit.component.imagewidth       = DISUSE;
  pref.edit.component.imageheight      = DISUSE;
  pref.edit.component.imageposition    = DISUSE;
  pref.edit.component.classid          = DISUSE;
  pref.edit.component.code             = DISUSE;
  pref.edit.component.codebase         = DISUSE;
  pref.edit.component.alt              = DISUSE;
  pref.edit.component.archive          = DISUSE;
  pref.edit.component.title            = DISUSE;
  pref.edit.component.labeltext        = DISUSE;
  pref.edit.component.fieldvalue       = USE;
  pref.edit.component.textid           = DISUSE;
  pref.edit.component.optionvalue      = DISUSE;
  pref.edit.component.optionvalue0     = DISUSE;
  pref.edit.component.option           = DISUSE;
  pref.edit.component.optioncols       = DISUSE;
  pref.edit.component.optionrows       = DISUSE;
  pref.edit.component.selectmode       = DISUSE;
  pref.edit.component.listsize         = DISUSE;
  pref.edit.component.tooltip          = DISUSE;
  pref.edit.component.heightc          = DISUSE;
  pref.edit.component.heightt          = DISUSE;
  pref.edit.component.fontsize         = USE;
  pref.edit.component.fontfamily       = DISUSE;
  pref.edit.component.fontweight       = DISUSE;
  pref.edit.component.fontstyle        = DISUSE;
  pref.edit.component.underline        = DISUSE;
  pref.edit.component.borderwidth      = DISUSE;
  pref.edit.component.borderstyle      = DISUSE;
  pref.edit.component.bordercolor      = DISUSE;
  pref.edit.component.fontcolor        = USE;
  pref.edit.component.backgroundcolorr = DISUSE;
  pref.edit.component.backgroundcolort = DISUSE;
  pref.edit.component.backgroundcolor  = USE;
  pref.edit.component.backgroundimage  = DISUSE;
  pref.edit.component.hrcolor          = DISUSE;
  pref.edit.component.align            = USE;
  pref.edit.component.editmode         = DISUSE;
  pref.edit.component.link             = DISUSE;
  pref.edit.component.target           = DISUSE;
  pref.edit.component.shade            = DISUSE;
  pref.edit.component.scrolling        = DISUSE;
  pref.edit.component.tabindex         = USE;
  pref.edit.component.accesskey        = USE;
  pref.edit.component.acckey           = DISUSE;
  pref.edit.component.style            = USE;
  pref.edit.component.params           = DISUSE;
  pref.edit.component.attributes       = DISUSE;
  pref.edit.component.embedsrc         = DISUSE;
  pref.edit.component.embedparams      = DISUSE;
  pref.edit.component.embedattributes  = DISUSE;
  pref.edit.component.onclick          = DISUSE;
  pref.edit.component.ondblclick       = DISUSE;
  pref.edit.component.onmousedown      = DISUSE;
  pref.edit.component.onmouseup        = DISUSE;
  pref.edit.component.onmouseover      = DISUSE;
  pref.edit.component.onmouseout       = DISUSE;
  pref.edit.component.onmousemove      = DISUSE;
  pref.edit.component.onkeypress       = DISUSE;
  pref.edit.component.onkeydown        = DISUSE;
  pref.edit.component.onkeyup          = DISUSE;
  pref.edit.component.onfocus          = DISUSE;
  pref.edit.component.onblur           = DISUSE;
  pref.edit.component.onchange         = DISUSE;
  
  // pref.edit.componentとの差分設定
  pref.edit.string.textid           = USE;
  pref.edit.string.fontfamily       = USE;
  pref.edit.string.fontweight       = USE;
  pref.edit.string.fontstyle        = USE;
  pref.edit.string.tooltip          = USE;
  pref.edit.string.underline        = USE;
  pref.edit.string.link             = USE;
  pref.edit.string.target           = USE;
  pref.edit.string.onclick          = USE;
  pref.edit.string.onfocus          = USE;
  pref.edit.string.onblur           = USE;

  // pref.edit.componentとの差分設定
  pref.edit.label.fontfamily       = USE;
  pref.edit.label.fontweight       = USE;
  pref.edit.label.fontstyle        = USE;
  pref.edit.label.underline        = USE;
  pref.edit.label.tabindex         = DISUSE;
  pref.edit.label.accesskey        = DISUSE;
  pref.edit.label.onclick          = USE;

  // pref.edit.componentとの差分設定
  pref.edit.text.textcols         = USE;
  pref.edit.text.maxlength        = USE;
  pref.edit.text.fontfamily       = USE;
  pref.edit.text.fontweight       = USE;
  pref.edit.text.fontstyle        = USE;
  pref.edit.text.onclick          = USE;
  pref.edit.text.onfocus          = USE;
  pref.edit.text.onblur           = USE;
  pref.edit.text.onchange         = USE;
  pref.edit.text.onkeypress       = USE;

  // password : pref.edit.textとの差分設定

  // pref.edit.componentとの差分設定
  pref.edit.file.textcols         = USE;
  pref.edit.file.fieldvalue       = DISUSE;
  pref.edit.file.onclick          = USE;
  pref.edit.file.onfocus          = USE;
  pref.edit.file.onblur           = USE;

  // pref.edit.componentとの差分設定
  pref.edit.textarea.textcols         = USE;
  pref.edit.textarea.textrows         = USE;
  pref.edit.textarea.fontfamily       = USE;
  pref.edit.textarea.fontweight       = USE;
  pref.edit.textarea.fontstyle        = USE;
  pref.edit.textarea.editmode         = USE;
  pref.edit.textarea.onclick          = USE;
  pref.edit.textarea.onfocus          = USE;
  pref.edit.textarea.onblur           = USE;
  pref.edit.textarea.onchange         = USE;
  pref.edit.textarea.onkeypress       = USE;

  // pref.edit.componentとの差分設定
  pref.edit.check.labeltext        = USE;
  pref.edit.check.textid           = USE;
  pref.edit.check.fontfamily       = USE;
  pref.edit.check.fontweight       = USE;
  pref.edit.check.fontstyle        = USE;
  pref.edit.check.optionvalue      = USE;
  pref.edit.check.optionvalue0     = DISUSE;
  pref.edit.check.align            = DISUSE;
  pref.edit.check.onclick          = USE;
  pref.edit.check.onfocus          = USE;
  pref.edit.check.onblur           = USE;

  // pref.edit.componentとの差分設定
  pref.edit.radio.fontfamily       = USE;
  pref.edit.radio.fontweight       = USE;
  pref.edit.radio.fontstyle        = USE;
  pref.edit.radio.option           = USE;
  pref.edit.radio.optioncols       = USE;
  pref.edit.radio.align            = DISUSE;
  pref.edit.radio.accesskey        = DISUSE;
  //pref.edit.radio.acckey           = USE;

  // pref.edit.componentとの差分設定
  pref.edit.combo.option           = USE;
  pref.edit.combo.align            = DISUSE;
  pref.edit.combo.onchange         = USE;

  // pref.edit.componentとの差分設定
  pref.edit.list.option           = USE;
  pref.edit.list.selectmode       = USE;
  pref.edit.list.listsize         = USE;
  pref.edit.list.align            = DISUSE;
  pref.edit.list.onchange         = USE;

  // pref.edit.componentとの差分設定
  pref.edit.button.labeltext        = USE;
  pref.edit.button.textid           = USE;
  pref.edit.button.tooltip          = USE;
  pref.edit.button.fieldvalue       = DISUSE;
  pref.edit.button.src              = USE;
  pref.edit.button.align            = DISUSE;
  pref.edit.button.onclick          = USE;
  pref.edit.button.onfocus          = USE;
  pref.edit.button.onblur           = USE;

  // submit : pref.edit.buttonとの差分設定

  // reset : pref.edit.buttonとの差分設定

  // pref.edit.componentとの差分設定
  pref.edit.image.name             = DISUSE;
  pref.edit.image.src              = USE;
  pref.edit.image.alt              = USE;
  pref.edit.image.tooltip          = USE;
  pref.edit.image.fieldvalue       = DISUSE;
  pref.edit.image.fontsize         = DISUSE;
  pref.edit.image.borderwidth      = USE;
  pref.edit.image.bordercolor      = USE;
  pref.edit.image.link             = USE;
  pref.edit.image.target           = USE;
  pref.edit.image.onclick          = USE;
  pref.edit.image.onfocus          = USE;
  pref.edit.image.onblur           = USE;

  // pref.edit.componentとの差分設定
  pref.edit.hide.visibility          = DISUSE;
  pref.edit.hide.width               = DISUSE;
  pref.edit.hide.height              = DISUSE;
  pref.edit.hide.fontsize            = DISUSE;
  pref.edit.hide.fontcolor           = DISUSE;
  pref.edit.hide.backgroundcolor     = DISUSE;
  pref.edit.hide.align               = DISUSE;
  pref.edit.hide.style               = DISUSE;
  pref.edit.hide.tabindex            = DISUSE;
  pref.edit.hide.accesskey           = DISUSE;

  // pref.edit.componentとの差分設定
  pref.edit.embed.name               = DISUSE;
  pref.edit.embed.src                = USE;
  pref.edit.embed.code               = USE;
  pref.edit.embed.codebase           = USE;
  pref.edit.embed.alt                = USE;
  pref.edit.embed.title              = USE;
  pref.edit.embed.fieldvalue         = DISUSE;
  pref.edit.embed.fontsize           = DISUSE;
  pref.edit.embed.fontcolor          = DISUSE;
  pref.edit.embed.backgroundcolor    = DISUSE;
  pref.edit.embed.accesskey          = DISUSE;
  pref.edit.embed.style              = DISUSE;
  pref.edit.embed.params             = USE;
  pref.edit.embed.attributes         = USE;

  // applet : pref.edit.embedとの差分設定
  pref.edit.applet.name               = DISUSE;
  pref.edit.applet.src                = DISUSE;
  pref.edit.applet.archive            = USE;
  pref.edit.applet.code               = USE;
  pref.edit.applet.codebase           = USE;
  pref.edit.applet.alt                = USE;
  pref.edit.applet.title              = USE;
  pref.edit.applet.fieldvalue         = DISUSE;
  pref.edit.applet.fontsize           = DISUSE;
  pref.edit.applet.fontcolor          = DISUSE;
  pref.edit.applet.backgroundcolor    = DISUSE;
  pref.edit.applet.accesskey          = DISUSE;
  pref.edit.applet.style              = DISUSE;
  pref.edit.applet.params             = USE;
  pref.edit.applet.attributes         = USE;

  // object : pref.edit.embedとの差分設定
  pref.edit.object.name               = DISUSE;
  pref.edit.object.src                = DISUSE;
  pref.edit.object.classid            = USE;
  pref.edit.object.archive            = USE;
  pref.edit.object.code               = USE;
  pref.edit.object.codebase           = USE;
  pref.edit.object.alt                = USE;
  pref.edit.object.title              = USE;
  pref.edit.object.fieldvalue         = DISUSE;
  pref.edit.object.fontsize           = DISUSE;
  pref.edit.object.fontcolor          = DISUSE;
  pref.edit.object.backgroundcolor    = DISUSE;
  pref.edit.object.accesskey          = DISUSE;
  pref.edit.object.style              = DISUSE;
  pref.edit.object.params             = USE;
  pref.edit.object.attributes         = USE;
  pref.edit.object.embedsrc           = USE;
  pref.edit.object.embedparams        = USE;
  pref.edit.object.embedattributes    = USE;

  // pref.edit.componentとの差分設定
  pref.edit.hr.name               = DISUSE;
  pref.edit.hr.height             = DISUSE;
  pref.edit.hr.thickness          = USE;
  pref.edit.hr.hrcolor            = USE;
  pref.edit.hr.shade              = USE;
  pref.edit.hr.fieldvalue         = DISUSE;
  pref.edit.hr.fontsize           = DISUSE;
  pref.edit.hr.fontcolor          = DISUSE;
  pref.edit.hr.backgroundcolor    = DISUSE;
  pref.edit.hr.tabindex           = DISUSE;
  pref.edit.hr.accesskey          = DISUSE;

  // pref.edit.componentとの差分設定
  pref.edit.iframe.name             = DISUSE;
  pref.edit.iframe.framename        = USE;
  pref.edit.iframe.src              = USE;
  pref.edit.iframe.scrolling        = USE;
  pref.edit.iframe.fieldvalue       = DISUSE;
  pref.edit.iframe.align            = DISUSE;
  pref.edit.iframe.fontcolor        = DISUSE;
  pref.edit.iframe.fontsize         = DISUSE;
  pref.edit.iframe.backgroundcolor  = DISUSE;
  pref.edit.iframe.accesskey        = DISUSE;
  pref.edit.iframe.borderwidth      = USE;
  pref.edit.iframe.borderstyle      = USE;
  pref.edit.iframe.bordercolor      = USE;
  pref.edit.iframe.style            = DISUSE;
  pref.edit.iframe.onfocus          = USE;
  pref.edit.iframe.onblur           = USE;

  // カスタマイズ属性
  pref.edit.container['customize-visibility']  = USE;
  pref.edit.table['customize-maxlines']        = USE;
  pref.edit.component['customize-visibility']  = USE;
  pref.edit.component['customize-mobility']    = USE;
  pref.edit.text['customize-defaultvalue']     = USE;
  pref.edit.textarea['customize-defaultvalue'] = USE;
  pref.edit.hide['customize-defaultvalue']     = USE;
  pref.edit.combo['customize-defaultvalue']    = USE;
  pref.edit.list['customize-defaultvalue']     = USE;
  pref.edit.radio['customize-defaultvalue']    = USE;
  pref.edit.check['customize-defaultvalue']    = USE;
  pref.edit.hide['customize-visibility']       = DISUSE;

  // カスタマイズ画面に表示する属性欄

  pref.customize.form.type            = READONLY;

  pref.customize.container.type       = READONLY;
  pref.customize.container.name       = READONLY;
  pref.customize.container.visibility = USE;
  pref.customize.container.top        = READONLY;
  pref.customize.container.left       = READONLY;

  pref.customize.panel.name           = DISUSE;
  pref.customize.table.maxlines       = USE;

  pref.customize.component.type       = READONLY;
  pref.customize.component.name       = READONLY;
  pref.customize.component.visibility = USE;
  pref.customize.component.top        = USE;
  pref.customize.component.left       = USE;
  pref.customize.component.fieldvalue = USE;

  pref.customize.container['customize-visibility']  = USE;
  pref.customize.table['customize-maxlines']        = USE;
  pref.customize.component['customize-visibility']  = USE;
  pref.customize.component['customize-mobility']    = USE;
  pref.customize.text['customize-defaultvalue']     = USE;
  pref.customize.textarea['customize-defaultvalue'] = USE;
  pref.customize.hide['customize-visibility']       = DISUSE;
  pref.customize.hide['customize-defaultvalue']     = USE;
  pref.customize.combo['customize-defaultvalue']    = USE;
  pref.customize.list['customize-defaultvalue']     = USE;
  pref.customize.radio['customize-defaultvalue']    = USE;
  pref.customize.check['customize-defaultvalue']    = USE;
  
  // type 選択肢
  pref.valueoption.type = {};
  var TYPE = getTYPE();
  for(var type in TYPE) {
    pref.valueoption.type[TYPE[type]] = getLiteral('pageitemtype.' + TYPE[type]);
  }
  
  // method 選択肢
  pref.valueoption.method = {};
  pref.valueoption.method['post'] = 'post';
  pref.valueoption.method['get']  = 'get';

  // 送信形式定義 選択肢
  pref.valueoption.enctype = {};
  pref.valueoption.enctype[''] = '';
  pref.valueoption.enctype['application/x-www-form-urlencoded']  = getLiteral('enctype.application/x-www-form-urlencoded');
  pref.valueoption.enctype['multipart/form-data']                = getLiteral('enctype.multipart/form-data');

  // 文字の太さ 選択肢
  pref.valueoption.fontweight = {};
  pref.valueoption.fontweight[''] = '';
  pref.valueoption.fontweight['lighter'] = getLiteral('fontweight.lighter');
  pref.valueoption.fontweight['normal']  = getLiteral('fontweight.normal');
  pref.valueoption.fontweight['bold']    = getLiteral('fontweight.bold');
  pref.valueoption.fontweight['bolder']  = getLiteral('fontweight.bolder');

  // 水平方向配置 選択肢
  pref.valueoption.align = {};
  pref.valueoption.align[''] = '';
  pref.valueoption.align['left']   = getLiteral('align.left');
  pref.valueoption.align['center'] = getLiteral('align.center');
  pref.valueoption.align['right']  = getLiteral('align.right');

  // キャプション配置 選択肢
  pref.valueoption.captionalign = {};
  pref.valueoption.captionalign['left']   = getLiteral('captionalign.left');
  pref.valueoption.captionalign['top']    = getLiteral('captionalign.top');
  pref.valueoption.captionalign['right']  = getLiteral('captionalign.right');
  pref.valueoption.captionalign['bottom'] = getLiteral('captionalign.bottom');

  // 画像配置 選択肢
  pref.valueoption.imageposition = {};
  pref.valueoption.imageposition['left']  = getLiteral('imageposition.left');
  pref.valueoption.imageposition['above'] = getLiteral('imageposition.above');
  pref.valueoption.imageposition['right'] = getLiteral('imageposition.right');
  pref.valueoption.imageposition['below'] = getLiteral('imageposition.below');

  // 枠線の線種 選択肢
  pref.valueoption.borderstyle = {};
  pref.valueoption.borderstyle['']       = '';
  pref.valueoption.borderstyle['none']   = getLiteral('borderstyle.none');
  pref.valueoption.borderstyle['dotted'] = getLiteral('borderstyle.dotted');
  pref.valueoption.borderstyle['dashed'] = getLiteral('borderstyle.dashed');
  pref.valueoption.borderstyle['solid']  = getLiteral('borderstyle.solid');
  pref.valueoption.borderstyle['double'] = getLiteral('borderstyle.double');
  pref.valueoption.borderstyle['groove'] = getLiteral('borderstyle.groove');
  pref.valueoption.borderstyle['ridge']  = getLiteral('borderstyle.ridge');
  pref.valueoption.borderstyle['inset']  = getLiteral('borderstyle.inset');
  pref.valueoption.borderstyle['outset'] = getLiteral('borderstyle.outset');

  // 境界線の線種 選択肢
  pref.valueoption.tdborderstyle = pref.valueoption.borderstyle;

  // 見出し列の線種 選択肢
  pref.valueoption.titlecolborderstyle = pref.valueoption.borderstyle;

  // 見出し行の線種 選択肢
  pref.valueoption.titlerowborderstyle = pref.valueoption.borderstyle;

  // テーブルのモード 選択肢
  pref.valueoption.tablemode = {};
  pref.valueoption.tablemode['MODE_SIMPLE'] = getLiteral('tablemode.simple');
  pref.valueoption.tablemode['MODE_COPY']   = getLiteral('tablemode.copy');
  pref.valueoption.tablemode['MODE_LINE']   = getLiteral('tablemode.line');

  // スクロール 選択肢
  pref.valueoption.scrolling = {};
  pref.valueoption.scrolling['auto'] = getLiteral('framescrolling.auto');
  pref.valueoption.scrolling['yes']  = getLiteral('framescrolling.yes');
  pref.valueoption.scrolling['no']   = getLiteral('framescrolling.no');

  // フォント 選択肢
  pref.valueoption.fontfamily = {};
  pref.valueoption.fontfamily['']                 = '';
  pref.valueoption.fontfamily['ＭＳ 明朝']        = 'ＭＳ 明朝';
  pref.valueoption.fontfamily['ＭＳ ゴシック']    = 'ＭＳ ゴシック';
  pref.valueoption.fontfamily['ＭＳ Ｐ明朝']      = 'ＭＳ Ｐ明朝';
  pref.valueoption.fontfamily['ＭＳ Ｐゴシック']  = 'ＭＳ Ｐゴシック';
  pref.valueoption.fontfamily['HGP創英角ﾎﾟｯﾌﾟ体'] = 'HGP創英角ﾎﾟｯﾌﾟ体';

  // アクセスキー 選択肢
  pref.valueoption.accesskey = {};
  pref.valueoption.accesskey[''] = '';
  charsToObjectPropertyValue(pref.valueoption.accesskey, '0123456789#*,+abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ');
  function charsToObjectPropertyValue(obj, chars) {
    for(var i = 0; i < chars.length; i++) {
      obj[chars.charAt(i)] = chars.charAt(i);
    } 
  }

  // 分割の向き 選択肢
  pref.valueoption.direction = {};
  pref.valueoption.direction['rows'] = getLiteral('direction.rows');
  pref.valueoption.direction['cols'] = getLiteral('direction.columns');

  // 見出しコーナー 選択肢
  pref.valueoption.corner = {};
  pref.valueoption.corner['CORNER_ROW'] = getLiteral('corner.row');
  pref.valueoption.corner['CORNER_COL'] = getLiteral('corner.col');

  // 表示 チェックボックス値
  pref.valueoption.visibility = {};
  pref.valueoption.visibility['']       = '';
  pref.valueoption.visibility['hidden'] = getLiteral('visibility.hidden');

  // 表示 チェックボックス値
  pref.valueoption.cellvisibility = pref.valueoption.visibility;

  // 配置方法 チェックボックス値
  pref.valueoption.locationfixing = {};
  pref.valueoption.locationfixing['pageright'] = getLiteral('locationfixing.pageright');

  // 斜体 チェックボックス値
  pref.valueoption.fontstyle = {};
  pref.valueoption.fontstyle['']       = '';
  pref.valueoption.fontstyle['italic'] = getLiteral('fontstyle.italic');

  // 下線 チェックボックス値
  pref.valueoption.underline = {};
  pref.valueoption.underline['']       = '';
  pref.valueoption.underline['underline'] = getLiteral('textdecoration.underline');

  // 複数選択 チェックボックス値
  pref.valueoption.selectmode = {};
  pref.valueoption.selectmode['']       = '';
  pref.valueoption.selectmode['multiple'] = getLiteral('selectmode.multiple');

  // 編集不可 チェックボックス値
  pref.valueoption.editmode = {};
  pref.valueoption.editmode['']       = '';
  pref.valueoption.editmode['readonly'] = getLiteral('editmode.readonly');

  // 影 チェックボックス値
  pref.valueoption.shade = {};
  pref.valueoption.shade['']       = '';
  pref.valueoption.shade['noshade'] = getLiteral('shade.noshade');

  // 見出し行 チェックボックス値
  pref.valueoption.titlerows = {};
  pref.valueoption.titlerows['']       = '';
  pref.valueoption.titlerows['1'] = getLiteral('titlerows.use');

  // 見出し列 チェックボックス値
  pref.valueoption.titlecols = {};
  pref.valueoption.titlecols['']       = '';
  pref.valueoption.titlecols['1'] = getLiteral('titlecols.use');

  // 見出し行表示 選択肢
  pref.valueoption.titlerowvanishing = {};
  pref.valueoption.titlerowvanishing['']       = getLiteral('titlerowvanishing.novanish');
  pref.valueoption.titlerowvanishing['vanish'] = getLiteral('titlerowvanishing.vanish');

  // 入力文字チェック
  pref.onkeypress.tabindex = _onkeypress_tabindex;
  pref.onkeypress.NUMBER = _onkeypress_NUMBER;

  function _onkeypress_NUMBER(keyCode, propertyId) {
    //数値チェック
    if(KEYCODE.NUM0 <= keyCode && keyCode <= KEYCODE.NUM9){
      return true;
    }
    return false;
  }

  function _onkeypress_tabindex(keyCode, propertyId) {
    //数値チェック
    if((KEYCODE.NUM0 <= keyCode && keyCode <= KEYCODE.NUM9) ||
       (keyCode == KEYCODE.MINUS)){
      return true;
    }
    return false;
  }
}

// 項目タイプID (表示順)
var TYPE = getTYPE();
function getTYPE() {
  if(getTYPE.TYPE == undefined) {
    getTYPE.TYPE = {
      FORM     : toTypeCase('form'),
      FRAME    : toTypeCase('frame'),
      TEXT     : toTypeCase('text'),
      STRING   : toTypeCase('string'),
      LABEL    : toTypeCase('label'),
      BUTTON   : toTypeCase('button'),
      SUBMIT   : toTypeCase('submit'),
      RESET    : toTypeCase('reset'),
      TABLE    : toTypeCase('table'),
      CELL     : toTypeCase('cell'),
      PANEL    : toTypeCase('panel'),
      HIDE     : toTypeCase('hide'),
      RADIO    : toTypeCase('radio'),
      CHECK    : toTypeCase('check'),
      COMBO    : toTypeCase('combo'),
      LIST     : toTypeCase('list'),
      TEXTAREA : toTypeCase('textarea'),
      PASSWORD : toTypeCase('password'),
      FILE     : toTypeCase('file'),
      IMAGE    : toTypeCase('image'),
      APPLET   : toTypeCase('applet'),
      OBJECT   : toTypeCase('object'),
      EMBED    : toTypeCase('embed'),
      IFRAME   : toTypeCase('iframe'),
      HR       : toTypeCase('hr')
    };
  }
  return getTYPE.TYPE;
}

/**
 * 項目タイプIDを小文字に統一する
 */
function toTypeCase(type) {
  return type.toLowerCase();
}

/**
 * 項目タイプ属性定義
 */
function getTypeInfoDefs(){
  if(!TypeInfoDefs.allcreated) {
    for(var i in TYPE) {
      getTypeInfoByTypeInfoDefs(TYPE[i], true);
    }
    TypeInfoDefs.allcreated = true;
  }
  return TypeInfoDefs.instance;
}

/**
 * 項目タイプ別の属性定義
 */
function getTypeInfoDef(typeid){
  var instance = getTypeInfoByTypeInfoDefs(typeid);
  if(!instance) {
    //alert('typeid(' + typeid + ') is unknown');
    throw createError('type "' + typeid + '" is unknown', 'VwMasterDataSet.js', 'getTypeInfoDef');
  }
  return instance;
}

/**
 * 項目タイプ別の属性定義
 */
function getPropertyInfoDef(typeid, propertyid){
  var instance = getTypeInfoDef(typeid)[propertyid];
  if(!instance) {
    //alert('propertyid(' + propertyid + ') is unknown (' + typeid + ').');
    throw createError('propertyid "' + propertyid + '" is unknown (' + typeid + ').', 'VwMasterDataSet.js', 'getPropertyInfoDef');
  }
  //showObject(instance, typeid);
  return instance;
}

/**
 * 項目タイプ別の属性定義
 */
function getTypeInfoByTypeInfoDefs(typeid, reliable) {
  var instance = TypeInfoDefs.getInstance();
  if(!instance[typeid]) {
    if(typeid == TYPE.CELL) {
      TypeInfoDefs.addCellType(typeid);
    } else if(typeid == TYPE.TABLE) {
      TypeInfoDefs.addTableType(typeid);
    } else {
      if(!reliable) {
        var exists = false;
        for(var i in TYPE) {
          if(typeid == TYPE[i]) {
            exists = true;
            break;
          }
        }
        if(!exists) {
          return null;
        }
      }
      TypeInfoDefs.addObjectType(typeid);
    }
  }
  return instance[typeid];
}

/**
 * TypeInfoDefsのインスタンスを返す
 */
TypeInfoDefs.getInstance = function () {
  if(!TypeInfoDefs.instance) {
    new TypeInfoDefs;
  }
  return TypeInfoDefs.instance;
};

/**
 * 項目タイプ属性定義
 */
function TypeInfoDefs(){
  TypeInfoDefs.instance = this;
  TypeInfoDefs.addObjectType = addObjectType;
  TypeInfoDefs.addTableType = addTableType;
  TypeInfoDefs.addCellType = addCellType;

  function addObjectType(typeid) {
    var prefEdit = pref.editarea[typeid];
    if(!prefEdit) {
      throw createError('type "' + typeid + '" is undefined.', 'VwMasterDataSet.js', 'TypeInfoDefs.addObjectType');
    }

    var obj = new Object();
    for(var propertyId in prefEdit.enumerator(true)) {
      obj[propertyId] = new Object();
      obj[propertyId].convertiblePropertyId = convertiblePropertyId(typeid, propertyId);
      obj[propertyId].isArrayValue = isArrayValue(propertyId);
    }

    TypeInfoDefs.instance[typeid] = obj;
  }

  function addCellType(typeid) {
    var prefEdit = pref.editarea.table;
    if(!prefEdit) {
      throw createError('type "' + typeid + '" is undefined.', 'VwMasterDataSet.js', 'TypeInfoDefs.addCellType');
    }

    var obj = new Object();
    for(var propid in prefEdit.enumerator(true)) {
      if(isCellPropertyId(propid) || propid == 'type') {
        var propertyId = convertToViewEditorPropertyId(propid, typeid);
        if(propertyId != propid) {
          alert(propid + ' < ' + propertyId);
        }
        obj[propertyId] = new Object();
        obj[propertyId].convertiblePropertyId = convertiblePropertyId(typeid, propertyId);
        obj[propertyId].isArrayValue = isArrayValue(propertyId);
      }
    }
    
    TypeInfoDefs.instance[typeid] = obj;
    return;
  }

  function addTableType(typeid) {
    var prefEdit = pref.editarea[typeid];
    if(!prefEdit) {
      throw createError('type "' + typeid + '" is undefined.', 'VwMasterDataSet.js', 'TypeInfoDefs.addTableType');
    }

    var obj = new Object();
    for(var propid in prefEdit.enumerator(true)) {
      if(!isCellPropertyId(propid)) {
        var propertyId = convertToViewEditorPropertyId(propid, typeid);
        if(propertyId != propid) {
          alert(propid + ' < ' + propertyId);
        }
        obj[propertyId] = new Object();
        obj[propertyId].convertiblePropertyId = convertiblePropertyId(typeid, propertyId);
        obj[propertyId].isArrayValue = isArrayValue(propertyId);
      }
    }

    TypeInfoDefs.instance[typeid] = obj;
    return;
  }
}

// タイプ間で共通の属性ID
function convertiblePropertyId(typeId, propertyId) {

  switch (propertyId) {
  case 'type':
    // タイプ変換のグループごと
    switch (typeId) {
    case TYPE.FORM:
      return 'type.root';
    case TYPE.FRAME:
      return 'type.frame';
    case TYPE.PANEL:
    case TYPE.TABLE:
      return 'type.node';
    case TYPE.CELL:
      return 'type.cell';
    default:
      return 'type.leaf';
    }
    break;
    
  case 'height':
    // タイプ変換のグループごと
    switch (typeId) {
    case TYPE.IMAGE:
    case TYPE.APPLET:
    case TYPE.OBJECT:
    case TYPE.EMBED:
      return 'height.image';
    case TYPE.BUTTON:
    case TYPE.SUBMIT:
    case TYPE.RESET:
      return 'height.button';
    default:
      return 'height.usedefault';
    }
    break;

  case 'width':
    // タイプ変換のグループごと
    switch (typeId) {
    case TYPE.STRING:
    case TYPE.LABEL:
    case TYPE.TEXT:
    case TYPE.PASSWORD:
    case TYPE.TEXTAREA:
    case TYPE.FILE:
    case TYPE.LIST:
    case TYPE.COMBO:
    case TYPE.CHECK:
      return 'width.text';
    case TYPE.IMAGE:
    case TYPE.APPLET:
    case TYPE.OBJECT:
    case TYPE.EMBED:
      return 'width.image';
    case TYPE.BUTTON:
    case TYPE.SUBMIT:
    case TYPE.RESET:
      return 'width.button';
    default:
      return 'width.usedefault';
    }
    break;
  }
  return propertyId;
}

// 配列の属性か
function isArrayValue(propertyId) {
  var arrays = getArrayPropertyNames();
  if(arrays[propertyId]) {
    return true;
  }
  return false;

  function getArrayPropertyNames() {
    if(!isArrayValue.arrayPropertyNames) {
      isArrayValue.arrayPropertyNames = createArrayPropertyNames();
    }
    return isArrayValue.arrayPropertyNames;
  }
  
  function createArrayPropertyNames() {
    var arrayPropertyNames = {};
    arrayPropertyNames.cell = true;
    arrayPropertyNames.embedotherparams = true;
    arrayPropertyNames.embedparams = true;
    arrayPropertyNames.jsfilename = true;
    arrayPropertyNames.otherparams = true;
    arrayPropertyNames.params = true;
    arrayPropertyNames.meta = true;
    arrayPropertyNames.acckey = true;
    arrayPropertyNames.attributes = true;
    arrayPropertyNames.embedattributes = true;
    arrayPropertyNames.option = true;
    return arrayPropertyNames;
  }

}
  
// 互換性のある属性を返す
function getConvertiblePropertyId(fromPropertyId, fromTypeId, toTypeId) {
  
  //タイプが同じなのでプロパティ名も同じ
  if(fromTypeId == toTypeId) return fromPropertyId;
  
  //  タイプ間互換プロパティID
  var convertiblePropertyId = getPropertyInfoDef(fromTypeId,fromPropertyId).convertiblePropertyId;
  
  // 互換性のある（convertiblePropertyIdが同一の）属性を検索
  for(var toPropertyId in getTypeInfoDef(toTypeId)) {
    if(convertiblePropertyId == getPropertyInfoDef(toTypeId,toPropertyId).convertiblePropertyId) {
      return toPropertyId;
    }
  }

  // 互換性のある属性なし
  return '';
}


////
function isValidItemType(typeid) {
  if(getPropertyEditTypes()[typeid]) {
    return true;
  }
  return false;
}

/**
 * 属性編集タイプを取得する
 */
function getPropertyEditType(typeid) {
  var types = getPropertyEditTypes();
  if(!types[typeid]) {
    //alert('type ' + typeid + ' is undefined. (getPropertyEditType)');
    throw createError('type "' + typeid + '" is undefined.', 'VwMasterDataSet.js', 'getPropertyEditType');
  }
  return types[typeid];
}

/**
 * 属性編集タイプを取得する
 */
function getPropertyEditTypes() {
  if(!PropertyEditTypes.instance) {
    PropertyEditTypes.instance = new PropertyEditTypes;
  }
  return PropertyEditTypes.instance;
}

/**
 * 属性編集タイプ
 */
function PropertyEditTypes() {
  
  initPropertyEditItemType();

  for(var i in TYPE) {
    if(i == 'CELL') continue;
    this[TYPE[i]] = new PropertyEditItemType;
  }

  // タイプ別定義（追加 or オーバーライド）

  // formのtypeは変更不可
  this.form.type = new PropertyEditType('type', 'text/readonly', 'itemtype');

  this.form[PREVIEWPROPERTYID] = new PropertyEditType(PREVIEWPROPERTYID, EDITTYPE.LONGTEXT, 'previewsetting');
  
  // string,labelでは fieldvalueをテキストと表示する
  this.string.fieldvalue = new PropertyEditType('fieldvalue', 'text', 'text');
  this.label.fieldvalue = this.string.fieldvalue;

  // hideでは fieldvalueを値と表示する
  //this.hide.fieldvalue = new PropertyEditType('fieldvalue', 'text', 'value');

  // checkでは labeltextをテキストと表示する
  //this.check.labeltext = new PropertyEditType('labeltext', 'text', 'text');


  // button,submit,resetでは labeltextをラベルと表示する
  //this.button.labeltext = new PropertyEditType('labeltext', 'text', 'buttonlabel');
  //this.submit.labeltext = this.button.labeltext;
  //this.reset.labeltext = this.button.labeltext;

  // image,button,submit,resetでは srcを画像ファイルと表示する
  this.image.src = new PropertyEditType('src', 'image', 'imagesrc');
  this.button.src = new PropertyEditType('src', 'image', 'imagesrc');
  this.submit.src = new PropertyEditType('src', 'image', 'imagesrc');
  this.reset.src = new PropertyEditType('src', 'image', 'imagesrc');

  // iframeでは srcをフレームソースと表示する
  this.iframe.src = new PropertyEditType('src', 'longtext', 'framesrc');

  /**
   * PropertyEditItemTypeBaseをタイプ分生成しないようにプロトタイプとして使用するためのオブジェクト
   */
  function PropertyEditItemType() {
  }
  
  /**
   * PropertyEditItemTypeBaseをタイプ分生成しないようにプロトタイプとして使用する
   */
  function initPropertyEditItemType() {
    if(!PropertyEditItemType.PropertyEditItemTypeInitialized) {
      PropertyEditItemType.prototype = new PropertyEditItemTypeBase();
      PropertyEditItemType.PropertyEditItemTypeInitialized = true;
    }
  }
}

/**
 * 属性編集タイプ ベースオブジェクト
 */
function PropertyEditItemTypeBase() {
  
  if(!PropertyEditItemTypeBase.PropertyEditItemTypeBaseInitialized) {
    PropertyEditItemTypeBase.prototype.getId = _getId;
    PropertyEditItemTypeBase.prototype.getEditTypeId = _getEditTypeId;
    PropertyEditItemTypeBase.prototype.getLabelId = _getLabelId;
    PropertyEditItemTypeBase.prototype.getSaveId = _getSaveId;
    PropertyEditItemTypeBase.prototype.isReadonly = _isReadonly;
    PropertyEditItemTypeBase.prototype.toString = _toString;
    PropertyEditItemTypeBase.PropertyEditItemTypeBaseInitialized = true;
  }
  
  /* this.<初期設定で指定する名前> = 
   *  new PropertyEditType('属性ID'(View定義ツール上での), 
   *                       '属性編集タイプ' (デフォルト=属性ID),
   *                       '属性名称ID' (デフォルト=属性ID));
   */ 

  this.pagetitle  = new PropertyEditType('pagetitle', 'text');
  this.pagewidth  = new PropertyEditType('pagewidth', 'number');
  this.pageheight = new PropertyEditType('pageheight', 'number');
  this.action     = new PropertyEditType('action', 'text');
  this.method     = new PropertyEditType('method', 'select');
  this.enctype    = new PropertyEditType('enctype', 'select');
  this.textcolor  = new PropertyEditType('textcolor', 'color');
  this.linkcolor  = new PropertyEditType('linkcolor', 'color');
  this.vlinkcolor = new PropertyEditType('vlinkcolor', 'color');
  this.alinkcolor = new PropertyEditType('alinkcolor', 'color');
  this.jsfilename = new PropertyEditType('jsfilename', 'jsfile', 'jsfile');
  this.meta       = new PropertyEditType('meta');
  this.onload     = new PropertyEditType('onload', 'event');
  this.onunload   = new PropertyEditType('onunload', 'event');
  this.onsubmit   = new PropertyEditType('onsubmit', 'event');
  this.onreset    = new PropertyEditType('onreset', 'event');

  this.colsrows       = new PropertyEditType('colsrows', HIDDEN);
  this.direction      = new PropertyEditType('direction', 'select');
  this.frameflag      = new PropertyEditType('frameflag', HIDDEN);
  this.framename      = new PropertyEditType('framename', 'ascii');
  this.frameresize    = new PropertyEditType('frameresize', 'check');
  this.framescrolling = new PropertyEditType('framescrolling', 'select');
  this.framesrc       = new PropertyEditType('framesrc', 'longtext');

  this.tablemode           = new PropertyEditType('tablemode', 'select');
  this.tablecols           = new PropertyEditType('tablecols', 'number');
  this.tablerows           = new PropertyEditType('tablerows', 'number');
  this.maxlines            = new PropertyEditType('maxlines', 'number');
  this.titlecols           = new PropertyEditType('titlecols', 'check');
  this.titlerows           = new PropertyEditType('titlerows', 'check');
  this.titlerowvanishing   = new PropertyEditType('titlerowvanishing', 'check');
  this.corner              = new PropertyEditType('corner', 'select');
  this.caption             = new PropertyEditType('caption', 'text');
  this.captionfontsize     = new PropertyEditType('captionfontsize', 'number');
  this.captionfontcolor    = new PropertyEditType('captionfontcolor', 'color');
  this.captionalign        = new PropertyEditType('captionalign', 'select');
  this.cellspacing         = new PropertyEditType('cellspacing', 'number');
  this.cellpadding         = new PropertyEditType('cellpadding', 'number');
  this.tdborderwidth       = new PropertyEditType('tdborderwidth', 'number');
  this.tdborderstyle       = new PropertyEditType('tdborderstyle', 'select');
  this.tdbordercolor       = new PropertyEditType('tdbordercolor', 'color');
  this.tdstyle             = new PropertyEditType('tdstyle', 'longtext');
  this.titlerowborderwidth = new PropertyEditType('titlerowborderwidth', 'number');
  this.titlerowborderstyle = new PropertyEditType('titlerowborderstyle', 'select');
  this.titlerowbordercolor = new PropertyEditType('titlerowbordercolor', 'color');
  this.titlerowcolor       = new PropertyEditType('titlerowcolor', 'color');
  this.titlerowstyle       = new PropertyEditType('titlerowstyle', 'longtext');
  this.titlecolborderwidth = new PropertyEditType('titlecolborderwidth', 'number');
  this.titlecolborderstyle = new PropertyEditType('titlecolborderstyle', 'select');
  this.titlecolbordercolor = new PropertyEditType('titlecolbordercolor', 'color');
  this.titlecolcolor       = new PropertyEditType('titlecolcolor', 'color');
  this.titlecolstyle       = new PropertyEditType('titlecolstyle', 'longtext');
  this.cellvisibility      = new PropertyEditType('cellvisibility', 'check');
  this.cellrow             = new PropertyEditType('cellrow', 'number/readonly');
  this.cellcol             = new PropertyEditType('cellcol', 'number/readonly');
  this.cellwidth           = new PropertyEditType('cellwidth', 'number');
  this.cellheight          = new PropertyEditType('cellheight', 'number');
  this.cellbordercolor     = new PropertyEditType('cellbordercolor', 'color');
  this.cellbackgroundcolor = new PropertyEditType('cellbackgroundcolor', 'color');
  this.cellbackgroundimage = new PropertyEditType('cellbackgroundimage', 'image');
  this.cellstyle           = new PropertyEditType('cellstyle', 'longtext');

  this.type             = new PropertyEditType('type', 'type', 'itemtype');
  this.name             = new PropertyEditType('name', 'ascii', 'itemid');
  this.groupid          = new PropertyEditType('groupid', 'ascii');
  this.fieldid          = new PropertyEditType('fieldid', 'ascii');
  this.top              = new PropertyEditType('top', 'number');
  this.left             = new PropertyEditType('left', 'number');
  this.visibility       = new PropertyEditType('visibility', 'check');
  this.width            = new PropertyEditType('width', 'number');
  this.height           = new PropertyEditType('height', 'number');
  this.locationfixing   = new PropertyEditType('locationfixing', 'check');
  this.thickness        = new PropertyEditType('thickness', 'number');
  this.textcols         = new PropertyEditType('textcols', 'number');
  this.textrows         = new PropertyEditType('textrows', 'number');
  this.framename        = new PropertyEditType('framename', 'ascii');
  this.src              = new PropertyEditType('src', 'longtext');
  this.imagewidth       = new PropertyEditType('imagewidth', 'number');
  this.imageheight      = new PropertyEditType('imageheight', 'number');
  this.imageposition    = new PropertyEditType('imageposition', 'select');
  this.classid          = new PropertyEditType('classid', 'longtext');
  this.code             = new PropertyEditType('code', 'text');
  this.codebase         = new PropertyEditType('codebase', 'longtext');
  this.alt              = new PropertyEditType('alt', 'text');
  this.archive          = new PropertyEditType('archive', 'longtext');
  this.title            = new PropertyEditType('title', 'text');
  this.labeltext        = new PropertyEditType('labeltext', 'text');
  this.tableclass       = new PropertyEditType('tableclass', 'text');
  this.textid           = new PropertyEditType('textid', 'text');
  this.tablerowclass    = new PropertyEditType('tablerowclass', 'text');
  this.tablecolclass    = new PropertyEditType('tablecolclass', 'text');
  this.fieldvalue       = new PropertyEditType('fieldvalue', 'text', 'initialvalue');
  this.optionvalue      = new PropertyEditType('optionvalue', 'text', 'value');
  this.optionvalue0     = new PropertyEditType('optionvalue0', 'text', 'value0');
  this.maxlength        = new PropertyEditType('maxlength', 'number');
  this.selectmode       = new PropertyEditType('selectmode', 'check');
  this.option           = new PropertyEditType('option');
  this.optioncols       = new PropertyEditType('optioncols', 'number');
  this.optionrows       = new PropertyEditType('optionrows', 'number');
  this.listsize         = new PropertyEditType('listsize', 'number');
  this.tooltip          = new PropertyEditType('tooltip', 'text');
  this.fontsize         = new PropertyEditType('fontsize', 'number');
  this.fontfamily       = new PropertyEditType('fontfamily', 'select');
  this.fontweight       = new PropertyEditType('fontweight', 'select');
  this.fontstyle        = new PropertyEditType('fontstyle', 'check');
  this.underline        = new PropertyEditType('underline', 'check');
  this.borderwidth      = new PropertyEditType('borderwidth', 'number');
  this.borderstyle      = new PropertyEditType('borderstyle', 'select');
  this.bordercolor      = new PropertyEditType('bordercolor', 'color');
  this.heightc          = new PropertyEditType('heightc', 'number');
  this.heightt          = new PropertyEditType('heightt', 'number');
  this.backgroundcolorr = new PropertyEditType('backgroundcolorr', 'color');
  this.backgroundcolort = new PropertyEditType('backgroundcolort', 'color');
  this.fontcolor        = new PropertyEditType('fontcolor', 'color');
  this.backgroundcolor  = new PropertyEditType('backgroundcolor', 'color');
  this.backgroundimage  = new PropertyEditType('backgroundimage', 'image');
  this.hrcolor          = new PropertyEditType('hrcolor', 'color');
  this.align            = new PropertyEditType('align', 'select');
  this.editmode         = new PropertyEditType('editmode', 'check');
  this.link             = new PropertyEditType('link', 'link');
  this.target           = new PropertyEditType('target', 'ascii');
  this.shade            = new PropertyEditType('shade', 'check');
  this.scrolling        = new PropertyEditType('scrolling', 'select', 'framescrolling');
  this.tabindex         = new PropertyEditType('tabindex', 'number');
  this.accesskey        = new PropertyEditType('accesskey', 'select');
  this.acckey           = new PropertyEditType('acckey', 'hidden');
  this.style            = new PropertyEditType('style', 'longtext');
  this.params           = new PropertyEditType('params', 'parameter');
  this.attributes       = new PropertyEditType('attributes', 'parameter');
  this.embedsrc         = new PropertyEditType('embedsrc', 'longtext');
  this.embedparams      = new PropertyEditType('embedparams', 'parameter');
  this.embedattributes  = new PropertyEditType('embedattributes', 'parameter');
  this.onclick          = new PropertyEditType('onclick', 'event');
  this.ondblclick       = new PropertyEditType('ondblclick', 'event');
  this.onmousedown      = new PropertyEditType('onmousedown', 'event');
  this.onmouseup        = new PropertyEditType('onmouseup', 'event');
  this.onmouseover      = new PropertyEditType('onmouseover', 'event');
  this.onmouseout       = new PropertyEditType('onmouseout', 'event');
  this.onmousemove      = new PropertyEditType('onmousemove', 'event');
  this.onkeypress       = new PropertyEditType('onkeypress', 'event');
  this.onkeydown        = new PropertyEditType('onkeydown', 'event');
  this.onkeyup          = new PropertyEditType('onkeyup', 'event');
  this.onfocus          = new PropertyEditType('onfocus', 'event');
  this.onblur           = new PropertyEditType('onblur', 'event');
  this.onchange         = new PropertyEditType('onchange', 'event');

  this['customize-visibility']   = new PropertyEditType('customize-visibility', EDITTYPE.CUSTOMIZE, 'visibility');
  this['customize-mobility']     = new PropertyEditType('customize-mobility', EDITTYPE.CUSTOMIZE, 'location');
  this['customize-defaultvalue'] = new PropertyEditType('customize-defaultvalue', EDITTYPE.CUSTOMIZE, 'initialvalue');
  this['customize-maxlines']     = new PropertyEditType('customize-maxlines', EDITTYPE.CUSTOMIZE, 'maxlines');

  function _getId(propertyId) {
    if(this[propertyId]) {
      return this[propertyId].getId();
    }
    
    return propertyId;
  }

  function _getEditTypeId(propertyId) {
    if(this[propertyId]) {
      return this[propertyId].getEditTypeId();
    }
    return propertyId;
  }
  
  function _getLabelId(propertyId) {
    if(this[propertyId]) {
      return this[propertyId].getLabelId();
    }
    return propertyId;
  }
  
  function _getSaveId(propertyId) {
    if(this[propertyId]) {
      return this[propertyId].getSaveId();
    }
    return propertyId;
  }

  function _isReadonly(propertyId) {
    if(this[propertyId]) {
      return this[propertyId].isReadonly();
    }
    return propertyId;
  }

  function _toString() {
    return '[PropertyEditItemTypeBase]';
  }

}

/**
 * 属性編集タイプ
 */
function PropertyEditType(id, editTypeId, labelId, saveId) {
  this.id = id;
  if(editTypeId) {
    this.editTypeId = editTypeId;
  }
  if(labelId) {
    this.labelId = labelId;
  }
  if(saveId) {
    this.saveId = saveId;
  }

  if(!PropertyEditType.PropertyEditTypeInitialized) {
    PropertyEditType.prototype.getId = _getId;
    PropertyEditType.prototype.getEditTypeId = _getEditTypeId;
    PropertyEditType.prototype.getLabelId = _getLabelId;
    PropertyEditType.prototype.getSaveId = _getSaveId;
    PropertyEditType.prototype.isReadonly = _isReadonly;
    PropertyEditType.PropertyEditTypeInitialized = true;
  }

  function _getId() {
    return this.id;
  }

  function _getEditTypeId() {
    return val(this.editTypeId, this.id);
  }
    
  function _getLabelId() {
    return val(this.labelId, this.id);
  }

  function _getSaveId() {
    return val(this.saveId, this.id);
  }

  function _isReadonly() {
    switch(this.getEditTypeId()) {
    case EDITTYPE.TEXT_READONLY :
    case EDITTYPE.NUMBER_READONLY :
    case EDITTYPE.CHECK_READONLY :
    case EDITTYPE.COLOR_READONLY :
      return true;
    }
    return false;
  }

  function val(p1, p2) {
    if(p1) {
      return p1;
    }
    return p2;
  }
}

/*
 * セルのIDを作成
 */
function getCellId(tableid, row, col) {
  if(!row) row = '1';
  if(!col) col = '1';
  //return tableid + '_cell_' + row + '_' + col;
  return tableid + '-' + row + '-' + col;
}

/*
 * セルのIDを作成
 */
function getCellName(tableid, row, col) {
  return getCellId(tableid, row, col);
}

/*
 * セルのIDかどうか
 */
function isCellId(cellid, tableid) {
  if(tableid) {
    //if(cellid.indexOf(tableid + '_cell_') == 0) {
    if(cellid.indexOf(tableid + '-') == 0) {
      return true;
    }
  } else {
    //if(cellid.indexOf('_cell_') > 0) {
    if(cellid.indexOf('-') > 0) {
      return true;
    }
  }
  return false;
}

/**
 * セルのIDから行を取得
 */
function getRowFromCellId(cellid) {
  var spl = cellid.split('-');
  if(spl.length == 3) {
    return spl[1];
  }
  return 0;
}

/**
 * セルのIDから列を取得
 */
function getColFromCellId(cellid) {
  var spl = cellid.split('-');
  if(spl.length == 3) {
    return spl[2];
  }
  return 0;
}

/*
 * セルのプロパティIDかどうか
 */
function isCellPropertyId(propertyid) {
  if(propertyid) {
    if(propertyid.indexOf('cell') == 0) {
      if(propertyid == 'cellspacing' ||
         propertyid == 'cellpadding') {
        return false;
      }
      return true;
    }
  }
  return false;
}

/**
 * Viewでの属性名をView定義ツールの属性名に変換する定義
 */
function ConvertLoadProperties() {
  this.common   = {bgcolor:'backgroundcolor', background:'backgroundimage', lnk:'link', cell:'option', maxlen:'maxlength'};
  this.form     = {caption:'pagetitle', width:'pagewidth', height:'pageheight'};
  this.table    = {maxcols:'tablecols', maxrows:'tablerows', mode:'tablemode', fontsizet:'captionfontsize', fontcolor:'captionfontcolor'};
  this.cell     = {visibility:'cellvisibility', row:'cellrow', col:'cellcol', width:'cellwidth', height:'cellheight', bgcolor:'cellbackgroundcolor', background:'cellbackgroundimage', bordercolor:'cellbordercolor', borderwidth:'cellborderwidth', style:'cellstyle'};
  this.panel    = {};
  this.string   = {text:'fieldvalue'};
  this.label    = this.string;
  this.text     = {text:'fieldvalue'};
  this.password = this.text;
  this.file     = this.text;
  this.textarea = this.text;
  this.button   = {text:'labeltext'};
  this.submit   = this.button;
  this.reset    = this.button;
  this.image    = {border:'borderwidth'};
  this.hide     = {value:'fieldvalue'};
  this.list     = {value:'fieldvalue', size:'listsize'};
  this.combo    = this.list;
  this.radio    = {value:'fieldvalue', maxcols:'optioncols', maxrows:'optionrows',bgcolorr:'backgroundcolorr',bgcolort:'backgroundcolort'};

  this.check    = {selvalue:'fieldvalue', value:'optionvalue', value0:'optionvalue0', text:'labeltext',bgcolort:'backgroundcolort'};
  
  
  this.embed    = {otherparams:'attributes', embedotherparams:'embedattributes'};
  this.applet   = this.embed;
  this.object   = this.embed;
  this.iframe   = {};
  this.hr       = {size:'thickness'};

}

/* View → View定義ツール 変換定義 */
var m_convertLoadProperties = createConvertLoadProperties();

/* View定義ツール → View 変換定義 */
var m_convertSaveProperties = createConvertSaveProperties();

/* 
 * View → View定義ツール 変換定義 
 */
function createConvertLoadProperties() {
  return new ConvertLoadProperties();
}

/* 
 * View定義ツール → View 変換定義 
 */
function createConvertSaveProperties() {
  var convertSaveProperties = {};
  for(var type in m_convertLoadProperties) {
    convertSaveProperties[type] = oposite(m_convertLoadProperties[type]);
  }
  return convertSaveProperties;

  function oposite(loadType) {
    var props = {};
    for(var prop in loadType) {
      props[loadType[prop]] = prop;
    }
    return props;
  }
}

/* 
 * 変換定義を使用して変換する
 */
function convertPropertyByConvertObject(obj, propertyId, typeId){
  if(obj.common && obj.common[propertyId]) {
    return obj.common[propertyId];
  }

  if(typeId) {
    var objType = obj[typeId];
    if(objType && objType[propertyId]) {
      return objType[propertyId];
    }
  }

  return propertyId;
}

/**
 * 編集中に使用している変形したプロパティ名称を登録用に変換
 * @param  :strProperty 文字型 プロパティ文字列
 *          strType 文字型 オブジェクトのタイプ
 * @return :変換後のプロパティ文字列
 */
function convertToViewPropertyId(strProperty, strType){
  return convertPropertyByConvertObject(m_convertSaveProperties, strProperty, strType);
}

/**
 * 編集中に使用している変形したプロパティ名称を登録用に変換
 * @param  :strProperty 文字型 プロパティ文字列
 *          strType 文字型 オブジェクトのタイプ
 * @return :変換後のプロパティ文字列
 */
function convertToViewEditorPropertyId(strProperty, strType){
  return convertPropertyByConvertObject(m_convertLoadProperties, strProperty, strType);
}

/**
 * Viewのプロパティとして正しいか
 */
function isValidViewProperty(typeid, propertyid) {

  var prefEdit = pref.edit[typeid];
  if(!prefEdit) {
    alert(typeid + ' is undefined.');
    log.warn('isValidViewProperty : ' + typeid + ' is undefined.');
    return false;
    //throw createError('type "' + typeid + '" is undefined', 'VwMasterDataSet.js', 'isValidViewProperty');
  }

  var toolPropertyId = convertPropertyByConvertObject(m_convertLoadProperties, propertyid, typeid);
  
  if(!prefEdit.isProperty(toolPropertyId)) {
    alert(typeid + '.' + propertyid + ' is unknown.');
    log.warn('isValidViewProperty : ' + typeid + '.' + propertyid + ' is unknown.');
    return false;
    //throw createError('property "' + typeid + '.' + propertyid + '" is unknown', 'VwMasterDataSet.js', 'isValidViewProperty');
  }

  if(!prefEdit.get(toolPropertyId)) {
    return false;
  }
  return true;
}

/*
 * 属性変換定義
 */
var m_propertyConversion = createPropertyConversionObject();
function createPropertyConversionObject() {

  var obj = {};

  var borderstyle = {
    none     : 'none',
    dotted   : 'dotted',
    dashed   : 'dashed',
    solid    : 'solid',
    'double' : 'double',
    groove   : 'groove',
    ridge    : 'ridge',
    inset    : 'inset',
    outset   : 'outset'
  }
  obj.borderstyle  = new PropertyConversion(borderstyle, 'BORDERFSTYLE_', '');
  obj.tdborderstyle = obj.borderstyle;

  var method = {
    post   : 'post',
    get    : 'get',
    frame  : 'frame'
  }
  obj.method       = new PropertyConversion(method, true, 'post');

  var align = {
    left   : 'left',
    center : 'center',
    right  : 'right'
  }
  obj.align        = new PropertyConversion(align, true, '');

/*  
  // 読み込み時に CAPTIONALIGN_xxx にも対応
  var captionalign = {
    top    : 'top',
    right  : 'right',
    bottom : 'bottom',
    left   : 'left'
  }
  obj.captionalign = new PropertyConversion(captionalign, 'CAPTIONALIGN_', '');
*/
  var captionalign = {
    CAPTIONALIGN_TOP    : 'top',
    CAPTIONALIGN_RIGHT  : 'right',
    CAPTIONALIGN_BOTTOM : 'bottom',
    CAPTIONALIGN_LEFT   : 'left'
  }
  obj.captionalign = new PropertyConversion(captionalign, true, 'top');
  
  var tablemode = {
    MODE_SIMPLE : 'MODE_SIMPLE',
    MODE_COPY   : 'MODE_COPY',
    MODE_LINE   : 'MODE_LINE'
  }
  obj.tablemode    = new PropertyConversion(tablemode, true, 'MODE_SIMPLE');
  
  var corner = {
    CORNER_COL : 'CORNER_COL',
    CORNER_ROW : 'CORNER_ROW'
  }
  obj.corner       = new PropertyConversion(corner, true, 'CORNER_COL');

  return obj;
}

/**
 * ViewEditorでの属性値に変換
 */
function convertToViewEditorPropertyValue(value, propertyId) {
  var conversionId = propertyId
  var conv = m_propertyConversion[conversionId];
  if(!conv) return value;
  return conv.convert(value);
}

/**
 * Viewでの属性値に変換
 */
function convertToViewPropertyValue(value, propertyId) {
  var conversionId = propertyId
  var conv = m_propertyConversion[conversionId];
  if(!conv) return value;
  return conv.reverse(value);
}

/**
 * 属性値変換
 */
function PropertyConversion(convertsionObj, conversiontype, defaultvalue) {

  if(convertsionObj) {
    this.convertsionObj = convertsionObj;
  }
  if(conversiontype) {
    this.ignorecase = true;
    if(typeof(conversiontype) == 'string') {
      this.valueprefix = conversiontype;
    }
  }
  if(defaultvalue) {
    this.defaultvalue = defaultvalue;
  }
  
  /**
   * Viewでの値 -> ViewEditorでの値
   */
  PropertyConversion.prototype.convert = convert;
  function convert(value) {
    if(this.valueprefix) {
      if(this.ignorecase) {
        if(value.toLowerCase().indexOf(this.valueprefix.toLowerCase()) == 0) {
          value = value.substring(this.valueprefix.length);
        }
      } else {
        if(value.indexOf(this.valueprefix) == 0) {
          value = value.substring(this.valueprefix.length);
        }
      }
    }

    if(this.ignorecase) {
      if(this.convertsionObj[value.toLowerCase()] != undefined) {
        return this.convertsionObj[value.toLowerCase()];
      }
      if(this.convertsionObj[value.toUpperCase()] != undefined) {
        return this.convertsionObj[value.toUpperCase()];
      }
    } else {
      if(this.convertsionObj[value] != undefined) {
        return this.convertsionObj[value];
      }
    }

    if(this.defaultvalue != undefined) {
      return this.defaultvalue;
    }
    return value;
  }

  /**
   * ViewEditorでの値 -> Viewでの値
   */
  PropertyConversion.prototype.reverse = reverse;
  function reverse(value) {
    for(var p in this.convertsionObj) {
      var convertedValue = this.convertsionObj[p];
      if(convertedValue == value) {
        return p;
      }
    }
    return value;
  }
}
/**/


/**
 *
 */
function getCustomizeInfo(type){
  if(!getCustomizeInfo.info) {
    getCustomizeInfo.info = {};
  }
  var obj = getCustomizeInfo.info[type];
  if(!obj) {
    obj = getCustomizeInfo.info[type] = {};
    setCustomProperties(obj, type);
  }
  return obj;
}

/**
 *
 */
function setCustomProperties(obj, type){
  var ids = [];
  var labels = [];
  var propertylist = pref.edit[type];
  var propertyEditType = getPropertyEditType(type);
  for(var propertyId in propertylist.enumerator()) {
    var editTypeId = propertylist.get(propertyId);
    if(editTypeId == USE) {
      var editTypeId = propertyEditType.getEditTypeId(propertyId);
    }
    if(editTypeId == EDITTYPE.CUSTOMIZE) {
      ids[ids.length] = propertyId;
      labels[labels.length] = propertyEditType.getLabelId(propertyId);
    }
  }
  
  obj.customProperties        = ids;
  obj.customPropertiesLiteral = labels;
}

/**
 * 実際の表示に使用する属性編集タイプ
 */
function getDisplayEditType(typeId, propertyId, spcEditType){
  var editType = getPropertyEditType(typeId).getEditTypeId(propertyId);
  if(editType == EDITTYPE.CUSTOMIZE) {
    return editType;
  }

  if(spcEditType == undefined) {
    spcEditType = pref.editarea[typeId].get(propertyId);
  }
  switch(spcEditType) {
  case READONLY:
    if(editType == EDITTYPE.NUMBER || editType == EDITTYPE.NUMBER_READONLY) {
      editType = EDITTYPE.NUMBER_READONLY;

    } else if(editType == EDITTYPE.COLOR || editType == EDITTYPE.COLOR_READONLY) {
      editType = EDITTYPE.COLOR_READONLY;

    } else if(editType == EDITTYPE.CHECK || editType == EDITTYPE.CHECK_READONLY) {
      editType = EDITTYPE.CHECK_READONLY;

    } else {
      editType = EDITTYPE.TEXT_READONLY;
    }
    break;

  case USE:
    break;

  default:
    editType = spcEditType;
  }
  return editType;
}

function addPropertyName(propertyId, name){
  setLiteral('property.' + propertyId, name);
}

