package sample4;

import jp.co.bbs.unit.tools.html.*;

import org.apache.poi.hssf.usermodel.*;
// poi-scratchpad-xxx.jar
import org.apache.poi.hslf.model.*;
import org.apache.poi.hslf.usermodel.*;

import java.io.*;
import java.util.Arrays;
import java.util.Iterator;
import java.util.TreeSet;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;


import org.apache.log4j.Logger;

public class DownloadSample2 extends PageElement {
	private static Logger log = Logger.getLogger(DownloadSample2.class);

	// �p�����[�^
	private String keyword = null;
	
	private String path = null;

	public void setKeyword(String keyword) {
		this.keyword = keyword;
	}

	public void setPath(String path) {
		this.path = path;
	}

	private static String APPLICATION_PATH_KEY = "APPLICATION_PATH";

	@Override
	public String toString() {

		StringBuffer sb = new StringBuffer();

		boolean request = false;
		if (keyword == null) {
			keyword = getRequest().getParameter("keyword");
			if (keyword != null) {
				request = true;
			}
		}
		
		if (!request) {
//			sb.append("<div id=\"documentsearch\" style=\"width:")
//					.append(getWidth()).append("px;");
			sb.append("<div id=\"documentsearch\" class=\"scrollbox\" style=\"width:")
			.append(getWidth() + 2).append("px;");
			sb.append("height:").append(getHeight()).append("px;");
			sb.append("overflow:scroll;");
			sb.append("\">");
		}
		String[] widths = {"30", "240", "340", "60"};
		sb.append("<table class=\"vw-table\" style=\"border-style-left:none;border-style-top:none;\">\n");
		sb.append("<col width=\"" + widths[0] + "\">");
		sb.append("<col width=\"" + widths[1] + "\">");
		sb.append("<col width=\"" + widths[2] + "\">");
		sb.append("<col width=\"" + widths[3] + "\">");
		sb.append("<tr>");
		sb.append("<td class=\"vw-cell linehead\">");
		sb.append("No.");
		sb.append("</td>");
		sb.append("<td class=\"vw-cell linehead\">");
		sb.append("�t�@�C����");
		sb.append("</td>");
		sb.append("<td class=\"vw-cell linehead\">");
		sb.append("�e�L�X�g");
		sb.append("</td>");
		sb.append("<td class=\"vw-cell linehead\">");
		sb.append("�y�[�WNo.");
		sb.append("</td>");
		sb.append("</tr>");
		File documentPath = null;
		if (path != null) {
			documentPath = new File(path);
		}
		if (documentPath == null || !documentPath.isDirectory()) {
			String applicationPath = (String) getSessionData().get(
				APPLICATION_PATH_KEY);
			if (new File(applicationPath, "mbbdoc").isDirectory()) {
				documentPath = new File(applicationPath, "mbbdoc");
			} else {
				documentPath = new File(new File(applicationPath).getParentFile()
						.getParentFile(), "mbbdoc");
			}
		}
		if (keyword != null) {
			File[] documentFiles = documentPath.listFiles();
			TreeSet files = new TreeSet(Arrays.asList(documentFiles)); // �\�[�g����
			int cnt = 0;
			keyword = keyword.toUpperCase();
			if (keyword.length() == 0) {
				// �S���\��
				for (Iterator ite = files.iterator(); ite.hasNext();) {
					File file = (File) ite.next();
					String fileName = file.getName();
					createLine(sb, widths, ++cnt, fileName, "", 0);
				}
				// java�̕W��ZIP�͓��{��t�@�C�����ɑΉ����Ă��Ȃ�
				//createLine(sb, widths, ++cnt, "*", "", 0);
			} else {
				// �����\��
				for (Iterator ite = files.iterator(); ite.hasNext();) {
					File file = (File) ite.next();
					BufferedReader br = null;
					try {
						br = new BufferedReader(getOfficeTextReader(file));
						String line = null;
						while ((line = br.readLine()) != null) {
							if (line.startsWith("[") || line.indexOf(":") == -1) {
								continue;
							}
							int p1 = line.indexOf(":");
							int p2 = line.indexOf(":", p1 + 1);
							if (p2 == -1) {
								continue;
							}
							String text = line.substring(p2 + 1);
							String fileName = line.substring(0, p1);
							String pageNo = line.substring(p1 + 1, p2);
							if (text.toUpperCase().indexOf(keyword) != -1) {
								createLine(sb, widths, ++cnt, fileName, getFocusText(text, keyword), Integer.parseInt(pageNo));
							}
						}
					} catch (Exception e) {
						e.printStackTrace();
						createLine(sb, widths, ++cnt, file.getName(), e.getMessage(), 0);
					} finally {
						if (br != null) {
							try {
								br.close();
							} catch (Exception e) {
							}
						}
					}
				}
			}
		}
		sb.append("</table>");
		if (!request) {
			sb.append("\n</div>\n");
		}

		return sb.toString();

	}
	
	private Reader getOfficeTextReader(File file) throws IOException {
		String inputFileName = file.getName();
		CharArrayWriter caw = new CharArrayWriter();
		if (inputFileName.toUpperCase().endsWith(".PPT")) {
			BufferedInputStream fis = new BufferedInputStream(new FileInputStream(file));
			SlideShow slideShow = new SlideShow(fis);
			Slide[] slides = slideShow.getSlides();
			for (int i = 0; i < slides.length; ++i) {
				int pageNo = i + 1;
				caw.write("[page:" + pageNo + "]\r\n");
				Shape[] shapes = slides[i].getShapes();
				for (int j = 0; j < shapes.length; ++j) {
					if (shapes[j] instanceof TextBox) {
						String text = ((TextBox)shapes[j]).getText();
						if (text != null) {
							caw.write(inputFileName + ":" + pageNo + ":" + text.replaceAll("\r", "\r\n") + "\r\n");
						}
					}
				}
			}
			fis.close();
		} else if (inputFileName.toUpperCase().endsWith(".XLS")) {
			FileInputStream fis = new FileInputStream(file);
			HSSFWorkbook workbook = new HSSFWorkbook(fis);
			for (int i = 0; i < workbook.getNumberOfSheets(); ++i) {
				HSSFSheet sheet = workbook.getSheetAt(i);
				int sheetNo = i + 1;
				caw.write("[sheet:" + sheetNo + ":" + sheet.getSheetName() + "]\r\n");
				for (int j = sheet.getFirstRowNum(); j <= sheet.getLastRowNum(); ++j) {
					HSSFRow row = sheet.getRow(j);
					StringBuffer rowtext = new StringBuffer();
					if (row != null) {
						for (int k = 0;  k < row.getLastCellNum(); ++k) {
							HSSFCell cell = row.getCell(k);
							if (k > 0) {
								rowtext.append("\t");
							}
							if (cell != null) {
								cell.setCellType(HSSFCell.CELL_TYPE_STRING);
								rowtext.append(cell.getStringCellValue());
							}
						}
					}
					String text = rowtext.toString();
					if (text.length() == 0 && sheet.getFirstRowNum() == sheet.getLastRowNum()) {
						continue;
					}
					caw.write(inputFileName + ":" + sheetNo + ":" + text.replaceAll("\r", " ") + "\r\n");
				}
			}
			fis.close();
		}
		return new CharArrayReader(caw.toCharArray());
	}
	
	private void createLine(StringBuffer sb, String[] widths, int index, String fileName, String text, int pageNo) {
		sb.append("<tr>");
		sb.append("<td class=\"vw-cell linebody\" style=\"text-align:right;\">");
		sb.append("<div style=\"width:" + widths[0] + "px;\">");
		sb.append(index);
		sb.append("</div>");
		sb.append("</td>");
		sb.append("<td class=\"vw-cell linebody\">");
		sb.append("<div style=\"width:" + widths[1] + "px;\">");
		if (pageNo <= 0) {
			sb.append("<a href=\"appcontroller?PROCESSID=&JSPID=jsp/SysDownload&CLASSNAME=sample4.DownloadSample2&DOWNLOAD_FILE_NAME="
					+ encodeFileName(fileName)
					+ "\" target=\"_blank\">");
		} else {
			sb.append("<a href=\"appcontroller?PROCESSID=&JSPID=jsp/SysDownload&CLASSNAME=sample4.DownloadSample2&DOWNLOAD_FILE_NAME="
					+ encodeFileName(fileName)
					+ "#"
					+ pageNo
					+ "\" target=\"_blank\">");
		}
		if ("*".equals(fileName)) {
			sb.append("�S�Ă܂Ƃ߂ă_�E�����[�h");
		} else {
			sb.append(escape(fileName));
		}
		sb.append("</a>");
		sb.append("</div>");
		sb.append("</td>");
		sb.append("<td class=\"vw-cell linebody\">");
		sb.append("<div style=\"width:" + widths[2] + "px;\">");
		sb.append(text);
		sb.append("</div>");
		sb.append("</td>");
		sb.append("<td class=\"vw-cell linebody\" style=\"text-align:right;\">");
		sb.append("<div style=\"width:" + widths[3] + "px;\">");
		if (pageNo > 0) {
			sb.append(pageNo);
		}
		sb.append("</div>");
		sb.append("</td>");
		sb.append("</tr>");
	}

	private String getFocusText(String text, String keyword) {
		StringBuffer sb = new StringBuffer();
		int p = text.toUpperCase().indexOf(keyword.toUpperCase());
		while (p != -1) {
			sb.append(escape(text.substring(0, p)));
			sb.append("<b><u>");
			sb.append(escape(text.substring(p, p + keyword.length())));
			sb.append("</u></b>");
			text = text.substring(p + keyword.length());
			p = text.toUpperCase().indexOf(keyword.toUpperCase());
		}
		sb.append(text);
		return sb.toString();
	}

	private static String encodeFileName(String name) {
		StringBuffer sb = new StringBuffer();
		byte[] b = null;
		try {
			b = name.getBytes("UTF-8");
			for (int i = 0; i < b.length; ++i) {
				int h = b[i] & 0xff;
				if (h >= 0x30 && h <= 0x7f) {
					sb.append(Character.toString((char) h));
				} else {
					sb.append("%");
					String s = Integer.toHexString(h);
					if (s.length() == 1) {
						sb.append("0");
					}
					sb.append(s);
				}
			}
		} catch (Exception e) {
			return name;
		}
		return sb.toString();
	}

	@Override
	public boolean handle() {
		String downloadFileName = getRequestParameter("DOWNLOAD_FILE_NAME");
		log.info("downloadFileName=" + downloadFileName);
		String applicationPath = (String) getSessionData().get(
				APPLICATION_PATH_KEY);
		File documentPath = new File(new File(applicationPath).getParentFile()
				.getParentFile(), "mbbdoc");
		if (documentPath == null || !documentPath.isDirectory()) {
			if (new File(applicationPath, "mbbdoc").isDirectory()) {
				documentPath = new File(applicationPath, "mbbdoc");
			} else {
				documentPath = new File(new File(applicationPath).getParentFile()
						.getParentFile(), "mbbdoc");
			}
		}
		String fileName = new File(downloadFileName).getName();
		if (!"*".equals(fileName)) {
			// �P��t�@�C���̃_�E�����[�h
			File file = new File(documentPath, fileName);
			if (file.exists()) {
				response.setContentType("application/octet-stream");
				String ua = request.getHeader("User-Agent");
				try {
					if (ua != null && ua.indexOf("MSIE") != -1) {
						response.setHeader(
								"Content-Disposition",
								"inline; filename="
										+ java.net.URLEncoder.encode(fileName,
												"UTF-8"));
					} else {
						response.setHeader(
								"Content-Disposition",
								"attachment; filename="
										+ javax.mail.internet.MimeUtility
												.encodeWord(fileName,
														"ISO-2022-JP", "B"));
					}

				} catch (Exception e) {
					log.error("", e);
				}
				try {
					writeToResponse(file);
				} catch (IOException e) {
					log.error("", e);
				}
				return true;
			}
		} else {
			// �܂Ƃ߂ă_�E�����[�h
			// �����{��t�@�C�����ɑΉ����Ă��Ȃ��̂Ń{�c�E�E�E
			try {
				ZipOutputStream zos = new ZipOutputStream(response.getOutputStream());
				response.setHeader(
						"Content-Disposition",
						"attachment; filename=documents.zip");
				File[] documentFiles = documentPath.listFiles();
				TreeSet files = new TreeSet(Arrays.asList(documentFiles)); // �\�[�g����
				for (Iterator ite = files.iterator(); ite.hasNext();) {
					File file = (File) ite.next();
					String entryFileName = file.getName();
					if (!entryFileName.toUpperCase().endsWith(".PPT")) {
						continue;
					}
					ZipEntry ze = new ZipEntry(entryFileName);
					ze.setTime(file.lastModified());
					zos.putNextEntry(ze);
					writeTo(zos, file);
				}
				zos.finish();
				zos.close();
			} catch (IOException e) {
				log.error("", e);
			}
		}

		return false;
	}
	public static void main(String[] args) {
		DownloadSample2 ds2 = new DownloadSample2();
		ds2.setKeyword("AppController");
		ds2.setPath("C:/MBB/mbbtrial/mbbdoc");
		System.out.println(ds2.toString());
	}
}
