// SysMenu.js : SysMenu.jsp用Script
// confirmLogoutとimagefileは外部で定義されていること
var selectedColor = '#c0c0c0';
var autoScroll = true;

function logout_confirm() {
  var msg = confirmLogout;

  if(msg == "") {
    msg = "are you sure you want to logout?";
  }
  if(confirm(msg)) {
    return true;
  }
  return false;
}

function doImageChange(id){
  if(window.document.images[id].src.indexOf(imagefile[0]) != -1){
    window.document.images[id].src  = imagefile[1];
  }else{
    window.document.images[id].src  = imagefile[0];
  }
  return false;
}

function doFolderClick(id, img){
  var open = false;
  var folder = null;
  if(document.all){
    folder=document.all.item(id);
  }
  if(folder==null&&document.getElementById){
    folder=document.getElementById(id);
  }
  if(folder.style.display == "none"){
    folder.style.display = "";
    open = true;
  } else {
    folder.style.display = "none";
  }
  doImageChange(img);
  if(autoScroll&&open){
    var body_offsetHeight=document.body.offsetHeight;
    var body_scrollHeight=document.body.scrollHeight;
    var body_scrollTop=document.body.scrollTop;
    var top=folder.offsetTop;
    var p=folder.offsetParent;
    while(p!=null){
      top+=p.offsetTop;
      p=p.offsetParent;
    }
    var offsetTop=top-body_scrollTop;
    var belowspace=body_offsetHeight-offsetTop; // 画面下部の領域サイズ
    if(belowspace<200&&offsetTop>body_offsetHeight/2){
      //画面の半分より下で、下の猶予が無い場合
      var targetTop=document.body.scrollTop;
      if(folder.offsetHeight>body_offsetHeight/2-belowspace){
        targetTop += body_offsetHeight/2-belowspace;
      }else{
        targetTop += folder.offsetHeight;
      }
      _menuscrollinterval=setInterval('doScrollMenu('+targetTop+')',10);
    }
  }
  return false;
}

var _menuscrollinterval;

function doScrollMenu(scrollTop) {
  if(_menuscrollinterval==null){
    return;
  }
  var top=document.body.scrollTop;
  if(document.body.scrollTop<scrollTop) {
    document.body.scrollTop=top+10;
    if(document.body.scrollTop<=top) {
      clearInterval(_menuscrollinterval);
      _menuscrollinterval=null;
    }
  }else{
    clearInterval(_menuscrollinterval);
    _menuscrollinterval=null;
  }
}

function doItemClick(item,href,menuitemId) {
  if (selectedItem != null) {
    selectedItem.style.backgroundColor='';
  }
  item.style.backgroundColor=selectedColor;
  selectedItem = item;
  
  var evt;
  if(document.all||event) evt = event;
  var key = evt.keyCode;
  var target = item.target;
  if(!href){
    href = item.href;
  }
  if (evt && evt.ctrlKey) { /* ctrl */
    href = href.replace('?APPLICATIONID=','?APPLICATIONID=^');
  }
  if (target == 'main') {
    var mainframe = parent.main;
    if (!mainframe) mainframe = parent.frames[2];
    if (_sessionid) {
      if (href.indexOf("?") != -1) {
        href = href + '&_sessionid=' + _sessionid + '&_menu=1';
      } else {
        href = href + '?_sessionid=' + _sessionid + '&_menu=1';
      }
    }
    mainframe.location = href;
  } else {
    window.open(href, target, '');
  }
  return false;
}

function isFolderOpend(folder) {
  if(folder.parentNode){
    for(var i=0;i<folder.parentNode.childNodes.length;++i){
      if(folder.parentNode.childNodes[i].tagName=='DIV'){
        return folder.parentNode.childNodes[i].style.display=='';
      }
    }
  }
}
// 全てのフォルダをオープンする
function doFolderOpenAll() {
  var items = document.getElementsByTagName('A');
  for(var i=0;i<items.length;++i){
    if(items[i].className=='folder'&&!isFolderOpend(items[i])){
      items[i].click();
    }
  }
}

// CORE<> ヘルプ対応：修飾キー＋メニュークリックでヘルプファイルを開く
// 子項目がある項目がクリックされた場合に配下を縮小・展開する
// クリック時にCtrlキーが押されている場合は選択された項目のヘルプを表示する
function doFolderClickHelp(id, img, appid, menu){
  if(event.ctrlKey){
    openHelpNewWindow(appid, menu);
    return false;
  } else {
    return doFolderClick(id, img);
  }
}

// クリック時にCtrlキーが押されている場合は選択された項目のヘルプを表示する
function openHelpWindow(appid, menu) {
  if(event.ctrlKey){
    openHelpNewWindow(appid, menu);
    return false;
  }
  return true;
}

