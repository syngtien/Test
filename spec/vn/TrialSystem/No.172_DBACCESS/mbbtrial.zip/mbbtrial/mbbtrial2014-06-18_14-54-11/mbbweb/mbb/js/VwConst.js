/**
 * VwConst
 * 定数定義
 */
LAST_MODIFIED('2010.05.20', '1.0.25');

////////////////////////////////////////////////////////////////////////////////////////

/** 
 * プロセスID 
 */
var PROCESSID_PREVIEW          = 'VwPreview';                 // プレビュー
var PROCESSID_PAGESELECT       = 'VwPageSelect';              // ページ選択
var PROCESSID_CUSTOMPAGESELECT = 'VwCustomizablePageSelect';  // カスタマイズページ選択
var PROCESSID_STORECHECK       = 'VwPrePageStoreCheck';       // ページ保存チェック
var PROCESSID_PAGESAVE         = 'VwPageDataStore';           // ページ保存
var PROCESSID_CUSTOMPAGESAVE   = 'VwCustomPageDataStore';     // カスタマイズページ保存
var PROCESSID_PROCESSSELECT    = 'VwProcessSelect';           // プロセス定義選択


/*
 * JSPID
 */
var JSPID_VIEWEDITOR          = 'jsp/VwViewEditor';           // View定義ツール 編集画面
var JSPID_VIEWEDITORFRAME     = 'jsp/VwViewEditorFrame';      // View定義ツール フレーム編集画面
var JSPID_VIEWEDITORCUSTOMIZE = 'jsp/VwViewEditorCustomize';  // View定義ツール カスタマイズ画面
var JSPID_ERROR               = 'jsp/SysError';               // エラー画面
var JSPID_PAGELIST            = 'jsp/VwPageList';             // ページ選択
var JSPID_PAGESAVE            = 'jsp/VwPageSave';             // ページ保存
var JSPID_SAVECOMPLETE        = 'jsp/VwSaveComplete';         // ページ保存完了
var JSPID_PREVIEW             = 'jsp/AppView';                // プレビュー
var JSPID_PREVIEWPDF          = 'jsp/PDFView';                // PDFプレビュー
var JSPID_PREVIEWMOBILE       = 'jsp/MobileView';             // 携帯プレビュー
var JSPID_PREVIEWSETTINGS     = 'jsp/VwPreviewSettings';      // プレビュー設定画面
var JSPID_IMAGELIST           = 'jsp/VwImageList';            // 画像選択画面
var JSPID_PROCESSLIST         = 'jsp/VwProcessList';          // プロセス定義選択画面

/**
 * ファイルパス(appcontrollerからの相対パス)
 */
var PATH_JSP    = './jsp/';
var PATH_HTML   = './html/';
var PATH_IMAGES = './images/';

/**
 * ダイアログファイル名
 */
var DIALOG_JSFILE        = PATH_HTML + 'VwJsFileSrcEdit.html';       //「外部JavaScriptファイル」編集ダイアログ
var DIALOG_LISTITEM      = PATH_HTML + 'VwListItemEdit.html';        //「選択肢」編集ダイアログ
var DIALOG_ADD           = PATH_HTML + 'VwPageItemAdd.html';         //「追加」ダイアログ
var DIALOG_SAVING        = PATH_HTML + 'VwSavingMessage.html';       //「保存中」ウィンドウ
var DIALOG_COLOR         = PATH_HTML + 'VwColorpicker.html';         //「色選択」ダイアログ
var DIALOG_EVENT         = './appcontroller?PROCESSID=&JSPID=jsp/VwEventHandlerEdit&PROCESSMODE=1';    //「イベント」ダイアログ
var DIALOG_LONGPROPERTY  = PATH_HTML + 'VwPropertyEdit.html';        //「プロパティ」編集ダイアログ
var DIALOG_PARAMETER     = PATH_HTML + 'VwParameterEdit.html';       //「パラメータ」編集ダイアログ(APPLET,EMBED,OBJECT用)
var DIALOG_METADATA      = PATH_HTML + 'VwMetaDataEdit.html';        //「メタ」編集ダイアログ
var DIALOG_TYPECHANGE    = PATH_HTML + 'VwPageItemChange.html';      //「項目タイプ変更」ダイアログ
var DIALOG_VERSION       = PATH_HTML + 'VwVersionInfo.html';         //「バージョン情報」ダイアログ
var DIALOG_OPENNEWPAGE   = PATH_HTML + 'VwOpenNewPage.html';         //「新規作成」ダイアログ
var DIALOG_FRAMETEMPLATE = PATH_HTML + 'VwFrameTemplate.html';       //「テンプレートからフレーム新規作成」ダイアログ
var DIALOG_ITEMSEARCH    = PATH_HTML + 'VwSearchItem.html';           //「項目検索」ダイアログ
var DIALOG_ERROROBJECT   = 'html/VwSearchItem.html';                           //「エラーオブジェクト一覧」ダイアログ

/*
 * 別ウィンドウの名前
 */
var DIALOGNAME_PAGELIST      = ''; //「開く」ダイアログ参照名
var DIALOGNAME_PAGESAVE      = ''; //「別名で保存」ダイアログ参照名
var DIALOGNAME_SAVING        = ''; //「保存中」ダイアログ参照名
var DIALOGNAME_PROCESSLIST   = ''; //「プロセス読込」ダイアログ参照名
var DIALOGNAME_ADD           = 'ADDDIALOG';        //「追加」ダイアログ参照名
var DIALOGNAME_TYPECHANGE    = 'TYPECHANGEDIALOG'; //「項目タイプ変更」ダイアログ参照名
var DIALOGNAME_VERSION       = 'VERSIONDIALOG';    //「バージョン情報」ダイアログ参照名
var DIALOGNAME_OPENNEWPAGE   = 'OPENNEWPAGEDIALOG'; //「新規作成」ダイアログ参照名
var DIALOGNAME_FRAMETEMPLATE = 'FRAMETEMPLATEDIALOG'; //「テンプレートからフレーム新規作成」ダイアログ参照名
var DIALOGNAME_IMAGELIST     = ''; //「画像ファイル一覧」ダイアログ参照名
var DIALOGNAME_PREVIEWSETTINGS = 'PREVIEWSETTINGSDIALOG'; //「プレビュー設定」ダイアログ参照名

/*
 * 各イメージファイル名
 */
// オブジェクト表示用
var IMAGEURL_APPLET  = PATH_IMAGES   + 'VwApplet.gif';
var IMAGEURL_OBJECT  = PATH_IMAGES   + 'VwObject.gif';
var IMAGEURL_EMBED   = PATH_IMAGES   + 'VwEmbed.gif';
var IMAGEURL_COMBO   = PATH_IMAGES   + 'VwCombo.gif';
var IMAGEURL_IMAGE   = PATH_IMAGES   + 'VwImage.gif';
var IMAGEURL_IMAGETP = PATH_IMAGES   + 'VwImageTransparent.gif';
var IMAGEURL_IMAGEBC = PATH_IMAGES   + 'VwBarcode.gif';
//var IMAGEURL_COLORTIPBG = PATH_IMAGES   + 'VwColorTipBackground.gif';
var IMAGEURL_COLORTIPBG = '';

// ツールバーアイコン
var IMAGEURL_NEW           = PATH_IMAGES + 'VwNew.gif';
var IMAGEURL_OPEN          = PATH_IMAGES + 'VwOpen.gif';
var IMAGEURL_SAVE          = PATH_IMAGES + 'VwSave.gif';
var IMAGEURL_CUT           = PATH_IMAGES + 'VwCut.gif';
var IMAGEURL_COPY          = PATH_IMAGES + 'VwCopy.gif';
var IMAGEURL_PASTE         = PATH_IMAGES + 'VwPaste.gif';
var IMAGEURL_CLEAR         = PATH_IMAGES + 'VwClear.gif';
var IMAGEURL_ADD           = PATH_IMAGES + 'VwAdd.gif';
var IMAGEURL_DISABLEDNEW   = PATH_IMAGES + 'VwDisabledNew.gif';
var IMAGEURL_DISABLEDOPEN  = PATH_IMAGES + 'VwDisabledOpen.gif';
var IMAGEURL_DISABLEDSAVE  = PATH_IMAGES + 'VwDisabledSave.gif';
var IMAGEURL_DISABLEDCUT   = PATH_IMAGES + 'VwDisabledCut.gif';
var IMAGEURL_DISABLEDCOPY  = PATH_IMAGES + 'VwDisabledCopy.gif';
var IMAGEURL_DISABLEDPASTE = PATH_IMAGES + 'VwDisabledPaste.gif';
var IMAGEURL_DISABLEDCLEAR = PATH_IMAGES + 'VwDisabledClear.gif';
var IMAGEURL_DISABLEDADD   = PATH_IMAGES + 'VwDisabledAdd.gif';


/** view定義ツールの色 を定義したクラス名 */
var CLASSNAME_BASEBACKGROUNDCOLOR = 'vw-editor-basebgcolor';
var CLASSNAME_BASEBORDERCOLOR = 'vw-editor-basebordercolor';

/** 属性欄ボタンの色 style */
//var STYLE_PROPBUTTONCOLOR = 'background-color:transparent;';
var STYLE_PROPBUTTONCOLOR = '';

/** フォームのID */
var ELEMENTID_FIRSTFORM = 'form1';

/** tag 属性名のprefix */
var PROPERTYIDPREFIX_TAG = 'tag';

/** カスタムtag 属性名のprefix */
var PROPERTYIDPREFIX_TAGCUSTOM = 'tag-custom';

/** １行の表示高さ(px) */
var DISPLAYROWHEIGHT = 20;

/** 画像ファイルディレクトリ(画像一覧ダイアログから参照) */
var CONSTIMAGEFILEDIRECTORY = 'images';

/** プレビュー情報の属性ID */
var PREVIEWPROPERTYID = '#previewparameters';

/** */
var KEYCODE = new Object();
KEYCODE.BACKSPACE  = 8;
KEYCODE.TAB        = 9;
KEYCODE.ENTER      = 13;
KEYCODE.PAGEUP     = 33;
KEYCODE.PAGEDOWN   = 34;
KEYCODE.END        = 35;
KEYCODE.HOME       = 36;
KEYCODE.ARROWWEST  = 37;
KEYCODE.ARROWNORTH = 38;
KEYCODE.ARROWEAST  = 39;
KEYCODE.ARROWSOUTH = 40;
KEYCODE.MINUS      = 45;
KEYCODE.DELETE     = 46;
KEYCODE.NUM0       = 48;
KEYCODE.NUM9       = 57;
//for(var ch = 65;ch <= 90; ch++) {
//  KEYCODE[String.fromCharCode(ch)] = ch;
//} 
KEYCODE.A = 65;
KEYCODE.C = 67;
KEYCODE.D = 68;
KEYCODE.F = 70;
KEYCODE.L = 76;
KEYCODE.N = 78;
KEYCODE.O = 79;
KEYCODE.S = 83;
KEYCODE.V = 86;
KEYCODE.X = 88;
KEYCODE.Y = 89;
KEYCODE.Z = 90;

KEYCODE.a = 97;
KEYCODE.z = 127;

/** クリップボードのフォーマット*/
var VIEWEDITORCLIPBOARDFORMAT = 'FORMAT=MBB ViewEditor';

/** クリップボードの互換フォーマット*/
var VIEWEDITORCLIPBOARDFORMAT_COMPATIBLE1 = 'FORMAT=MBB ViewEditor';
var VIEWEDITORCLIPBOARDFORMAT_COMPATIBLE2 = 'FORMAT=MBB ViewEditor1.0.23';

/** クリップボードに設定するフォーマット名*/
var VIEWEDITORCLIPBOARDFORMAT_COPY = VIEWEDITORCLIPBOARDFORMAT_COMPATIBLE2;

/*
 * バージョン情報
 */
var m_versionInfo;

/*
 * バージョンを設定する
 */
function LAST_MODIFIED(dt, ver) {
  dt = dt.replace('/','.').replace('/','.');
  if(!m_versionInfo) {
    m_versionInfo = {};
    setVersionInfo('2004.01.15', '1.0.0');
  }
  if(m_versionInfo.lastdate < dt) {
    setVersionInfo(dt, ver);
  }
  function setVersionInfo(dt, ver) {
    m_versionInfo.lastdate = dt;
    m_versionInfo.date = dt.replace('.0','.').replace('.0','.');
    m_versionInfo.name = 'ViewEditor ' + ver;
    m_versionInfo.copyright = 'Copyright (C) 2003-' + dt.substring(0,4) + ' Business Brain Showa-ota Inc.All Rights Reserved.';
  }
}

