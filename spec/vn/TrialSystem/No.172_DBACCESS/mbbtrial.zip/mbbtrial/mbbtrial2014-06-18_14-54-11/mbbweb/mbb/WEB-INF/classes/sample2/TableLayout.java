package sample2;

import java.sql.*;

import jp.co.bbs.unit.item.mst.Table;
import jp.co.bbs.unit.tools.html.*;


public class TableLayout extends PageElement {
	
	// �p�����[�^
	private String tableId = null;
	
	public void setTableId(String tableId) {
		this.tableId = tableId;
	}

	public TableLayout() {
	}
	
	@Override
	public String toString() {
		
		StringBuffer sb = new StringBuffer();
		
		boolean request = false;
		if (tableId == null) {
			tableId = getRequest().getParameter("tableId");
			if (tableId != null) {
				request = true;
			}
		}
		
		if (!request) {
			sb.append("<div id=\"tablelayout\" class=\"scrollbox\" style=\"width:").append(getWidth()).append("px;");
			sb.append("height:").append(getHeight()).append("px;");
			sb.append("overflow:scroll;");
			//sb.append("border-style:solid;border-width:1px;border-color:#000000;");
			sb.append("\">");
		}
		String[] widths = {"40","100","200","60","100"};
		sb.append("<table class=\"vw-table\" style=\"border-style-left:none;border-style-top:none;\">\n");
		sb.append("<col width=\"" + widths[0] + "\">");
		sb.append("<col width=\"" + widths[1] + "\">");
		sb.append("<col width=\"" + widths[2] + "\">");
		sb.append("<col width=\"" + widths[3] + "\">");
		sb.append("<col width=\"" + widths[4] + "\">");
		sb.append("<tr>");
		sb.append("<td class=\"vw-cell linehead\">");
		sb.append("No.");
		sb.append("</td>");
		sb.append("<td class=\"vw-cell linehead\">");
		sb.append("�f�[�^�t�B�[���hID");
		sb.append("</td>");
		sb.append("<td class=\"vw-cell linehead\">");
		sb.append("�f�[�^���ږ���");
		sb.append("</td>");
		sb.append("<td class=\"vw-cell linehead\">");
		sb.append("�敪");
		sb.append("</td>");
		sb.append("<td class=\"vw-cell linehead\">");
		sb.append("�f�[�^�^�C�v");
		sb.append("</td>");
		sb.append("</tr>");
		if (tableId != null) {
			PreparedStatement stmt = null;
			ResultSet rs = null;
			try {
				stmt = getConnection().prepareStatement(
						  "SELECT a.DATAFIELDID, a.DATAFIELDCLASS, b.DATATYPE, b.DIGIT, b.DECIMALPLACE, c.NAMEVALUE"
						+ " FROM TABLELAYOUTMASTER a"
						+ " LEFT JOIN DATAFIELDMASTER b ON b.DATAFIELDID=a.DATAFIELDID"
						+ " LEFT JOIN DATAFIELDNAME c ON c.DATAFIELDID=a.DATAFIELDID"
						+ " AND c.DISPLANGID='JA' AND c.PROPERTYID='OFFICIALNAME'"
						+ " WHERE a.TABLEID=? ORDER BY a.DATAFIELDORDER"
						);
				stmt.setString(1, tableId);
				rs = stmt.executeQuery();
				int cnt = 0;
				while (rs.next()) {
					String dataFieldId = rs.getString(1);
					String dataFieldClass = rs.getString(2);
					String dataType = rs.getString(3);
					int digit = rs.getInt(4);
					int decimalPlace = rs.getInt(5);
					String dataFieldName = rs.getString(6);
					sb.append("<tr>");
					sb.append("<td class=\"vw-cell linebody\" style=\"text-align:right;\">");
					sb.append("<div style=\"width:" + widths[0] + "px;\">");
					sb.append(++cnt);
					sb.append("</div>");
					sb.append("</td>");
					sb.append("<td class=\"vw-cell linebody\">");
					sb.append("<div style=\"width:" + widths[1] + "px;white-space:nowrap;\">");
					if ("1".equals(dataFieldClass)) {
						sb.append("<b>");
					}
					sb.append(dataFieldId);
					if ("1".equals(dataFieldClass)) {
						sb.append("</b>");
					}
					sb.append("</div>");
					sb.append("</td>");
					sb.append("<td class=\"vw-cell linebody\">");
					sb.append("<div style=\"width:" + widths[2] + "px;white-space:nowrap;\">");
					if ("1".equals(dataFieldClass)) {
						sb.append("<b>");
					}
					sb.append(dataFieldName);
					if ("1".equals(dataFieldClass)) {
						sb.append("</b>");
					}
					sb.append("</div>");
					sb.append("</td>");
					sb.append("<td class=\"vw-cell linebody\">");
					sb.append("<div style=\"width:" + widths[3] + "px;\">");
					if ("1".equals(dataFieldClass)) {
						sb.append("<b>");
					}
					if ("1".equals(dataFieldClass)) {
						sb.append("�L�[");
					} else if ("2".equals(dataFieldClass)) {
						sb.append("��{");
					} else if ("3".equals(dataFieldClass)) {
						sb.append("����");
					} else if ("4".equals(dataFieldClass)) {
						sb.append("���");
					}
					if ("1".equals(dataFieldClass)) {
						sb.append("</b>");
					}
					sb.append("</div>");
					sb.append("</td>");
					sb.append("<td class=\"vw-cell linebody\">");
					sb.append("<div style=\"width:" + widths[4] + "px;\">");
					if ("1".equals(dataFieldClass)) {
						sb.append("<b>");
					}
					sb.append(dataType);
					if (decimalPlace > 0) {
						sb.append(" (").append(digit).append(",").append(decimalPlace).append(")");
					} else if (digit > 0) {
						sb.append(" (").append(digit).append(")");
					}
					if ("1".equals(dataFieldClass)) {
						sb.append("</b>");
					}
					sb.append("</div>");
					sb.append("</td>");
					sb.append("</tr>");
				}
			} catch (SQLException e) {
				
			} finally {
				if (rs != null) {
					try {
						rs.close();
					} catch (SQLException e) {}
				}
				if (stmt != null) {
					try {
						stmt.close();
					} catch (SQLException e) {}
				}
			}
		}
		sb.append("</table>");
		if (!request) {
			sb.append("\n</div>\n");
		}

		return sb.toString();
		
	}

	
}
