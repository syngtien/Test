package sample5;

import java.applet.Applet;
import java.awt.BorderLayout;
import java.awt.Graphics;
import java.awt.LayoutManager;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.TreeMap;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import jp.co.bbs.unit.tools.util.html.Document;
import jp.co.bbs.unit.tools.util.html.Element;

public class Applet1 extends Applet {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	
//	public void paint(Graphics g){
//		g.drawString("Hello World !!",100, 100);
//	}
//
//
	public void init() {
//		// TODO Auto-generated method stub
//		super.init();
		setLayout(null);
		JTabbedPane tp = new JTabbedPane();
		add(tp);
		tp.setBounds(0,0,700,300);
		JPanel panel1 = new JPanel((LayoutManager)null);
		JPanel panel2 = new JPanel((LayoutManager)null);
		JPanel panel3 = new JPanel((LayoutManager)null);
		tp.addTab("tab1", panel1);
		tp.addTab("tab2", panel2);
		tp.addTab("tab3", panel3);
		
		// TAB1
		DefaultTableModel model1 = new DefaultTableModel(5, 10);
		JTable jTable1 = new JTable(model1);
		panel1.add(jTable1);
		jTable1.setBounds(0, 0, 700, 300);
		
		// TAB2
		final DefaultTableModel model2 = new DefaultTableModel(0, 8);
		JTable jTable2 = new JTable(model2);
		JScrollPane jsp2 = new JScrollPane(jTable2);
		jsp2.setBounds(0, 0, 580, 270);
		jsp2.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
		panel2.add(jsp2);
		jTable2.setBounds(0, 0, 580, 300);
		jTable2.setAutoResizeMode(HEIGHT);
		final String url2_1 = this.getCodeBase() + "do.http://info.finance.yahoo.co.jp/exchange/";
		JButton btn2_1 = new JButton("�בփ��[�g");
		btn2_1.setBounds(580, 0, 110, 20);
		btn2_1.setToolTipText("http://info.finance.yahoo.co.jp/exchange/ ���ŐV�f�[�^���擾���܂�");
		JLabel lbl2_1 = new JLabel("Proxy:");
		lbl2_1.setBounds(580, 20, 40, 20);
		final JTextField txt2_1 = new JTextField();
		txt2_1.setToolTipText("�uIP�A�h���X:�|�[�g�v�̌`���Ŏw�肵�܂�");
		txt2_1.setBounds(620, 20, 70, 20);
		panel2.add(btn2_1);
		panel2.add(lbl2_1);
		panel2.add(txt2_1);
		btn2_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					for (int i = model2.getRowCount(); i > 0; --i) {
						model2.removeRow(i - 1);
					}
					URL url = null;
					String proxy = txt2_1.getText();
					if (proxy != null && proxy.trim().length() > 0) {
						url = new URL(url2_1 + "@" + proxy);
					} else {
						url = new URL(url2_1);
					}
					HttpURLConnection  conn = (HttpURLConnection)url.openConnection();
					conn.setRequestProperty("Cookie", " JSESSIONID=" + getParameter("JSESSIONID"));
					BufferedInputStream bis = new BufferedInputStream(conn.getInputStream());
					byte[] buf = new byte[1024];
					int r = 0;
					ByteArrayOutputStream baos = new ByteArrayOutputStream();
					while ((r = bis.read(buf)) != -1) {
						if (r > 0) {
							baos.write(buf, 0, r);
						}
					}
					bis.close();
					String html = baos.toString("UTF-8");
					html = html.replaceAll("[\r\n]+", "");
					html = html.replaceAll("^.*<!-- �O���בփ��[�g�\ -->", "");
					html = html.replaceAll("<!--��v�ʉ�-->.*$", "");
					html = html.replaceAll("<img [^>]+>", "");
					String head = html.replaceAll("</tr></thead><tbody>.*$", "").replaceAll("^.*<th></th>", "").replaceAll("<th>", "").replaceAll("</th>", "\t");
					String[] heads = head.split("\t");
					model2.addRow(new Object[]{"", heads[0].trim(), heads[1].trim(), heads[2].trim(), heads[3].trim(), heads[4].trim(), heads[5].trim(), heads[6].trim()});
					html = html.replaceAll("^.*</tr></thead><tbody><tr class=\"odd\">", "");
					html = html.replaceAll("</tr></tbody>.*$", "");
					html = html.replaceAll("<(td|tr) class=\"(empty|strong|even|odd)\">", "");
					html = html.replaceAll("<a [^>]+>|</a>", "");
					html = html.replaceAll("</th>", "\t");
					html = html.replaceAll("</t[dh]></tr>", "\n");
					html = html.replaceAll("<th [^>]+>", "");
					html = html.replaceAll("<td>", "");
					html = html.replaceAll("</td>", "\t");
					String[] lines = html.split("\n");
					for (int i = 0; i < lines.length; ++i) {
						String[] item = lines[i].split("\t");
						if (item.length >= 2) {
							model2.addRow(new Object[]{item[0].trim(), item[1].trim(), item[2].trim(), item[3].trim(), item[4].trim(), item[5].trim(), item[6].trim(), item[7].trim()});
						}
					}
				} catch (Exception e1) {
					JOptionPane.showMessageDialog(null, e1.getMessage(), "ERROR",
							JOptionPane.INFORMATION_MESSAGE);
				}
			}
		});

		// TAB3
		final DefaultTableModel model3 = new DefaultTableModel(0, 2);
		JTable jTable3 = new JTable(model3);
		JScrollPane jsp3 = new JScrollPane(jTable3);
		jsp3.setBounds(0, 0, 500, 270);
		jsp3.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
		panel3.add(jsp3);
		jTable3.setBounds(0, 0, 500, 0);
		jTable3.setAutoResizeMode(HEIGHT);
		final String url3_1 = this.getCodeBase() + "do.getSessionData";
		JButton btn3_1 = new JButton("getSessionData");
		btn3_1.setBounds(500, 0, 150, 20);
		panel3.add(btn3_1);
		btn3_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					for (int i = model3.getRowCount(); i > 0; --i) {
						model3.removeRow(i - 1);
					}
					URL url = new URL(url3_1);
					HttpURLConnection  conn = (HttpURLConnection)url.openConnection();
					conn.setRequestProperty("Cookie", " JSESSIONID=" + getParameter("JSESSIONID"));
					ObjectInputStream ois = new ObjectInputStream(conn.getInputStream());
					HashMap sessionData = (HashMap)ois.readObject();
					ois.close();
					if (sessionData != null) {
						for (Iterator ite = new TreeMap(sessionData).keySet().iterator(); ite.hasNext(); ) {
							String key = (String)ite.next();
							Object value = sessionData.get(key);
							model3.addRow(new Object[]{key, value});
						}
					}
				} catch (Exception e1) {
					JOptionPane.showMessageDialog(null, e1.getMessage(), "ERROR",
							JOptionPane.INFORMATION_MESSAGE);
				}
			}
		});
		JButton btn3_2 = new JButton("bbs.co.jp");
		btn3_2.setBounds(500, 20, 150, 20);
		panel3.add(btn3_2);
		btn3_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					for (int i = model3.getRowCount(); i > 0; --i) {
						model3.removeRow(i - 1);
					}
					URL url = new URL(getCodeBase() + "do.http://www.bbs.co.jp/");
					HttpURLConnection  conn = (HttpURLConnection)url.openConnection();
					conn.setRequestProperty("Cookie", " JSESSIONID=" + getParameter("JSESSIONID"));
					String contentType = conn.getContentType();
					BufferedInputStream bis = new BufferedInputStream(conn.getInputStream());
					byte[] buf = new byte[1024];
					int r = 0;
					ByteArrayOutputStream baos = new ByteArrayOutputStream();
					while ((r = bis.read(buf)) != -1) {
						if (r > 0) {
							baos.write(buf, 0, r);
						}
					}
					bis.close();
					StringBuffer sb = new StringBuffer();
					sb.append(baos.toString("JISAutoDetect"));
					Document html = Document.parseHTML(sb);
					Element[] elements = html.getAllElements(Element.TEXT_ELEMENT_NAME);
					for (int i = 0; i < elements.length; ++i) {
						if (!elements[i].isWhiteSpace() && !(elements[i].getParentElement() != null && elements[i].getParentElement().equalsTagName("script"))) {
							model3.addRow(new Object[]{elements[i].getText(), ""});
						}
					}
				} catch (Exception e1) {
					JOptionPane.showMessageDialog(null, e1.getMessage(), "ERROR",
							JOptionPane.INFORMATION_MESSAGE);
				}
			}
		});
		
	}
}
