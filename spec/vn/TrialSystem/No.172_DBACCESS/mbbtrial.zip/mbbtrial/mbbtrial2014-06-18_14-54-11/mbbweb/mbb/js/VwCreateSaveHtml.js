/**
 * VwCreateSaveHtml
 * 保存データ作成
 */
LAST_MODIFIED('2004.10.26', '1.0.25');

//
/*
 obj.parentPageItemId 親が変わったかチェックする
 obj.originalParentId 親が変わったかチェックする

  parentPageItemId VwSetPageVariable.jsで設定
 
*/

/**
 * 編集データ保存用データを作成する為のデータオブジェクトを作成する
 * @param  :dlgRtn オブジェクト 属性値にページID、画面名称、パッケージ名称を持つ
 * @return :作成したデータオブジェクト
 */
function createSaveData(dlgRtn){
  var dt1 = (new Date()).toString();
  
  var originalFormId = m_objDataSet[ELEMENTID_FIRSTFORM].getProperty('originalitemid');
  if(originalFormId.length == '') {
    originalFormId = ELEMENTID_FIRSTFORM;
  }
  
  /* page直下 */

  //作成データ保存用オブジェクト
  var page = new Object();

  page.pageId             = dlgRtn.pageId;
  page.packageId          = dlgRtn.packageId;
  //2003/08/18 page.timestampValue追加(更新チェック用)
  page.timestampValue     = dlgRtn.timestampValue;
  page.fieldIdSource      = '';
  page.fieldIdSourceClass = '';
  page.pageName           = dlgRtn.pageName;
  page.editStatus         = m_monitorEditStatus;
  //2003/04/09 page.pagetype追加(フレーム編集は別処理の為"0"で決め打ち)
  //2003/04/10 page.pagetTypeをpage.pageClassに変更
  page.pageClass          = m_pageClass;

  //page.pageName
  page.pageName                           = new Object();
  page.pageName[dlgRtn.langId]            = new Object();
  page.pageName[dlgRtn.langId].value      = dlgRtn.pageName;
  page.pageName[dlgRtn.langId].propertyId = 'OFFICIALNAME';

  //page.pageItems
  page.pageItems = new Object();

  //登録する全エレメントのID取得
  for(var i=0; i < m_addElementArray.length; i++){

    //ID取得
    var pageItemId = m_addElementArray[i];
    var dataset    = getDataSet(pageItemId);
    var typeid     = dataset.getProperty('type');
    var pageItem   = new Object();
    pageItem.properties     = new Object();

    if(typeid == TYPE.CELL) {
      pageItem.pageItemId           = dataset.getProperty('originalitemid');
      pageItem.pageItemTypeId       = 'panel';
      pageItem.parentPageItemId     = dataset.getProperty('parenttableid');
      pageItem.parentPageItemTypeId = 'table';
      if(!pageItem.pageItemId) {
        pageItem.pageItemId         = pageItemId;
      }
      //log.debug('pageItemId:' + pageItem.pageItemId + ' parent:' + pageItem.parentPageItemId);

      var propertyids = pref.edit.table.enumerator(true);
    } else {
      pageItem.pageItemId           = pageItemId;
      pageItem.pageItemTypeId       = typeid;
      pageItem.parentPageItemId     = '';
      pageItem.parentPageItemTypeId = '';
      var propertyids = pref.edit[typeid].enumerator(true);
    }
    page.pageItems[pageItem.pageItemId] = pageItem;

    //トップレベルのFORMかどうかの切り分け
    if(pageItemId == ELEMENTID_FIRSTFORM){

      pageItem.properties['top']  = {value:'', enable:'0'};
      pageItem.properties['left'] = {value:'', enable:'0'};

      for(var propertyid in propertyids){
        if(propertyid == 'type') continue;
        
        // 値
        var value = dataset.getProperty(propertyid);
        
        // viewプロパティID
        var viewPropertyId = convertToViewPropertyId(propertyid, typeid);

        if(propertyid == 'enctype' && value == ''){
          //エンコードタイプは設定時以外送信しない
        }else{
          // view値
          var viewValue = convertToViewPropertyValue(value, viewPropertyId);

          if(isArrayValue(propertyid)) {
            pageItem.properties[viewPropertyId] = {values:viewValue, enable:'0'};
          } else {
            pageItem.properties[viewPropertyId] = {value:viewValue, enable:'0'};
          }
        }
      }

    } else {

      //FORM(PAGE)以外
      pageItem.originalParentId = dataset.getProperty('originalparentitemid');
      if(originalFormId != ELEMENTID_FIRSTFORM) {
        if(pageItem.originalParentId == originalFormId) {
          pageItem.originalParentId = ELEMENTID_FIRSTFORM;
        }
      }
      
      //共通設定項目(top,left)設定
      var enableflg = getEnableClass(dataset, 'customize-mobility');
      pageItem.properties['top']  = {value:dataset.getProperty('top'), enable:enableflg};
      pageItem.properties['left'] = {value:dataset.getProperty('left'), enable:enableflg};
      var element = getDocumentElementById(pageItemId);
      pageItem.properties['offsetheight'] = {value:element.offsetHeight, enable:'0'};
      pageItem.properties['offsetwidth']  = {value:element.offsetWidth, enable:'0'};

      if(typeid == TYPE.CELL){

        for(var propertyid in propertyids) {
          if(isCellPropertyId(propertyid) || propertyid == 'name') {
            var viewPropertyId = convertToViewPropertyId(propertyid, TYPE.CELL);
            var viewValue = convertToViewPropertyValue(dataset.getProperty(propertyid), viewPropertyId);
            pageItem.properties[viewPropertyId] = {value:viewValue, enable:'0'};
            //log.debug('CELL ' + propertyid + '>' + viewPropertyId + ':' + viewValue);
          }
        }

      } else if(typeid == TYPE.TABLE){

        var tablemode = dataset.getProperty('tablemode');

        //項目TYPE毎のプロパティデータセット
        for(var propertyid in propertyids){
          if(isCellPropertyId(propertyid) || propertyid == 'type') continue;
          
          // テーブルのモードによるフィルタ(シンプルモード：maxlines不要、、ラインモード：maxrows不要、コピーモード：maxlines、maxrows不要)
          switch(propertyid) {
          case 'maxlines': 
            if(!useMaxLines(tablemode)) {
              continue;
            }
            break;
          case 'tablerows': 
            if(!useTableRows(tablemode)) {
              continue;
            }
            break;
          case 'titlerows':
          case 'titlecols':
          case 'corner':
          case 'titlerowborderwidth':
          case 'titlerowborderstyle':
          case 'titlerowbordercolor':
          case 'titlerowcolor':
          case 'titlerowstyle':
          case 'titlecolborderwidth':
          case 'titlecolborderstyle':
          case 'titlecolbordercolor':
          case 'titlecolcolor':
          case 'titlecolstyle':
            if(!useTitles(tablemode)) {
              continue;
            }
            break;
          }

          //プロパティ名称変換
          var viewPropertyId = convertToViewPropertyId(propertyid, typeid);
          var viewValue = convertToViewPropertyValue(dataset.getProperty(propertyid), viewPropertyId);
          
          switch(propertyid) {
          case 'visibility':
            pageItem.properties[viewPropertyId] = {value:viewValue, enable:getEnableClass(dataset, 'customize-visibility')};
            break;
          case 'maxlines':
            pageItem.properties[viewPropertyId] = {value:viewValue, enable:getEnableClass(dataset, 'customize-maxlines')};
            break;
          default:
            pageItem.properties[viewPropertyId] = {value:viewValue, enable:'0'};
          }
        } // for

        // 特殊属性(コピーモード時のTABLEにgroupid付加)
        if(useGroupId(tablemode)){
          var name = dataset.getProperty('name');
          if(name.length != 0){
            pageItem.properties['groupid'] = {value:name, enable:'0'};
          }
        }

      } else {
        // container以外
        
        //項目TYPE毎のプロパティデータセット
        for(var propertyid in propertyids){
          if(propertyid == 'type') continue;

          //プロパティ名称変換
          var viewPropertyId = convertToViewPropertyId(propertyid, typeid);
          var viewValue = convertToViewPropertyValue(dataset.getProperty(propertyid), viewPropertyId);

          switch(propertyid) {
          case 'visibility':
            pageItem.properties[viewPropertyId] = {value:viewValue, enable:getEnableClass(dataset, 'customize-visibility')};
            break;
          case 'fieldvalue':
            pageItem.properties[viewPropertyId] = {value:viewValue, enable:getEnableClass(dataset, 'customize-defaultvalue')};
            break;
          default:
            if(isArrayValue(propertyid)) {
              pageItem.properties[viewPropertyId] = {values:viewValue, enable:'0'};
            }else{
              pageItem.properties[viewPropertyId] = {value:viewValue, enable:'0'};
            }
          }
        } // for
      }
    }
  }

  //var dt4 = (new Date()).toString();
  //alert('dt1:' + dt1 + '\ndt4:' + dt4);
  
  return page;

  function getEnableClass(dataset, id) {
    if(dataset.getProperty(id) == 'enabled'){
      return '1';
    }else{
      return '0';
    }
  }
}


