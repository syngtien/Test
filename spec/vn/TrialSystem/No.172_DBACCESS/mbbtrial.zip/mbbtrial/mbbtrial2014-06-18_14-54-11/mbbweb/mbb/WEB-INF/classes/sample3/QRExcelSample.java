package sample3;

import jp.co.bbs.unit.sys.ProcessException;
import java.util.Date;
import java.sql.*;

public class QRExcelSample extends jp.co.bbs.unit.proc.tool.excel.exec.ExcelFileDownload {

	@Override
	public void doExecute() throws ProcessException {
		String value = getParameter("value");
		setCellValue(0, 0, "QR�R�[�h�T���v��");
		setCellValue(1, 0, value);
		addBarcode(value, BARCODE_QR, 2, 7, 0, 1);
		write();
	}

}
