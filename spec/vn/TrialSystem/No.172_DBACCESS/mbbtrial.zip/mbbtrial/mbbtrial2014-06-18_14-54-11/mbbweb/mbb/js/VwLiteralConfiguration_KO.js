/**
 * VwLiteralConfiguration_KO
 * 文字列定義（韓国語/英語）
 */
try {
LAST_MODIFIED('2005.11.30', '1.0.37');
}catch(e){}

// 言語ID
var DISPLANGID = 'KO';

/**
 * リテラル定義
 */
function LiteralNames() {

  // 共通
  this['common.close']             = 'Close';
  this['common.ok']                = 'OK'; 
  this['common.cancel']            = 'Cancel'; 
  this['common.add']               = 'Add';
  this['common.replace']           = 'Replace';
  this['common.delete']            = 'Delete'; 
  this['common.list']              = 'List';
  this['common.search']            = 'Search';
  this['common.back']              = 'Back'; 
  this['common.selectall']         = 'Select All';
  this['common.unselectall']       = 'Select None';
  this['common.pageid']            = 'Page ID'; 
  this['common.officialname']      = 'Official Name'; 
  this['common.packageid']         = 'Package ID';
  this['common.langid']            = 'Language ID'; 
  this['common.language']          = 'Language';
  this['common.processid']         = 'Process ID';
  this['common.processmode']       = 'Process Mode';
  this['processmode.1']            = 'Initialize';
  this['processmode.2']            = 'Confirm';
  this['processmode.3']            = 'Execute';
  this['common.jspid']             = 'JSPID';
  this['common.fielddefinitionid'] = 'Item Definition ID';
  this['common.applicationid']     = 'Application ID'; 
  this['common.parentclass']       = 'Parent Class';
  this['common.pageclass']         = 'Page Class';
  this['pageclass.0']              = 'Normal';
  this['pageclass.1']              = 'Frame'; 
  this['common.unspecified']       = 'Unspecified'; 
  this['common.all']               = 'All'; 
  this['common.objectid']          = 'Object ID'; 
  this['common.itemtype']          = 'Item Type';
  this['common.itemid']            = 'Item ID';
  this['common.itemname']          = 'Item Name';
  this['common.fieldid']           = 'Field ID';
  this['common.text']              = 'Text';
  this['common.id']                = 'ID';
  this['common.name']              = 'Name';
  this['common.value']             = 'Value';
  this['common.returnvalue']       = 'Return Value';
  this['matchingmethod.partialmatch']  = 'partial match';
  this['matchingmethod.fullmatch']     = 'full match';
  this['matchingmethod.forwardmatch']  = 'forward match';
  this['matchingmethod.backwardmatch'] = 'backward match';
  this['common.colon']             = ':';
  this['common.title']             = 'Title';

  //メニュー menuitem.
  this['menuitem.file']        = 'File';
  this['menuitem.edit']        = 'Edit';
  this['menuitem.help']        = 'Help';

  this['menuitem.new']         = 'New'; 
  this['menuitem.open']        = 'Open';
  this['menuitem.save']        = 'Save';
  this['menuitem.saveas']      = 'Save As'; 
  this['menuitem.loadfields']  = 'Load Process Definition'; 
  this['menuitem.preview']     = 'Preview'; 
  this['menuitem.pdfpreview']  = 'PDF Preview'; 
  this['menuitem.previewsettings']     = 'Preview Settings';

  this['menuitem.undo']        = 'Undo'; 
  this['menuitem.redo']        = 'Redo'; 
  this['menuitem.cut']         = 'Cut';
  this['menuitem.copy']        = 'Copy'; 
  this['menuitem.paste']       = 'Paste';
  this['menuitem.delete']      = 'Delete'; 
  this['menuitem.selectall']   = 'Select All';
  this['menuitem.add']         = 'Add';
  this['menuitem.find']        = 'Find'; 

  this['menuitem.versioninfo'] = 'About ViewEditor'; 

  this['command.move']           = 'Move';
  this['command.resize']         = 'Resize';
  this['command.pageitemchange'] = 'Change Type';

  //編集中情報 editor.xxxx
  this['editor.pageid']     = 'Page ID';
  this['editor.pagename']   = 'Page Name';
  this['editor.editormode'] = 'Mode';
  //画面モード editmode.xxx
  this['editormode.new']        = 'New';
  this['editormode.edit']       = 'Edit'; 
  this['editormode.customize']  = 'Customize';

  // プロパティ編集欄
  this['propertyarea.caption'] = 'Properties';
  //FRAME propertygroup.
  this['propertygroup.page']      = 'Page'; 
  this['propertygroup.division']  = 'Division'; 
  this['propertygroup.frame']     = 'Frame';
  this['propertygroup.frameset']  = 'Frame Set';

  //項目TYPE名 pageitemtype.xxx
  this['pageitemtype.form']       = 'Form';
  this['pageitemtype.frame']      = 'Frame';
  this['pageitemtype.panel']      = 'Panel';
  this['pageitemtype.table']      = 'Table';
  this['pageitemtype.combo']      = 'ComboBox';
  this['pageitemtype.list']       = 'ListBox';
  this['pageitemtype.radio']      = 'RadioButton';
  this['pageitemtype.button']     = 'Button';
  this['pageitemtype.image']      = 'Image';
  this['pageitemtype.file']       = 'File';
  this['pageitemtype.hide']       = 'Hidden';
  this['pageitemtype.check']      = 'CheckBox';
  this['pageitemtype.label']      = 'ReadonlyText';
  this['pageitemtype.string']     = 'String';
  this['pageitemtype.textarea']   = 'TextArea';
  this['pageitemtype.text']       = 'Text';
  this['pageitemtype.password']   = 'Password';
  this['pageitemtype.applet']     = 'Applet';
  this['pageitemtype.embed']      = 'Plug-in';
  this['pageitemtype.object']     = 'Object';
  this['pageitemtype.submit']     = 'SubmitButton';
  this['pageitemtype.reset']      = 'ResetButton';
  this['pageitemtype.titledtext'] = 'Titled Text';
  this['pageitemtype.iframe']     = 'InlineFrame'; // 2003.09.18
  this['pageitemtype.hr']         = 'HorizontalLine'; // 2003.10.02

  //プロパティ項目名
  this['property.onclick']             = 'onClick';
  this['property.ondblclick']          = 'onDblClick';
  this['property.onmousedown']         = 'onMouseDown';
  this['property.onmouseup']           = 'onMouseUp';
  this['property.onmouseover']         = 'onMouseOver';
  this['property.onmouseout']          = 'onMouseOut';
  this['property.onmousemove']         = 'onMouseMove';
  this['property.onkeydown']           = 'onKeyDown';
  this['property.onkeyup']             = 'onKeyUp';
  this['property.onkeypress']          = 'onKeyPress';
  this['property.onfocus']             = 'onFocus';
  this['property.onblur']              = 'onBlur';
  this['property.onchange']            = 'onChange';
  this['property.onload']              = 'onLoad';
  this['property.onunload']            = 'onUnload';
  this['property.onsubmit']            = 'onSubmit';
  this['property.onreset']             = 'onReset';
  this['property.itemtype']            = 'Item Type';
  this['property.itemid']              = 'Item ID';
  this['property.itemname']            = 'Item Name';
  this['property.groupid']             = 'Group ID';
  this['property.fieldid']             = 'Field ID';
  this['property.top']                 = 'Top(px)'; 
  this['property.left']                = 'Left(px)';
  this['property.visibility']          = 'Visibility';
  this['property.customizable']        = 'Customizable';
  this['property.customized']          = 'Customized';
  this['property.style']               = 'Style'; 
  this['property.width']               = 'Width(px)'; 
  this['property.height']              = 'Height(px)';
  this['property.heightc']             = 'CheckBox Height(px)';
  this['property.heightt']             = 'Text Height(px)';
  this['property.backgroundcolorr']    = 'RadioButton Background Color';
  this['property.backgroundcolort']    = 'Text Background Color';
  this['property.backgroundcolor']     = 'Background Color'; 
  this['property.backgroundimage']     = 'Background Image'; 
  this['property.fontcolor']           = 'Font Color'; 
  this['property.initialvalue']        = 'Initial Value';
  this['property.value']               = 'Value';
  this['property.value0']              = 'Unchecked Value';

  this['property.tableclass']          = 'Class ID';
  this['property.tablerowclass']       = 'Row Class ID';
  this['property.tablecolclass']       = 'Column Class ID';
  this['property.text']                = 'Text'; 
  this['property.textid']              = 'Text ID'; 
  this['property.fontsize']            = 'Font Size(pt)';
  this['property.fontfamily']          = 'Font Name'; 
  this['property.fontweight']          = 'Font Weight'; 
  this['property.fontstyle']           = 'Font Style';
  this['property.align']               = 'Horizontal Position';
  this['property.target']              = 'Target'; 
  this['property.pagetitle']           = 'Page Title'; 
  this['property.pagewidth']           = 'Page Width(px)'; 
  this['property.pageheight']          = 'Page Height(px)';
  this['property.action']              = 'Action'; 
  this['property.method']              = 'Method'; 
  this['property.jsfile']              = 'JavaScript Path';
  this['property.meta']                = 'Meta Infos';
  this['property.enctype']             = 'Encode Type';
  this['property.labeltext']           = 'Label'; 
  this['property.maxlength']           = 'Max Character Length';
  this['property.imagesrc']            = 'Image File'; 
  this['property.alt']                 = 'Substitute Text';
  this['property.link']                = 'Hyper Link'; 
  this['property.selectmode']          = 'Selection Mode'; 
  this['property.listsize']            = 'List Size'; 
  this['property.tablemode']           = 'Mode';
  this['property.tablecols']           = 'Columns';
  this['property.tablerows']           = 'Rows';
  this['property.maxlines']            = 'Rows';
  this['property.titlecols']           = 'Title Column';
  this['property.titlerows']           = 'Title Row';
  this['property.titlerowvanishing']   = 'Title Row Display';
  this['property.corner']              = 'Title Corner';
  this['property.titlerowborderwidth'] = 'Title Row Border Thickness(px)';
  this['property.titlerowborderstyle'] = 'Title Row Line Type';
  this['property.titlerowbordercolor'] = 'Title Row Color';
  this['property.titlerowcolor']       = 'Title Row Background Color';
  this['property.titlerowstyle']       = 'Title Row Style';
  this['property.titlecolborderwidth'] = 'Title Column Border Thickness(px)';
  this['property.titlecolborderstyle'] = 'Title Column Line Type';
  this['property.titlecolbordercolor'] = 'Title Column Color';
  this['property.titlecolcolor']       = 'Title Column Background Color';
  this['property.titlecolstyle']       = 'Title Column Style';
  this['property.option']              = 'Options'; 
  this['property.optioncols']          = 'Max Columns'; 
  this['property.optionrows']          = 'Max Rows';
  this['property.underline']           = 'Underline';
  this['property.textdecoration']      = 'Decoration';
  this['property.borderwidth']         = 'Border Thickness(px)'; 
  this['property.borderstyle']         = 'Border Line Type'; 
  this['property.bordercolor']         = 'Border Color'; 
  this['property.caption']             = 'Caption';
  this['property.captionfontsize']     = 'Caption Font Size(pt)';
  this['property.captionfontcolor']    = 'Caption Font Color';
  this['property.captionalign']        = 'Caption Align';
  this['property.cellspacing']         = 'Cell Spacing(px)';
  this['property.cellpadding']         = 'Cell Padding(px)';
  this['property.tdborderwidth']       = 'Boundary Line Thickness(px)';
  this['property.tdborderstyle']       = 'Boundary Line Type';
  this['property.tdbordercolor']       = 'Boundary Line Color';
  this['property.tdstyle']             = 'Boundary Style';
  this['property.cellrow']             = 'Cell Row'; 
  this['property.cellcol']             = 'Cell Column'; 
  this['property.cellvisibility']      = 'Cell Visibility';
  this['property.cellwidth']           = 'Cell Width(px)';
  this['property.cellheight']          = 'Cell Height(px)'; 
  this['property.cellbackgroundcolor'] = 'Cell Background Color'; 
  this['property.cellbackgroundimage'] = 'Cell Background Image'; 
  this['property.cellbordercolor']     = 'Cell Border Color'; 
  this['property.cellstyle']           = 'Cell Style';
  this['property.editmode']            = 'Edit Mode';
  this['property.code']                = 'Code'; 
  this['property.codebase']            = 'Code Base';
  this['property.title']               = 'Title';
  this['property.classid']             = 'Class ID'; 
  this['property.archive']             = 'Archive';
  this['property.src']                 = 'Source'; 
  this['property.imagewidth']          = 'Image Width(px)';
  this['property.imageheight']         = 'Image Height(px)';
  this['property.imageposition']       = 'Image Position';
  this['property.params']              = 'Parameter';
  this['property.attributes']          = 'Additional Attributes'; 
  this['property.embedsrc']            = 'Embed Source';
  this['property.embedparams']         = 'Embed Parameter'; 
  this['property.embedattributes']     = 'Additional Embed Attributes'; 
  this['property.tooltip']             = 'Tool Tip';
  this['property.accesskey']           = 'Access Key';
  this['property.textcolor']           = 'Text Color';
  this['property.linkcolor']           = 'Link Color';
  this['property.vlinkcolor']          = 'Visited Link Color';
  this['property.alinkcolor']          = 'Active Link Color';
  this['property.textcols']            = 'Width(characters)';
  this['property.textrows']            = 'Height(characters)';
  this['property.hrcolor']             = 'Color';
  this['property.shade']               = 'Shade';
  this['property.thickness']           = 'Thickness(px)';
  this['property.tabindex']            = 'Tab Order';
  this['property.locationfixing']      = 'Location Fixing';

  this['visibility.hidden']            = 'Hidden';
  this['fontweight.lighter']           = 'Lighter'; 
  this['fontweight.normal']            = 'Normal';
  this['fontweight.bold']              = 'Bold';
  this['fontweight.bolder']            = 'Bolder';
  this['fontstyle.italic']             = 'Italic';
  this['align.left']                   = 'Left';
  this['align.center']                 = 'Center';
  this['align.right']                  = 'Right'; 
  this['captionalign.left']            = 'Top Left';
  this['captionalign.top']             = 'Top Center';
  this['captionalign.right']           = 'Top Right';
  this['captionalign.bottom']          = 'Bottom';
  this['imageposition.left']           = 'Left of Label';
  this['imageposition.above']          = 'Above Label';
  this['imageposition.right']          = 'Right of Label';
  this['imageposition.below']          = 'Below Label';
  this['textdecoration.underline']     = 'Underline'; 
  this['selectmode.multiple']          = 'Multiple';
  this['enctype.application/x-www-form-urlencoded'] = 'Form Encode';
  this['enctype.multipart/form-data']               = 'File Upload';
  this['tablemode.simple']             = 'Simple';
  this['tablemode.copy']               = 'Copy';
  this['tablemode.line']               = 'Line';
  this['corner.row']                   = 'Title Row';
  this['corner.col']                   = 'Title Column';
  this['titlerows.use']                = 'Add title row';
  this['titlecols.use']                = 'Use leftmost column';
  this['titlerowvanishing.novanish']   = 'Display Always';
  this['titlerowvanishing.vanish']     = 'Vanish When No Records';
  this['borderstyle.none']             = 'None';
  this['borderstyle.dotted']           = 'Dotted';
  this['borderstyle.dashed']           = 'Dashed';
  this['borderstyle.solid']            = 'Solid';
  this['borderstyle.double']           = 'Double';
  this['borderstyle.groove']           = 'Groove';
  this['borderstyle.ridge']            = 'Ridge';
  this['borderstyle.inset']            = 'Inset';
  this['borderstyle.outset']           = 'Outset'; 
  this['editmode.readonly']            = 'Readonly'; 
  this['common.editbutton']            = 'Edit'; 
  this['locationfixing.pageright']     = 'Connect With Right End of Page';

  this['customizable.visibility']      = 'Visibility';
  this['customizable.location']        = 'Location'; 
  this['customizable.initialvalue']    = 'Initial Value';
  this['customizable.maxlines']        = 'Rows';
  this['customized.visibility']        = 'Visibility'; 
  this['customized.location']          = 'Location'; 
  this['customized.initialvalue']      = 'Initial Value';
  this['customized.maxlines']          = 'Rows'; 

  this['shade.noshade']                = 'No Shade';

  // デフォルト値
  //追加ダイアログで追加される実行ボタン
  this['initialvalue.addsubmit.value'] = 'Submit';
  this['initialvalue.createexecutebutton.value'] = 'Execute';
  this['initialvalue.createconfirmbutton.value'] = 'Confirm';
  this['initialvalue.createlistbutton.value']    = 'List';

  //SUBMIT
  this['initialvalue.submit.value'] = 'Submit'; 

  //RESET
  this['initialvalue.reset.value'] = 'Reset'; 

  // 表示オブジェクト用
  //FILE
  this['element.file.browsebuttonlabel'] = 'Browse';

  // フレーム編集画面
  this['property.frameborderwidth'] = 'Border Width(px)'; 
  this['property.framebordercolor'] = 'Border Color'; 
  this['property.direction']        = 'Direction';
  this['direction.rows']            = 'Rows'; 
  this['direction.columns']         = 'Columns';
  this['property.divisionlevel']    = 'Level';
  this['divisions.nodivisions']     = 'No Division';
  this['divisions.unit']            = ' Divisions'; 
  this['property.framename']        = 'Frame Name'; 
  this['property.framesrc']         = 'Frame Source'; 
  this['property.framescrolling']   = 'Scrolling';
  this['property.framenoresize']    = 'Resize'; 
  this['framescrolling.auto']       = 'Auto'; 
  this['framescrolling.yes']        = 'Yes';
  this['framescrolling.no']         = 'No'; 
  this['framenoresize.noresize']    = 'Fixed';

  // 新規ダイアログdialog.pagenew.xxx
  this['dialog.pagenew.title']  = 'New Page';

  // フレームテンプレートダイアログ dialog.frametemplate.xxx
  this['dialog.frametemplate.title']        = 'Choose Frame Template';
  this['dialog.frametemplate.frame']        = 'Frame'; 
  this['dialog.frametemplate.description']  = 'Description';
  this['dialog.frametemplate.heighttop']          = 'Height of Top';
  this['dialog.frametemplate.heightbottom']       = 'Height of Bottom';
  this['dialog.frametemplate.heightlefttop']      = 'Height of Left-Top';
  this['dialog.frametemplate.heightrighttop']     = 'Height of Right-Top';
  this['dialog.frametemplate.heightrightbottom']  = 'Height of Right-Bottom';
  this['dialog.frametemplate.widthleft']          = 'Width of Left';
  this['dialog.frametemplate.widthright']         = 'Width of Right';
  this['dialog.frametemplate.widthtopleft']       = 'Width of Top-Left';
  this['dialog.frametemplate.widthmiddleleft']    = 'Width of Middle-Left';
  this['dialog.frametemplate.widthbottomleft']    = 'Width of Bottom-Left';
  this['dialog.frametemplate.widthbottomright']   = 'Width of Bottom-Right';
  this['dialog.frametemplate.dividehorizontally'] = 'Divide horizontally into two';
  this['dialog.frametemplate.dividevertically']   = 'Divide vertically into two';
  this['dialog.frametemplate.divideverticallytohorizontally']   = 'Divide vertically, then divide each horizontally';
  this['dialog.frametemplate.dividehorizontallytovertically']   = 'Divide horizontally, then divide each vertically';
  this['dialog.frametemplate.divideverticallyandhorizontally']  = 'Divide vertically and horizontally into four';

  // ページ一覧ダイアログ dialog.pagelist.xxx
  this['dialog.pagelist.title'] = 'Page List';

  // 保存ダイアログ dialog.pagesave.xxx
  this['dialog.pagesave.title'] = 'Save As';

  // 保存中ダイアログ dialog.savemessage.xxx
  this['dialog.savemessage.title']          = 'Page Save';
  this['dialog.savemessage.verifying']      = 'Verifying Saving Data...';
  this['dialog.savemessage.saving']         = 'Saving...';
  this['dialog.savemessage.savingcomplete'] = 'Saving Complete';
  this['dialog.savemessage.savingfailed']   = 'Saving Failed';
  this['dialog.savemessage.errors']         = 'Errors:';

  //プロセス一覧ダイアログ dialog.processlist.xxx
  this['dialog.processlist.title']          = 'Process List';

  //項目IDの確認ダイアログ dialog.confirmfieldid.xxx
  this['dialog.confirmfieldid.title']       = 'Confirmation Of FieldIds';
  this['dialog.confirmfieldid.fieldidlist'] = 'Field ID List';

  // 追加ダイアログ dialog.pageitemadd.xxx
  this['dialog.pageitemadd.title']              = 'Add Page Item';
  this['dialog.pageitemadd.titletext']          = 'Label';
  this['dialog.pageitemadd.addsubmitbutton']    = 'Add Submit Button';
  this['dialog.pageitemadd.processdefinition']  = 'Process Definition';
  this['dialog.pageitemadd.userdefifnition']    = 'User Definition';
  this['dialog.pageitemadd.specifyobjectid']    = 'Specify Object Id';
  this['dialog.pageitemadd.createlist']         = 'Create List Table';
  this['dialog.pageitemadd.appendtitle']        = 'Append Title';
  this['dialog.pageitemadd.appendtitletoitem']  = 'Append Title To Item';
  this['dialog.pageitemadd.createcells']        = 'Create Cell For Each Item';
  this['dialog.pageitemadd.setoptionproperty']  = 'Set DataFieldValue To Option';
  this['dialog.pageitemadd.createbuttons']      = 'Create Buttons';

  // 検索ダイアログ
  this['dialog.find.title']                 = 'Find';
  this['dialog.find.closewhenselected']     = 'Close when selected';
  this['dialog.find.updatewhenactivated']   = 'Update list when activated';
  this['dialog.find.update']                = 'Update';
  this['dialog.find.framename']             = 'Frame Name';
  this['dialog.find.frame']                 = 'Frame';
  this['dialog.find.frameset']              = 'Frame Set';

  // エラーオブジェクト一覧ダイアログ dialog.errorobject.xxx
  this['dialog.errorobject.title']            = 'Error Objects';
  this['dialog.errorobject.descriptiontitle'] = 'Description';
  this['dialog.errorobject.V0001'] = 'Ununique';
  this['dialog.errorobject.V0002'] = 'Overlapped';
  this['dialog.errorobject.V0003'] = 'Out of parent';
  this['dialog.errorobject.V0004'] = 'Out of Form';
  this['dialog.errorobject.V0005'] = 'Partly out of parent';
  this['dialog.errorobject.V0006'] = 'Too small width';
  this['dialog.errorobject.V0007'] = 'Unspecified width';

  // バージョン情報ダイアログ dialog.versioninfo.title
  this['dialog.versioninfo.title']          = 'About ViewEditor';

  // 項目タイプ変更ダイアログ
  // dialog.pageitemchange.xxx
  this['dialog.pageitemchange.title']       = 'Change Field Type';

  // プロパティ編集ダイアログ dialog.propertyedit.xxx
  this['dialog.propertyedit.title']         = 'Property Edit';
  this['dialog.propertyedit.propertyvalue'] = 'Property Value';

  // 画像一覧ダイアログ dialog.imagelist.xxx
  this['dialog.imagelist.title']         = 'Image Files';
  this['dialog.imagelist.listfile']      = 'File Name';
  this['dialog.imagelist.listpreview']   = 'Preview';
  this['dialog.imagelist.file']          = 'File';
  this['dialog.imagelist.openuploader']  = 'Add Image...';

  // dialog.colorpicker.xxx
  this['dialog.colorpicker.title']          = 'Choose Color';
  this['dialog.colorpicker.basecolor']      = 'Base Color';
  this['dialog.colorpicker.usercolor']      = 'User Color';
  this['dialog.colorpicker.originalcolor']  = 'Original Color';
  this['dialog.colorpicker.addcolor']       = 'Add Color';
  this['dialog.colorpicker.red']            = 'Red';
  this['dialog.colorpicker.green']          = 'Green';
  this['dialog.colorpicker.blue']           = 'Blue';
  this['dialog.colorpicker.color']          = 'Color';

  // イベント編集ダイアログ dialog.eventedit.xxx
  this['dialog.eventedit.title']                = 'Event Edit';
  this['dialog.eventedit.title_hyperlink']      = 'Hyper Link Edit';
  this['dialog.eventedit.functionname']         = 'Function Name';
  this['dialog.eventedit.operationname']        = '';
  this['dialog.eventedit.editurl']              = 'URL';
  this['dialog.eventedit.editjs']               = 'JavaScript';
  this['dialog.eventedit.singlequotrequired']   = 'Single quotation marks are required for literal values';
  this['dialog.eventedit.userdefinition']       = 'User Definition';
  this['dialog.eventedit.hyperlink']            = 'Hyper Link';

  // JSファイル編集ダイアログ dialog.jsfileedit.xxx
  this['dialog.jsfileedit.title']         = 'JavaScript File Include';
  this['dialog.jsfileedit.listtitle']     = 'JavaScript Files';
  this['dialog.jsfileedit.jsfilepath']    = 'File Path';

  // リスト項目編集ダイアログ dialog.listitemedit.xxx
  this['dialog.listitemedit.title']       = 'List Options Edit';
  this['dialog.listitemedit.listtitle']   = 'List Options';
  this['dialog.listitemedit.text']        = 'Text';
  this['dialog.listitemedit.value']       = 'Value';

  // パラメータ編集ダイアログ dialog.parameteredit.xxx
  this['dialog.parameteredit.title']      = 'Parameter Edit';
  this['dialog.parameteredit.listtitle']  = 'Parameters';
  this['dialog.parameteredit.name']       = 'Name';
  this['dialog.parameteredit.value']      = 'Value';
  this['dialog.parameteredit.title_before'] = '';
  this['dialog.parameteredit.title_after']  = ' Edit';

  // メタ情報編集ダイアログ dialog.metaedit.xxx
  this['dialog.metaedit.title']      = 'Meta Info Edit';
  this['dialog.metaedit.listtitle']  = 'Meta Infos';
  this['dialog.metaedit.attrname']   = 'Attribute';
  this['dialog.metaedit.attrval']    = 'Item';
  this['dialog.metaedit.value']      = 'Value';
  this['dialog.metaedit.title_before'] = '';
  this['dialog.metaedit.title_after']  = ' Edit';

  // 画像アップロードダイアログ 
  this['dialog.imageupload.title']              = 'Image Upload';
  this['dialog.imageupload.rename']             = 'Rename uploaded file';
  this['dialog.imageupload.overwrite.caption']  = 'When conflict of file name:';
  this['dialog.imageupload.overwrite.off']      = 'Do not replace';
  this['dialog.imageupload.overwrite.on']       = 'Replace';
  this['dialog.imageupload.submit']             = 'Upload';
  this['dialog.imageupload.continue']           = 'Continue';

  // 項目IDアレイ編集ダイアログ dialog.fieldidarrayedit.xxx
  this['dialog.fieldidarrayedit.title']      = 'Field ID Array Edit';
  this['dialog.fieldidarrayedit.listtitle']  = 'Field ID List';
  this['dialog.fieldidarrayedit.text']       = 'Field ID';
  this['dialog.fieldidarrayedit.value']      = 'Value';

  // 配列型引数編集ダイアログ dialog.arrayedit.xxx
  this['dialog.arrayargumentedit.title']        = 'Array Argument Edit';
  this['dialog.arrayargumentedit.listtitle']    = 'List';

  //caption.pageid
  // ヘルプ
  // help.applicationmaster.xxx
  this['help.applicationmaster.title']  = 'Application Master Help';

  // help.pagemaster.xxx
  this['help.pagemaster.title']         = 'Page Master Help';

  // help.processmaster.xxx
  this['help.processmaster.title']      = 'Process Master Help';

  // ソート項目編集 dialog.sortfieldedit.xxx
  this['dialog.sortfieldedit.title']      = 'Sort Field Edit';

  // プレビュー設定ダイアログ dialog.previewsettings.xxx
  this['dialog.previewsettings.title']      = 'Preview Settings';
  this['dialog.previewsettings.params']     = 'Parameters';

  // 項目IDヘルプ
  this['help.fieldid.title']     = 'Field ID Help';

  // 戻り値ヘルプ
  this['help.returnvalue.title'] = 'Return Value Help';
}

/**
 * メッセージ定義
 */
function Messages() {

  // 読込時エラーメッセージ
  this.E0001 = '\'$prm0\' is not defined as Data Name.';
  this.E0002 = 'PageItem（$prm0）is not found.';
  this.E0003 = '$prm0（$prm1）is out of the object hierarchy.';
  this.E0004 = 'Only form object can be on top level of the object hierarchy.';
  this.E0005 = '$prm1（$prm2）requires the property（$prm0）.';
  this.E0006 = 'table（pageItemId=$prm0）requires the cell（row=$prm1,col=$prm2）.';
  this.E0007 = '$prm0（$prm3）contains invalid property value（$prm1=$prm2）.';
  this.E0008 = 'Field type \'$prm0\' is unknown.(The object can\'t be saved.）';
  this.E0009 = 'Could not display correctly because the cell（row=$prm1,col=$prm2）does not exist under the table（pageItemId=$prm0）.';
  this.E0010 = 'Property（$prm1=$prm2）for an undefined object（$prm0）is ignored.';
  this.E0011 = 'Customizing Property（$prm1=$prm2）for an undefined object（$prm0）is ignored.';
  this.E0012 = '$prm0（$prm3）does not contain the property（$prm1）to customize（$prm1=$prm2）.';
  this.E0013 = 'Customizing（$prm1=$prm2）on $prm0（$prm3）is not permitted.';
  this.E0014 = 'Reference to the parent（$prm2）of $prm1（$prm0）is circulated.';
  this.E0015 = 'Property value \'$prm2\' on $prm1（$prm0）is corrected.';

  // 編集時alertメッセージ
  this.A0001 = 'Reading went wrong';
  this.A0002 = 'Data reading went wrong';
  this.A0003 = 'Object（$prm0）not found.';

  // 追加ダイアログ 
  this.A0010 = 'Field Id cannot be empty.'; 
  this.A0011 = 'Object Id cannot be empty.';
  this.A0012 = 'Object Id must be in 20 characters or less.';
  this.A0013 = 'Invalid character \'$prm0\' is used in Object Id.'; 
  this.A0014 = 'Object Id \'$prm0\' already exists.';

  // 保存時
  this.A0020 = 'This Page ID already exists.Do you continue to save?';
  this.A0021 = 'Complete.';
  this.A0022 = 'Saving failed.';
  this.A0023 = 'You can\'t save this page.';

  // JSファイル編集ダイアログ 
  this.A0030 = 'File Path cannot be empty.';
  this.A0031 = 'This File Path already exists.';

  // 選択肢編集ダイアログ 
  this.A0040 = 'Text cannot be empty.';
  this.A0041 = 'This Text already exists.';
  this.A0042 = 'This Value already exists.';
  this.A0043 = 'This Access Key already exists.';
  this.A0044 = 'Access Keys are valid only for Radio Button.'
  this.A0045 = 'This $prm0 already exists.';

  // パラメータ編集ダイアログ 
  this.A0050 = 'Name cannot be empty.';
  this.A0051 = 'This Name already exists.';

  // プレビュー 
  this.A0060 = 'Not available until saved.';
  this.A0061 = 'Previews current saved content.';
  this.A0062 = 'Preview settings contains an error below.\n'
              + 'Do you continue to preview with default settings?'
              + '\n\nError : $prm0\n\nSettings : $prm1';

  // 画像アップロード
  this.A0070 = 'Input file name.';
  this.A0071 = '\'$prm0\' is invalid character.\nRename uploaded file.($prm1)';
  this.A0072 = 'Input another name to upload.';
  this.A0073 = '\'$prm0\' is invalid character.($prm1)';
  this.A0074 = 'Uploaded file is empty.<br>';
  this.A0075 = '$prm0 is uploaded.<br>';
  this.A0076 = '<font color=red>Upload failed.</font><br>File：$prm0 <br>';
  this.A0077 = '<font color=red>Upload failed.</font><br>File name \'$prm0\' already exists.<br>';
  this.A0078 = '<font color=red>File size is too large.<br>(Maximum:$prm0)</font><br>';
  this.A0079 = '<font color=red>File type is not image.</font><br>File：$prm0 <br>Content-Type:$prm1<br>';
  this.A0080 = 'File name does not contain valid extention.($prm0)\nRename uploaded file.\nValid extentions are\n\n$prm1';
  this.A0081 = 'File name does not contain valid extention.($prm0)\nValid extentions are\n\n$prm1';

  // 編集時confirmメッセージ
  this.C0001 = 'Are you sure you are deleting the selected items？';
  this.C0002 = 'The contents of edit are cleared.\nIs it all right？';
  this.C0003 = 'Are you sure you are converting the selected item into String？';
  this.C0004 = 'Are you sure you are deleting items that may be customized？';
  this.C0005 = 'You are creating a new page.<br>\nCurrent page is being disposed of.';

  // 編集時statusメッセージ
  this.S0001 = 'Loading. Please wait for a while...';
  this.S0002 = 'Creating objects...';
  this.S0003 = 'Preparing ...';
  this.S0005 = 'Creating Table...';
  this.S0006 = 'You can create $prm0 rows or less on the Table object.';
  this.S0007 = 'You can create $prm0 columns or less on the Table object.';
  this.S0008 = 'Processing...';

  // コマンド実行中メッセージ
  this.S0010 = 'Cutting...';
  this.S0011 = 'Copying...';
  this.S0012 = 'Pasting...';
  this.S0013 = 'Deleting...';
  this.S0014 = 'Undoing...';
  this.S0015 = 'Undoing "$prm0"...';
  this.S0016 = 'Redoing...';
  this.S0017 = 'Redoing "$prm0"...';

  this.S0020 = 'Editting $prm0';

  // 保存時メッセージ
  this.V0001 = 'Some objects share same Field IDs.\nDo you continue saving this page?';
  this.V0001_1 = 'Field ID:$prm0';
  this.V0001_2 = '$prm0 (Field Type:$prm1)';
  this.V0001_OV = '$prm0 objects share same Field IDs.'
                    + '\nDo you continue saving this page?'
                    + '\n\nYou can see details by "Cancel"';

  this.V0002 = 'Some objects overlap and will make errors.\nDo you continue saving this page?';
  this.V0002_1 = '';
  this.V0002_2 = '$prm0 (Field Type:$prm1, Field ID:$prm2)';
  this.V0002_OV = '$prm0 objects overlap and will make errors.'
                    + '\nDo you continue saving this page?'
                    + '\n\nYou can see details by "Cancel"';

  this.V0003 = 'Some objects are laid outside of their parent objects.\nYou can\'t save.';
  this.V0003_1 = '$prm0 (Field Type:$prm1, Field ID:$prm2, Parent Object ID:$prm3)';
  this.V0003_OV = '$prm0 objects are laid outside of their parent objects.\nYou can\'t save.'
                    + '\n\nYou can see details by "Cancel"';

  this.V0004 = 'Some objects are laid outside of the Form object.\nDo you continue saving this page?';
  this.V0004_1 = '$prm0 (Field Type:$prm1, Field ID:$prm2)';
  this.V0004_OV = '$prm0 objects are laid outside of the Form object.'
                    + '\nDo you continue saving this page?'
                    + '\n\nYou can see details by "Cancel"';

  this.V0005 = 'Some objects are laid partly outside of their parent objects and will make errors.\nDo you continue saving this page?';
  this.V0005_1 = '$prm0 (Field Type:$prm1, Field ID:$prm2, Parent Object ID:$prm3)';
  this.V0005_OV = '$prm0 objects are laid partly outside of their parent objects and will make errors.'
                    + '\nDo you continue saving this page?'
                    + '\n\nYou can see details by "Cancel"';

  this.V0006 = 'Width of these objects are too small.It makes layout broken occasionally.\n'
                 + 'Correct width to the \'expected\' value or a bigger or empty.\n'
                 + 'Do you continue saving this page?';
  this.V0006_1 = '$prm0 (Field Type:$prm1, Field ID:$prm2) current:$prm3 expected:$prm4';
  this.V0006_OV = '$prm0 objects have been set too small width.It makes layout broken occasionally.\n'
                 + 'Correct width to a bigger value or empty.\n'
                 + 'Do you continue saving this page?'
                 + '\n\nYou can see details by "Cancel"';

  this.V0007 = 'Width of these objects are empty.It makes layout broken occasionally.\n'
                 + 'Do you continue saving this page?';
  this.V0007_1 = '$prm0 (Field Type:$prm1, Field ID:$prm2)';
  this.V0007_OV = 'Width of $prm0 objects are set empty.It makes layout broken occasionally.\n'
                  + 'Do you continue saving this page?'
                  + '\n\nYou can see details by "Cancel"';

  // 設定エラー
  this.P0001 = 'Cannot display property \'$prm1\' as a checkbox.\nThe setting indicated below must be wrong.'
             + '\n\npref.xxx.$prm0.$prm1 = \'check\';';
  this.P0002 = 'Cannot display property \'$prm1\' as a selection.\nThe setting indicated below must be wrong.'
             + '\n\npref.xxx.$prm0.$prm1 = \'select\';';
  this.P0003 = 'Property edit type \'$prm2\' is unknown.\nThe setting indicated below must be wrong.'
             + '\n\npref.xxx.$prm0.$prm1 = \'$prm2\';';
}

/**
 * 受け取ったキーに対応するリテラルを返す
 * @param  :_key string キー
 * @return :リテラル
 */
function getLiteral(_key){
  
  var literalNames = LiteralNames.instance;
  if(!literalNames) {
    literalNames = LiteralNames.instance = new LiteralNames();
  }
  
  if(literalNames[_key] != undefined){
    return literalNames[_key];
  } else {
    var splt = _key.split('.');
    return '!' + splt[splt.length - 1];
  }
}

/**
 * 追加する
 */
function setLiteral(_key, value){
  
  var literalNames = LiteralNames.instance;
  if(!literalNames) {
    literalNames = LiteralNames.instance = new LiteralNames();
  }
  literalNames[_key] = value;
}

/**
 * 受け取ったメッセージIDとパラメータによって作成したメッセージを返す
 * @param  :_id   文字型 メッセージID,
 *          _prms 配列   置き換える文字
 * @return :      文字型 メッセージ
 */
function getMessage(_id, _prms){
  
  var messages = Messages.instance;
  if(!messages) {
    messages = Messages.instance = new Messages();
  }

  var msg = '';
  if(messages[_id]){
    // idが存在
    
    if(_prms) {
      // prmが存在
      return replacePrms(messages[_id], _prms);
    } else {
      // prmなし
      return messages[_id];
    }

  }else{
    // idが存在しないとき、id (prm1, prm2, ...)と出力
    
    var retPrm = '';
    if(_prms) {
      for(var i in _prms) {
        retPrm += ', $prm' + i;
      }
    }
    if(retPrm != '') {
      // prmあり
      return replacePrms(_id + ' (' + retPrm.substring(2) + ')' , _prms);
    }
    // prmなし
    return _id;
  }

  // $prm#部分の置き換え
  function replacePrms(_msg, _prms) {
    var retMsg = _msg;
    for(var i in _prms) {
      if(-1 < retMsg.indexOf('$prm' + i)) {
        for(var chkMsg = '';chkMsg != retMsg;) {
          chkMsg = retMsg;
          retMsg = retMsg.replace('$prm' + i, _prms[i]);
        }
      }
    }
    return retMsg;
  }
}
