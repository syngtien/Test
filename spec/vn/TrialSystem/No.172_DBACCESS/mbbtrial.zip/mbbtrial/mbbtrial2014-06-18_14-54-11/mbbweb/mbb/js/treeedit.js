﻿// 
var hiddenIdName = 'DEPARTMENTID';
var hiddenUpdateIdName = 'DEPARTMENTIDOLD';
var hiddenTextName = 'OFFICIALNAME';
var hiddenParentIdName = 'PARENTDEPARTMENTID';
var hiddenParentClassName = 'PARENTCLASS';

//
var itemIcon = 'images/box1.gif';

// スタイル
var textColor = '#000000';
var backgroundColor = '';
var borderStyle = 'none';
var selectedTextColor = '#ffffff';
var selectedBackgroundColor = '#000080';
var selectedBorderStyle = 'dotted';
var draggingTextColor = '#a0a0a0';
var draggingBackgroundColor = '';
var draggingBorderStyle = 'dotted';
var dragoverTextColor = '#000000';
var dragoverBackgroundColor = '';
var dragoverBorderStyle = 'none none solid none';

// グローバル変数
var netscape = false;
var dragItem = null;
var targetItem = null;
var selectedItem = null;
var autoIdNumberStart = 10000;
var autoIdNumberIncrease = 10;
var rootNodeName = 'root';
var rootNode = null;
var indentSize = 20;
var textColumnSize = 200;

var itemBaseHTML = '<span class="item"><img src="' + itemIcon + '" border="0" class="icon"><span class="text"></span>'
  + '<input type="text" name="' + hiddenIdName + '" value="">'
  + '<input type="hidden" name="' + hiddenUpdateIdName + '" value="">'
  + '<input type="hidden" name="' + hiddenTextName + '" value="">'
  + '<input type="hidden" name="' + hiddenParentIdName + '" value="">'
  + '<input type="hidden" name="' + hiddenParentClassName + '" value="">'
  + '</span>';



// イベントハンドラ
function doBodyMouseUp(body) {
  var item = event.srcElement;
  doUndragItem();
}
function doClick(e) {
  var item = getItem(e);
  doSelectItem(item);
}
function doDblClick(e) {
  var item = getItem(e);
  doSelectItem(item);
  doEditItem(selectedItem);
}
function doMouseDown(e) {
  var item = getItem(e);
  if (selectedItem != null) {
    doUnselectItem(selectedItem);
  }
  doDragItem(item);
}
function doMouseUp(e) {
  if (targetItem == null) {
    doUndragItem();
    return;
  }
  var item = getItem(e);
  if (item == null) {
    return;
  }
  if (targetItem != null) {
    setStyle(targetItem, textColor, backgroundColor, borderStyle);
    targetItem = null;
  }

  if (dragItem != null && dragItem != item) {
    doDropItem(item);
  }
  doUndragItem();
}
function doMouseOver(e) {
  var item = getItem(e);
  if (item == null) {
    return;
  }
  item = getDIVElement(item);
  if (item == null) {
    return;
  }
  item.style.cursor = 'pointer';
  if (item != null && dragItem != null && dragItem != item) {
    if (isChildElement(dragItem, item)) {
      targetItem = null;
      return;
    }
    targetItem = getSPANElement(item);
    if (targetItem != null) {
      setStyle(targetItem, dragoverTextColor, dragoverBackgroundColor, dragoverBorderStyle);
    }
  }
}
function doMouseOut(e) {
  var item = getItem(e);
  if (item == null) {
    return;
  }
  item = getDIVElement(item);
  if (item == null) {
    return;
  }
  item.style.cursor = 'default';
  if (targetItem != null) {
    targetItem.style.borderStyle = 'none';
    if (targetItem != selectedItem) {
      setStyle(targetItem, textColor, backgroundColor, borderStyle);
    }
    targetItem = null;
  }
}
function doKeyDown(e) {
  var key = null;
  var isCtrl = false;
  var isShift = false;
  var eventsrc = null;
  if (netscape) {
    eventsrc = e.target;
    key = e.which;
  } else {
    eventsrc = event.srcElement;
    key = event.keyCode;
    isCtrl = event.ctrlKey
    isShift = event.shiftKey
  }
  if (key == 13 /* Enter */) {
    var editBox = document.getElementById('editbox');
    if (editBox != null) {
      editBox.blur();
    }
  } else if (key == 113 /* F2 */) {
    if (selectedItem != null) {
      doEditItem(selectedItem);
    }
  } else if (key == 27 /* ESC */) {
    doEditCancel();
  } else if (key == 37 /* LEFT */) {
  } else if (key == 38 /* UP */) {
    if (!isCtrl && !isShift) {
      var item = getPrevItem(selectedItem);
      if (item != null) {
        doSelectItem(item);
      }
    }
  } else if (key == 39 /* RIGHT */) {
  } else if (key == 40 /* DOWN */) {
    if (!isCtrl && !isShift) {
      if (selectedItem == null) {
        var item = getFirstItem();
        doSelectItem(item);
        return;
      }
      var item = getNextItem(selectedItem);
      if (item != null) {
        doSelectItem(item);
      }
    }
  }
  
}
function showStatus(item) {
  if (item != null) {
    item = getDIVElement(item);
    var level = getLevel(item);
    var id = getElementByName(item, hiddenIdName);
    var updtid = getElementByName(item, hiddenUpdateIdName);
    var name = getElementByName(item, hiddenTextName);
    var parentid = getElementByName(item, hiddenParentIdName);
    var parentclass = getElementByName(item, hiddenParentClassName);
    var msg = level + ',id=' + item.id;
    if (id != null) {
      msg = msg + ',' + hiddenIdName + '=' + id.value;
    }
    if (updtid != null) {
      msg = msg + ',' + hiddenUpdateIdName + '=' + updtid.value;
    }
    if (name != null) {
      msg = msg + ',' + hiddenTextName + '=' + name.value;
    }
    if (parentid != null) {
      msg = msg + ',' + hiddenParentIdName + '=' + parentid.value;
    }
    if (parentclass != null) {
      msg = msg + ',' + hiddenParentClassName + '=' + parentclass.value;
    }
    window.status = msg;
  }
}

// イベントの発生したDIVエレメントを返す
function getItem(e) {
  var item = null;
  var eventtype = null;
  if (netscape) {
    item = e.target;
    eventtype = e.type;
  } else {
    item = event.srcElement;
    eventtype = event.type;
  }
  if (item.tagName == 'INPUT') {
    if (event.type != 'mousedown') {
      return null;
    }
    if (rootNode != null) {
      rootNode.onselectstart = null;
    }
    item.onblur = doEditEnd;
    return null;
  }
  return getDIVElement(item);
}

// itemのDIVエレメントを返す
function getDIVElement(item) {
  if (item == null) {
    return null;
  }
  if (item.nodeName == 'DIV') {
    return item;
  }
  if (item.parentNode != null) {
    var parent = item.parentNode;
    if (parent.nodeName == 'DIV' && parent.id != null) {
      return parent;
    }
    return getDIVElement(parent);
  }
  return null;
}
// item配下のSPANエレメントを返す
function getSPANElement(item) {
  if (item == null) {
    return null;
  }
  if (item.nodeName == 'SPAN' && item.className == 'item') {
    return item;
  }
  item = getDIVElement(item);
  var children = item.childNodes;
  for (var i = 0; i < children.length; i++) {
    if (children[i].nodeName == 'SPAN' && children[i].className == 'item') {
      return children[i];
    } else if (children[i].nodeName == 'DIV') {
      return getSPANElement(children[i]);
    }
  }
  return null;
}
// item配下のtagnameエレメントを返す
function getElementByTagName(item, tagname) {
  if (item == null) {
    return null;
  }
  if (item.nodeName == tagname) {
    return item;
  }
  item = getSPANElement(item);
  var children = item.childNodes;
  for (var i = 0; i < children.length; i++) {
    if (children[i].nodeName == tagname) {
      return children[i];
    }
  }
  return null;
}
// item配下のnameを持つinutエレメントを返す
function getElementByName(item, name) {
  if (item == null) {
    return null;
  }
  item = getSPANElement(item);
  if (item == null) {
    return null;
  }
  var children = item.childNodes;
  for (var i = 0; i < children.length; i++) {
    if (children[i].nodeName == 'INPUT') {
      var elem = children[i];
      if (elem.name == name) {
        return elem;
      }
    }
  }
  return null;
}
// item配下のclass名nameを持つエレメントを返す
function getElementByClassName(item, name) {
  if (item == null) {
    return null;
  }
  item = getSPANElement(item);
  if (item == null) {
    return null;
  }
  var children = item.childNodes;
  for (var i = 0; i < children.length; i++) {
    if (children[i].className == name) {
      return children[i];
    }
  }
  return null;
}
function getText(item) {
  var textElement = getElementByName(item, hiddenTextName);
  if (textElement != null) {
    return textElement.value;
  }
  return "";
}
function setText(item, text) {
  var textElement = getElementByName(item, hiddenTextName);
  if (textElement != null) {
    textElement.value = text;
  }
  var dispTextElement = getElementByClassName(item, 'text');
  if (dispTextElement != null) {
    dispTextElement.innerHTML = '<nobr>' + text + '</nobr>';
  }
}


// 選択されているかをチェック
function isSelected(item) {
  if (item == null || selectedItem == null) {
    return false;
  }
  if (item == selectedItem) {
    return true;
  }
  return false;
}
// idがitem配下ののエレメントかをチェック
function isChildElement(item, target) {
  if (item == null) {
    return false;
  }
  if (item.childNodes == null || item.childNodes.length == 0) {
    return false;
  }
  target = getDIVElement(target);
  if (target == null) {
    return null;
  }
  var children = item.childNodes;
  for (var i = 0; i < children.length; i++) {
    if (children[i].id == target.id) {
      return true;
    } else if (children[i].childNodes != null && children[i].childNodes.length > 0) {
      if (isChildElement(children[i], target)) {
        return true;
      }
    }
  }
  return false;
}


function doSelectItem(item) {
  item = getSPANElement(item);
  if (item != null && item != selectedItem) {
    if (selectedItem != null) {
      doUnselectItem(selectedItem);
    }
    selectedItem = item;
    setStyle(selectedItem, selectedTextColor, selectedBackgroundColor, selectedBorderStyle);
    showStatus(selectedItem);
  }
  rootNode.focus();
}
function doUnselectItem(item) {
  if (item != null) {
    setStyle(item, textColor, backgroundColor, 'none');
    selectedItem = null;
  }
}
function doDragItem(item) {
  if (item != null) {
    dragItem = getDIVElement(item);
    dragItem.style.cursor = 'pointer';
    setStyle(dragItem, draggingTextColor, draggingBackgroundColor, draggingBorderStyle);
  }
}
function doUndragItem() {
  if (dragItem != null) {
    if (isSelected(dragItem)) {
      setStyle(dragItem, selectedTextColor, selectedBackgroundColor, selectedBorderStyle);
    } else {
      setStyle(dragItem, textColor, backgroundColor, borderStyle);
    }
    dragItem.style.cursor = 'default';
    dragItem = null;
  }
  if (targetItem != null) {
    setStyle(targetItem, textColor, backgroundColor, borderStyle);
    targetItem = null;
  }
}
// dragItemをitemへドラッグアンドドロップしたときの処理
function doDropItem(item) {
  item = getDIVElement(item);
  if (item == dragItem) {
    return;
  }
  var selectedid = dragItem.id;
  doUnselectItem(dragItem);
  moveItemAfter(item, dragItem);
  doSelectItem(document.getElementById(selectedid));
}
function doEditItem(item) {
  if (document.getElementById('editbox') != null) {
    return;
  }
  if (rootNode != null) {
    rootNode.onselectstart = null;
  }
  var editItem = getSPANElement(item);
  if (editItem == null || targetItem != null || editItem != selectedItem) {
    return;
  }
  doUnselectItem(editItem);
  var text = getText(editItem);
  var textElement = getElementByClassName(editItem, 'text');
  if (textElement != null) {
    var width = textElement.style.width;
    textElement.innerHTML = '<input id="editbox" type="text" value="' + text
     + '" onblur="doEditEnd(this);" onkeydown="doKeyDown();">';
    var editBox = document.getElementById('editbox');
    editBox.style.width = width;
    var nameValue = getElementByName(editBox.parentNode, hiddenTextName);
    if (nameValue != null) {
      nameValue.value = text;
    }
    editBox.select();
    editBox.focus();
  }
}
function doEditEnd() {
  if (rootNode != null) {
    rootNode.onselectstart = doSelectStart;
  }
  var editBox = document.getElementById('editbox');
  if (editBox == null) {
    return;
  }
  var text = editBox.value;
  var parentNode = editBox.parentNode;
  setText(parentNode, text);
  doModifiedItem(parentNode);
  doSelectItem(parentNode);
}
function doEditCancel() {
  if (rootNode != null) {
    rootNode.onselectstart = doSelectStart;
  }
  var editBox = document.getElementById('editbox');
  if (editBox == null) {
    return;
  }
  var text = getText(editBox.parentNode);
  editBox.onblur = null;
  editBox.blur();
  var parentNode = editBox.parentNode;
  setText(parentNode, text);
  doModifiedItem(parentNode);
  doSelectItem(parentNode);
}


// SPANエレメントに対しstyleを設定する
function setStyle(item, text, background, border) {
  if (item != null) {
    if (item.nodeName == 'DIV') {
      item = getSPANElement(item);
    }
    if (item == null) {
      return;
    }
    if (text != null) {
      item.style.color = text;
    }
    if(background != null) {
      item.style.backgroundColor = background;
    }
    if (border != null) {
      item.style.borderStyle = border;
      item.style.borderWidth = '1px';
    }
  }
}
// itemの下(同一階層)に新しいアイテムを追加する
function appendNewItem(item, newid, child) {
  item = getDIVElement(item);
  if (item == null) {
    return null;
  }
  if (item.id == rootNodeName) {
    var tmp = getLastItem();
    if (tmp != null) {
      item = getDIVElement(tmp);
      child = false;
    }
  }
  if (newid == null) {
    newid = autoIdNumberStart;
    autoIdNumberStart += autoIdNumberIncrease;
  }
  var selectedid = item.id;
  var selectedlevel = getLevel(item);
  doUnselectItem(selectedItem);
  if (item != null) {
    var newitem = document.createElement('DIV');
    var nextItem = getNextItemByLevel(item, getLevel(item));
    if (nextItem != null) {
      item.parentNode.insertBefore(newitem, nextItem);
    } else {
      if (item.id == rootNodeName || child) {
        item.appendChild(newitem);
        selectedlevel ++;
      } else {
        item.parentNode.appendChild(newitem);
      }
    }
    newitem.innerHTML = itemBaseHTML;
    newitem.id = newid;
  }
  var newitem = document.getElementById(newid);
  if (child) {
    setLevel(newitem, selectedlevel + 1);
  } else {
    setLevel(newitem, selectedlevel);
  }
  initDragItem(document.getElementById(selectedid));
  initDragItem(newitem);
  doModifiedItem(newitem);
  return newitem;
}
// toitemの前(同一階層)にfromitemを移動する
function moveItem(toitem, fromitem) {
  fromitem = getDIVElement(fromitem);
  if (fromitem == null) {
    return;
  }
  var toid = null;
  var tolevel = 0;
  if (toitem != null) {
    toitem = getDIVElement(toitem);
    toid = toitem.id;
    tolevel = getLevel(toitem);
  }
  var fromid = fromitem.id;
  doUnselectItem(selectedItem);
  var fromHTML = fromitem.innerHTML;
  var newitem = document.createElement('DIV');
  if (toitem == null) {
    fromitem.parentNode.appendChild(newitem);
    tolevel = getLevel(fromitem);
  } else {
    toitem.parentNode.insertBefore(newitem, toitem);
  }
  newitem.innerHTML = fromHTML;
  newitem.id = fromid;
  var fromparent = fromitem.parentNode;
  fromparent.removeChild(fromitem);
  var newitem = document.getElementById(fromid);
  setLevel(newitem, tolevel);
  doModifiedItem(fromparent);
  doModifiedItem(newitem.parentNode);
}
// toitemの後ろ(同一階層)にfromitemを移動する
function moveItemAfter(toitem, fromitem) {
  if (fromitem == null || toitem == null) {
    return;
  }
  var toid = null;
  var tolevel = 0;
  if (toitem != null) {
    toitem = getDIVElement(toitem);
    toid = toitem.id;
    tolevel = getLevel(toitem);
  }
  var parentitem = toitem.parentNode;
  toitem = getNextItemByLevel(toitem, getLevel(toitem));
  var fromid = fromitem.id;
  doUnselectItem(selectedItem);
  var fromHTML = fromitem.innerHTML;
  var newitem = document.createElement('DIV');
  if (toitem == null) {
    parentitem.appendChild(newitem);
  } else {
    toitem.parentNode.insertBefore(newitem, toitem);
  }
  newitem.innerHTML = fromHTML;
  newitem.id = fromid;
  var fromparent = fromitem.parentNode;
  fromparent.removeChild(fromitem);
  setLevel(newitem, tolevel);
  doModifiedItem(fromparent);
  doModifiedItem(newitem.parentNode);
}
// fromitemをtoitemの１階層下に移動する
function moveItemToChild(toitem, fromitem) {
  toitem = getDIVElement(toitem);
  fromitem = getDIVElement(fromitem);
  if (toitem == null || fromitem == null) {
    return;
  }
  var tolevel = getLevel(toitem);
  var fromid = fromitem.id;
  doUnselectItem(selectedItem);
  var fromHTML = fromitem.innerHTML;
  var fromparent = fromitem.parentNode;
  fromparent.removeChild(fromitem);
  var newitem = document.createElement('DIV');
  toitem.appendChild(newitem);
  newitem.innerHTML = fromHTML;
  newitem.id = fromid;
  setLevel(newitem, tolevel + 1);
  doModifiedItem(fromparent);
  doModifiedItem(newitem.parentNode);
}
function setAttribute(item, id, value) {
  if (item == null) {
    return;
  }
  var elm = getElementByName(item, id);
  if (elm != null) {
    elm.value = value;
  } else {
    elm = getElementByClassName(item, id);
    if (elm.tagName == 'SPAN') {
      elm.innerHTML = value;
    }
  }
  if (id == 'id') {
    item = getDIVElement(item);
    item.id = value;
  }
}
// 移動等変更終了後に呼ばれる関数
function doModifiedItem(item) {
  item = getDIVElement(item);
  if (item == null) {
    return;
  }
  if (item != rootNode) {
    var level = getLevel(item);
    var textElement = getElementByClassName(item, 'text');
    var text = getText(item);
    if (textElement != null) {
      textElement.style.width = textColumnSize - level * indentSize;
      textElement.style.overflow = 'hidden';
      textElement.title = text;
    }
    var idElement = getElementByName(item, hiddenIdName);
    if (idElement != null) {
      idElement.value = item.id;
    }
    // 合計ID
    var parentId = getElementByName(item, hiddenParentIdName);
    if (parentId != null) {
      var parent = item.parentNode;
      if (parent != null && parent.nodeName == 'DIV' && parent != rootNode) {
        var id = getElementByName(parent, hiddenIdName);
        parentId.value = id.value;
      } else {
        parentId.value = '';
      }
    }

    // 合計区分
    var parentClass = getElementByName(item, hiddenParentClassName);
    if (parentClass != null) {
      if (hasChild) {
        parentClass.value = '1';
      } else {
        parentClass.value = '0';
      }
    }
  }

  var children = item.childNodes;
  var hasChild = false;
  for (var i = 0; i < children.length; i++) {
    if (children[i].nodeName == 'DIV') {
      doModifiedItem(children[i]);
      hasChild = true;
    }
  }

  initDragItem(item);

}



// 最初のDIVアイテムを返す
function getFirstItem() {
  for (var i = 0; i < document.all.length; i++) {
    var tmp = document.all[i];
    if (tmp.nodeName == 'DIV' && tmp.id != null && tmp.id != rootNodeName) {
      return tmp;
    }
  }
  return null;
}
// root直下の最後のDIVアイテムを返す
function getLastItem() {
  var root = document.getElementById(rootNodeName);
  var children = root.childNodes;
  for (var i = children.length - 1; i >= 0 ; i--) {
    var tmp = children[i];
    if (tmp.nodeName == 'DIV' && tmp.id != null) {
      return tmp;
    }
  }
  return null;
}
// 直前(上側)のDIVアイテムを返す
function getPrevItem(item) {
  if (item == null) {
    return null;
  }
  if (item.nodeName != 'DIV') {
    item = getDIVElement(item);
  }
  var prevItem = null;
  for (var i = 0; i < document.all.length; i++) {
    var tmp = document.all[i];
    if (tmp == item) {
      break;
    }
    if (tmp.nodeName == 'DIV' && tmp.id != null && tmp.id != rootNodeName) {
      prevItem = tmp;
    }
  }
  return prevItem;
}
// 直後(下側)のDIVアイテムを返す
function getNextItem(item) {
  if (item == null) {
    return null;
  }
  if (item.nodeName != 'DIV') {
    item = getDIVElement(item);
  }
  var nextItem = null;
  for (var i = 0; i < document.all.length; i++) {
    var tmp = document.all[i];
    if (nextItem == null && tmp != item) {
      continue;
    }
    if (nextItem != null && tmp.nodeName == 'DIV') {
      return tmp;
    }
    if (nextItem == null) {
      nextItem = tmp;
    }
  }
  return null;
}
// 直前(上側)のDIVアイテムを返す
function getPrevItemByLevel(item, level) {
  if (item == null) {
    return null;
  }
  if (item.nodeName != 'DIV') {
    item = getDIVElement(item);
  }
  var prevItem = null;
  var children = item.parentNode.childNodes;
  for (var i = 0; i < children.length; i++) {
    var tmp = children[i];
    if (tmp == item) {
      break;
    }
    if (tmp.nodeName == 'DIV') {
      prevItem = tmp;
    }
  }
  if (prevItem == null) {
    return null;
  }
  return prevItem;
}
// 直後(下側)のレベルがlevelのDIVアイテムを返す
function getNextItemByLevel(item, level) {
  if (item == null) {
    return null;
  }
  if (item.nodeName != 'DIV') {
    item = getDIVElement(item);
  }
  var nextItem = null;
  var children = item.parentNode.childNodes;
  for (var i = children.length - 1; i >= 0 ; i--) {
    var tmp = children[i];
    if (tmp == item) {
      break;
    }
    if (tmp.nodeName == 'DIV') {
      nextItem = tmp;
    }
  }
  if (nextItem == null) {
    return null;
  }
  return nextItem;
}


function getLevel(item) {
  if (item == null) {
    return -1;
  }
  if (item.nodeName != 'DIV') {
    item = item.parentNode;
  }
  var level = item.className;
  if (level != null && level.substring(0, 5) == 'level') {
    return Number(level.substring(5, level.length));
  }
  return -1;
}
// itemに階層レベルを設定する（再帰的に子アイテムを設定）
function setLevel(item, level) {
  if (item == null) {
    return;
  }
  item.className = 'level' + Number(level).toString();
  if (item.childNodes == null) {
    return;
  }
  var children = item.childNodes;
  for (var i = 0; i < children.length; i++) {
    if (children[i].nodeName == 'DIV') {
      setLevel(children[i], level + 1);
    }
  }
}
// item配下の指定したレベルのアイテムを返す
function getLevelItem(item, level) {
  if (item == null) {
    return null;
  }
  if (item.nodeName != 'DIV') {
    item = item.parentNode;
    if (item.nodeName != 'DIV') {
      return null;
    }
  }
  if (getLevel(item) == level) {
    return item;
  }
  if (item.parentNode == null || item.parentNode.nodeName == 'BODY') {
    return null;
  }
  if (item.parentNode.nodeName == 'DIV' && getLevel(item.parentNode) == level) {
    return item.parentNode;
  } else {
    var parent = getLevelItem(item.parentNode, level);
    if (parent == null) {
      return item;
    }
    return parent;
  }
}
// 選択中のアイテムの直前(上側)のアイテムの子アイテムとして移動
function doMoveToChild() {
  if (selectedItem == null || selectedItem.parentNode == null) {
    return;
  }
  var selectedid = selectedItem.parentNode.id;
  var src = getDIVElement(selectedItem);
  var prevItem = null;
  prevItem = getPrevItemByLevel(src, getLevel(src));
  if (prevItem != null) {
    moveItemToChild(prevItem, src);
    doSelectItem(document.getElementById(selectedid));
  }
}
// 選択中のアイテムを１つ上の階層へ移動する
function doMoveToParent() {
  if (selectedItem == null || selectedItem.parentNode == null || selectedItem.parentNode.parentNode == null) {
    return;
  }
  if (selectedItem.parentNode.parentNode.nodeName != 'DIV') {
    return;
  }
  var selectedid = selectedItem.parentNode.id;
  var parentitem = getDIVElement(selectedItem.parentNode.parentNode);
  var toitem = getNextItemByLevel(parentitem, getLevel(parentitem));
  if (toitem != null) {
    moveItem(toitem, selectedItem);
  } else {
    moveItemToChild(parentitem.parentNode, selectedItem);
  }
  doSelectItem(document.getElementById(selectedid));
}
// 選択中のアイテムを１つ上(同一階層のみ)へ移動する
function doMoveToUp() {
  if (selectedItem == null) {
    return;
  }
  var selectedid = selectedItem.parentNode.id;
  var level = getLevel(selectedItem);
  var prevItem = getPrevItemByLevel(selectedItem, level);
  if (prevItem == null) {
    return;
  }
  moveItem(prevItem, selectedItem);
  doSelectItem(document.getElementById(selectedid));
}
// 選択中のアイテムを１つ上(同一階層のみ)へ移動する
function doMoveToDown() {
  if (selectedItem == null) {
    return;
  }
  var level = getLevel(selectedItem);
  var nextItem = getNextItemByLevel(selectedItem, level);
  if (nextItem != null) {
    var selectedid = selectedItem.parentNode.id;
    nextitem = getNextItemByLevel(nextItem, level);
    moveItem(nextitem, selectedItem);
    doSelectItem(document.getElementById(selectedid));
  }
}
function doAddItem() {
  var newitem = null;
  if (selectedItem == null) {
    newitem = appendNewItem(document.getElementById(rootNodeName), null, true);
  } else {
    newitem = appendNewItem(selectedItem, null, false);
  }
  doSelectItem(newitem);
  doEditItem(newitem);
}
function doRemoveItem() {
  if (selectedItem == null) {
    return;
  }
  var item = getDIVElement(selectedItem);
  if (item == null | item.parentNode == null) {
    return;
  }
  var parent = item.parentNode;
  parent.removeChild(item);
  doModifiedItem(parent);
  selectedItem = null;
}


function doSelectStart(e){
  if (netscape) {
    alert('test');  } else {
    window.event.returnValue = false;
  }
  return false;}
function initDragItem(item) {
  if (item == null) {
    return;
  }
  if (item != rootNode) {
    item.onmousedown = doMouseDown;
    item.onmouseup = doMouseUp;
    item.onmouseover = doMouseOver;
    item.onmouseout = doMouseOut;
    item.onclick = doClick;
    item.ondblclick = doDblClick;
  }

  if (item.childNodes == null) {
    return;
  }
  var children = item.childNodes;
  for (var i = 0; i < children.length; i++) {
    if (children[i].nodeName == 'DIV') {
      initDragItem(children[i]);
    }
  }
}

// アイテムの配置
var noparentarray = new Array();
function putItem(id, parentid, text) {
  var parentitem = null;
  var tochild = false;
  if (rootNode == null) {
    rootNode = document.getElementById(rootNodeName);
  }
  if (parentid == null || parentid == '' || parentid == ' ') {
    parentitem = rootNode;
  } else {
    parentitem = document.getElementById(parentid);
    if (parentitem == null) {
      // 親アイテムが見つからない場合は、root直下に配置しアレイに格納
      noparentarray[id] = parentid;
      parentitem = document.getElementById(rootNodeName);
    }
    //test用ダミー
    else {
      noparentarray[id] = parentid;
      parentitem = document.getElementById(rootNodeName);
    }
    //
    tochild = true;
  }
  var newitem = appendNewItem(parentitem, id, tochild);
  if (newitem != null) {
    setText(newitem, text);
    doModifiedItem(newitem);
  }
}
// 最終的なアイテムの階層構造の設定
function disposeItems() {
  for(var id in noparentarray ) {
    var parentid = noparentarray[id];
    moveItemToChild(document.getElementById(parentid), document.getElementById(id));
  }
  if (rootNode == null) {
    rootNode = document.getElementById(rootNodeName);
  }
  if (rootNode != null) {
    rootNode.onselectstart = doSelectStart;
  }
}

// グローバルステートメント
if (navigator.appName == 'Netscape') {
  netscape = true;
  window.captureEvents(Event.CLICK|Event.MOUSEDOWN|Event.MOUSEUP|Event.KEYDOWN|Event.KEYUP|Event.BLUR|Event.SELECT);
}document.onkeydown = doKeyDown;
