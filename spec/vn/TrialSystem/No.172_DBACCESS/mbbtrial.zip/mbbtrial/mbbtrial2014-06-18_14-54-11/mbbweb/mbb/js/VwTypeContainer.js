/**
 * VwTypeContainer
 * 項目タイプ表示（コンテナ系）
 */
LAST_MODIFIED('2004.10.29', '1.0.26');

/*
 * 使用するタイプを登録する
 */
registerViewObject(TYPE.FORM, ViewObjectPage);
registerViewObject(TYPE.TABLE, ViewObjectTable);
registerViewObject(TYPE.PANEL, ViewObjectPanel);

/**
 * Page情報を含むFormタイプのtypeObject実装クラス
 * @param  :
 * @return :作成したHTML文字列
 */
function ViewObjectPage(){

  ViewObjectPage.prototype.setDefaultProperty  = fnSetDefaultProperty_common;
  ViewObjectPage.prototype.getPropertiesHtml   = fnGetPropertiesHtml;

  function fnGetPropertiesHtml(objDs){
    return;
  }


  /** 
   * 表示更新メソッド群 
   */
  this.setter = new Setter();

  function Setter() {
    Setter.prototype.pagewidth = _pagewidth;
    Setter.prototype.pageheight = _pageheight;
    Setter.prototype.backgroundimage = table_background;
    Setter.prototype.style = _style;
    
    // 幅
    function _pagewidth(newValue, elementId, dataset, cellElementId, cellDataset) {
      var modified = '';
      if(newValue < 10) {
        newValue = 10;
        modified = 'modified';
      }
      getDocumentElementById(elementId).style.width = newValue;
      return flags(newValue, modified);
    }
    
    // 高さ
    function _pageheight(newValue, elementId, dataset, cellElementId, cellDataset) {
      getDocumentElementById(elementId).style.height = newValue;
      return flags(newValue);
    }
  }

  // スタイル
  function _style(newValue, elementId, dataset, cellElementId, cellDataset) {
    var formElement = getDocumentElementById(elementId);
    var classname = getClassNameFromStylePropertyValue(newValue);
    if(classname != '') {
      formElement.className = 'vw-form ' + classname;
    } else {
      formElement.className = 'vw-form';
    }
    return flags(newValue);
  }
}

/**
 * FormタイプのtypeObject実装クラス
 * @param  :
 * @return :作成したHTML文字列
 */
/*
function objectForm(){

  objectForm.prototype.setDefaultProperty  = fnSetDefaultProperty;
  objectForm.prototype.getPropertiesHtml   = fnGetPropertiesHtml;

  function fnSetDefaultProperty(objDS){
    var preference = pref.init.form;
    objDS.setProperty('action',     preference.get('action'));
    objDS.setProperty('method',     preference.get('method'));
  }

  function fnGetPropertiesHtml(objDs){
    return;
  }

}
*/

/**
 * FrameタイプのtypeObject実装クラス
 * @param  :
 * @return :作成したHTML文字列
 */

/**
 * PanelタイプのtypeObject実装クラス
 * @param  :
 * @return :作成したHTML文字列
 */
function ViewObjectPanel(){

  ViewObjectPanel.prototype.setDefaultProperty  = fnSetDefaultProperty;
  ViewObjectPanel.prototype.getPropertiesHtml   = fnGetPropertiesHtml;

  function fnSetDefaultProperty(objDS){
    fnSetDefaultProperty_common(objDS);
    var preference = pref.init.panel;
    var width = preference.get('width');
    var pageWidth = parseInt(getDataSet(ELEMENTID_FIRSTFORM).getProperty('pagewidth'));
    var right = Number(preference.get('right'));
    var left = Number(preference.get('left'));
    var setwidth = pageWidth - left + right;
    if(width && width < setwidth) {
      setwidth = width;
    } 
    if(setwidth < 10) {
      setwidth = 10;
    } 
    objDS.setProperty('width',  setwidth);
    objDS.setProperty('height', preference.get('rows') * DISPLAYROWHEIGHT);
  }

  function fnGetPropertiesHtml(objDs){
    var strCursor  = getCursorType(objDs);
    var strBgcolor = tagFree(getBgcolorType(objDs, 1), '');
    var strBorderColor = tagFree(objDs.getProperty('bordercolor'), '');
    var strHTML  = '<table id="' + objDs.getProperty('id') +
      '" width="' + objDs.getProperty('width') +
      'px" height="' + objDs.getProperty('height') +
      'px" class="vw-panel ' + getNonTextElementClassProperty(objDs) +
      '" style="cursor:' + strCursor +
      '; background-color:' + strBgcolor +
      '; border-color:' + strBorderColor;
    if(pref.view.get('usebackgroundimage')) {
      strHTML += ';background-image:' + getImageSrcUrl(objDs.getProperty('backgroundimage'));
    }
    strHTML += ';' + cancelStyle() + '" cellspacing="0" cellpadding="0"><tr><td>&nbsp;</td></tr></table>';

    return strHTML;
  }

  /** 
   * 表示更新メソッド群 
   */
  this.setter = new Setter();

  function Setter() {
    Setter.prototype.width = _width;
    Setter.prototype.height = _height;
    Setter.prototype.backgroundcolor = table_backgroundcolor;
    Setter.prototype.backgroundimage = table_background;

    // 幅
    function _width(newValue, elementId, dataset, cellElementId, cellDataset) {
      var validvalue = getValidPanelWidth(newValue);
      var modified = ''
      if(newValue != validvalue){
        newValue = validvalue;
        modified = 'modified';
      }

      getDocumentElementById(elementId).width = newValue;
      getDocumentElementById(elementId).setAttribute('width', newValue);
      return flags(newValue, 'resized', modified, 'border');
    }
    
    // 高さ
    function _height(newValue, elementId, dataset, cellElementId, cellDataset) {
      var validvalue = getValidPanelHeight(newValue);
      var modified = ''
      if(newValue != validvalue){
        newValue = validvalue;
        modified = 'modified';
      }
      
      dataset.setProperty('rows', newValue / DISPLAYROWHEIGHT);
      getDocumentElementById(elementId).height = newValue;
      getDocumentElementById(elementId).setAttribute('height', newValue);
      return flags(newValue, 'resized', 'modified');
    }
  }
}


/**
 * TableタイプのtypeObject実装クラス
 * @param  :
 * @return :作成したHTML文字列
 */
function ViewObjectTable(){

  ViewObjectTable.prototype.setDefaultProperty  = fnSetDefaultProperty;
  ViewObjectTable.prototype.getPropertiesHtml   = fnGetPropertiesHtml;

  function fnSetDefaultProperty(objDS){
    fnSetDefaultProperty_common(objDS);
    var id = objDS.getProperty('id')
    var objDSTD = getDataSet(getCellId(id));
    var preference = pref.init.table;
    var width = preference.get('width');
    var pageWidth = parseInt(getDataSet(ELEMENTID_FIRSTFORM).getProperty('pagewidth'));
    var right = Number(preference.get('right'));
    var left = Number(preference.get('left'));
    var setwidth = pageWidth - left + right;
    if(width && width < setwidth) {
      setwidth = width;
    } 
    if(setwidth < 10) {
      setwidth = 10;
    } 
    objDSTD.setProperty('parenttableid', id);
    objDSTD.setProperty('cellwidth',     setwidth);
    objDSTD.setProperty('cellheight',    preference.get('rows') * DISPLAYROWHEIGHT);

    objDS.setProperty('tablecols', 1);
    objDS.setProperty('tablerows', 1);
    if(!useTitles(objDS.getProperty('tablemode'))) {
      objDS.setProperty('titlecols', '');
      objDS.setProperty('titlerows', '');
    }
    objDS.setExtraProperty('setwidth', setwidth);
  }

  function fnGetPropertiesHtml(objDs){

    //TABLEのID取得
    var tmpTblId = objDs.getProperty('id');

    //作成する行数、列数取得
    var createCols = Number(objDs.getProperty('tablecols'));
    if(useTableRows(objDs.getProperty('tablemode'))){
      var titlerows = 0;
      var titlecols = 0;
      var createRows = Number(objDs.getProperty('tablerows'));
    }else{
      var titlerows = Number(objDs.getProperty('titlerows'));
      var titlecols = Number(objDs.getProperty('titlecols'));
      var createRows = titlerows + 1;
      
      if(titlerows > 0 || titlecols > 0) {
        var title = {row:{},col:{}};
        title.corner = objDs.getProperty('corner');
        title.row.className = getElementClassProperty(objDs, 'titlerowstyle');
        title.row.bordercolor = objDs.getProperty('titlerowbordercolor');
        title.row.bgcolor = objDs.getProperty('titlerowcolor');
        title.col.className = getElementClassProperty(objDs, 'titlecolstyle');
        title.col.bordercolor = objDs.getProperty('titlecolbordercolor');
        title.col.bgcolor = objDs.getProperty('titlecolcolor');
      }
    }

    var strBgcolor = getBgcolorType(objDs, 1);
    var strCursor  = getCursorType(objDs);

    var bordercolor = tagFree(objDs.getProperty('bordercolor'), '#000000');
    if(bordercolor == ''){
      //bordercolor = '#000000';
    }

    var borderstyle = objDs.getProperty('borderstyle');
    if(borderstyle == '' || borderstyle == 'none'){
      borderstyle = 'solid';
    }
    
    var visible = true;
    if(objDs.getProperty('visibility') == 'hidden'){
      visible = false;
    }
    
    //TABLEとCELLのHTML文字列作成
    var strHTML = '<table id="' + tmpTblId +
      '" class="vw-table ' + getNonTextElementClassProperty(objDs) +
      '" style="cursor:' + strCursor +
      '; background-color:' + tagFree(strBgcolor, pref.view.get('taggedtablecolor')) +
      '; border-collapse:collapse; border-width:1px; border-style:solid; border-color:' + bordercolor + ';font-size:1px; margin:0px; padding:0px';
    if(pref.view.get('usebackgroundimage')) {
      strHTML += '; background-image:' + getImageSrcUrl(objDs.getProperty('backgroundimage'));
    }
    strHTML += ';" cellspacing="0" cellpadding="0"><caption id="' + tmpTblId + '_caption_top"></caption><tbody>';



    var windowStatusKeep = window.status;
    var takeMuchTime = (createRows * createCols > 20);
    for(var i=1; i<=createRows; i++){
      strHTML +=   '<tr>';

      for(var j=1; j<=createCols; j++){
        var tmpHtml = '';
        if(takeMuchTime) {
          window.status = windowStatusKeep + ' (行:' + i + ' 列:' + j + ')';
        }
        //CELLのID生成
        var tmpTdPanelId = getCellId(tmpTblId, i, j);
        //CELLのDataSet保存
        var tmpTdObjDS   = getDataSet(tmpTdPanelId);
        if(tmpTdObjDS == null) {
          throw createError('cell "' + tmpTdPanelId + '" is not exists.', 'VwTypeContainer.js', 'ViewObjectTable.fnGetPropertiesHtml');
        }
        
        if(i <= titlerows || j <= titlecols) {
          if(i <= titlerows && j <= titlecols) {
            var corner = title.corner;
          } else if(i <= titlerows) {
            var corner = 'CORNER_ROW';
          } else {
            var corner = 'CORNER_COL';
          }
          if(corner == 'CORNER_ROW') {
            var th = title.row;
          } else {
            var th = title.col;
          }

          tmpHtml +=   '<td class="vw-table-th ' + th.className + '" style="background-color:' + th.bgcolor + ';border:solid 1px ' + th.bordercolor + ';margin:0px; padding:0px;">'
                  +  '<table id="' + tmpTdPanelId + '" class="vw-cell ' + getCellElementClassProperty(tmpTdObjDS) + '" ';
        } else {
          tmpHtml +=   '<td class="vw-table-td" style="border:solid 1px ' + bordercolor + ';margin:0px; padding:0px;">'
                  +  '<table id="' + tmpTdPanelId + '" class="vw-cell ' + getCellElementClassProperty(tmpTdObjDS) + '" ';
        }

        var cellvisible = visible;
        if(visible){
          if(tmpTdObjDS.getProperty('cellvisibility') == 'hidden'){
            cellvisible = false;
            tmpHtml += ' bgcolor="' + pref.view.get('hiddencolor') + '" ';
          } else {
            var bgcolor = tmpTdObjDS.getProperty('cellbackgroundcolor');

            tmpHtml +=       'bgcolor="' + tagFree(bgcolor, pref.view.get('taggedtablecolor')) + '" ';
          }
        }

        tmpHtml +=       'cellspacing="0" cellpadding="0" ';

        var cellbordercolor = tagFree(tmpTdObjDS.getProperty('cellbordercolor'), 'silver');
        //var cellheight = getHeightByRows(tmpTdObjDS.getProperty('rows'));
        var cellheight = parseInt(tmpTdObjDS.getProperty('cellheight'))
        if(cellbordercolor != ''){
          tmpHtml += 'width="' + (parseInt(tmpTdObjDS.getProperty('cellwidth')) - 1) +
            'px" height="' + (cellheight - 1) +
            'px" border="1" bordercolor="' + cellbordercolor + '" ';
        }else{
          tmpHtml += 'width="' + (parseInt(tmpTdObjDS.getProperty('cellwidth')) - 1) +
            'px" height="' + (cellheight - 1) +
            'px" border="0" ';
        }

        tmpHtml += 'style="cursor:' + strCursor + '; border-collapse:collapse;font-size:1px;margin:0px; padding:0px;';
        if(cellvisible) {
          if(pref.view.get('usebackgroundimage')) {
            tmpHtml += 'background-image:' + getImageSrcUrl(tmpTdObjDS.getProperty('cellbackgroundimage')) + ';';
          }
        } else {
          tmpHtml += 'background-color:' + pref.view.get('hiddencolor') + ';';
        }
        tmpHtml += '"><tr><td>&nbsp;</td></tr></table></td>';

        strHTML += tmpHtml;
      }
      strHTML +=   '</tr>';
    }
    strHTML +=   '</tbody></table>';

    window.status = windowStatusKeep;
    return strHTML;
  }

  /** 
   * 表示更新メソッド群 
   */
  this.setter = new Setter();

  function Setter() {
    Setter.prototype.width = _width;
    Setter.prototype.height = _height;
    Setter.prototype.tablemode = _tablemode;
    Setter.prototype.tablecols = _tablecols;
    Setter.prototype.tablerows = _tablerows;
    Setter.prototype.maxlines = _maxlines;
    Setter.prototype.corner = _corner;
    Setter.prototype.titlecols = _titlecols;
    Setter.prototype.titlerows = _titlerows;
    Setter.prototype.backgroundcolor = table_backgroundcolor;
    Setter.prototype.backgroundimage = table_background;
    Setter.prototype.bordercolor = _bordercolor;
    Setter.prototype.titlerowbordercolor = _$repaint;
    Setter.prototype.titlerowcolor = _$repaint;
    Setter.prototype.titlerowstyle = _$repaint;
    Setter.prototype.titlecolbordercolor = _$repaint;
    Setter.prototype.titlecolcolor = _$repaint;
    Setter.prototype.titlecolstyle = _$repaint;
    Setter.prototype.cellvisibility = _cellvisibility;
    Setter.prototype.cellwidth = _cellwidth;
    Setter.prototype.cellheight = _cellheight;
    Setter.prototype.cellbackgroundcolor = _cellbackgroundcolor;
    Setter.prototype.cellbackgroundimage = _cellbackgroundimage;
    Setter.prototype.cellbordercolor = _cellbordercolor;
    Setter.prototype.cellstyle = _cellstyle;

    Setter.prototype.resizewidth = _resizewidth;
    Setter.prototype.resizeheight = _resizeheight;

    // 幅（リサイズ時）
    function _resizewidth(newValue, elementId, dataset, cellElementId, cellDataset, inf) {
      var tablecols = dataset.getProperty('tablecols');
      var tdNewValue = newValue;
      cellDataset = getDataSet(cellElementId);
      if(!cellDataset) {
        log.debug('?(_resizewidth)cellElementId:' + cellElementId + ' elementId:' + elementId)
      }
      var tdcol = Number(cellDataset.getProperty('cellcol'));
      for(var i = 1; i <= tablecols; i++) {

        //CELLのID生成
        var tdid = getCellId(elementId, 1, i);// + tablecols;
        //CELLのDataSet保存
        var tdds   = getDataSet(tdid);
        
        var width = Number(tdds.getProperty('cellwidth'));
        
        if(i == tdcol) {
          var modifiedOriginalValue = width;
        } else {
          tdNewValue -= width;
        }
        
      }
      
      var limited = '';
      if(tdNewValue < 5) {
        newValue = newValue + 5 - tdNewValue;
        tdNewValue = 5;
      } else if(inf && inf.order && inf.order.index > 0 && inf.modifiedValues && inf.modifiedValues[tdcol]) {
        var org = inf.modifiedValues[tdcol].originalWidth;
        if(tdNewValue > org) {
          newValue = newValue + org - tdNewValue;
          tdNewValue = org;
          limited = 'limited';
        }
      }
      
      var rtn = _cellwidth(tdNewValue, elementId, dataset, cellElementId, cellDataset);
      
      //var flg = flags(newValue, 'updated', 'reconstructed');
      var flg = flags(newValue, 'updated', 'resized', 'border', limited);
      flg.modifiedField = 'fld_cellwidth';
      flg.modifiedValue = rtn.value;
      flg.modifiedOriginalValue = modifiedOriginalValue;
      return flg;
    }
    
    // 高さ（リサイズ時）
    function _resizeheight(newValue, elementId, dataset, cellElementId, cellDataset, inf) {
      //log.debug('_resizeheight(' + newValue + ',' + elementId + ',' + cellElementId + ')');
      var maxrow = getDesignTableRows(dataset);
      var tdNewValue = newValue;
      cellDataset = getDataSet(cellElementId);
      if(!cellDataset) {
        log.debug('?(_resizeheight)cellElementId:' + cellElementId + ' elementId:' + elementId)
      }
      var tdrow = Number(cellDataset.getProperty('cellrow'));
      for(var i = 1; i <= maxrow; i++) {

        //CELLのID生成
        var tdid = getCellId(elementId, i, 1);
        //CELLのDataSet保存
        var tdds   = getDataSet(tdid);
        
        var height = Number(tdds.getProperty('cellheight'));

        if(i == tdrow) {
          var modifiedOriginalValue = height;
        } else {
          tdNewValue -= height;
        }
        
      }
      
      var limited = '';
      if(tdNewValue < 20) {
        newValue = newValue + 20 - tdNewValue;
        tdNewValue = 20;
      } else if(inf && inf.order && inf.order.index > 0 && inf.modifiedValues && inf.modifiedValues[tdrow]) {
        var org = inf.modifiedValues[tdrow].originalHeight;
        if(tdNewValue > org) {
          newValue = newValue + org - tdNewValue;
          tdNewValue = org;
          limited = 'limited';
        }
      }

      var rtn = _cellheight(tdNewValue, elementId, dataset, cellElementId, cellDataset);
      var flg = flags(newValue, 'updated', 'border', limited);
      flg.reconstructed = rtn.reconstructed;
      //var flg = flags(newValue, 'updated', 'resized', 'border');
      flg.modifiedField = 'fld_cellheight';
      flg.modifiedValue = rtn.value;
      flg.modifiedOriginalValue = modifiedOriginalValue;
      //log.debug(new DescriptionObject(flg, 'flg'));
      return flg;
    }
    
    // 幅
    function _width(newValue, elementId, dataset, cellElementId, cellDataset) {
      // 無視
      return flags(newValue, 'updated');
    }
    
    // 高さ
    function _height(newValue, elementId, dataset, cellElementId, cellDataset) {
      // 無視
      return flags(newValue, 'updated');
    }

    // テーブルモード
    function _tablemode(newValue, elementId, dataset, cellElementId, cellDataset, inf) {
      log.debug('_tablemode:' + newValue);

      var updates = null;//createOtherUpdates('size', 2, updates);
      var repaint = 'repaint';
      var mxlines = '';
      
      if(inf) {
        var oldValues;
        var newValues;
        if(newValue == inf.tablemode) {
          newValues = inf;
          oldValues = inf.org;
        } else {
          newValues = inf.org;
          oldValues = inf;
        }

        //log.debug(new DescriptionObject(inf, 'inf' , 2));

      } else {

        var oldValues = {};
        oldValues.tablemode = dataset.getProperty('tablemode');
        oldValues.tablerows = dataset.getProperty('tablerows');
        oldValues.maxlines = dataset.getProperty('maxlines');
        oldValues.titlerows = dataset.getProperty('titlerows');
        oldValues.tablecols = dataset.getProperty('tablecols');
        oldValues.titlecols = dataset.getProperty('titlecols');
        oldValues.createrows = getDesignTableRowsByObject(oldValues);
        var newValues = {};
        newValues.tablemode = newValue;
        if(useTableRows(newValue)){
          if(useTitles(oldValues.tablemode)) {
            newValues.tablerows = Number(oldValues.titlerows) + 1;
          } else {
            newValues.tablerows = oldValues.tablerows;
          }
        } else {
          newValues.tablerows = '';
        }
        if(needMaxLines(newValue)){
          newValues.maxlines = '1';
        } else {
          newValues.maxlines = '';
        }
        if(useTitles(newValue)){
          if(useTitles(oldValues.tablemode)) {
            newValues.titlerows = oldValues.titlerows;
            newValues.titlecols = oldValues.titlecols;
          } else {
            if(oldValues.tablerows > 1) {
              newValues.titlerows = pref.init.table.get('titlerows');
            } else {
              newValues.titlerows = '';
            }
            newValues.titlecols = pref.init.table.get('titlecols');
          }
        } else {
          newValues.titlerows = '';
          newValues.titlecols = '';
        }
        newValues.tablecols = oldValues.tablecols;
        newValues.createrows = getDesignTableRowsByObject(newValues);
        newValues.org = oldValues;
        oldValues.org = newValues;

        if(oldValues.createrows > newValues.createrows){
          var shift = newValues.createrows - oldValues.createrows;
          newValues.undoTransfer = new UndoTransferCellProperties(elementId, 'row', oldValues.createrows, shift);
        }
      }

      //log.debug(new DescriptionObject(oldValues, 'oldValues' , {'':3,org:0}));
      //log.debug(new DescriptionObject(newValues, 'newValues' , {'':3,org:0}));

      if(newValues.undoTransfer) {
        newValues.undoTransfer.shorten();
      }

      var createTableAllInfo = createTableAll(elementId, newValues.createrows, Number(newValues.tablecols), 'tablemode', cellElementId, newValues.createTableAllInfo);
      newValues.createTableAllInfo = createTableAllInfo;
      oldValues.createTableAllInfo = createTableAllInfo;

      dataset.setProperty('tablemode', newValues.tablemode);
      dataset.setProperty('tablerows', newValues.tablerows);
      dataset.setProperty('maxlines', newValues.maxlines);
      dataset.setProperty('titlerows', newValues.titlerows);
      dataset.setProperty('titlecols', newValues.titlecols);

      if(oldValues.undoTransfer) {
        oldValues.undoTransfer.enlarge();
      }
      
      var flg = flags(newValue, 'resized', updates, 'repaint');
      flg.undoInfos = newValues;
      return flg;
    }

    // 行見出し列数
    function _titlecols(newValue, elementId, dataset, cellElementId, cellDataset, inf) {
      log.debug('_titlecols:' + newValue);
      var modified = '';

      var titlerows = Number(dataset.getProperty('titlerows'))
      var oldValue = Number(dataset.getProperty('titlecols'));

      if(oldValue == 0 && 0 < titlerows) {
        var corner = dataset.getProperty('corner');
        if(corner == '') {
          corner = pref.init.table.get('corner');
          dataset.setProperty('corner', corner);
        }

        if(elementId == m_selection.current.front) {
          var fldcorner = getDocumentElementById('fld_corner');
          if(fldcorner) {
            fldcorner.value = corner;
          }
        }
      }

      if(elementId == m_selection.current.front) {
        var cornerdisplay = 'none';
        if(0 < Number(newValue)) {
          setTableTitleColPropertyDisplay('');

          if(titlerows) {
            cornerdisplay = '';
          }
        } else {
          setTableTitleColPropertyDisplay('none');
          if(newValue != '') {
            modified = 'modified';
          }
        }

        var tmpElement = getDocumentElementById('fld_corner_tr');
        if(tmpElement) {
          tmpElement.style.display = cornerdisplay;
        }
      }
      return flags(newValue, modified, 'repaint');
    }

    // 列見出し行数
    function _titlerows(newValue, elementId, dataset, cellElementId, cellDataset, inf) {
      log.debug('_titlerows:' + newValue);
      var modified = '';

      var oldValue = Number(dataset.getProperty('titlerows'))
      var titlecols = Number(dataset.getProperty('titlecols'));

      // corner値表示
      if(oldValue == 0 && 0 < titlecols) {
        var corner = dataset.getProperty('corner');
        if(corner == '') {
          corner = pref.init.table.get('corner');
          dataset.setProperty('corner', corner);
        }

        if(elementId == m_selection.current.front) {
          var fldcorner = getDocumentElementById('fld_corner');
          if(fldcorner) {
            fldcorner.value = corner;
          }
        }
      }

      // corner属性欄表示
      if(elementId == m_selection.current.front) {
        var cornerdisplay = 'none';
        if(0 < Number(newValue)) {
          setTableTitleRowPropertyDisplay('');

          if(titlecols) {
            cornerdisplay = '';
          }
        } else {
          setTableTitleRowPropertyDisplay('none');
          
          if(newValue != '') {
            modified = 'modified';
          }
        }

        var tmpElement = getDocumentElementById('fld_corner_tr');
        if(tmpElement) {
          tmpElement.style.display = cornerdisplay;
        }
      }
      
      var tablerows = Number(newValue) + 1;
      var tablecols = dataset.getProperty('tablecols');

      var undoTransfer = null;
      if(Number(oldValue) > Number(newValue)){
        if(inf) {
          if(inf.undoTransferCell) {
            inf.undoTransferCell.shorten();
          }
        } else {
          var curSize = getCurrentTableSizeInf(elementId);
          var currentRow = getDataSet(m_selection.current.cell).getProperty('cellrow');
          if(Number(currentRow) > Number(oldValue)) {
            currentRow = Number(oldValue);
          }
          var shift = newValue - oldValue;
          undoTransfer = new UndoTransferCellProperties(elementId, 'row', currentRow, shift);
          undoTransfer.shorten();
        }
      }

      var undoInfos = createTableAll(elementId, tablerows, tablecols, 'titlerows', cellElementId, inf);
      dataset.setProperty('titlerows', newValue);

      if(inf == undefined) {
        var orgtop = Number(dataset.getProperty('top'));
        if(undoInfos.tableSize.height > undoInfos.org.tableSize.height) {
          if(orgtop > 0) {
            var top = orgtop - (undoInfos.tableSize.height - undoInfos.org.tableSize.height);
            if(top < 0) {
              top = 0;
            }
            undoInfos.top = top;
            undoInfos.org.top = orgtop;
          }
        } else if(undoInfos.tableSize.height < curSize.tableSize.height){
          undoInfos.top = orgtop + (curSize.tableSize.height - undoInfos.tableSize.height);
          undoInfos.org.top = orgtop;
        }
      }

      if(undoInfos.top != undefined) {
        dataset.setProperty('top', undoInfos.top);
        var el = getDocumentElementById(elementId + '_span');
        el.top = undoInfos.top;
        if(elementId == m_selection.current.front) {
          //var el = getDocumentElementById('fld_top');
          //if(el) {
          //  el.value = undoInfos.top;
          //}
          setPropertyEditValue('top', TYPE.TABLE, dataset, undoInfos.top);
        }
      }
      
      var flg = flags(newValue, 'resized', 'updated', modified, 'repaint');
      if(undoInfos) {
        flg.undoInfos = undoInfos;

        if(Number(oldValue) < Number(newValue)) {
          if(inf) {
            if(inf.undoTransferCell) {
              inf.undoTransferCell.enlarge();
              flg.undoInfos.undoTransferCell = inf.undoTransferCell;
              flg.undoInfos.org.undoTransferCell = inf.undoTransferCell;
            }
          } else {
            var cellRow = getDataSet(m_selection.current.cell).getProperty('cellrow');
            if(Number(cellRow) > Number(oldValue)) {
              var copyRow = Number(oldValue);
              var cellRow = Number(newValue) + 1;
              var cellCol = getDataSet(m_selection.current.cell).getProperty('cellcol');
              m_selection.setCell(getCellId(m_selection.current.front, cellRow, cellCol));
            } else {
              var copyRow = Number(cellRow);
            }
            if(Number(copyRow) == 0) {
              var currentRow = 1;
            } else {
              var currentRow = copyRow;
            }
            var shift = newValue - oldValue;
            undoTransfer = new UndoTransferCellProperties(elementId, 'row', currentRow, shift, copyRow);
            undoTransfer.enlarge();
            flg.undoInfos.undoTransferCell = undoTransfer;
            flg.undoInfos.org.undoTransferCell = undoTransfer;
          }
        } else if(undoTransfer) {
          flg.undoInfos.undoTransferCell = undoTransfer;
          flg.undoInfos.org.undoTransferCell = undoTransfer;
        }
      }
      return flg;

    }
    
    // 列数
    function _corner(newValue, elementId, dataset, cellElementId, cellDataset, inf) {
      return flags(newValue, 'repaint');
    }
    
    // 列数
    function _tablecols(newValue, elementId, dataset, cellElementId, cellDataset, inf) {
      log.debug('_tablecols:' + newValue);

      var modified = '';
      if(newValue == '' || newValue == '0'){
        newValue = '1';
        modified = 'modified';
      }

      var oldValue = dataset.getProperty('tablecols');
      if(Number(oldValue) == Number(newValue)) {
        log.debug('_tablecols:' + oldValue + ' > ' + newValue);
        return flags(newValue, 'updated', modified);
      }

      var tablerows = getDesignTableRows(dataset);
      var undoTransfer = null;
      if(Number(oldValue) > Number(newValue)){
        if(inf) {
          if(inf.undoTransferCell) {
            inf.undoTransferCell.shorten();
          }
        } else {
          var currentCol = getDataSet(m_selection.current.cell).getProperty('cellcol');
          var shift = newValue - oldValue;
          undoTransfer = new UndoTransferCellProperties(elementId, 'col', currentCol, shift);
          undoTransfer.shorten();
        }
      }
 
      var undoInfos = createTableAll(elementId, tablerows, newValue, 'tablecols', cellElementId, inf);
      dataset.setProperty('tablecols', newValue);
      
      var flg = flags(newValue, 'resized', 'updated', modified, 'repaint');
      if(undoInfos) {
        flg.undoInfos = undoInfos;

        if(Number(oldValue) < Number(newValue)) {
          if(inf) {
            if(inf.undoTransferCell) {
              inf.undoTransferCell.enlarge();
              flg.undoInfos.undoTransferCell = inf.undoTransferCell;
              flg.undoInfos.org.undoTransferCell = inf.undoTransferCell;
            }
          } else {
            var currentCol = getDataSet(m_selection.current.cell).getProperty('cellcol');
            var shift = newValue - oldValue;
            undoTransfer = new UndoTransferCellProperties(elementId, 'col', currentCol, shift, currentCol, undoInfos.divided);
            undoTransfer.enlarge();
            flg.undoInfos.undoTransferCell = undoTransfer;
            flg.undoInfos.org.undoTransferCell = undoTransfer;
          }
        } else if(undoTransfer) {
          flg.undoInfos.undoTransferCell = undoTransfer;
          flg.undoInfos.org.undoTransferCell = undoTransfer;
        }
      }

      return flg;
    }

    // シンプルモード行数
    function _tablerows(newValue, elementId, dataset, cellElementId, cellDataset, inf) {
      log.debug('_tablerows:' + newValue);

      var modified = '';
      if(newValue == '' || newValue == '0'){
        newValue = '1';
        modified = 'modified';
      }

      var oldValue = dataset.getProperty('tablerows');
      if(Number(oldValue) == Number(newValue)) {
        return flags(newValue, 'updated', modified);
      }
      
      var tablecols = dataset.getProperty('tablecols');

      var undoTransfer = null;
      if(Number(oldValue) > Number(newValue)){
        if(inf) {
          if(inf.undoTransferCell) {
            inf.undoTransferCell.shorten();
          }
        } else {
          var currentRow = getDataSet(m_selection.current.cell).getProperty('cellrow');
          var shift = newValue - oldValue;
          undoTransfer = new UndoTransferCellProperties(elementId, 'row', currentRow, shift);
          undoTransfer.shorten();
        }
      }

      var undoInfos = createTableAll(elementId, newValue, tablecols, 'tablerows', cellElementId, inf);
      dataset.setProperty('tablerows', newValue);

      var flg = flags(newValue, 'resized', 'updated', modified, 'repaint');
      if(undoInfos) {
        flg.undoInfos = undoInfos;

        if(Number(oldValue) < Number(newValue)) {
          if(inf) {
            if(inf.undoTransferCell) {
              inf.undoTransferCell.enlarge();
              flg.undoInfos.undoTransferCell = inf.undoTransferCell;
              flg.undoInfos.org.undoTransferCell = inf.undoTransferCell;
            }
          } else {
            var currentRow = getDataSet(m_selection.current.cell).getProperty('cellrow');
            var shift = newValue - oldValue;
            undoTransfer = new UndoTransferCellProperties(elementId, 'row', currentRow, shift);
            undoTransfer.enlarge();
            flg.undoInfos.undoTransferCell = undoTransfer;
            flg.undoInfos.org.undoTransferCell = undoTransfer;
          }
        } else if(undoTransfer) {
          flg.undoInfos.undoTransferCell = undoTransfer;
          flg.undoInfos.org.undoTransferCell = undoTransfer;
        }
      }
      return flg;
    }
    
    // ラインモード行数
    function _maxlines(newValue, elementId, dataset, cellElementId, cellDataset, inf) {
      log.debug('_maxlines:' + newValue);

      var modified = '';
      if(newValue == '0'){
        newValue = '1';
        modified = 'modified';
      }
      if(newValue == ''){
        if(needMaxLines(dataset.getProperty('tablemode'))) {
          newValue = '1';
          modified = 'modified';
        }
      }
      var flg = flags(newValue, modified);
      return flg;
    }

    // 枠線の色
    function _bordercolor(newValue, elementId, dataset, cellElementId, cellDataset) {
      var setColor = tagFree(newValue, 'black');
      if(newValue.length == 0){
        setColor = 'black';
      }
      setCellBorderColor(setColor, elementId);
      setElementStyleBoderColor(getDocumentElementById(elementId), setColor, 'black');
      return flags(newValue);
    }
    
    // セルの表示
    function _cellvisibility(newValue, elementId, dataset, cellElementId, cellDataset) {
      //非表示チェック時hidden
      
      if(newValue != 'hidden') {
        // @visible newValue = 'visible';
      }
      cellDataset.setProperty('cellvisibility', newValue);
/**/
      //z-index保存
      var docNode = getDocumentElementById(elementId + '_span');
      var tmpZindex = docNode.style.zIndex;
      setOuterHTML(docNode, getElementHtml(dataset));
      docNode = getDocumentElementById(elementId + '_span');
      docNode.style.zIndex = tmpZindex;
      docNode.style.border = pref.view.get('selectionborder');
      setResizeHandle(elementId);
/**/      
      return flags(newValue, 'updated', 'reconstructed');
    }
    
    // セルの幅
    function _cellwidth(newValue, elementId, dataset, cellElementId, cellDataset) {
      var validvalue = getValidPanelWidth(newValue);
      var modified = ''
      if(newValue != validvalue){
        newValue = validvalue;
        modified = 'modified';
      }

      if(cellElementId.length != 0){
        var setWidth = setAllRow(newValue, elementId, dataset, cellElementId, cellDataset);
        if(cellElementId == m_selection.current.cell) {
          getDocumentElementById('fld_cellwidth').value = setWidth;
        }
      }
      //return flags(newValue, 'resized', 'updated', modified, 'border', 'reconstructed');
      return flags(newValue, 'resized', 'updated', modified, 'border');
    }
    
    // セルの高さ
    function _cellheight(newValue, elementId, dataset, cellElementId, cellDataset) {
      var validvalue = getValidPanelHeight(newValue);
      var modified = ''
      if(newValue != validvalue){
        newValue = validvalue;
        modified = 'modified';
      }

      if(cellElementId.length != 0){
        var setHeight = setAllCol(newValue, elementId, dataset, cellElementId, cellDataset);
        if(cellElementId == m_selection.current.cell) {
          getDocumentElementById('fld_cellheight').value = setHeight;
        }
      }
      if(m_browserType.isNN) {
        return flags(newValue, 'resized', 'updated', modified, 'border', 'reconstructed');
      } else {
        return flags(newValue, 'resized', 'updated', modified, 'border');
      }
    }

    // セルの背景色
    function _cellbackgroundcolor(newValue, elementId, dataset, cellElementId, cellDataset) {
      if(dataset.getProperty('visibility') != 'hidden' &&
         cellDataset.getProperty('cellvisibility') != 'hidden'){
        getDocumentElementById(cellElementId).bgColor = tagFree(newValue, pref.view.get('taggedtablecolor'));
      }
      getDataSet(cellElementId).setProperty('cellbackgroundcolor', newValue);
      return flags(newValue, 'updated');
    }

    // セルの背景画像
    function _cellbackgroundimage(newValue, elementId, dataset, cellElementId, cellDataset) {
      cellDataset.setProperty('cellbackgroundimage', newValue);
      if(pref.view.get('usebackgroundimage')) {
        var applyflg = true;
        if(newValue != '') {
          if(cellDataset.getProperty('cellvisibility') == 'hidden') {
            applyflg = false;
          } else if (dataset.getProperty('visibility') == 'hidden') {
            applyflg = false;
          }
        }
        if(applyflg) {
          addImageFileBuffer(newValue);
          getDocumentElementById(cellElementId).style.backgroundImage = getImageSrcUrl(newValue);
        }
      }
      return flags(newValue, 'updated');
    }

    // セルの枠線の色
    function _cellbordercolor(newValue, elementId, dataset, cellElementId, cellDataset) {
      var tmpTdNode = getDocumentElementById(cellElementId);
      if(newValue.length != 0){
        tmpTdNode.border = 1;
        tmpTdNode.borderColor = tagFree(newValue, 'silver');
      }else{
        tmpTdNode.border = 0;
        tmpTdNode.borderColor = '';
      }
      cellDataset.setProperty('cellbordercolor', newValue);
      return flags(newValue, 'updated');
    }

    // セルのスタイル
    function _cellstyle(newValue, elementId, dataset, cellElementId, cellDataset) {
      cellDataset.setProperty('cellstyle', newValue);
      return flags(newValue, 'repaint', 'updated');
    }
  }
  
  /** 再描画メソッド */  
  ViewObjectTable.prototype.repaint = _repaint;

  /**
   * 再描画メソッド
   */
  function _repaint(elementId, dataset, cellElementId, cellDataset) {
    //log.debug('table._repaint enter');
    var windowStatus = window.status;
    window.status = getMessage('S0005');

    var span = getDocumentElementById(elementId + '_span');

    //既存のHTMLを置換
    setOuterHTML(span, getElementHtml(dataset));

    // 2003.05.12 zIndex設定
    var top = parseInt(dataset.getProperty('top'));
    var left = parseInt(dataset.getProperty('left'));
    
    //log.debug('setting zIndex:' + (top + left));
    span = getDocumentElementById(elementId + '_span');
    span.style.zIndex = top + left;

    window.status = windowStatus;
    
    // cellのIDを付け直す
    var maxrow = getDesignTableRows(dataset);
    var row = getRowFromCellId(m_selection.cell);
    if(row < 1) {
      row = 1;
    } else if(maxrow < row) {
      row = maxrow;
    }
    var maxcol = parseInt(dataset.getProperty('tablecols'));
    var col = getColFromCellId(m_selection.cell);
    if(col < 1) {
      col = 1;
    } else if(maxcol < col) {
      col = maxcol;
    }
    
    m_selection.remove(elementId);
    m_selection.add(elementId, getCellId(elementId, row, col));

    //log.debug('table._repaint exit');
  }
}

/**
 * maxlines属性を使用するか
 */
function useMaxLines(tablemode) {
  return (tablemode != 'MODE_SIMPLE');
}

/**
 * maxlines属性を必須とするか
 */
function needMaxLines(tablemode) {
  return (tablemode == 'MODE_LINE');
}

/**
 * tablerows属性を使用するか
 */
function useTableRows(tablemode) {
  return (tablemode == 'MODE_SIMPLE');
}

/**
 * groupid属性を使用するか
 */
function useGroupId(tablemode) {
  return (tablemode != 'MODE_SIMPLE');
}

/**
 * １行だけ定義し、動的に行が生成されるtablemode
 */
function isTableRowsGenerative(tablemode) {
  return (tablemode != 'MODE_SIMPLE');
}

/**
 * titlerows,titlecols属性を使用するか
 */
function useTitles(tablemode) {
  return (tablemode != 'MODE_SIMPLE');
}

/**
 * titlerowvanishing属性を使用するか
 */
function useTitleRowVanishing(tablemode, titlerows) {
  
  if(titlerows == undefined || Number(titlerows) > 0) {
    return (tablemode == 'MODE_COPY');
  }
  return false;
}

/**
 * TABLEのボーダー色変更時、セルのボーダー色を変更する
 * @param  :
 * @return :
 */
function setCellBorderColor(setColor, element){
  if(!element) {
    //element = m_currentElement;
    alert('??????');
  }
  //try{
    var useTdId = new Array();
    for(var i=0; i<m_addElementArray.length; i++){
      if(getDataSet(m_addElementArray[i]).getProperty('parenttableid') == element){
        useTdId[useTdId.length] = m_addElementArray[i];
      }
    }
    for(var i=0; i<useTdId.length; i++){
      setElementStyleBoderColor(getDocumentElementById(useTdId[i]).parentNode, setColor);
    }
  //} catch(e) {
  //  showObject(useTdId,'useTdId',3);
  //}
}

// 背景色
function table_backgroundcolor(newValue, elementId, dataset, cellElementId, cellDataset) {
  if(dataset.getProperty('visibility') != 'hidden'){
    //getDocumentElementById(elementId).bgColor = tagFree(newValue, pref.view.get('taggedtablecolor'));
    getDocumentElementById(elementId).style.backgroundColor = tagFree(newValue, pref.view.get('taggedtablecolor'));
  }
  return flags(newValue);
}

// 背景画像
function table_background(newValue, elementId, dataset, cellElementId, cellDataset) {
  if(pref.view.get('usebackgroundimage')) {
    addImageFileBuffer(newValue);
    getDocumentElementById(elementId).style.backgroundImage = getImageSrcUrl(newValue);
  }
  return flags(newValue);
}

/**
 *
 */
function getValidPanelHeight(value) {
  if(value != ''){
    var mod = (value % DISPLAYROWHEIGHT);
    if(mod != 0) {
      value -= mod;
    }
    if(value < DISPLAYROWHEIGHT) {
      value = DISPLAYROWHEIGHT;
    }
  } else {
    value = DISPLAYROWHEIGHT;
  }
  return value;
}

/**
 *
 */
function getValidPanelWidth(value) {
  if(value != ''){
    if(value < 1) {
      value = 1;
    }
  } else {
    value = 20;
  }
  return value;
}

/**
 * セルの行変更時、同列のセル幅を全て同値に設定
 * @param  :numVal セルの幅値
 * @return :
 */
function setAllRow(numVal, elementId, dataset, cellElementId, cellDataset){

  if(numVal*1 == 0) numVal = 1;

  //変更後のテーブル幅とページ幅のチェック
  numVal = checkTableSize(parseInt(numVal), elementId, dataset, cellElementId, cellDataset, true);

  //現在の列
  var currentCol = cellDataset.getProperty('cellcol');
  //全行数取得(TR数)
  var numAllRows = getDocumentElementById(elementId).childNodes.item(1).childNodes.length;
  var setWidth = parseInt(numVal) - 1;
  if(setWidth <= 0) return numVal;
  for(var i=0; i<numAllRows; i++){
    //var tmpId = getDocumentElementById(elementId).childNodes.item(1).childNodes.item(i).childNodes.item(currentCol - 1).childNodes.item(0).id;
    var tmpId = getCellId(elementId, (i + 1), currentCol);
    getDataSet(tmpId).setProperty('cellwidth', numVal);
    var tdel = getDocumentElementById(tmpId);
    tdel.width = numVal - 1;
  }
  var stl = getDocumentElementById(elementId + '_span').style;
  var border = stl.border;
  stl.border = '';
  stl.border = border;
  
/*
  setOuterHTML(getDocumentElementById(elementId + '_span'), getElementHtml(dataset));

  // 2003.05.12 zIndex追加
  getDocumentElementById(elementId + '_span').style.zIndex = parseInt(dataset.getProperty('top')) + parseInt(dataset.getProperty('left'));

  getDocumentElementById(elementId + '_span').style.border = pref.view.get('selectionborder');
*/
  return numVal;

}

/**
 * セルの列変更時、同行のセル高さを全て同値に設定
 * @param  :numVal セルの高さ値
 * @return :
 */
function setAllCol(numVal, elementId, dataset, cellElementId, cellDataset){

  if(numVal*1 == 0) numVal = 1;

  //変更後のテーブル高さとページ高さのチェック
  numVal = checkTableSize(parseInt(numVal), elementId, dataset, cellElementId, cellDataset, false);

  //現在の行
  var currentRow = cellDataset.getProperty('cellrow');
  //全列数取得(TD数)
  var numAllCols = getDocumentElementById(elementId).childNodes.item(1).childNodes.item(0).childNodes.length;
  var setHeight = parseInt(numVal) - 1;
  if(setHeight <= 0) return numVal;
  for(var i=0; i<numAllCols; i++){
    //var tmpId = getDocumentElementById(elementId).childNodes.item(1).childNodes.item(currentRow - 1).childNodes.item(i).childNodes.item(0).id;
    try {
      var tmpId = getCellId(elementId, currentRow, (i + 1));
      getDataSet(tmpId).setProperty('cellheight', numVal);
      var tdel = getDocumentElementById(tmpId);
      tdel.height = numVal - 1;
    }catch(e){
      alert(e.message + '\ncell:' + tmpId);
    }
  }
  var stl = getDocumentElementById(elementId + '_span').style;
  var border = stl.border;
  stl.border = '';
  stl.border = border;

/**/
  if(m_browserType.isNN) {
    setOuterHTML(getDocumentElementById(elementId + '_span'), getElementHtml(dataset));

    // 2003.05.12 zIndex追加
    getDocumentElementById(elementId + '_span').style.zIndex = parseInt(dataset.getProperty('top')) + parseInt(dataset.getProperty('left'));

    getDocumentElementById(elementId + '_span').style.border = pref.view.get('selectionborder');
  }
/**/
  return numVal;

}

/**
 * サイズ変更後のエレメントとページサイズの整合性チェック
 * @param  :numValue   数値型   変更後の該当セルのサイズ
 *          boolWidth  ブール値 true:幅 false:高さ
 * @return :
 */
function checkTableSize(numValue, elementId, dataset, cellElementId, cellDataset, boolWidth){

  if(numValue < 0) {
    return 1;
  } else {
    return numValue;
  }

/*
  var objEditTbl = getDocumentElementById(elementId);
  if(boolWidth){

    //TABLEのサイズ取得(幅)
    var tmpMaxCols = parseInt(dataset.getProperty('tablecols'));
    var tmpTdSumWidth = 0;
    for(var i=1; i<tmpMaxCols+1; i++){
      tmpTdSumWidth  += parseInt(getDataSet(getCellId(elementId, 1, i)).getProperty('cellwidth'));
    }
    //alert(cellElementId + ':' + typeof(cellDataset));
    var afterTblSize = tmpTdSumWidth + numValue - parseInt(cellDataset.getProperty('cellwidth'));
    
    var pageSize     = parseInt(getDataSet(ELEMENTID_FIRSTFORM).getProperty('pagewidth'));
    var tblPosition  = parseInt(dataset.getProperty('left'));

  }else{

    //TABLEのサイズ取得(高さ)
    var tmpMaxRow = getDesignTableRows(dataset);
    var tmpTdSumHeight = 0;
    for(var i=1; i<tmpMaxRow+1; i++){
      tmpTdSumHeight += parseInt(getDataSet(getCellId(elementId, i, 1)).getProperty('cellheight'));
    }
    var afterTblSize = tmpTdSumHeight + numValue - parseInt(cellDataset.getProperty('cellheight'));
    var pageSize     = parseInt(getDataSet(ELEMENTID_FIRSTFORM).getProperty('pageheight'));
    var tblPosition  = parseInt(dataset.getProperty('top'));

  }

  var rtnValue = numValue;

  if(rtnValue < 0) rtnValue = 1;

  return rtnValue;
*/
}

function getCurrentTableSizeInf(parentId) {
  var org = {};
  org.size = {width:{}, height:{}};
  org.tableSize = {width:0, height:0};
  for(var j=0; j<m_addElementArray.length; j++){
    var ds = getDataSet(m_addElementArray[j]);
    if(!ds.isType(TYPE.CELL)) {
      continue;
    }
    if(ds.getProperty('parenttableid') != parentId) {
      continue;
    }
    if(parseInt(ds.getProperty('cellrow')) == 1) {
      var width = Number(ds.getProperty('cellwidth'));
      org.size.width[ds.getProperty('cellcol')] = width;
      org.tableSize.width += width;
    }
    if(parseInt(ds.getProperty('cellcol')) == 1) {
      var height = Number(ds.getProperty('cellheight'));
      org.size.height[ds.getProperty('cellrow')] = height;
      org.tableSize.height += height;
    }
  }
  return org;
}

/**
 * テーブルのセルのサイズを作成
 */
function getCreateTableSizeInf(parentId, row, col, orgRow, orgCol, setwidth) {

  // TABLE列、行追加デフォルト、最小サイズ
  var MINCELLWIDTH = 20;

  var inf = {maxRow:row, maxCol:col};
  var org = {maxRow:orgRow, maxCol:orgCol};
  var cur = getCurrentTableSizeInf(parentId);
  org.size = cur.size;
  org.tableSize = cur.tableSize;

  //log.debug(new DescriptionObject(org, '==org==', 3));
  
  inf.size = {width:{}, height:{}};
  inf.tableSize = {width:0, height:0};

  // showObject(inf,'inf',4);

  // width
  if(setwidth == org.tableSize.width && (org.maxCol == 1 && inf.maxCol != 1)) {
    if(org.tableSize.width < MINCELLWIDTH * inf.maxCol) {
      // 最小の大きさでサイズを作成する
      for(var i = 1; i <= inf.maxCol; i++) {
        inf.size.width[i] = MINCELLWIDTH;
        inf.tableSize.width += MINCELLWIDTH; 
      }
    } else {
      // テーブルの大きさが変わらないようにサイズを作成する
      var snap = pref.operation.get('snap');
      var wid = parseInt(org.tableSize.width / inf.maxCol / snap) * snap;
      var leftov = org.tableSize.width;
      for(var i = 1; i < inf.maxCol; i++) {
        inf.size.width[i] = wid;
        leftov -= wid;
      }
      inf.size.width[inf.maxCol] = leftov;
      inf.tableSize.width = org.tableSize.width;
    }

    // 分割されて各セルのサイズが設定済みであることを示す。
    // サイズの属性が上書きされないようにフラグをたてる
    inf.divided = true;
  } else {
    // 既存のセルのサイズは変更しないでサイズを作成する
    for(var i = 1; i <= inf.maxCol; i++) {
      if(i <= org.maxCol) {
        inf.size.width[i] = org.size.width[i];
      } else {
        inf.size.width[i] = MINCELLWIDTH;
      }
      inf.tableSize.width += inf.size.width[i]; 
    }
  }

  // height
  for(var i = 1; i <= inf.maxRow; i++) {
    if(i <= org.maxRow) {
      inf.size.height[i] = org.size.height[i];
    } else {
      inf.size.height[i] = DISPLAYROWHEIGHT;
    }
    inf.tableSize.height += inf.size.height[i];
  }
  
  inf.org = org;
  org.org = inf;

  return inf;
}

/**
 * 行、列数の変化によって編集画面上のテーブルを作成する
 * @param  :parentId 文字型 テーブルのID
 *          rowsval  文字型 作成する総行数
 *          colsval  文字型 作成する総列数
 *          strProperty 文字型 プロパティ文字列
 * @return :
 */
function createTableAll(parentId, rowsval, colsval, strProperty, cellId, undoInf){
  //log.debug('createTableAll(' + parentId + ',' + rowsval + ',' + colsval + ',' + strProperty + ')');

  if(cellId.length == 0) return null;

  if(undoInf) {
    var exstate = rowsval + '/' + colsval;
    if(undoInf.state == exstate) {
      // redo
      var inf = undoInf;
      var org = undoInf.org;
    } else if(undoInf.org.state == exstate) {
      // undo
      var inf = undoInf.org;
      var org = undoInf;
    } else {
      // state do not match
      throw createError('state do not match. state:' + exstate + '  undo state:' + undoInf.state + '  redo state:' + undoInf.org.state, 'VwTypeContainer.js', 'createTableAll');
    }

  } else {
    var tableds = getDataSet(parentId);
    var orgMaxRow = getDesignTableRows(tableds);
    var setwidth = tableds.getExtraProperty('setwidth');
    var orgMaxCol = Number(tableds.getProperty('tablecols'));
    var inf = getCreateTableSizeInf(parentId, Number(rowsval), Number(colsval), orgMaxRow, orgMaxCol, setwidth);
    var org = inf.org;
    inf.state = rowsval + '/' + colsval;
    org.state = orgMaxRow + '/' + orgMaxCol;
  }
  
  //log.debug(new DescriptionObject(org,'org',{'':3,org:0}));
  //log.debug(new DescriptionObject(inf,'inf',{'':3,org:0}));
  
  //行、列に変動がない時は戻る
  if(inf.state == org.state) {
    return null;
  }
  
  for(var row = 1; row <= inf.maxRow; row++) {
    for(var col = 1; col <= inf.maxCol; col++) {
      var cellid = getCellId(parentId, row, col);
      var cellds = getDataSet(cellid, null);

      if(org.maxRow < row || org.maxCol < col) {
        // なかったセル

        m_addElementArray[m_addElementArray.length] = cellid;

        cellds = createDataSet(cellid, TYPE.CELL);
        for(var p in pref.edit.table.enumerator(true)) {
          if(isCellPropertyId(p)) {
            cellds.setProperty(p, '');
          }
        }
      //  log.debug('created cell : ' + cellid);
      //} else {
      //  log.debug('existing cell : ' + cellid);
      }

      cellds.setProperty('parenttableid', parentId);
      cellds.setProperty('cellwidth',     inf.size.width[col]);
      cellds.setProperty('cellheight',    inf.size.height[row]);

      cellds.setProperty('cellrow', row);
      cellds.setProperty('cellcol', col);
    }
  }

  // なくなったセルを削除
  for(var row = 1; row <= org.maxRow; row++) {
    if(row <= inf.maxRow) {
      var col = inf.maxCol + 1;
    } else {
      var col = 1;
    }
    for(; col <= org.maxCol; col++) {
      var cellid = getCellId(parentId, row, col);
      for(var j=0; j<m_addElementArray.length; j++){
        if(m_addElementArray[j] == cellid){
          m_addElementArray.splice(j, 1);
          //log.debug('deleted cell : ' + cellid);
          break;
        }
      }
    }
  }

  return inf;

}

/**
 * 同じ列か
 */
function isSameCol(tdid1, tdid2) {
  return isSameColOrRow(tdid1, tdid2, 'col');
}

/**
 * 同じ行か
 */
function isSameRow(tdid1, tdid2) {
  return isSameColOrRow(tdid1, tdid2, 'row');
}

/**
 * 同じ列か行か
 */
function isSameColOrRow(tdid1, tdid2, colOrRow) {
  var indx = {row:1,col:2}[colOrRow]
  if(tdid1 != '' && tdid2 != '') {
    var spl1 = tdid1.split('-');
    var spl2 = tdid2.split('-');
    if(spl1.length == 3 && spl2.length == 3) {
      if(spl1[0] == spl2[0] && spl1[indx] == spl2[indx]) {
        return true;
      }
    }
  }
  return false;
}

function getHeightByRows(rows) {
  if(!rows) {
    rows = 1;
  }
  return rows * DISPLAYROWHEIGHT;
}

/*
 * 表示するテーブルの行数を取得する
 * @param dataset
 */
function getDesignTableRows(dataset) {
  var tablemode = dataset.getProperty('tablemode');
  if(useTableRows(tablemode)) {
    return Number(dataset.getProperty('tablerows'));
  } else if(useTitles(tablemode)){
    return Number(dataset.getProperty('titlerows')) + 1;
  } else {
    return 1;
  }
}

/*
 * 表示するテーブルの行数を取得する
 * @param obj
 */
function getDesignTableRowsByObject(obj) {
  if(useTableRows(obj.tablemode)) {
    return Number(obj.tablerows);
  } else if(useTitles(obj.tablemode)) {
    return Number(obj.titlerows) + 1;
  } else {
    return 1;
  }
}
