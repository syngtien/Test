/**
 * VwUtilityAction
 * コマンドユーティリティ
 */
LAST_MODIFIED('2004.12.07', '1.0.28');

/**
 * エレメントのコピー、ペーストを行うためのクリップボードオブジェクト オブジェクト
 * 構造 m_tmpElementClipBord.id                      ID
 *                          .type                    TYPE
 *                          .name                    NAME
 *                          .properties[]            添え字：プロパティ名称
 *                          .properties[].value      プロパティ値
 *                          .td[]                    添え字：セルのID       (type=table時のみ)
 *                          .td[].properties[]       添え字：プロパティ名称 (type=table時のみ)
 *                          .td[].properties[].value プロパティ値           (type=table時のみ)
 */
var m_tmpElementClipBord = new Array();
 
/**
 * 編集オブジェクトのカット機能
 * @param  :
 * @return :
 */
function doCommandCut(){
  if(m_monitorEditStatus == 2) return;
  if(m_selection.front == ELEMENTID_FIRSTFORM) return;
  
  var prog = new WindowStatusProgressBar(m_selection.length() * 4, getMessage('S0010'));

  if(!copyElementImp(prog)) {
    prog.release();
    return;
  }
  
  // コマンドセット
  var cmdSet = new UndoableCommandSet(getLiteral('menuitem.cut'));
  cmdSet.add(new CommandSelect(true));

  m_selection.removeAll(prog);
  
  for(var i = 0; i < m_tmpElementClipBord.length; i++) {
    prog.update()
    clipCutElement(m_tmpElementClipBord[i].id, cmdSet);
  }

  prog.release();

  cmdSet.add(new CommandSelect(false));
  m_undoManager.execute(cmdSet);

  //log.debug('updating property area. [VwUtilityAction.js/doCommandCut]');
  m_selection.updatePropertyArea();
  
  // メニューの状態
  m_menuBar.enableSave();
  m_menuBar.enableMenuItem('EDIT', 'PASTE');
  m_menuBar.disableMenuItem('EDIT', 'CUT');
  m_menuBar.disableMenuItem('EDIT', 'COPY');
  m_menuBar.disableMenuItem('EDIT', 'DELETE');
}

/**
 * 編集オブジェクトのカット機能
 * @param  :
 * @return :
 */
function clipCutElement(elementId, cmdSet){

  //undo&redo用
  var objParam = createDeleteUndoParam(elementId, '', getDocumentElementById(elementId + '_span').style.zIndex);
  var cmd = createActionCommand(objParam);
  cmdSet.add(cmd);
  //m_selection.remove(elementId);
  deleteElement(elementId);
}

/**
 * 編集オブジェクトのコピー機能
 * @param  :
 * @return :
 */
function doCommandCopy(){
  var prog = new WindowStatusProgressBar(m_selection.length() * 2, getMessage('S0011'));
  copyElementImp(prog);
  prog.release();
}

/**
 * 編集オブジェクトのコピー機能
 * @param  :
 * @return :
 */
function copyElementImp(progressBar){
  if(m_monitorEditStatus == 2) return false;

  var clipboard = new Array();
  clipboard.referencePoint = new Object();
  clipboard.referencePoint.top = -1;
  clipboard.referencePoint.left = -1;
  
  if(progressBar) {
    var prog = progressBar;
  } else {
    var prog = new WindowStatusProgressBar(m_selection.length() * 2, getMessage('S0011'));
  }

  for(var id in m_selection.elements) {
    prog.update();
    var clip = clipCopyElement(id);
    if(clip){
      clipboard[clipboard.length] = clip;
      var top = parseInt(clip.properties['top'].value);
      var left = parseInt(clip.properties['left'].value);
      if(clipboard.referencePoint.top == -1 || top < clipboard.referencePoint.top) {
        clipboard.referencePoint.top = top;
      }
      if(clipboard.referencePoint.left == -1 || left < clipboard.referencePoint.left) {
        clipboard.referencePoint.left = left;
      }
    }
  }

  // クリップボードにコピー
  setSystemClipboard(clipboard, prog);

  if(!progressBar) {
    prog.release();
  }
  
  if(clipboard.length > 0) {
    m_tmpElementClipBord = clipboard;

    m_menuBar.enableMenuItem('EDIT', 'PASTE');

    return true;
  } else {
    return false;
  }
}

/**
 * 編集オブジェクトのコピー機能
 * @param  :
 * @return :
 */
function clipCopyElement(elementId){
  if(elementId == '' || elementId == ELEMENTID_FIRSTFORM) return null;
  
  var clip = new Object();

  //コピー元エレメントの情報取得
  clip.id = elementId;

  //コピー元DataSetのキャッシュ
  var objOrgDS = getDataSet(elementId);

  clip.type = objOrgDS.getProperty('type');
  clip.name = objOrgDS.getProperty('name');
  
  //コピー元のプロパティを保存
  clip.properties = new Object();

  for(var propid in getTypeInfoDef(clip.type)){
    if(propid == 'type') continue;

    var setValue = objOrgDS.getProperty(propid);

    if(getPropertyInfoDef(clip.type,propid).isArrayValue){
      if(setValue.length == 0) {
        continue;
      }
      setValue = createOptionItemsValue(setValue);
    } else {
      if(setValue == '') {
        continue;
      }
    }

    clip.properties[propid] = {value:setValue};
  }

  //table時tdpanelのプロパティを取得
  if(clip.type == TYPE.TABLE){
    clip.td = new Object();
    //cellのIDを取得
    for(var i=0; i < m_addElementArray.length; i++){
      if(getDataSet(m_addElementArray[i]).parenttableid &&
         getDataSet(m_addElementArray[i]).parenttableid.value == clip.id) {
        //clip.td[m_addElementArray[i]] = m_addElementArray[i];
        clip.td[m_addElementArray[i]] = new Object();
      }
    }
    
    //cellのプロパティを取得
    for(var tdid in clip.td){
      clip.td[tdid].properties = new Object();
      var dataset = getDataSet(tdid);
      //cellのプロパティをセット
      for(var tmpTdProperty in getTypeInfoDef(TYPE.CELL)){
        if(propid == 'type') continue;

        var setValue = dataset.getProperty(tmpTdProperty);

        if(setValue == '') {
          continue;
        }

        clip.td[tdid].properties[tmpTdProperty] = {value:setValue};
      }
    }
  }
  
  return clip;
}

/**
 * 編集オブジェクトのペースト機能
 * @param  :
 * @return :
 */
function doCommandPaste(){

  var oldStatus = window.status;
  window.status = getMessage('S0012');
  
  var clipboard = null;

  // クリップボードからペースト
  if(canGetSystemClipboard()) {
    clipboard = getSystemClipboard();
  }

  if(clipboard) {
    m_tmpElementClipBord = clipboard;
  }
  
  if(m_tmpElementClipBord.length == 0) {
    window.status = oldStatus;
    return;
  }

  var prog = new WindowStatusProgressBar(m_tmpElementClipBord.length + m_selection.length());

  m_selection.removeAll(prog);
  
  // コマンドセット
  var cmdSet = new UndoableCommandSet(getLiteral('menuitem.paste'));
  cmdSet.add(new CommandSelect(true));

  var referencePoint = m_tmpElementClipBord.referencePoint;
  if(pref.operation.pastelocation) {
    referencePoint = getShiftReferencePoint(m_tmpElementClipBord[0], {top:0,left:0});
  }
  
  for(var i = 0; i < m_tmpElementClipBord.length; i++) {
    prog.update();
    var clip = m_tmpElementClipBord[i];
    clipPasteElement(m_tmpElementClipBord[i], referencePoint, cmdSet);
  }
  prog.release();

  window.status = oldStatus;
  
  cmdSet.add(new CommandSelect(false));
  m_undoManager.execute(cmdSet);

  //log.debug('updating property area. [VwUtilityAction.js/doCommandPaste]');
  m_selection.updatePropertyArea();
  
  if(m_selection.front != ELEMENTID_FIRSTFORM) {
    m_menuBar.enableSave();
    m_menuBar.enableMenuItem('EDIT', 'CUT');
    m_menuBar.enableMenuItem('EDIT', 'COPY');
    m_menuBar.enableMenuItem('EDIT', 'DELETE');
  }

}

/** 
 * 配置可能な位置を取得する
 */
function getShiftReferencePoint(sampleObject, referencePoint) {
  var SHIFTREFERENCETOP = DISPLAYROWHEIGHT * pref.operation.pasteshift.row;
  var SHIFTREFERENCELEFT = pref.operation.pasteshift.left;
  if(SHIFTREFERENCETOP == 0 && SHIFTREFERENCELEFT == 0) {
    return referencePoint;
  }
  var sampleTop = 0;
  var sampleLeft = 0;
  if(sampleObject && sampleObject.properties) {
    if(sampleObject.properties.top) {
      sampleTop = Number(sampleObject.properties.top.value);
    }
    if(sampleObject.properties.top) {
      sampleLeft = Number(sampleObject.properties.left.value);
    }
  }
  
  while(existsAtLocation(sampleTop, sampleLeft)) {
    referencePoint.top -= SHIFTREFERENCETOP;
    referencePoint.left -= SHIFTREFERENCELEFT;
    sampleTop += SHIFTREFERENCETOP;
    sampleLeft += SHIFTREFERENCELEFT;
  }
  return referencePoint;

  function existsAtLocation(sampleTop, sampleLeft) {
    //var msg = 'Sample:' + sampleTop + '/' + sampleLeft + '\n';
    for(var i = 0; i < m_addElementArray.length; i++) {
      var elementId = m_addElementArray[i];
      if(elementId == ELEMENTID_FIRSTFORM) {
        continue;
      }
      if(isCellId(elementId)) {
        continue;
      }
      var dataset = getDataSet(elementId);
      if(dataset) {
        //msg += Number(dataset.getProperty('top')) + '/' + Number(dataset.getProperty('left')) + '\n';
        if(Number(dataset.getProperty('top')) == sampleTop &&
           Number(dataset.getProperty('left')) == sampleLeft) {
          //alert(msg + elementId);
          return true;
        }
      }
    }
    //alert(msg + 'false');
    return false;
  }
}

/**
 * 編集オブジェクトのペースト機能
 * @param  :
 * @return :
 */
function clipPasteElement(clip, referencePoint, cmdSet){

  var workId = getNewId(clip.type);
  
  //DataSet作成
  var objPasteDS = createDataSet(workId, clip.type, clip.name);
  m_addElementArray[m_addElementArray.length] = workId;

  //コピー元のプロパティをセット
  for(var i in clip.properties){
    var setProperty = i;
    var setValue    = clip.properties[i].value;
    if(i == 'top') {
      objPasteDS.setProperty(i, setValue - referencePoint.top);
    } else if(i == 'left') {
      objPasteDS.setProperty(i, setValue - referencePoint.left);
    } else {
      objPasteDS.setProperty(i, setValue);
    }
  }

  //table時
  if(objPasteDS.isType(TYPE.TABLE)){
    for(var cellid in clip.td){
      var cell = clip.td[cellid];
      var tmpNewTdId = getCellId(workId, cell.properties['cellrow'].value, cell.properties['cellcol'].value);
      //DataSet作成
      createDataSet(tmpNewTdId, TYPE.CELL);
      m_addElementArray[m_addElementArray.length] = tmpNewTdId;
      //新規に作成したテーブルのセルオブジェクトにコピーしたセルのデータをセット
      var objTmpTdDS = getDataSet(tmpNewTdId);
      objTmpTdDS.setProperty('parenttableid', workId);

      //コピー元のプロパティをセット
      for(var cellpropid in cell.properties){
        objTmpTdDS.setProperty(cellpropid, cell.properties[cellpropid].value);
      }
    }
  }
  getDocumentElementById(ELEMENTID_FIRSTFORM).innerHTML += getElementHtml(getDataSet(workId));

  //zIndex付加
  try {
    if(objPasteDS.isType(TYPE.TABLE) || objPasteDS.isType(TYPE.PANEL)){
      getDocumentElementById(workId + '_span').style.zIndex = getMaxzIndex(1);
    }else{
      getDocumentElementById(workId + '_span').style.zIndex = parseInt(m_maxzIndex) + 1;
      m_maxzIndex = parseInt(m_maxzIndex) + 1;
    }
  }catch(e){}

  // ?
  m_selection.add(workId);
  
  //undo&redo用
  var objParam = createAddUndoParam(workId, getLiteral('menuitem.paste'));
  var cmd = createActionCommand(objParam);
  cmdSet.add(cmd);
}

/**
 * コピーしたデータをテキストとしてクリップボードへ設定
 */
function setSystemClipboard(clipdata, progressBar) {
  
  if(!canUseSystemClipboard()) return false;
  if(clipdata.length == 0) return;
  
  if(!progressBar) {
    progressBar = dummyProgressBar();
  }
  var textdata = VIEWEDITORCLIPBOARDFORMAT_COPY;
  textdata += addClipParam('referencePoint.top', clipdata.referencePoint.top);
  textdata += addClipParam('referencePoint.left', clipdata.referencePoint.left);
  for(var i = 0; i < clipdata.length; i++) {
    progressBar.update();
    
    textdata += addClipParam(i + '.type', clipdata[i].type);
//    textdata += addClipParam(i + '.name', clipdata[i].name);
    textdata += addClipProperties(i + '.properties', clipdata[i].properties, clipdata[i].type);

    for(var cellid in clipdata[i].td) {
      textdata += addClipProperties(i + '.td.' + cellid + '.properties', clipdata[i].td[cellid].properties);
    }
    
  }
  
  clipboardData.setData("Text",textdata);
  return;
  
  function addClipProperties(_key, _properties, _type) {
    var textdata = '';

    // 互換性のため (optionrows必須)
    if(_type == TYPE.RADIO) {
      var optionrows = 1;
      try{
        var len = _properties.option.value.length;
        var col = Number(_properties.optioncols.value);
        optionrows = parseInt((len+col-1)/col);
      }catch(e){}
      _properties.optionrows = {value:optionrows};
    }
    
    for(var propId in _properties) {
      if(propId == 'type') continue;
      var key = _key + '.' + propId + '.value';
      var val = _properties[propId].value;
      if(_type && isArrayValue(propId)){
        for(var items = 0; items < val.length; items++) {
          textdata += addClipParam(key + '.' + items, val[items]);
        }
      } else {
        if(val != '') {
          textdata += addClipParam(key, val);
        }
      }
    }
    return textdata;
  }
    
  function addClipParam(key,value) {
    return '&\n' + key + '=' + clipValueEncode(value);
  }
  
  function clipValueEncode(val) {
    if(typeof(val) == 'number' && val == 0) return '0';
    if(!val) return '';

    val = val.toString();
    val = val.replace(/#/g, '#sharp;');
    val = val.replace(/&/g, '#amp;');
    return val;
  }
}

/**
 * クリップボードを使用できるか
 */
function canUseSystemClipboard() {
  if(!m_browserType.isIE) return false;
  return true;
}

/**
 * クリップボードからペーストするデータを取得できるか
 */
function canGetSystemClipboard() {
  if(!canUseSystemClipboard()) return false;
  
  try {
    var textdata = clipboardData.getData("Text");
  } catch(e) {
    return false;
  }
  
  if(textdata) {
    if(textdata.indexOf(VIEWEDITORCLIPBOARDFORMAT) == 0) {
      return true;
    }
  }
  return false;
}

/**
 * クリップボードからペーストするデータを取得
 */
function getSystemClipboard() {

  if(!canUseSystemClipboard()) return null;
  
  var clipdata = null;

  var textdata = clipboardData.getData("Text");
  if(textdata) {
    var textdatasplit = textdata.split('&');
    if(textdatasplit[0] == VIEWEDITORCLIPBOARDFORMAT_COMPATIBLE2) {
      clipdata = createClip(textdatasplit);

    } else if(textdatasplit[0] == VIEWEDITORCLIPBOARDFORMAT_COMPATIBLE1) {
      clipdata = createClip(textdatasplit);
      for(var i = 0; i < clipdata.length; i++) {
        convertCompatible1(clipdata[i]);
      }

    } else {
      // 未対応のフォーマット
      alert('Current clipboard data format is not supported. (incompatible version)');
      
      clipdata = new Array();
      clipdata.referencePoint = {top:0, left:0};
    }
  }

  return clipdata;

  /*
   * オブジェクトを作成する
   */
  function createClip(textdatasplit) {
    var clipdata = new Array();
    clipdata.referencePoint = {top:0, left:0};

    for(var i = 1; i < textdatasplit.length; i++) {
      var pos = textdatasplit[i].indexOf('=');
      if(pos < 1) continue;
      var id = textdatasplit[i].substr(0,pos);
      var val = clipValueDecode(textdatasplit[i].substr(pos + 1));
      if(id.charAt(0) == '\r') id = id.substr(1);
      if(id.charAt(0) == '\n') id = id.substr(1);
      var idsplit = id.split('.');
      var tempObj = clipdata;
      for(var j = 0; j < idsplit.length - 1; j++) {
        var att = idsplit[j];
        if(tempObj[att] == undefined) {
          tempObj[att] = new Object();
        }
        tempObj = tempObj[att];
      }
      tempObj[idsplit[idsplit.length - 1]] = val;
    }
    return clipdata;
  }

  /*
   * 値デコード
   */
  function clipValueDecode(encval) {
    encval = encval.replace(/#amp;/g, '&');
    encval = encval.replace(/#sharp;/g,  '#');
    return encval;
  }

  /*
   *
   */
  function convertCompatible1(clip) {
    clip.type = toTypeCase(clip.type);
    for(var p in clip.properties) {
      switch(p) {
      case 'stylewidth'   : exchange(clip, p, 'width'); break;
      case 'styleheight'  : exchange(clip, p, 'height'); break;
      case 'stylebgcolor' : exchange(clip, p, 'backgroundcolor'); break;
      case 'bgcolor'      : exchange(clip, p, 'backgroundcolor'); break;
      case 'background'   : exchange(clip, p, 'backgroundimage'); break;
      case 'mode'         : exchange(clip, p, 'tablemode'); break;
      case 'maxcols'      : exchange(clip, p, 'tablecols'); break;
      case 'maxrows'      : exchange(clip, p, 'tablerows'); break;
      case 'radiomaxrows' : exchange(clip, p, 'optionrows'); break;
      case 'radiomaxcols' : exchange(clip, p, 'optioncols'); break;
      case 'multiple'     : exchange(clip, p, 'selectmode'); break;
      case 'size'         : exchange(clip, p, 'listsize'); break;
      case 'border'       : exchange(clip, p, 'borderwidth'); break;
      case 'otherparams'       : exchange(clip, p, 'attributes'); break;
      case 'embedotherparams'  : exchange(clip, p, 'embedattributes'); break;
      case 'textvalue'    : exchange(clip, p, 'fieldvalue'); break;
      case 'selvalue'     : exchange(clip, p, 'fieldvalue'); break;
      case 'hidevalue'    : exchange(clip, p, 'fieldvalue'); break;
      case 'text'         : exchange(clip, p, 'labeltext'); break;
      case 'value'        : 
        switch(clip.type) {
        case 'button':
        case 'submit':
        case 'reset':
          exchange(clip, p, 'labeltext');
          break;
        case 'check':
          exchange(clip, p, 'optionvalue');
          break;
        default:
          exchange(clip, p, 'fieldvalue');
        }
        break;
      case 'textalign'    : 
        exchange(clip, p, 'align');
      case 'align'        : 
        if(clip.properties.align.value) {
          clip.properties.align.value = clip.properties.align.value.toLowerCase();
        }
        break;
      }
    }

    if(clip.td) {
      for(var cellid in clip.td) {
        var cell = clip.td[cellid];
        for(var p in cell.properties) {
          switch(p) {
          case 'tdcol'        : exchange(cell, p, 'cellcol'); break;
          case 'tdrow'        : exchange(cell, p, 'cellrow'); break;
          case 'tdwidth'      : exchange(cell, p, 'cellwidth'); break;
          case 'tdheight'     : exchange(cell, p, 'cellheight'); break;
          case 'tdbgcolor'    : exchange(cell, p, 'cellbackgroundcolor'); break;
          case 'tdbordercolor': exchange(cell, p, 'cellbordercolor'); break;
          case 'tdbackground' : exchange(cell, p, 'cellbackgroundimage'); break;
          }
        }
      }
    }
    
    function exchange(obj, oldprop, newprop) {
      obj.properties[newprop] = obj.properties[oldprop];
      delete obj.properties[oldprop];
    }
  }
}

/**
 * 「削除」押下時の処理
 * @param  :shiftOn ブール シフトボタン押下状態
 * @return :
 */
function doCommandDelete(shiftOn){
  if(m_monitorEditStatus == 2) return;
  if(m_selection.front == ELEMENTID_FIRSTFORM) return;

  if(shiftOn || confirm(getMessage('C0001'))){
    // 実行
  } else {
    return;
  }
  
  var oldStatus = window.status;
  window.status = getMessage('S0013');

  //複数選択初期化

  // コマンドセット
  var cmdSet = new UndoableCommandSet(getLiteral('menuitem.delete'));
  cmdSet.add(new CommandSelect(true));
  
  var prog = new WindowStatusProgressBar(m_selection.length());
  for(var id in m_selection.elements) {
    prog.update();
    var objParam = createDeleteUndoParam(id, '削除', getDocumentElementById(id + '_span').style.zIndex);
    var cmd = createActionCommand(objParam);
    cmdSet.add(cmd);
    m_selection.remove(id);
    deleteElement(id);
  }
  prog.release();
  
  window.status = oldStatus;

  //log.debug('updating property area. [VwUtilityAction.js/doCommandDelete]');
  m_selection.updatePropertyArea();

  cmdSet.add(new CommandSelect(false));
  m_undoManager.execute(cmdSet);
  
  // メニューの状態
  m_menuBar.enableSave();
  m_menuBar.disableMenuItem('EDIT', 'CUT');
  m_menuBar.disableMenuItem('EDIT', 'COPY');
  m_menuBar.disableMenuItem('EDIT', 'DELETE');
  
  return;

  //削除しようとしたオブジェクトが読込時にカスタマイズ可だった場合、警告を出す
  var tmpFlg  = false;
  var tmpType = getDataSet(m_selection.front).getProperty('type');
  var tmpProp = getCustomizeInfo(tmpType).customProperties;
  for(var i=0; i<tmpProp.length; i++){

  // 2003.05.20 カスタマイズ属性を編集中のデータではなく、登録データを見るように変更
    if(getDataSet(m_selection.front).getCustomProperty(tmpProp[i], 'originalvalue') == 'enabled'){
      tmpFlg = true;
      break;
    }
  }

  if(!tmpFlg){
    var confMsg = getMessage('C0001');
  }else{
    if(m_monitorEditStatus == 1){
      var confMsg = getMessage('C0004');
    }else{
      var confMsg = getMessage('C0001');
    }
  }

  if(shiftOn || confirm(confMsg)){
    doCommandDelete();
    itemFocusSetter(ELEMENTID_FIRSTFORM);
    return;
  }
}

/**
 * エレメント削除処理
 * @param  :
 * @return :
 */
function deleteElement(elementId){
  if(!elementId) {
    //elementId = m_selection.front;
    alert('??elementId');
  }
  
  //id保存配列から該当IDを削除
  for(var i=0;i<m_addElementArray.length;i++){
    if(m_addElementArray[i]==elementId){
      m_addElementArray.splice(i, 1);

      //削除ID保持配列にデータをセット
      m_deleteElementArray[m_deleteElementArray.length] = elementId;

      break;
    }
  }

  //TABLE時、紐付くセルのIDを空文字に入れ替える
  //削除する要素数
  var deleteCounter = 0;
  if(getDataSet(elementId).isType(TYPE.TABLE)){
    for(var i=0;i<m_addElementArray.length;i++){
      if(getDataSet(m_addElementArray[i]).getProperty('parenttableid') == elementId){
        deleteCounter++;
        m_addElementArray.splice(i, 1, '');
      }
    }
  }

  //要素が空文字の配列を削除
  for(var i=0; i<deleteCounter; i++){
    for(var j=0; j<m_addElementArray.length; j++){
      if(m_addElementArray[j] == ''){
        m_addElementArray.splice(j, 1);
      }
    }
  }

  //対象エレメント削除
  var delSpan = getDocumentElementById(elementId + '_span');
//  delSpan.outerHTML = '';
  setOuterHTML(delSpan, '');

}


/**
 * 選択中のオブジェクトのIDを持つ
 */
var m_selection = new Selection(ELEMENTID_FIRSTFORM);

/**
 * 選択中のオブジェクトのIDを持つ
 */
function Selection(_defaultElementId) {
  // 属性欄表示オブジェクト
  this.defaultElementId = _defaultElementId;

  // 属性欄表示オブジェクト
  this.front = this.defaultElementId;
  
  // セル
  this.cell = '';
  
  // 更新チェック用
  this.save = {front:'', cell:''};

  // プロパティ欄
  this.current = {front:'', cell:''};

  // 選択されているオブジェクト
  this.elements = new Object();
  this.elements[this.front] = new Object();

  Selection.prototype.setFront = _setFront;
  Selection.prototype.setCell = _setCell;
  Selection.prototype.setCurrent = _setCurrent;
  Selection.prototype.savePoint = _savePoint;
  Selection.prototype.changed = _changed;
  Selection.prototype.has = _has;
  Selection.prototype.add = _add;
  Selection.prototype.remove = _remove;
  Selection.prototype.removeAll = _removeAll;
  Selection.prototype.updatePropertyArea = _updatePropertyArea;
  Selection.prototype.length = _length;
  Selection.prototype.toString = _toString;

  /**
   * 選択している項目を設定する
   */
  function _setFront(front, cell) {
    //log.debug('Selection._setFront(' + front + ',' + cell + ')');
    this.front = front;
    if(cell) {
      this.cell = cell;
    } else {
      this.cell = '';
    }
  }
  
  /**
   * 選択している項目を設定する
   */
  function _setCell(cell) {
    //log.debug('Selection._setCell(' + cell + ')');
    this.cell = cell;
  }
  
  /**
   * 属性欄に表示している項目を設定する
   */
  function _setCurrent(front, cell) {
    //log.debug('Selection._setCurrent(' + front + ',' + cell + ')');
    this.current.front = front;
    if(cell) {
      this.current.cell = cell;
    } else {
      this.current.cell = '';
    }
  }
  
  /**
   * 選択しているオブジェクトの数をかえす
   */
  function _length() {
    var len = 0;
    if(this.front != this.defaultElementId) {
      for(var id in this.elements) {
        len++;
      }
    }
    return len;
  }
  
  /**
   * 現在プロパティを表示しているオブジェクトを記憶する
   */
  function _savePoint() {
    this.save.front = this.front;
    this.save.cell = this.cell;
  }

  /**
   * 現在プロパティを表示しているオブジェクトと
   * 記憶しているオブジェクトが同じか比較する
   */
  function _changed() {
    if(this.save.front == this.front && this.save.cell == this.cell) {
      return false;
    } else {
      return true;
    }
  }

  /**
   * _elementIdが選択されているか調べる
   */
  function _has(_elementId) {
    if(this.elements[_elementId]) {
      return true;
    } else {
      return false;
    }
  }

  /**
   * _elementIdを選択する
   */
  function _add(_elementId, cellId) {
    //log.debug('Selection._add(' + _elementId + ',' + cellId + ')');
    
    if(_elementId == this.defaultElementId) return true;
    if(this.front == this.defaultElementId) {
      delete this.elements[this.front];
    }

    if(!this.elements[_elementId]) {
      var ds = getDataSet(_elementId);
      if(ds.getProperty('parenttableid') != '') return false;
      
      this.elements[_elementId] = new SelectedElementInfo(_elementId);
      this.elements[_elementId].select();
    }
    if(this.elements[_elementId]) {
      this.front = _elementId;
      if(cellId) {
        this.cell = cellId;
      } else {
        this.cell = '';
      }
      return true;
    } else {
      delete this.elements[_elementId];
    }
    return false;
  }

  /**
   * _elementIdを解除する
   */
  function _remove(_elementId) {
    if(this.elements[_elementId]) {
      try {
        this.elements[_elementId].unselect();
      } catch(e) {
      }
    }
    delete this.elements[_elementId];

    this.front = this.defaultElementId;
    this.cell = '';
    for(var id in this.elements) {
      this.front = id;
    }
    if(this.front != this.defaultElementId) {
      if(getDataSet(this.front).isType(TYPE.TABLE)) {
        this.cell = getCellId(this.front);
      }
    } else {
      this.elements[this.front] = new Object();
    }
  }

  /**
   * すべて選択解除する
   */
  function _removeAll(progressBar) {
    if(this.front == this.defaultElementId) return;
    if(progressBar) {
      var prog = progressBar;
    } else {
      var prog = new WindowStatusProgressBar(this.length());
    }
    for(var id in this.elements) {
      prog.update();
      try {
        this.elements[id].unselect();
      } catch(e) {
      }
      delete this.elements[id]
    }
    if(!progressBar) {
      prog.release();
    }
    
    this.front = this.defaultElementId;
    this.cell = '';
    this.elements[this.front] = new Object();
  }
  
  function _updatePropertyArea(curFld) {
    //log.debug('_updatePropertyArea(' + curFld + ')');
    if(curFld) {
      window.setTimeout('m_propertyArea.update("' + curFld + '")',0);
    } else {
      window.setTimeout('m_propertyArea.update()',0);
    }
  }

  function _toString() {
    return (new DescriptionObject(this, 'Selection', 3)).toString()
  }
}

/**
 * 選択されているオブジェクトの情報
 */
function SelectedElementInfo(_elementId) {
  this.elementId = _elementId;
  this.element = getDocumentElementById(this.elementId + '_span');
  
  SelectedElementInfo.prototype.select = _select;
  SelectedElementInfo.prototype.unselect = _unselect;
    
  function _select() {
    this.element = getDocumentElementById(this.elementId + '_span');
    //showObject(this.element,this.elementId,3);
    try {
      this.element.style.border = pref.view.get('selectionborder');
    } catch(e) {
      alert(this.elementId);
    }
    setResizeHandle(this.elementId);
  }

  function _unselect() {
    var border = 'none';
    var objDS = getDataSet(this.elementId);
    if(m_monitorEditStatus == 2 && objDS.getItemCustomizable()){
      if(objDS.getCustomized()){
        //カスタマイズ済時
        border = pref.view.get('customizedborder');
      }else{
        //未カスタマイズ時
        border = pref.view.get('customizableborder');
      }
    }
    
    this.element = getDocumentElementById(this.elementId + '_span');
    this.element.style.border = border;
    removeResizeHandle(this.elementId);
  }
}

/**
 * undo
 * @param  :
 * @return :
 */
function executeUndoableCommand(cmd){
  m_undoManager.execute(cmd);
}


/*
 * Undoを実行
 */
function doCommandUndo() {
  var prog = new WindowStatusProgressBar(0, getMessage('S0014'));
  m_undoManager.undo();
  prog.release();
}

/*
 * Redoを実行
 */
function doCommandRedo() {
  var prog = new WindowStatusProgressBar(0, getMessage('S0016'));
  m_undoManager.redo();
  prog.release();
}

/**
 * 移動時のundoコマンド生成用のパラメータを作成する
 * @param  :id   オブジェクトID
 *          orgW 元の横位置
 *          orgH 元の縦位置
 *          orgW 設定する横位置
 *          orgH 設定する縦位置
 * @return :objParam パラメータオブジェクト
 */
function createMoveUndoParam(id, orgW, orgH, newW, newH){
  var objParam           = new Object();
      objParam.id        = id;
      objParam.action    = 3;
      objParam.name      = '移動';
      objParam.orgwidth  = orgW;
      objParam.orgheight = orgH;
      objParam.width     = newW;
      objParam.height    = newH;
  return objParam;
}

/**
 * 削除時のundoコマンド生成用のパラメータを作成する
 * @param  :id      オブジェクトID
 *          strName アクション文字列
 *          zidx    zIndex
 * @return :objParam パラメータオブジェクト
 */
function createDeleteUndoParam(id, strName, zidx){
  var objParam        = new Object();
      objParam.id     = id;
      objParam.action = 2;
      objParam.name   = strName;
      objParam.zindex = zidx;
  return objParam;
}

/**
 * 追加時のundoコマンド生成用のパラメータを作成する
 * @param  :id      オブジェクトID
 *          strName アクション文字列
 * @return :objParam パラメータオブジェクト
 */
function createAddUndoParam(id, strName){
  var objParam        = new Object();
      objParam.id     = id;
      objParam.action = 1;
      objParam.name   = strName;
      objParam.zindex = getDocumentElementById(id + '_span').style.zIndex;
  return objParam;
}

/**
 * アクション毎にコマンドオブジェクトを生成する
 * @param  :objParam           オブジェクト 各アクション実行時に生成されるパラメータオブジェクト
 * @param  :objParam.id        文字型       対応アクション実行対象オブジェクトID
 *          objParam.action    数値型       対応アクション識別フラグ(1:追加(貼り付け),2:削除(切り取り),3:移動,4:プロパティ設定,5:項目タイプ変換)
 *          objparam.orgwidth  数値型       「移動」時のみ、移動前座標(X)
 *          objParam.orgheight 数値型       「移動」時のみ、移動前座標(Y)
 *          objparam.width     数値型       「移動」時のみ、移動後座標(X)
 *          objParam.height    数値型       「移動」時のみ、移動後座標(Y)
 *          objParam.zindex    数値型       「追加(貼り付け)」、「削除(切り取り)」、「項目タイプ変換」時のみ、エレメントのzIndex
 *          objParam.propname  文字型       「プロパティ設定」時のみ、プロパティテーブル内のID
 *          objParam.orgval    文字型       「プロパティ設定」時のみ、旧設定値
 *          objParam.newval    文字型       「プロパティ設定」時のみ、設定値
 *          objParam.orgds     オブジェクト 「項目タイプ変換」時のみ、元DataSet
 *          objParam.totype    文字列       「項目タイプ変換」時のみ、変換後の項目タイプ
 *          objParam.orgtds    配列         「項目タイプ変換」時のみ、変換元項目タイプがTABLE時のみ使用セルのID配列。インデックスはID、要素はDataSetとなる
 * @return :
 */
function createActionCommand(objParam){
  if(objParam.action == 4) {
    return new UndoPropertyEdit(objParam.id, objParam.td, objParam.propname, objParam.orgval, objParam.newval);
  } else {
    return new undoCommandManager(objParam);
  }
}

/**
 * コマンド実装クラス
 * @param  :
 * @return :
 */
function undoCommandManager(objParam){

  /** property */
  this.id               = objParam.id;
  this.action           = objParam.action;
  this.presentationName = objParam.name;
  if(objParam.td) {
    this.td               = objParam.td;
  } else {
    this.td               = '';
  }
  //各アクション個別プロパティ設定
  if(objParam.action == 1){
    //追加(貼り付け)時
    this.zindex    = objParam.zindex;
  }else if(objParam.action == 2){
    //削除(切り取り)時
    this.zindex    = objParam.zindex;
  }else if(objParam.action == 3){
    //移動時
    this.orgwidth  = objParam.orgwidth;
    this.orgheight = objParam.orgheight;
    this.width     = objParam.width;
    this.height    = objParam.height;
  }else if(objParam.action == 4){
    //プロパティ設定時
    this.propname  = objParam.propname;
    this.orgval    = objParam.orgval;
    this.newval    = objParam.newval;
  }else if(objParam.action == 5){
    //項目タイプ変換時
    this.orgtype   = objParam.orgtype;
    this.orgds     = duplicateDataSet(objParam.orgds);
    this.newtype   = objParam.newtype;
    this.zindex    = objParam.zindex;
    //元の項目タイプがTABLE時、使用していた全セルのid配列、それに紐付くDataSetをコピー
    if(this.orgtype == TYPE.TABLE){
      this.orgtds = new Array();
      for(var i in objParam.orgtds){
        this.orgtds[i] = duplicateDataSet(objParam.orgtds[i]);
      }
    }
  }

  /** method */
  undoCommandManager.prototype.execute = fnExecute; //ダミー
  undoCommandManager.prototype.undo    = fnUndo;    //undo(元に戻す)
  undoCommandManager.prototype.redo    = fnRedo;    //redo(やり直す)

  /**
   * ダミー
   * @param  :
   * @return :
   */
  function fnExecute(){

  }

  /**
   * 元に戻す
   * @param  :
   * @return :
   */
  function fnUndo(){
    var targetId     = this.id;
    var targetTdId   = this.td;
    var targetAction = this.action;

    switch(targetAction){
      //追加(貼り付け)
      case 1:
        undoAdd(targetId);
        break;
      
      //削除(切り取り)
      case 2:
        readdElement(targetId);
        getDocumentElementById(targetId + '_span').style.zIndex = this.zindex;
        break;
      
      //移動
      case 3:
          var docNodeStyle = getDocumentElementById(targetId + '_span').style;
          var objDS   = getDataSet(targetId);
          docNodeStyle.top  = this.orgheight;
          docNodeStyle.left = this.orgwidth;
          objDS.setProperty('top', this.orgheight);
          objDS.setProperty('left', this.orgwidth);
          if(targetId == m_selection.current.front) {
            getDocumentElementById('fld_top').value  = this.orgheight;
            getDocumentElementById('fld_left').value = this.orgwidth;
          }
          customizedMobilityChecker(objDS, this.orgheight, this.orgwidth, targetId);
        break;
      
      //プロパティ設定
      case 4:
        alert('!!!!!!!!');

      //項目タイプを元に戻す
      case 5:
        if(this.orgtype == TYPE.TABLE){
          for(var i in this.orgtds){
            //使用していたセルのIDをm_addElementArrayに追加
            m_addElementArray[m_addElementArray.length] = i;
            addDataSet(i, duplicateDataSet(this.orgtds[i]));
          }
        }

        /**/
        if(this.orgtype == TYPE.PANEL){
          for(var i=0;i<m_addElementArray.length;i++){

            if(getDataSet(m_addElementArray[i]).getProperty('parenttableid') == targetId){
              m_addElementArray.splice(i, 1);
            }
          }
        }

        /**/
        deleteDataSet(targetId);
        addDataSet(targetId, duplicateDataSet(this.orgds));
        setOuterHTML(getDocumentElementById(targetId + '_span'), getElementHtml(getDataSet(targetId)));
        getDocumentElementById(targetId + '_span').style.zIndex = this.zindex;
        // @
        if(m_selection.has(targetId)) {
          getDocumentElementById(targetId + '_span').style.border = pref.view.get('selectionborder');
          setResizeHandle(targetId);
        }
      break;
    }
  }

  /**
   * やり直す
   * @param  :
   * @return :
   */
  function fnRedo(){
    var targetId     = this.id;
    var targetTdId   = this.td;
    var targetAction = this.action;

    switch(targetAction){
      //追加(貼り付け)
      case 1:
        readdElement(targetId);
        getDocumentElementById(targetId + '_span').style.zIndex = this.zindex;
        break;
      
      //削除(切り取り)
      case 2:
        undoAdd(targetId);
        break;
      
      //移動
      case 3:
        var docNodeStyle = getDocumentElementById(targetId + '_span').style;
        var objDS   = getDataSet(targetId);
        docNodeStyle.top  = this.height;
        docNodeStyle.left = this.width;
        objDS.setProperty('top', this.height);
        objDS.setProperty('left', this.width);
        if(targetId == m_selection.current.front) {
          getDocumentElementById('fld_top').value  = this.orgheight;
          getDocumentElementById('fld_left').value = this.orgwidth;
        }
        customizedMobilityChecker(objDS, this.height, this.width, targetId);
        break;
      
      //項目タイプ変換
      case 5:
        changeItemType(this.orgtype, this.newtype, this.id);
        getDocumentElementById(targetId + '_span').style.zIndex = this.zindex;
        // @
        if(m_selection.has(targetId)) {
          getDocumentElementById(targetId + '_span').style.border = pref.view.get('selectionborder');
          setResizeHandle(targetId);
        }
        break;
    }
  }
}

/****/
//2003.10.15
/**
 * コマンド実装クラス
 * @param  :
 * @return :
 */
function UndoPropertyEdit(elementId, cellId, propertyId, oldValue, newValue, inf) {

  /** property */
  this.presentationName = '';
  this.elementId  = elementId;
  this.cellId     = cellId;
  this.propertyId = propertyId;
  this.oldValue   = oldValue;
  this.newValue   = newValue;
  this.inf = inf;
  
  this.undomsg = getMessage('S0014') + ' (' + this.elementId + ')';
  this.redomsg = getMessage('S0016') + ' (' + this.elementId + ')';
  //this.undomsg = getMessage('S0015', new Array(this.propertyId)) + ' (' + this.elementId + ')';
  //this.redomsg = getMessage('S0017', new Array(this.propertyId)) + ' (' + this.elementId + ')';
  
  
  /** method */
  UndoPropertyEdit.prototype.execute = _execute; //ダミー
  UndoPropertyEdit.prototype.undo    = _undo;    //undo(元に戻す)
  UndoPropertyEdit.prototype.redo    = _redo;    //redo(やり直す)

  /**
   * ダミー
   * @param  :
   * @return :
   */
  function _execute(){
    updateViewToolTipAttribute(this.elementId);
  }

  /**
   * 元に戻す
   * @param  :
   * @return :
   */
  function _undo(){
    var dataset = getDataSet(this.elementId);
    var celldataset = getDataSet(this.cellId, '');
    _do(this.elementId, this.cellId, this.propertyId, this.oldValue, dataset, celldataset, this.undomsg, this.inf);
    updateViewToolTipAttribute(this.elementId);
  }

  /**
   * やり直す
   * @param  :
   * @return :
   */
  function _redo(){
    var dataset = getDataSet(this.elementId);
    var celldataset = getDataSet(this.cellId, '');
    _do(this.elementId, this.cellId, this.propertyId, this.newValue, dataset, celldataset, this.redomsg, this.inf);
    updateViewToolTipAttribute(this.elementId);
  }

  /**
   * 
   * @param  :
   * @return :
   */
  function _do(elementId, cellId, propId, val, dataset, celldataset, msg, inf) {
    var windowStatus = window.status;
    window.status = msg;// + ' ' + elementId + '.' + propId;
    var type = dataset.getProperty('type');
    var rtn = getViewObject(type).update(propId, val, elementId, dataset, cellId, celldataset, inf);
    if(rtn) {
      
      if(!rtn.updated) {
        // datasetは更新されていない
        dataset.setProperty(propId, rtn.value);
      }

      if(rtn.repaint) {
        // span再描画
        getViewObject(type).repaint(elementId, dataset, cellId, celldataset);
      }

      if(rtn.border) {
        // spanのborder再描画
        var spanStyle = getDocumentElementById(elementId + '_span').style;
        var border = spanStyle.border;
        spanStyle.border = 'none';
        spanStyle.border = border;
      }
      
      if(rtn.reconstructed) {
        if(m_selection.has(elementId)) {
          setResizeHandle(elementId);
        }
      } else if(rtn.resized) {
        // サイズが変更されたのでリサイズハンドルの位置を修正
        if(m_selection.has(elementId)) {
          validateResizeHandleLocation(elementId);
        }
      }
        
      window.status = windowStatus;
    }
  }  
}

/**
 * コマンド実装クラス
 * オブジェクトを選択状態にする
 * @param  :undoFlg   true: undoの時に選択, false:redoのときに選択
 *          updateFlg false: 属性欄を更新しない true/default:属性欄を更新する
 *          id        選択状態にするオブジェクトのID 
 *                    ''(空文字列):addメソッドで追加
 *                    指定なし:現在選択されているもの
 * @return :
 */
function CommandSelect(undoFlg, updateFlg, id){

  /** property */
/**/
  this.front = m_selection.defaultElementId;
  this.cell = '';
  this.length = 0;
  
  this.elements = new Object();
  if(typeof(id) == 'undefined') {
    for(var id in m_selection.elements) {
      this.elements[id] = id;
      this.length++;
    }
    this.front = m_selection.front;
    this.cell = m_selection.cell;
  }
  
  this.undoFlg = undoFlg;
  
  this.updateFlg = true;
  if(typeof(updateFlg) == 'boolean' && updateFlg == false) {
    this.updateFlg = false;
  }

  
  /** method */
  if(!CommandSelect.initialized) {
    CommandSelect.prototype.execute = _execute; //ダミー
    CommandSelect.prototype.undo    = _undo;    //undo(元に戻す)
    CommandSelect.prototype.redo    = _redo;    //redo(やり直す)
    CommandSelect.prototype.undoSize = _undoSize;
    CommandSelect.prototype.redoSize = _redoSize;
    CommandSelect.prototype.select  = _select;
    CommandSelect.prototype.add = _add; //追加
    CommandSelect.initialized = true;
  }

  function _add(_id, _cellId){
    this.elements[_id] = _id;
    this.front = _id;
    if(_cellId) {
      this.cell = _cellId;
    } else {
      if(this.front == m_selection.front) {
        this.cell = m_selection.cell;
      } else {
        this.cell = '';
      }
    }
    this.length++;
  }
  
  /**
   * やり直す
   * @param  :
   * @return :
   */
  function _select(progressBar){
    var _front = m_selection.front;
    var _cell = m_selection.cell;
    //m_selection.removeAll();
        
    // 進捗表示用
    if(progressBar) {
      var prog = progressBar;
    } else {
      var prog = new WindowStatusProgressBar(this.length, getMessage('S0008'));
    }
    
    // 選択状態をはずす or ハンドルの位置修正
    for(var id in m_selection.elements) {
      if(id != ELEMENTID_FIRSTFORM) {
        if(this.elements[id]) {
          prog.update();
          //setResizeHandle(id);
        } else {
          m_selection.remove(id);
        }
      }
    }

    // 選択状態にする
    for(var id in this.elements) {
      if(m_selection.elements[id]) {
        //validateResizeHandleLocation(id);
      } else {
        prog.update();
        m_selection.add(id);
      }
    }

    if(!progressBar) {
      prog.release();
    }

    m_selection.setFront(this.front, this.cell);

    if(this.updateFlg || _front != m_selection.front || _cell != m_selection.cell) {
      //log.debug('updating property area. [VwUtilityAction.js/CommandSelect._select]');
      m_selection.updatePropertyArea();
    }
    
    if(m_selection.front == ELEMENTID_FIRSTFORM){
      m_menuBar.disableMenuItem('EDIT', 'CUT');
      m_menuBar.disableMenuItem('EDIT', 'COPY');
      m_menuBar.disableMenuItem('EDIT', 'DELETE');
    }else{
      m_menuBar.enableMenuItem('EDIT', 'CUT');
      m_menuBar.enableMenuItem('EDIT', 'COPY');
      m_menuBar.enableMenuItem('EDIT', 'DELETE');
    }
  }
  
  /**
   * @param  :
   * @return :
   */
  function _execute(progressBar){
  }

  /**
   * 元に戻す
   * @param  :
   * @return :
   */
  function _undo(progressBar){
    if(this.undoFlg) {
      this.select(progressBar);
    }
  }

  /**
   * やり直す
   * @param  :
   * @return :
   */
  function _redo(progressBar){
    if(!this.undoFlg) {
      return this.select(progressBar);
    }
  }

  /**
   * 元に戻す
   * @param  :
   * @return :
   */
  function _undoSize(){
    if(this.undoFlg) {
      return this.length;
    }
    return 0;
  }

  /**
   * やり直す
   * @param  :
   * @return :
   */
  function _redoSize(){
    if(!this.undoFlg) {
      return this.length;
    }
    return 0;
  }
}


/**
 * 削除のundo及び、追加のredo
 * @param  :targetId 文字型 対象オブジェクトID
 * @return :
 */
function readdElement(targetId){
  //削除したIDをm_addElementArrayに追加
  m_addElementArray[m_addElementArray.length] = targetId;
  //削除ID保持配列からIDを削除
  for(var i=0; i<m_deleteElementArray.length; i++){
    if(m_deleteElementArray[i] == targetId){
      m_deleteElementArray.splice(i, 1);
    }
  }

  //2003.06.24 テーブル削除のUNDOでセルのIDが復元されていなかったバグ対処
  //TABLE削除時、セルのIDを再生成
  if(getDataSet(targetId).isType(TYPE.TABLE)){
    var objDs = getDataSet(targetId);
    //作成する行数、列数取得
    var createCols = parseInt(objDs.getProperty('tablecols'));
    var createRows = getDesignTableRows(objDs);
    
    //セルのID生成、m_addElementArrayに追加
    for(var i=1; i<createRows+1; i++){
      for(var j=1; j<createCols+1; j++){
        m_addElementArray[m_addElementArray.length] = getCellId(targetId, i, j);
      }
    }
  }

  //HTML文字列を作成しページに追加する
  getDocumentElementById(ELEMENTID_FIRSTFORM).innerHTML += getElementHtml(getDataSet(targetId));
}

/**
 * 追加のundo及び、削除のredo
 * @param  :targetId 文字型 対象オブジェクトID
 * @return :
 */
function undoAdd(targetId){
  //id保存配列から該当IDを削除
  for(var i=0;i<m_addElementArray.length;i++){
    if(m_addElementArray[i]==targetId){
      m_addElementArray.splice(i, 1);
      //削除ID保持配列にデータをセット
      m_deleteElementArray[m_deleteElementArray.length] = targetId;
      break;
    }
  }
  //TABLE時、紐付くセルのIDを空文字に入れ替える
  //削除する要素数
  var deleteCounter = 0;
  if(getDataSet(targetId).isType(TYPE.TABLE)){
    for(var i=0;i<m_addElementArray.length;i++){
      if(getDataSet(m_addElementArray[i]).getProperty('parenttableid') == targetId){
        deleteCounter++;
        m_addElementArray.splice(i, 1, '');
      }
    }
  }
  //要素が空文字の配列を削除
  for(var i=0; i<deleteCounter; i++){
    for(var j=0; j<m_addElementArray.length; j++){
      if(m_addElementArray[j] == ''){
        m_addElementArray.splice(j, 1);
      }
    }
  }
  //対象エレメント削除
  var delSpan = getDocumentElementById(targetId + '_span');
  setOuterHTML(delSpan, '');

}

/*    */


/**
 * tabキーによる項目移動(カスタマイズ時：カスタマイズ可能項目のみ)
 * @param  :
 * @return :
 */
function jumpItem(shiftKey){
  //追加項目がない時は戻す
  var numItems = parseInt(m_addElementArray.length);
  if(numItems < 2) return;

  //tab移動可能項目id配列作成
  var tabAbleArray = new Array();
  if(m_monitorEditStatus == 2){
    //カスタマイズ時
    for(var i=0; i<numItems; i++){
      var objDS = getDataSet(m_addElementArray[i]);
      if(!objDS.isType(TYPE.CELL) && objDS.getItemCustomizable()){
        tabAbleArray[tabAbleArray.length] = m_addElementArray[i];
      }
    }
  }else{
    //編集時
    for(var i=0; i<numItems; i++){
      var objDS = getDataSet(m_addElementArray[i]);
      if(!objDS.isType(TYPE.CELL)){
        tabAbleArray[tabAbleArray.length] = m_addElementArray[i];
      }
    }
  }

  //tab移動対象配列内でのカレントのインデックスを取得
  var numTabMove = parseInt(tabAbleArray.length);
  for(var i=0; i<numTabMove; i++){
    if(tabAbleArray[i] == m_selection.front){
      if(shiftKey) {
        if(i == 0){
          var tmpNewId = tabAbleArray[numTabMove - 1];
        }else{
          var tmpNewId = tabAbleArray[i-1];
        }
      } else {
        if((i + 1) == numTabMove){
          var tmpNewId = tabAbleArray[0];
        }else{
          var tmpNewId = tabAbleArray[i+1];
        }
      }
      break;
    }
  }

  if(!tmpNewId || tmpNewId == '') return;
  
  m_selection.removeAll();
  m_selection.add(tmpNewId);

  //log.debug('updating property area. [VwUtilityAction.js/jumpItem]');
  m_selection.updatePropertyArea();

  itemFocusSetter(tmpNewId);
}



/*
 * メニューの状態を更新する
 */
function undoStateChanged(_canUndo, _canRedo, _canSave) {
  if(_canUndo) {
    m_menuBar.enableMenuItem('EDIT', 'UNDO');
  } else {
    m_menuBar.disableMenuItem('EDIT', 'UNDO');
  }
  if(_canRedo) {
    m_menuBar.enableMenuItem('EDIT', 'REDO');
  } else {
    m_menuBar.disableMenuItem('EDIT', 'REDO');
  }
  if(!_canSave) {
    m_menuBar.disableSave();
  }
}

/**
 *
 */
var m_propertyArea = new PropertyArea();

/**
 * 個別プロパティセットオブジェクト
 * @param  :objId 文字型 個別プロパティセット表示部分DIVのID
 * @return :
 */
function PropertyArea(){
  //@:property
  //this.parentId = objId;

  //@:public method
  PropertyArea.prototype.update = fnUpdate;  //個別プロパティテーブル作成

  /**
   * カレントエレメントのプロパティテーブルを作成する
   * @param  :strType 文字型 作成する項目タイプ
   * @return :
   */
  function fnUpdate(curFld){
    //
    var front = m_selection.front;
    var cell = m_selection.cell;
    
    var dataset = getDataSet(front, null);
    if(!dataset) {
      return;
    }
    
    var strType = dataset.getProperty('type');
    
    // 
    if(strType == TYPE.TABLE) {
      if(cell == '') {
        cell = getCellId(front);
        m_selection.setCell(cell);
      }
    }
    
    //プロパティテーブルドキュメントノード
    var propTblNode = getDocumentElementById('fld_showPropertyTable_div');

    //プロパティテーブルを一旦非表示にする
    propTblNode.style.visibility = 'hidden';

    //個別部分の入れ物作成
    fnCreateTypePropTbl(strType, front, cell);
    
    //個別部分にデータセット
    fnSetTypePropTbl(strType, front, cell);

    //プロパティテーブルの非表示解除
    propTblNode.style.visibility = 'visible';

    m_selection.current.front = front;
    m_selection.current.cell = cell;
    
    if(curFld) {
      var fld = getDocumentElementById(curFld);
      if(fld) {
        try {
          fld.focus();
        //  fld.select();
        }catch(e){}
      } else {
        log.debug('Could not focus on "' + curFld + '".');
      }
    }
    
    // 
    if(cell != '') {
      window.status = front + '/' + cell;
    } else {
      window.status = front;
    }
  }
  
  //個別部分の入れ物作成
  function fnCreateTypePropTbl(strType, elementId, cellElementId){
    if(elementId != ''){

      //typeObject
      var objType = getViewObject(strType);

      //個別部分のプロパティテーブル作成(typeObject作成)
      objType.createPropertyTable(elementId, cellElementId, getDataSet(elementId));
    }
  }

  //個別部分にデータ設定
  function fnSetTypePropTbl(strType, elementId, cellElementId){
    if(elementId == '') return;

    var objDS = getDataSet(elementId);

    var objType = getViewObject(strType);

    //カスタマイズ時は「項目TYPE」非表示
    if(m_monitorEditStatus == 2){
      
      hideNonCustomizable('visibility', 'fld_visibility_tr');
      hideNonCustomizable('mobility', 'fld_top_tr');
      hideNonCustomizable('mobility', 'fld_left_tr');
      hideNonCustomizable('defaultvalue', 'fld_fieldvalue_tr');
      hideNonCustomizable('maxlines', 'fld_maxlines_tr');
      
      function hideNonCustomizable(customizePropertyId, trElementId) {
        var tr = getDocumentElementById(trElementId);
        if(tr) {
          if(objDS.getCustomizableItems()[customizePropertyId] == false){
            tr.style.display  = 'none';
          }else{
            tr.style.display  = '';
          }
        }
      }
    }
    
    // DataSetからプロパティテーブルへ
    log.debug('setting property table : ' + elementId + '/' + cellElementId);
    var typeinfodef = getTypeInfoDef(strType);
    for(var propid in typeinfodef){
      objType.setPropertyTable(propid, objDS, elementId, cellElementId);
    }

    //カスタマイズプロパティ
    var customProperties = getCustomizeInfo(strType).customProperties;
    for(var i=0; i<customProperties.length; i++){
      objType.setPropertyTable(customProperties[i], objDS, elementId, cellElementId);
    }

    //TABLE時、セルのプロパティをセット
    if(strType == TYPE.TABLE){
      for(var propid in getTypeInfoDef(TYPE.CELL)){
        if(propid == 'type') continue;
        objType.setPropertyTable(propid, objDS, elementId, cellElementId);
      }
    }
  }
}

/*
 *
 */
function createError(strMessage, strFileName, strMethod) {
  var msg;
  if(strMethod) {
    if(strFileName && !m_browserType.isNN) {
      msg = strMethod + ' / ' + strFileName + '\n' + strMessage;
    } else {
      msg = strMethod + '\n' + strMessage
    }
  } else {
    if(strFileName && !m_browserType.isNN) {
      msg = strFileName + '\n' + strMessage;
    } else {
      msg = strMessage;
    }
  }
  log.debug('createError: method=' + strMethod + ' file=' + strFileName + '\n' + strMessage);
  return new Error(msg);
}
