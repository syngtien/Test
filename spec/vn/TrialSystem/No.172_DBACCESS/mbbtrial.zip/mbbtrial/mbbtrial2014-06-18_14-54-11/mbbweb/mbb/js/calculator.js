
var objCalculator = null;
/**
 * カレンダー画面を開く。
 * @param fieldId カレンダー上で選択した日付をセットするテキストボックスのID
 */

function calculatorHelp(fieldId){

	var win = window.open("", "calculatorWin", "width=250,height=300");
	objCalculator = new Calculator("objCalendar", "opener", fieldId, win);

	objCalculator.disp();

}


function Calculator(name, own, fieldId, obj) {
	this.name = name;
	this.own = own;
	this.fieldId = fieldId;
	this.obj = obj;

	return this;
}

Calculator.prototype.disp = function () {
	this.writeCalendar();
}

Calculator.prototype.writeCalendar = function () {
	var d = this.obj.document;
	d.open();

//	d.writeln('<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">');
	d.writeln('<html>');
	d.writeln('<head>');
	d.writeln('<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">');
	d.writeln('<title>calculator</title>');
	
	d.writeln('<script language="JavaScript1.3">');
	d.writeln('	var number = 0;');
	d.writeln('	var stocknumber = 0;');
	d.writeln('	var cleared = "";');
	d.writeln('	var changed = "";');
	
	d.writeln('function setDataToOpener(){');
	d.writeln('    if(window.opener.document.getElementById)');
	d.writeln('        window.opener.document.getElementById("' + this.fieldId + '").value = document.calc.disp.value;');
	d.writeln('    else');
   	d.writeln('        window.opener.document.all("' + this.fieldId + '").value = document.calc.disp.value;');
	d.writeln('    window.close();');
	d.writeln('}');

	d.writeln('//数値ボタン押下時に実行する入力関数');
	d.writeln('function keyin(key){');
	d.writeln('	if (cleared == 0){');
	d.writeln('		document.calc.disp.value = "";');
	d.writeln('		cleared = 1;');
	d.writeln('	}');
	d.writeln(' if(document.calc.disp.value == "0")document.calc.disp.value="";');
	d.writeln('	document.calc.disp.value = document.calc.disp.value + key;');
	d.writeln('	if (document.calc.disp.value.indexOf(".") < 0){');
	d.writeln('		document.calc.disp.value = document.calc.disp.value.substr(0, 12);');
	d.writeln('	}else{');
	d.writeln('		document.calc.disp.value = document.calc.disp.value.substr(0, 13);');
	d.writeln('	}');
	d.writeln('	changed = 1;');
	d.writeln('}');

	d.writeln('//[.]押下時に実行する入力関数');
	d.writeln('function dot(key){');
	d.writeln('	var dipvalue = document.calc.disp.value;');

	d.writeln('	if (dipvalue.indexOf(".") < 0 || cleared == 0) {');
	d.writeln('		if (dipvalue == "" || cleared == 0) {');
	d.writeln('			document.calc.disp.value = "0";');
	d.writeln('		}');
	d.writeln('		document.calc.disp.value = document.calc.disp.value + key;');
	d.writeln('		cleared = 1;');
	d.writeln('	}');
	d.writeln('}');

	d.writeln('//[+][-][*][/]押下時に実行する演算関数');
	d.writeln('function calculate(operator){');
	d.writeln('	cleared = 0;');
	d.writeln('	if (number == 0){');
	d.writeln('		document.calc.scape.value = operator;');
	d.writeln('		number = eval(document.calc.disp.value);');
	d.writeln('	}else{');
	d.writeln('		stocknumber = eval(document.calc.disp.value);');
	d.writeln('		if (changed == 1){');
	d.writeln('			switch (document.calc.scape.value){');
	d.writeln('			    case "+":');
	d.writeln('				document.calc.disp.value = number + stocknumber;');
	d.writeln('				break;');
	d.writeln('			    case "-":');
	d.writeln('				document.calc.disp.value = number - stocknumber;');
	d.writeln('				break;');
	d.writeln('			    case "*":');
	d.writeln('				document.calc.disp.value = number * stocknumber;');
	d.writeln('				break;');
	d.writeln('			    case "/":');
	d.writeln('				document.calc.disp.value = number / stocknumber;');
	d.writeln('				break;');
	d.writeln('			}');
	d.writeln('		}');
	d.writeln('		number = eval(document.calc.disp.value);');
	d.writeln('		document.calc.scape.value = operator;');
	d.writeln('	}');
	d.writeln('	changed = 0;');
	d.writeln('}');

	d.writeln('//[=][%][M+][M-]押下時に実行する演算結果表示関数');
	d.writeln('function result(key){');
	d.writeln('	stocknumber = eval(document.calc.disp.value);');
	d.writeln('	switch (document.calc.scape.value){');
	d.writeln('	    case "+":');
	d.writeln('		document.calc.disp.value = number + stocknumber;');
	d.writeln('		if (document.calc.disp.value.length > 12){');
	d.writeln('			document.calc.disp.value = "Error!";');
	d.writeln('		}');
	d.writeln('		break;');
	d.writeln('	    case "-":');
	d.writeln('		document.calc.disp.value = number - stocknumber;');
	d.writeln('		break;');
	d.writeln('	    case "*":');
	d.writeln('		document.calc.disp.value = number * stocknumber;');
	d.writeln('		if (document.calc.disp.value.length > 12){');
	d.writeln('			document.calc.disp.value = "Error!";');
	d.writeln('		}');
	d.writeln('		break;');
	d.writeln('	    case "/":');
	d.writeln('		document.calc.disp.value = number / stocknumber;');
	d.writeln('		if (stocknumber == 0){');
	d.writeln('			document.calc.disp.value = "Error!";');
	d.writeln('		}');
	d.writeln('		break;');
	d.writeln('	}');
	d.writeln('	document.calc.disp.value = document.calc.disp.value.substr(0, 12);');
	d.writeln('	switch (key) {');
	d.writeln('	    case "%":');
	d.writeln('		switch (document.calc.scape.value) {');
	d.writeln('		    case "+":	// x + y % → xのy%増しは?');
	d.writeln('			document.calc.disp.value = number + stocknumber * number / 100;');
	d.writeln('			break;');
	d.writeln('		    case "-":	// x - y % → xはyの何%増し?');
	d.writeln('			document.calc.disp.value = (number - stocknumber) / stocknumber * 100;');
	d.writeln('			break;');
	d.writeln('		    case "*":	// x * y % → xのy%は?');
	d.writeln('			document.calc.disp.value /= 100;');
	d.writeln('			break;');
	d.writeln('		    case "/":	// x / y % → xはyの何%?');
	d.writeln('			if (stocknumber != 0) {');
	d.writeln('				document.calc.disp.value *= 100;');
	d.writeln('			}');
	d.writeln('			break;');
	d.writeln('		}');
	d.writeln('		break;');
	d.writeln('	    case "M-":');
	d.writeln('		document.calc.memory.value -= eval(document.calc.disp.value);');
	d.writeln('		break;');
	d.writeln('	    case "M+":');
	d.writeln('		document.calc.memory.value = eval(document.calc.memory.value) ');
	d.writeln('					   + eval(document.calc.disp.value);');
	d.writeln('		break;');
	d.writeln('	}');
	d.writeln('	number = 0;');
	d.writeln('	stocknumber = 0;');
	d.writeln('	cleared = 0;');
	d.writeln('	document.calc.scape.value = key;');
	d.writeln('}');

	d.writeln('//[MR]押下時に実行するメモリー結果表示関数');
	d.writeln('function readMemory(){');
	d.writeln('	document.calc.disp.value = document.calc.memory.value;');
	d.writeln('	cleared = 0;');
	d.writeln('}');

	d.writeln('//[MC]押下時に実行するメモリー消去関数');
	d.writeln('function clearMemory(){');
	d.writeln('	document.calc.memory.value = "0";');
	d.writeln('}');

	d.writeln('//[√]押下時に実行する演算結果表示関数');
	d.writeln('function calcRoot(key){');
	d.writeln('	if (document.calc.disp.value != ""){');
	d.writeln('		number = document.calc.disp.value;');
	d.writeln('		document.calc.scape.value = key;');
	d.writeln('		document.calc.disp.value = Math.sqhrt(number);');
	d.writeln('		document.calc.disp.value = document.calc.disp.value.substr(0,13);');
	d.writeln('	}');
	d.writeln('	cleared = 0;');
	d.writeln('}');

	d.writeln('//[+/-]押下時に実行する演算結果表示関数');
	d.writeln('function signChange(key) {');
	d.writeln('	if (document.calc.disp.value != ""){');
	d.writeln('		document.calc.disp.value = -document.calc.disp.value;');
	d.writeln('	}');
	d.writeln('}');

	d.writeln('//[C]押下時に削除を実行する関数');
	d.writeln('function clearNumber(){');
	d.writeln('	document.calc.disp.value = "0";');
	d.writeln('}');

	d.writeln('//[AC]押下時に全削除を実行する関数');
	d.writeln('function allclear(){');
	d.writeln('	document.calc.disp.value = "0";');
	d.writeln('	document.calc.scape.value = "";');
	d.writeln('	number = 0;');
	d.writeln('	stocknumber = 0;');
	d.writeln('	document.calc.memory.value = "0";');
	d.writeln('}');

	d.writeln('// キー入力による操作の補助');
	d.writeln('function keyProc(ev) {');
	d.writeln('	var evCh = String.fromCharCode(ev);');

	d.writeln('	if (evCh >= "0" && evCh <= "9") {	// 数値キー');
	d.writeln('		keyin(evCh);');
	d.writeln('	} else if (evCh == "+" || evCh == "-" ');
	d.writeln('		|| evCh == "*" || evCh == "/") {// 四則演算');
	d.writeln('		calculate(evCh);');
	d.writeln('	} else if (evCh == "r" || evCh == "R") {// MR');
	d.writeln('		readMemory();');
	d.writeln('	} else if (evCh == "m" || evCh == "M") {// M-');
	d.writeln('		result("M-");');
	d.writeln('	} else if (evCh == "p" || evCh == "P") {// M+');
	d.writeln('		result("M+");');
	d.writeln('	} else if (evCh == "a" || evCh == "A") {// AC');
	d.writeln('		allclear();');
	d.writeln('	} else if (evCh == "c" || evCh == "C") {// C');
	d.writeln('		clearNumber();');
	d.writeln('	} else if (evCh == "q" || evCh == "Q") {// sqrt');
	d.writeln('		calcRoot(\'√\');');
	d.writeln('	} else if (evCh == "%" || evCh == "=") {// %');
	d.writeln('		result(evCh);');
	d.writeln('	} else if (evCh == ".") {		// .');
	d.writeln('		dot(evCh);');
	d.writeln('	} else if (evCh == "s" || evCh == "S") {// +/-');
	d.writeln('		signChange(\'+/-\');');
	d.writeln('	}');
	d.writeln('}');

	d.writeln('</script>');
	d.writeln('<style type="text/css">');
	d.writeln('<!--');
	d.writeln('INPUT {');
	d.writeln('	text-align:center;');
	d.writeln('	width:27;');
	d.writeln('	height:23;');
	d.writeln('	color:white;');
	d.writeln('	background-color:gray;');
	d.writeln('}');
	d.writeln('INPUT.function {');
	d.writeln('	background-color:#9999CC;');
	d.writeln('}');
	d.writeln('INPUT.num {');
	d.writeln('	background-color:#333333;');
	d.writeln('}');
	d.writeln('INPUT.clear {');
	d.writeln('	background-color:#ff3333;');
	d.writeln('}');

	d.writeln('INPUT.lcd {');
	d.writeln('	text-align:right;');
	d.writeln('	font-size:12pt;');
	d.writeln('	width:110;');
	d.writeln('	color:navy;');
	d.writeln('	background-color:#D3D3D3;');
	d.writeln('}');
	d.writeln('-->');
	d.writeln('</style>');

	d.writeln('</head>');
	d.writeln('<body bgcolor="#cc6600" text="white">');
	d.writeln('<form id="calc" name="calc">');
	d.writeln('<table border="2" bordercolor="#330033" width="180" height="250" align="center" style="background:#fcffff;">');
	d.writeln('<tbody>');
	d.writeln(' <tr>');
	d.writeln(' <td>');
	d.writeln(' <span style="float:left;margin:3px 0px 0px 18px;">');
	d.writeln('   <input class="lcd" type="text" id="disp" name="disp" size="20" value="0"');
	d.writeln('      onKeyPress="return false;">');
	d.writeln(' </span>');
	d.writeln(' <div style="text-align:right;margin:3px 4px 0px 0px;">');
	d.writeln('   <input type="text" style="background-color:#D3D3D3" id="scape" name="scape"');
	d.writeln('      value="" size="3" onKeyPress="return false;">');
	d.writeln(' </div>');

	d.writeln(' <div style="text-align:right;margin:1px 3px 3px 0px;">');
	d.writeln('   <input class="lcd" type="text" style="font-size:8pt; width:85; height:18"');
	d.writeln('     id="memory" name="memory" size="20" value="0" onKeyPress="return false;">');
	d.writeln(' </div>');
	d.writeln(' <hr>');

	d.writeln(' <table width="100%"><tbody>');
	d.writeln('  <tr>');
	d.writeln('  <td><input class="function" type="button" id="mclear" name="mclear" value="MC" onclick="clearMemory()"></td>');
	d.writeln('  <td><input class="function" type="button" id="mread" name="mread" value="MR" onclick="readMemory()"></td>');
	d.writeln('  <td><input class="function" type="button" id="mminus" name="mminus" value="M-" onclick="result(\'M-\')"></td>');
	d.writeln('  <td><input class="function" type="button" id="mplus" name="mplus" value="M+" onclick="result(\'M+\')"></td>');
	d.writeln('  <td><input class="function" type="button" id="sign" name="sign" value="+/-" onclick="signChange(\'+/-\')"></td>');

	d.writeln('  </tr>');
	d.writeln('  <tr>');
	d.writeln('  <td><input class="num" type="button" id="seven" name="seven" value="7" onclick="keyin(\'7\')"></td>');
	d.writeln('  <td><input class="num" type="button" id="eight" name="eight" value="8" onclick="keyin(\'8\')"></td>');
	d.writeln('  <td><input class="num" type="button" id="nine" name="nine" value="9" onclick="keyin(\'9\')"></td>');
	d.writeln('  <td><input type="button" id="divide" name="divide" style="font-size:13pt;" value="÷" onclick="calculate(\'/\')"></td>');
	d.writeln('  <td><input class="clear" type="button" id="clear" name="clear" value="C" onclick="clearNumber()"></td>');
	d.writeln('  </tr>');

	d.writeln('  <tr>');
	d.writeln('  <td><input class="num" type="button" id="four" name="four" value="4" onclick="keyin(\'4\')"></td>');
	d.writeln('  <td><input class="num" type="button" id="five" name="five" value="5" onclick="keyin(\'5\')"></td>');
	d.writeln('  <td><input class="num" type="button" id="six" name="six" value="6" onclick="keyin(\'6\')"></td>');
	d.writeln('  <td><input type="button" id="multiply" name="multiply" style="font-size:13pt;" value="×" onclick="calculate(\'*\')"></td>');
	d.writeln('  <td><input class="clear" type="button" id="all" name="all" value="AC" onclick="allclear()"></td>');


	d.writeln('  </tr>');
	d.writeln('  <tr>');
	d.writeln('  <td><input class="num" type="button" id="one" name="one" value="1" onclick="keyin(\'1\')"></td>');
	d.writeln('  <td><input class="num" type="button" id="two" name="two" value="2" onclick="keyin(\'2\')"></td>');
	d.writeln('  <td><input class="num" type="button" id="three" name="three" value="3" onclick="keyin(\'3\')"></td>');
	d.writeln('  <td><input type="button" id="subtraction" name="subtraction" value="－" onclick="calculate(\'-\')"></td>');
	d.writeln('  <td><input type="button" id="root" name="root" value="√" onclick="calcRoot(\'√\')"></td>');
	d.writeln('  </tr>');
	d.writeln('  <tr>');
	d.writeln('  <td><input class="num" type="button" id="zero" name="zero" value="0" onclick="keyin(\'0\')"></td>');
	d.writeln('  <td><input class="num" type="button" id="point" name="point" value="." onclick="dot(\'.\')"></td>');

	d.writeln('  <td><input type="button" id="percent" name="percent" value="%" onclick="result(\'%\')"></td>');
	d.writeln('  <td><input type="button" id="plus" name="plus" value="＋" onclick="calculate(\'+\')"></td>');
	d.writeln('  <td><input type="button" id="equal" name="equal" value="＝" onclick="result(\'=\')"></td>');
	d.writeln('  </tr>');

	d.writeln('  <tr>');
	d.writeln('  <td colspan="2"></td>');
	d.writeln('  <td><input type="button" id="decide" name="decide" value="OK" onclick="setDataToOpener();"></td>');
	d.writeln('  <td colspan="2"><input type="button" id="cancel" name="cancel" value="Cancel" style="width:50;" onclick="window.close();"></td>');
	d.writeln('  </tr>');

	d.writeln(' </tbody>');
	d.writeln('</table>');
	d.writeln('</td>');
	d.writeln('</tr>');
	d.writeln('</tbody>');
	d.writeln('</table>');
	d.writeln('</form>');
	d.writeln('</body>');
	d.writeln('</html>');

	d.close();
}
