/**
 *  Utility関数ライブラリ
 */

/**
 * 指定された文字列がnullかブランクの場合、trueを返す。
 * @param str 検証対象の文字列
 * @param boolean 
 */
function isEmpty(str){
	if (str == null || str == "") {
		return true;
	}
	return false;
}

/**
 * 指定された文字列の前後にあるスペースを取り除く
 * @param str 操作対象の文字列
 * @return 処理された文字列
 */
function trim(str){
	if (isEmpty(str))
		return "";

	return leftTrim(rightTrim(str));
}
/**
 * 小数点以下が0の場合削除
 */
function ntrim(str){
	if (isEmpty(str))
		return '0';

	var n = leftTrim(rightTrim(str));
	if(isNaN(n)) {
		return '0';
	}
	if((typeof n) != 'string') {
		n = String(n);
	}
	if(n.indexOf('.')!=-1){
		for(var i = n.length - 1; i > n.indexOf('.'); --i) {
			if (n.charAt(i) != '0') break;
			n = n.substring(0, n.length - 1);
		}
		if (n.charAt(n.length - 1) == '.') {
			n = n.substring(0, n.length - 1);
		}
	}
	return n;
}

/**
 * 指定された文字列の前にあるスペースを取り除く
 * @param str 操作対象の文字列
 * @return 処理された文字列
 */
function leftTrim(str){
	if (isEmpty(str))
		return "";
	var pos = 0;
	var chr;
	for (var i=0;i<str.length;i++){
		chr = str.charAt(i);
		if (chr == " ")
			pos++;
		else
			break;
	}
	if (pos > 0){
		return str.substring(pos, str.length);
	}else{
		return str;
	}
}

/**
 * 指定された文字列の後にあるスペースを取り除く
 * @param str 操作対象の文字列
 * @return 処理された文字列
 */
function rightTrim(str){
	if (isEmpty(str))
		return "";

	var pos = 0;
	var chr;
	for (var i=str.length-1;i>=0;i++){
		chr = str.charAt(i);
		if (chr == " ")
			pos++;
		else
			break;
	}
	if (pos > 0){
		if((str.length-pos-1)==0){
			return str.substring(0, 1);
		}else{
			return str.substring(0, str.length-pos-1);
		}
	}else{
		return str;
	}

}

/*
 * 指定の文字列が空文字もしくはスペースのみであるかを判定する
 * @param str 検証対象の文字列
 * @return boolean
 */
function isBlank(str){
	if (isEmpty(str))
		return true;

	var tmpstr;
	tmpstr = trim(str);
	return (tmpstr == "");
}

/**
 * 文字列（引数1）の中の指定した文字（引数2）の数を返す
 * @param str 検索対象の文字列
 * @param chr カウントする文字
 * @return 検索対象文字列中に存在した文字の数
 */
function countChar(str,chr) {
	var cnt = 0;
	
	if (isEmpty(str))
		return 0;

	for (var i=0; i<str.length; i++) {
		if (str.charAt(i) == chr)
			cnt++;
	}
	return cnt;
}

/**
 * 文字列が指定した長さになるまで指定された文字を文字列の左側に埋める。
 * テキスト内での右寄せに使用する。
 * @param str 操作対象文字列
 * @param maxlength 文字埋め処理後の文字列の長さ
 * @param filstr 埋める文字
 * @return 処理後の文字列
 */
function leftPadding(str, length, filstr) {

	var strtemp = "";
	
	strtemp = str;
	
	if (isEmpty(filstr))
		filstr = " ";

	if (str.length == length) {
		return str;
	}

	for (var i = 1; i <= (length - str.length); i++) {
		strtemp = filstr + strtemp;
	}

	return strtemp;
}

/**
 * 引数で指定した文字より前の文字列を返す。
 * 1つめの引数の文字列から、2つめの引数より前にある部分の文字列を取得する。
 * @param str  操作対象文字列
 * @param searchStr 探す文字列
 * @return 指定された文字列の前の部分
 */
function getFrontString(str, searchStr) {
	var targetIndex = 0;
	
	targetIndex = str.indexOf(searchStr);
	if (targetIndex == -1) 
		return str;

	return str.substring(0,targetIndex);
}

/**
 * 引数で指定した文字より後ろの文字列を返す。
 * 1つめの引数の文字列から、2つめの引数より後ろにある部分の文字列を取得する。
 * @param str  操作対象文字列
 * @param searchStr 探す文字列
 * @return 指定された文字列の後の部分
 */
function getBackString(str, searchStr) {
	var targetIndex = 0;
	targetIndex = str.indexOf(searchStr);
	if (targetIndex == -1)
		return null;
	return str.substring(targetIndex + searchStr.length,str.length);
}

/**
 * 指定の文字列の長さが指定の長さを超えていないか判定する。
 * @param str  検証対象文字列
 * @param maxlength 最大桁数
 * @return boolean
 */
function isInMaxLength(str, maxlength) {
	if (str == null)
		return false;
	return (str.length <= maxlength);
}

/**
 * 正しい日付(年月日)の形式であるかを判定する.
 * @param str 検証対象日付文字列
 * @return boolean
 */
function isDate(str){
	if (isEmpty(str))
		return false;

	//数字以外の区切り文字が無いか探す
	//あったらそれに対応するパターンでチェックする。
	var data,yyyy,mm,dd;
	var yyyynum,mmnum,ddnum;
	//月の最大値を配列に格納する
	var m = new Array(0,31,28,31,30,31,30,31,31,30,31,30,31);

	if (isPositiveInteger(str)){
		//alert("b");
		//指定された文字列が正の整数である場合、yyyymmdd形式であると
		//想定する。
		if (str.length != 8)
			return false;
		
		yyyy = str.substr(0,4);
		mm = str.substr(4,2);
		if (mm.charAt(0) == "0")
			mm=mm.charAt(1);

		dd = str.substr(6,2);
		if (dd.charAt(0) == "0")
			dd=dd.charAt(1);
	}else{
		//alert("c");
		var q = str;
		//区切り文字を特定する
		var delimiter;
		//alert(q);
		if (q.indexOf("/") != -1){
			delimiter = "/";
			// 2000/08/01 などの0をとる
			q = q.replace(/\/0+/g,delimiter);
		}else if(q.indexOf("-") != -1){
			delimiter = "-";
			q = q.replace(/\-0+/g,delimiter);
		}else if (q.indexOf(".") != -1){
			delimiter = ".";
			q = q.replace(/\.0+/g,delimiter);
		}else{
			//想定外の区切り文字はfalseとする
			return false;
		}
		//alert(q);
		
		// /区切りで配列に格納
		var r = q.split(delimiter);
		yyyy = r[0];
		mm = r[1];
		dd = r[2];
	}
	yyyynum = parseInt(yyyy);
	mmnum = parseInt(mm);
	ddnum = parseInt(dd);
	//alert(yyyynum);
	//alert(mmnum);
	//alert(ddnum);
	//閏年を考慮して月末の日付を設定しなおす
	if (yyyynum%4==0){
		m[2]=29;
		if (yyyynum%100==0){
			m[2]=28;
			if (yyyynum%400==0){
				m[2]=29;
			}
		}
	}

	// 年が、4桁の数字で有効範囲内かチェック
	if (yyyynum < 1970 || yyyynum > 9999 || yyyy.match(/^\d{4}$/)==null){
		return false;
	}else if (mmnum < 1 || mmnum > 12 || mm.match(/^\d{1,2}$/)==null){
		// 月が、1-2桁の数字で、有効範囲かチェック
		return false;
	}else if (ddnum < 1 || ddnum > m[mm] || dd.match(/^\d{1,2}$/)==null){
		// 日が、1-2桁の数字で、有効範囲かチェック
		return false;
	}
	return true;
}

/**
 * 正しい日付(年月)の形式であるかを判定する.
 * @param str 検証対象日付文字列
 * @return boolean
 */
function isYYYYMM(str){
	if (isEmpty(str))
		return false;

	//数字以外の区切り文字が無いか探す
	//あったらそれに対応するパターンでチェックする。
	var data,yyyy,mm;
	var yyyynum,mmnum;
	//月の最大値を配列に格納する
	var m = new Array(0,31,28,31,30,31,30,31,31,30,31,30,31);

	if (isPositiveInteger(str)){
		//指定された文字列が正の整数である場合、yyyymm形式であると
		//想定する。
		if (str.length != 6)
			return false;
		
		yyyy = str.substr(0,4);
		mm = str.substr(4,2);
		if (mm.charAt(0) == "0")
			mm=mm.charAt(1);
		
		//alert(yyyy);
		//alert(mm);

	}else{
		var q = str;
		//区切り文字を特定する
		var delimiter;
		if (q.indexOf("/") != -1){
			delimiter = "/";
			// 2000/08 などの0をとりつつ、00を消す
			q = q.replace(/\/0+/g,delimiter);
		}else if(q.indexOf("-") != -1){
			delimiter = "-";
			q = q.replace(/\-0+/g,delimiter);
		}else if (q.indexOf(".") != -1){
			delimiter = ".";
			q = q.replace(/\.0+/g,delimiter);
		}else{
			//想定外の区切り文字はfalseとする
			return false;
		}

		// /区切りで配列に格納
		var r = q.split(delimiter);
		yyyy = r[0];
		mm = r[1];
	}
	yyyynum = parseInt(yyyy);
	mmnum = parseInt(mm);

	//閏年を考慮して月末の日付を設定しなおす
	if (yyyynum%4==0){
		m[2]=29;
		if (yyyynum%100==0){
			m[2]=28;
			if (yyyynum%400==0){
				m[2]=29;
			}
		}
	}

	// 年が、4桁の数字で有効範囲内かチェック
	if (yyyynum < 1970 || yyyynum > 9999 || yyyy.match(/^\d{4}$/)==null){
		return false;
	}else if (mmnum < 1 || mmnum > 12 || mm.match(/^\d{1,2}$/)==null){
	// 月が、1-2桁の数字で、有効範囲かチェック
		return false;
	}
	return true;
}





/**
 * 指定された数値が正の整数であるか判定する.
 * @param str 検証対象数値
 * @return boolean
 */
function isPositiveInteger(num){
	var str = num + "";
	if (isEmpty(str))
		return false;

	for (var i=0;i<str.length;i++){
		var chr = str.charAt(i);
		if (chr <"0" || chr>"9")
			return false;
	}
	return true;
}

/**
 * 指定された数値が整数であるか判定する.
 * @param str 検証対象数値
 * @return boolean
 */
function isInteger(num){
	var str = num + "";
	if (isEmpty(str))
		return false;
	
	for (var i=0;i<str.length;i++){
		var chr = str.charAt(i);
		if (i==0 && chr=="-")
			continue;
		
		if (chr <"0" || chr>"9")
			return false;
	}

	return true;
}

/**
 * 数値としてみなせるか判定する
 * @param str 検証対象数値
 * @return boolean
 */
function isNumeric(num){
	var str = num + "";
	var oneDecimal = false;

	if (isEmpty(str))
		return false;
	if (str=="." || str=="-")
		return false;

	for (var i=0;i<str.length;i++){
		var chr= str.charAt(i);
		if(i==0 && chr == "-")
			continue;

		if(chr == "." && !oneDecimal){
			oneDecimal = true;
			continue;
		}
		if (chr < "0" || chr > "9")
			return false;
	}
	return true;
}
/**
 *  MBB独自仕様
 *  - , . 半角スペース 0-9以外があったらfalseを返す
 */
function isNumber(num){

	var str = num + "";
	var oneDecimal = false;

	if (isEmpty(str))
		return false;

	for (var i=0;i<str.length;i++){
		var chr= str.charAt(i);
		
		if ((chr < "0" || chr > "9") && chr!="-" && chr!="," && chr!="." && chr!=" ")
			return false;
	}
	return true;
}

/**
 * 指定された数値について、正しい数値であることの判定、指定された
 * 整数最大桁数、小数最大桁数、マイナスの許可に関する判定を行う。
 * @param num                検証対象数値
 * @param intmaxlength       整数最大多数
 * @param decimalmaxlength   小数最大桁数
 * @param allowminus         マイナスを許可する場合trueを設定する
 * @return 
 */
function verifyNumber(num, intmaxlength, decimalmaxlength, allowminus){

	var integerpart = "", decimalpart = "";
	var decimalpoint = ".";
	var minussign = "-";
	var isminus = false;

	var str = num + "";
	if (isEmpty(str))
		return false;

	if (!isNumeric(str))
		return false;

	//マイナス符号が最初についているか判定する。
	isminus = (str.charAt(0) == minussign);
	//alert(isminus);

	//マイナス値を許さない
	if (isminus){
		//マイナス値の検証
		if (!allowminus)
			return false;
	}

	//小数点の位置を得る
	var decimalpointpos = str.indexOf(decimalpoint);
	
	//整数部と小数部に分ける
	if (decimalpointpos == -1){
		integerpart = str;
		decimalpart = "";
	}else{
		integerpart = getFrontString(str, decimalpoint);
		decimalpart = getBackString(str, decimalpoint);
		if (decimalpart == null || decimalpart == ""){
			decimalpointpos = -1;
			decimalpart = "";
		}
	}

	if (isminus){
		//マイナス符号がついている場合、
		//整数部からマイナス符号を取り除く
		integerpart = getBackString(integerpart, minussign);
	}

	//整数部が無いが小数点があり、小数部に値がある場合、
	//整数部をゼロとする。
	if (integerpart == null || integerpart == ""){
		if(decimalpointpos != -1 && decimalpart != ""){
			integerpart = "0";
		}
	}

	//alert(integerpart);	
	if (integerpart.length > intmaxlength)
		return false;

	if (decimalpart.length > decimalmaxlength)
		return false;

	return true;
}

/**
 * このファイルをインクルードしているwindowのドキュメントオブジェクトに属する
 * 指定されたIDのエレメントオブジェクトそのものを返す。
 * これはクロスブラウザ用である。Netscapeでdocument.allは使用不可能であるため、
 * この関数を使用する。
 * @param    id         参照を得たいエレメントのID
 * @return   エレメントオブジェクト
 */
function getField(id){
	if (document.getElementById) {
		return document.getElementById(id);
	} else if (document.all) {
		return document.all.item(id);
	}
	return null;
}

/**
 * このファイルをインクルードしているwindowのドキュメントオブジェクトに属する
 * 指定されたIDのエレメントオブジェクトのvalueを返す。
 * これはクロスブラウザ用である。Netscapeでdocument.allは使用不可能であるため、
 * この関数を使用する。
 * @param    id         参照を得たいエレメントのID
 * @return   エレメントオブジェクト
 */
function getFieldValue(id){
	var item = getField(id);
	if (item == null) {
		alert(id + ' not found.');
		return '';
	}
	if (item.tagName=='SELECT'&&item.selectedIndex!=-1) {
		return item.options[item.selectedIndex].value;
	}
	if (item.value) {
		return item.value;
	} else {
		if (item.innerText) {
			return item.innerText;
		} else if (item.textContent) {
			return item.textContent;
		}
	}
	return '';
}

/**
 * このファイルをインクルードしているwindowのドキュメントオブジェクトに属する
 * 指定されたIDのエレメントオブジェクトのvalueを返す。
 * これはクロスブラウザ用である。Netscapeでdocument.allは使用不可能であるため、
 * この関数を使用する。
 * @param    id         参照を得たいエレメントのID
 */
function setFieldValue(id, value){
	if (document.getElementById) {
		if (document.getElementById(id)) {
			var item = document.getElementById(id);
			if (item.tagName=='INPUT'||item.tagName=='SELECT'||item.value) {
				if (item.type=='hidden' && document.getElementById(id+'_radio')) {
					// ラジオボタンの場合
					var opt = document.getElementById(id+'_'+value);
					if (opt) opt.click();
				} else if (item.type=='hidden' && document.getElementById(id+'_check')) {
					// チェックボックスの場合
					var chk = document.getElementById(id+'_check');
					if (value == true) {
						if (!chk.checked) chk.click();
					} else if (value == false) {
						if (chk.checked) chk.click();
					}
				} else {
					item.value = value;
				}
			} else {
				if (item.innerText) {
					item.innerText = value;
				} else if (item.textContent) {
					item.textContent = value;
				}
			}
			if (document.getElementById(id).onchange) document.getElementById(id).onchange();
		}
	} else if (document.all) {
		if (document.all.item(id)) {
			var item = document.all.item(id);
			if (item.tagName=='INPUT'||item.value) {
				item.value = value;
			} else if (item.textContent) {
				item.textContent = value;
			}
			if (document.all.item(id).onchange) document.all.item(id).onchange();
		}
	}
}

/**
 * URLエンコード
 */
function encodeUrl(str){
	// エンコードされた文字列
	var urlStr = '';

	// 対象の文字
	var chr;

	// 対象の文字のunicode
	var uni;

	// 1文字づつ変換
	for(var i = 0; i < str.length; i++){
		chr = str.charAt(i);
		uni = str.charCodeAt(i);
		if(chr == ' '){
			//スペース
			urlStr += '+';
		} else if(uni == 0x2a || 
				uni == 0x2d || 
				uni == 0x2e || 
				uni == 0x5f || 
				((uni >= 0x30) && (uni <= 0x39)) || 
				((uni >= 0x41) && (uni <= 0x5a)) || 
				((uni >= 0x61) && (uni <= 0x7a))) {
			// 変換なし
			urlStr = urlStr + chr;
		} else if((uni >= 0x0) && (uni <= 0x7f)){
			// 1バイト
			var tmp = '0' + uni.toString(16);
			urlStr += '%'+ tmp.substr(tmp.length - 2);
		} else if(uni > 0x1fffff){
			// 4バイト (extended)
			urlStr += '%' + (oxf0 + ((uni & 0x1c0000) >> 18)).toString(16);
			urlStr += '%' + (0x80 + ((uni & 0x3f000) >> 12)).toString(16);
			urlStr += '%' + (0x80 + ((uni & 0xfc0) >> 6)).toString(16);
			urlStr += '%' + (0x80 + (uni & 0x3f)).toString(16);
		} else if(uni > 0x7ff){
			// 3バイト
			urlStr += '%' + (0xe0 + ((uni & 0xf000) >> 12)).toString(16);
			urlStr += '%' + (0x80 + ((uni & 0xfc0) >> 6)).toString(16);
			urlStr += '%' + (0x80 + (uni & 0x3f)).toString(16);
		} else {
			// 2バイト
			urlStr += '%' + (0xc0 + ((uni & 0x7c0) >> 6)).toString(16);
			urlStr += '%' + (0x80 + (uni & 0x3f)).toString(16);
		}
	}
	return urlStr;
}

function addHiddenField(obj, id, name, value) {
	if (document.getElementById) {
		var input = document.createElement('input');
		if (document.all) {
			//alert("5");
			input.id = id;
			input.type = 'hidden';
			input.name = name;
			input.value = value;
		} else {
			//alert("6");
			input.setAttribute('id',id);
			input.setAttribute('type', 'hidden');
			input.setAttribute('name', name);
			input.setAttribute('value', value);
		}
		//alert("7");
		obj.appendChild(input);
		return input;
	}
	return null;
}

function sum(id) {
	var s = Number(0);
	for(var i=1; ; ++i) {
		var item = getField(id + '_' + i);
		if (item == null) break;
		try {
			s += Number(item.value);
		}catch(e){}
	}
	return s;
}

function disable(id) {
	var item = getField(id);
	if (item) {
		item.disabled = true;
		addHiddenField(item.parentNode, item.id+'_disabled', item.name, item.value);
	}
}

function enable(id) {
	var item = getField(id);
	if (item) {
		item.disabled = false;
		var h = getField(item.id+'_disabled');
		if (h) {
			item.parentNode.removeChild(h);
		}
	}
}

function check(id, b) {
	var item = getField(id);
	if(item == null || item.type != 'checkbox') item = getField(id+'_check');
	if(item){
		item.checked=b;
		item.onclick();
	}
}

var Placeholder = (function() {
  function Placeholder(item, text) {
    if(typeof(item)=='string'){
      item=document.getElementById(item);
    }
    if(item){
      var guide = document.createElement('span');
      guide.className='placeholder';
      guide.style.color='#aaaaaa';
      guide.style.padding='3px';
      guide.style.position='absolute';
      guide.style.display='block';
      //guide.style.left=item.getBoundingClientRect().left;
      //guide.style.top=item.getBoundingClientRect().top;
      guide.style.left='1px';
      guide.style.top='2px';
      guide.style.width=item.style.width;
      guide.style.height=item.style.height;
      guide.innerText=text;
      //item.parentNode.appendChild(guide);
      item.parentNode.insertBefore(guide, item);
	  item.parentNode.style.position = 'relative';
      guide.onclick=function(){this.style.display='none';item.focus();};
      var item_onfocus=item.onfocus;
      var item_onchange=item.onchange;
      var item_onblur=item.onblur;
      var item_onkeydown=item.onkeydown;
      if(item.value!=''){guide.style.display='none';}else{guide.style.display='';}
      item.onfocus=function(){guide.style.display='none';if(item_onfocus)item_onfocus();};
      item.onchange=function(){if(item.value!=''){guide.style.display='none';}else{guide.style.display='';};if(item_onchange)item_onchange();};
      item.onblur=function(){if(item.value!=''){guide.style.display='none';}else{guide.style.display='';};if(item_onblur)item_onblur();};
      item.onkeydown=function(){guide.style.display='none';if(item_onkeydown)item_onkeydown();};
    }
  };
  return Placeholder;
})();

function setPlaceholder(item, text) {
  new Placeholder(item, text);
}

//2014/07/07 追加
// Initial Popup
var Popup = (function() {
	function Popup(itemId, text, width, height) {
		var item;
		var marginLeft = 10;
		var marginTop = -7.5;
		
		if (typeof (itemId) == 'string') {
			item = getField(itemId);
		}
		
		var str = itemId + '_div';
		var divItem = getField(str);
		if (!divItem) {
			// create tag div guide
			var guide = document.createElement('div');
			guide.id = itemId + '_div';
			guide.style.position='absolute';
			//guide.className = 'leftarrowdiv';
			guide.style.background = '#BB0000';
			guide.style.color = 'white';
			guide.style.padding = '5px';
			
			// get top left width height 	
			var leftItem = parseInt(item.getBoundingClientRect().left);
			var topItem = parseInt(item.getBoundingClientRect().top);
			var widthItem = parseInt(item.offsetWidth);
			var heightItem = parseInt(item.offsetHeight);
			
			if(width != null && width != '') {
				if(parseInt(width) > 0) {
					width = parseInt(width);
				} else {
					width = widthItem;
				}
			} else {
				width = widthItem;
			}
			
			if (height != null && height != '') {
				if (parseInt(height) > 0) {
					height = parseInt(height);
				} else {
					height = heightItem;
				}
			} else {
				height = heightItem;
			}

			guide.style.left = widthItem + 20 + 'px';
			guide.style.width = width;
			guide.style.height = height;
			guide.style.display = 'none';
			guide.innerHTML = text;

			item.parentNode.insertBefore(guide, item);
			item.parentNode.style.position = 'relative';
		}
	};
	
	return Popup;
})();

// Call function to initial Popup
function setPopup(itemId, text, width, height) {
	new Popup(itemId, text, width, height);
}

// Hidden popup
function hiddenPopup(itemId) {
	var str = itemId + '_div';
	var obj = getField(str);
	if (obj) {
		obj.style.display = 'none';
		obj.style.filter = 'alpha(opacity=0)';
	}
}

// Show popup
function showPopup(itemId, al) {
	var str = itemId + '_div';
	fadeInLeft(str);
}


function fadeInLeft(id, alpha, left) {
	var obj = getField(id);
	
	var alpha = alpha == null ? 0 : alpha;
	var left = left == null ? parseInt(obj.style.left.replace('px','')) + 40 : left;
	
	alpha += 5;
	left -= 2;
	
	obj.style.display = 'block';
	obj.style.filter = 'alpha(opacity=' + alpha + ')';
	obj.style.left = left + 'px';
	
	if (alpha < 100) {
		setTimeout('fadeInLeft("'+id+'",'+alpha+','+left+')', 30);
	}
}


function addEvent(obj, type, func) {
	if (obj.attachEvent) {
		obj.attachEvent('on' + type, func);
	} else if (obj.addEventListener) {
		obj.addEventListener(type, func, false);
	}
}


function wordCount(inputItemId, messageitemId, maxLength) {
    var impression = getFieldValue(inputItemId);
    var str = '';
    var impressionLength = impression.length;
        if (impressionLength > maxLength) {
        str = '<span style="color:red;">' + impressionLength + '文字</span>/' + maxLength + '文字' + ' 文字数がオーバーしています。'    } else {
        str = '<span style="color:black;">' + impressionLength + '文字</span>/' + maxLength + '文字';
    }
    getField(messageitemId).innerHTML = str;
}


function setWordCount(inputItemId, messageitemId, maxLength){
	var obj = getField(inputItemId);
	addEvent(obj, 'keypress', function(){wordCount(inputItemId, messageitemId, maxLength)});
	addEvent(obj, 'keyup',  function(){wordCount(inputItemId, messageitemId, maxLength)});
	addEvent(obj, 'change',  function(){wordCount(inputItemId, messageitemId, maxLength)});
	addEvent(obj, 'blur',  function(){wordCount(inputItemId, messageitemId, maxLength)});
}

function showLoading(item){
	// get top left width height 	
	var leftItem = parseInt(item.getBoundingClientRect().left);
	var topItem = parseInt(item.getBoundingClientRect().top);
	var widthItem = parseInt(item.offsetWidth);
	var heightItem = parseInt(item.offsetHeight);
	
	var div = document.createElement("div");
	div.id = "loading";
	div.style.position = "absolute";
	div.style.top = (topItem - 10) + "px";
	div.style.left = leftItem + "px";
	//div.style.top = "50%";
	//div.style.left = "50%";
	div.style.zIndex = 1000;
	var img = document.createElement("img");
	img.setAttribute("src", "images/loading.gif");
	div.appendChild(img);
	//item.parentNode.appendChild(div);
	item.parentNode.insertBefore(div, item);
	//document.body.appendChild(div);
}