package sample1;

import java.sql.*;
import java.util.Hashtable;

import jp.co.bbs.unit.tools.html.*;


public class QueryTable extends PageElement {
	
	// �p�����[�^
	/** �e�[�u��ID */
	private String tableId = null;
	
	public void setTableId(String tableId) {
		this.tableId = tableId;
	}

	/** �񕝃��X�g */
	private String widths = null;
	
	public void setWidths(String widths) {
		this.widths = widths;
	}
	
	private String order = null;
	
	public void setOrder(String order) {
		this.order = order;
	}
	
	private String checkField = null;

	public void setCheckField(String checkField) {
		this.checkField = checkField;
	}
	
	private String DEFAULT_WIDTH = "40"; // �f�t�H���g�̗�̕�
	
	public QueryTable() {
	}
	
	@Override
	public String toString() {
		
		StringBuffer sb = new StringBuffer();
		
		if (getRequestParameterBool("body")) {
			tableId = getRequestParameter("tableId");
			String sql = "SELECT * FROM " + tableId;
			PreparedStatement stmt = null;
			ResultSet rs = null;
			try {
				int skipCount = getRequestParameterInt("skipCount", 0);
				int viewRows = getRequestParameterInt("viewRows", 0);
				stmt = getConnection().prepareStatement(sql);
				rs = stmt.executeQuery();
				for (int i = 0; i < skipCount; ++i) {
					// ���R�[�h�ǂݔ�΂�
					if (!rs.next()) {
						break;
					}
				}
				sb.append("<table id=\"").append(tableId).append("\">\n");
				createBodyXML(sb, rs, viewRows, skipCount);
				sb.append("</table>\n");
			} catch (SQLException e) {
			} finally {
				if (rs != null) {
					try {
						rs.close();
					} catch (SQLException e) {}
				}
				if (stmt != null) {
					try {
						stmt.close();
					} catch (SQLException e) {}
				}
			}
			return sb.toString();
		}

		sb.append("<script type=\"text/javascript\" src=\"js/sample1/ResizeTable.js\"></script>\n");
		
		int height = getHeight();
		int width = getWidth();
		int lineHeight = 24;
		height = ((int)(height / lineHeight)) * lineHeight; // 24�̔{���ɕ␳
		int virtualHeight = height;
		int recordCount = 0;
		int viewRows = height / lineHeight - 1;
		int sbHeight = 14; // �e�[�u�����̉��X�N���[���o�[���̍���
		
		String id = "resizelist";
		// ���E�ɕ����č������e�[�u���{�́A�E�����X�N���[���o�[
		sb.append("<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" style=\"margin:0;padding:0;");
		if (height > 0) {
			sb.append("height:").append(height + sbHeight).append("px;");
		}
		sb.append("\">\n");
		sb.append("<tr>\n");
		sb.append("<td valign=\"top\" style=\"margin:0;padding:0;\">\n");
		// �e�[�u���{��
		sb.append("<div style=\"");
		if (width > 0) {
			sb.append("width:").append(width).append("px;");
		}
		if (height > 0) {
			sb.append("height:").append(height + sbHeight).append("px;");
		}
		sb.append("overflow-x:auto;overflow-y:hidden;\">\n");
		
		sb.append("<table class=\"resizable vw-table\" id=\"");
		sb.append(id);
		sb.append("\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" style=\"width:100%;\">\n");


		String sqlCount = "SELECT count(*) FROM " + tableId;
		String sql = "SELECT * FROM " + tableId;
		if (order != null && order.trim().length() > 0) {
			sql = sql + " ORDER BY " + order;
		}
		PreparedStatement stmt = null;
		ResultSet rs = null;
		
		try {
			int skipCount = getRequestParameterInt("skipCount", 0);
			stmt = getConnection().prepareStatement(sqlCount);
			rs = stmt.executeQuery();
			if (rs.next()) {
				recordCount = rs.getInt(1);
			}
			rs.close();
			stmt.close();
			
			virtualHeight = recordCount * lineHeight;
			
			stmt = getConnection().prepareStatement(sql);
			rs = stmt.executeQuery();
			ResultSetMetaData meta = rs.getMetaData();
			// header
			sb.append("<tr>\n");
			int cols = meta.getColumnCount();
			String[] fieldIds = new String[cols];
			String[] w = {};
			if (widths != null) {
				w = widths.split(",");
			}
			// ��̕\��
			for (int i = 0; i <= cols; ++i) {
				String fieldId = null;
				if (i == 0) {
					fieldId = "No.";
				} else {
					fieldId = meta.getColumnName(i);
					fieldIds[i - 1] = fieldId;
				}
				sb.append("<td class=\"resizable vw-table-th linehead\" style=\"");
				// �^�C�g����̕�
				sb.append("width:");
				if (i >= 0 && i < w.length && w[i] != null && w[i].trim().length() > 0) {
					sb.append(w[i]);
				} else {
					sb.append(DEFAULT_WIDTH);
				}
				sb.append("px;");
				sb.append("\">\n");
				// �^�C�g������L���v�V�����ƃ��T�C�Y�o�[�ɂQ����
				sb.append("<table class=\"cell-table\"><tr>");
				String cellStyle = "cell";
				if (i == 0) {
					cellStyle = cellStyle + " cell-num";
				}
				sb.append("<td class=\"").append(cellStyle).append("\"><span class=\"vw-cell\">").append(fieldId).append("</span></td>");
				sb.append("<td class=\"resizer\" onmousedown=\"th_dragstart(event);\"></td></tr>");
				sb.append("</table>\n");
				sb.append("</td>\n");
			}
			// �Ō�̗�ɃX�y�[�T��ǉ�
			sb.append("<td class=\"spacer\">\n");
			sb.append("</td>\n");
			sb.append("</tr>\n");
			
			for (int i = 0; i < skipCount; ++i) {
				if (!rs.next()) {
					break;
				}
			}
//			// body
			createBodyHTML(sb, rs, viewRows, skipCount);
			
		} catch (SQLException e) {
			
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {}
			}
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {}
			}
		}
			
		sb.append("</table>\n");
		sb.append("</div>\n");
		sb.append("</td>\n");
		//
		// �c�X�N���[���o�[����
		sb.append("<td valign=\"top\" style=\"margin:0;padding:0;\">\n");
		sb.append("<div style=\"width:20px;");
		int borderAdj = 3;
		sb.append("height:").append(height - borderAdj).append("px;");
		sb.append("overflow-y:scroll;align:right;\" onscroll=\"doscroll(this,'");
		sb.append(id);
		sb.append("')\">\n");
		// �X�N���[���o�[�R���g���[���p�_�~�[�̈�(���R�[�h�����̍����̋󔒗̈�)
		sb.append("<div id=\"scrolldiv\" style=\"");
		sb.append("height:").append(virtualHeight + (lineHeight - 1 - borderAdj)).append("px;");
		sb.append("margin:0;padding:0;width:0px;background-color:#00ffff;overflow:hidden;\">&nbsp;</div>\n");
		sb.append("</div>\n");
		
		sb.append("</td>\n");
		sb.append("</tr>\n");
		// �s���\���G���A
		sb.append("<tr>\n");
		sb.append("<td colspan=\"2\">");
		sb.append("<input type=\"hidden\" id=\"tableId\" value=\"" + tableId + "\">\n");
		// ���׍s��
		sb.append("<input type=\"hidden\" id=\"viewRows\" value=\"" + viewRows + "\">\n");
		sb.append("<span class=\"vw-string\" id=\"lineInfo\">1/" + recordCount + "</span>\n");
		sb.append("</td>\n");
		sb.append("</tr>\n");
		sb.append("</table>\n");

		return sb.toString();
		
	}
	

	private void createBodyHTML(StringBuffer sb, ResultSet rs, int lines, int skipCount)
		throws SQLException {
		ResultSetMetaData meta = rs.getMetaData();
		int cols = meta.getColumnCount();
		String[] fieldIds = new String[cols];
		for (int row = 0; row < lines; ++row) {
			int rowId = skipCount + row + 1;
			if (rs.next()) {
				sb.append("<tr>\n");
				String rowStyle = "line-even";
				if (rowId % 2 == 1) {
					rowStyle = "line-odd";
				}
				for (int i = 0; i <= cols; ++i) {
					String fieldId = null;
					if (i > 0) {
						fieldId = meta.getColumnName(i);
					}
					sb.append("<td class=\"resizable\"");
					//sb.append(" style=\"").append("\"");
					sb.append(">\n");
					String cellStyle = "cell";
					if (i == 0) {
						cellStyle = cellStyle + " cell-num";
					}
					sb.append("<table class=\"cell-table\"><tr><td class=\"").append(cellStyle).append(" vw-table-td linebody ").append(rowStyle).append("\">");
					sb.append("<span class=\"vw-cell\">");
					if (i == 0) {
						sb.append(rowId);
					} else {
						String value = "";
						if (this.checkField != null && this.checkField.equals(fieldId)) {
							if (getSessionData() != null) {
								Object values = getSessionData().get("sample1.QueryTable_VALUES");
								if (values instanceof Hashtable) {
									String v = (String)((Hashtable)values).get(Integer.toString(rowId));
									if ("1".equals(v)) {
										value = " checked";
									}
								}
							}
							sb.append("<input id=\"" + rowId + "\" type=\"checkbox\" onclick=\"doCheckStore('sample1.QueryTable',this.id,this.checked);\"" + value + ">");
						}
						sb.append(rs.getString(i));
					}
					sb.append("</span></td></tr></table>\n");
					sb.append("</td>\n");
				}
				// �Ō�̗�ɃX�y�[�T��ǉ�
				sb.append("<td class=\"spacer\">\n");
				sb.append("</td>\n");
				sb.append("</tr>\n");
				
			} else {
				break;
			}
		}
	}
	private void createBodyXML(StringBuffer sb, ResultSet rs, int lines, int skipCount)
	throws SQLException {
		ResultSetMetaData meta = rs.getMetaData();
		int cols = meta.getColumnCount();
		for (int row = 0; row < lines; ++row) {
			int rowId = skipCount + row + 1;
			if (rs.next()) {
				sb.append("<tr>");
				sb.append("<td>");
				sb.append(rowId);
				sb.append("</td>");
				for (int i = 0; i < cols; ++i) {
					String fieldId = null;
					if (i > 0) {
						fieldId = meta.getColumnName(i);
					}
					sb.append("<td>");
					if (this.checkField != null
							&& this.checkField.equals(fieldId)) {
						//sb.append("<input type=\"checkbox\" value=\"1\"/>");
						String value = "";
						if (getSessionData() != null) {
							Object values = getSessionData().get("sample1.QueryTable_VALUES");
							if (values instanceof Hashtable) {
								String v = (String)((Hashtable)values).get(Integer.toString(rowId));
								if ("1".equals(v)) {
									value = " value=\"1\"";
								}
							}
						}
						sb.append("<input id=\"" + rowId + "\" type=\"checkbox\"" + value + "/>");
					}
					sb.append(rs.getString(i + 1));
					sb.append("</td>");
				}
				sb.append("</tr>");
			} else {
				break;
			}
		}
	}
	
}
