/**
 * VwUtility
 * ユーティティ
 */
try {
LAST_MODIFIED('2004.11.08', '1.0.27');
}catch(e){}

/**
 * URLエンコード
 */
function URLEncode(str){
  // エンコードされた文字列
  var urlStr = '';         

  // 対象の文字
  var chr;

  // 対象の文字のunicode
  var uni;
  
  // 1文字づつ変換
  for(var i = 0; i < str.length; i++){
    chr = str.charAt(i);
    uni = str.charCodeAt(i);
    
    if(chr == ' '){
      
      //スペース
      urlStr += '+';
      
    } else if(uni == 0x2a || 
              uni == 0x2d || 
              uni == 0x2e || 
              uni == 0x5f || 
              ((uni >= 0x30) && (uni <= 0x39)) || 
              ((uni >= 0x41) && (uni <= 0x5a)) || 
              ((uni >= 0x61) && (uni <= 0x7a))) {
      
      // 変換なし
      urlStr = urlStr + chr;
      
    } else if((uni >= 0x0) && (uni <= 0x7f)){     

      // 1バイト
      var tmp = '0' + uni.toString(16);
      urlStr += '%'+ tmp.substr(tmp.length - 2);
      
    } else if(uni > 0x1fffff){     

      // 4バイト (extended)
      urlStr += '%' + (oxf0 + ((uni & 0x1c0000) >> 18)).toString(16);
      urlStr += '%' + (0x80 + ((uni & 0x3f000) >> 12)).toString(16);
      urlStr += '%' + (0x80 + ((uni & 0xfc0) >> 6)).toString(16);
      urlStr += '%' + (0x80 + (uni & 0x3f)).toString(16);
      
    } else if(uni > 0x7ff){        

      // 3バイト
      urlStr += '%' + (0xe0 + ((uni & 0xf000) >> 12)).toString(16);
      urlStr += '%' + (0x80 + ((uni & 0xfc0) >> 6)).toString(16);
      urlStr += '%' + (0x80 + (uni & 0x3f)).toString(16);
      
    } else {                      

      // 2バイト
      urlStr += '%' + (0xc0 + ((uni & 0x7c0) >> 6)).toString(16);
      urlStr += '%' + (0x80 + (uni & 0x3f)).toString(16);
    }
  }
  return urlStr;
}

/**
 * すべての文字がasciiか
 */
function isAscii(str) {

  // 1文字づつ調べる
  for(var i = 0; i < str.length; i++){
    if(str.charCodeAt(i) > 0x7f){     
      return false;
    }
  }
  return true;
}

/**
 * 長いメッセージを分割してダイアログに表示
 * @param  :_msg     メッセージ
 *          _alerter ダイアログの親window
 */
function alertMore(_msg, _alerter){
  var callAlert = window.alert;

  if(typeof(_alerter) == 'object' && _alerter.alert) {
    callAlert = _alerter.alert;
  }
  var msg = _msg.toString();
  var maxDialogRow = 45;
  if(navigator.appName != 'Microsoft Internet Explorer'){
    maxDialogRow = 30;
  }

  var idx=0;
  var sts=0;
  var end=0;
  var msgArray = new Array();

  // 分割
  while(parseInt(idx) != -1){
    for(var i=0; i < maxDialogRow; i++){
      idx = msg.indexOf('\n', end);
      if(idx == -1){
          end = 0;
          break;
      }
      end = idx + 1;
    }
    if(msg.length <= end){
        end = 0;
    }
    if(end == 0){
      msgArray[msgArray.length] = msg.substr(sts) + '\n';
    }else{
      msgArray[msgArray.length] = msg.slice(sts,end);
    }
    sts = end;
  }

  var length = msgArray.length;
  if(length == 1) {

    // 1画面に収まる
    alert(msgArray[0]);

  } else {
    
    for(var i = 0; i < length; i++){
      var dispMsg = msgArray[i];

      // 全体の何番目か表示
      dispMsg += '\n[' + (i + 1) + '/' + length + ']';
      
      if(i == (length - 1)){

        // 最後のダイアログ
        callAlert(dispMsg);

      }else{

        // 最後ではない
        callAlert(dispMsg + ' ...');

      }
    }
  }
}

/**
 * オブジェクトをダイアログに階層表示
 * @param  :_obj   対象オブジェクト
 *          _name  オブジェクトの名前
 *          _info  最大階層数
 */
function showObject(_obj, _name, _info) {
  alertMore(new DescriptionObject(_obj, _name, _info));
}

/**
 * オブジェクトを階層表示するオブジェクト
 * @param  :_obj   対象オブジェクト
 *          _name  オブジェクトの名前
 *          _info  最大階層数
 *          _level 階層 (内部で使用。最上位は指定なし)
 */
function DescriptionObject(_obj, _name, _info, _level) {
  this.indent = '';
  this.type = 'leaf';
  this.description = '';
  if(_level) {
    this.level = _level;
  } else {
    this.level = 0;
  }
  this.levellimit = 1;
  this.levellimits = {};

  if(_info) {
    if(typeof(_info) == 'number') {
      this.levellimit = _info;
    } else if(typeof(_info) == 'object') {
      if(_info['']) {
        this.levellimit = _info[''];
      }
      this.levellimits = _info;
    }
  }
  
  // 階層の枝を表現するテキスト
  if(!DescriptionObject.treeParts) {
    DescriptionObject.treeParts = {};
    DescriptionObject.treeParts['│'] = '　│ ';
    DescriptionObject.treeParts['├'] = '　├ ';
    DescriptionObject.treeParts['└'] = '　└ ';
    DescriptionObject.treeParts['　'] = '　　 ';
  }
  this.treeParts = DescriptionObject.treeParts;
  
  if(_name) {
    this.name = _name;
  } else {
    this.name = 'untitled';
  }
  this.children = new Array();
  switch(typeof(_obj)) {
  case 'string':
    this.description = _obj;
    break;
  case 'number':
    this.description = _obj.toString();
    break;
  case 'object':
    this.type = 'node';
    this.description = '(object)';
    if(_obj == null) {
      this.description += 'null';
    }
    if(this.level < this.levellimit) {
      for(var prop in _obj) {
        var childinf = _info;
        if(this.levellimits[prop] != undefined) {
          if(this.level >= this.levellimits[prop]) {
            continue;
          } else {
            childinf = {};
            for(var p in this.levellimits) {
              childinf[p] = this.levellimits[p];
            }
            childinf[''] = this.levellimits[prop];
          }
        }
        this.children[this.children.length] = new DescriptionObject(_obj[prop], prop, childinf, this.level + 1);
      }
    }
    break;
  case 'function':
  case 'undefined':
    this.description = '(' + typeof(_obj) + ')';
    break;
  case 'boolean':
  default:
    this.description = '(' + typeof(_obj) + ')' + _obj.toString();
  }

  DescriptionObject.prototype.toString = function() {
    var str = this.name + ':' + this.description;
    if(this.type == 'node') {
      for(var i = 0; i < this.children.length; i++) {
        if(i < this.children.length - 1) {
          this.children[i].indent = this.indent + this.treeParts['│'];
          str += '\n' + this.indent + this.treeParts['├'] + this.children[i].toString();
        } else {
          this.children[i].indent = this.indent + this.treeParts['　'];
          str += '\n' + this.indent + this.treeParts['└'] + this.children[i].toString();
        }
      }
    }
    return str;
  }
}

/**
 * HTML文字列生成オブジェクト
 */
function HtmlTag(_tagname) {
  if(_tagname) {
    this.tagname = _tagname.toLowerCase();
  } else {
    this.tagname = 'div';
  }
  switch(this.tagname) {
  case 'input':
  case 'br':
  case 'p':
  case 'img':
    break;
  default:
    this.innerHTML = '';
    this.innerText = '';
  }
  this.style = new Object();

  /**
   *  開始タグ出力
   */
  HtmlTag.prototype.open = function() {
    var _html = '';
    _html += '<' + this.tagname;

    // 属性部分文字列
    for(var i in this) {
      if(typeof(this[i]) == 'function') {
      } else if(typeof(this[i]) == 'boolean' && this[i] == true) {
        _html += ' ' + i;
      } else {
        if(i.toLowerCase() == 'style') continue;
        if(i.toLowerCase() == 'tagname') continue;
        if(i.toLowerCase() == 'innertext') continue;
        if(i.toLowerCase() == 'innerhtml') continue;
          
        _html += ' ' + i + '="' + this[i] + '"';
      }
    }

    // style部分文字列
    var _style = '';
    for(var i in this.style) {
      
      // 大文字をハイフン+小文字に変換　例）fontSize → font-size
      var _stylename = '';
      for(var idx = 0; idx < i.length; idx++) {
        var chr = i.charAt(idx).toString()
        if(0 < idx) {
          if(0 == chr.search(/[A-Z]/)) {
            _stylename += '-';
          }
        }
        _stylename += chr.toLowerCase();
      }
      
      _style += ' ' + _stylename + ':' + this.style[i] + ';';
    }
    if(_style != '') {
      _html += ' style="' + _style + '"';
    }

    _html += '>';

    return _html;
  }
  
  /**
   *  終了タグ出力
   */
  HtmlTag.prototype.close = function() {
    return '</' + this.tagname + '>';
  }

  /**
   *  innerHTMLを指定して出力
   */
  HtmlTag.prototype.containing = function(_html) {
    return this.open() + _html + this.close();
  }
  
  /**
   *  タグ出力
   */
  HtmlTag.prototype.toString = function() {
    if(typeof(this.innerHTML) != 'undefined') {
      return this.containing(this.innerHTML);
    } else if(typeof(this.innerText) != 'undefined') {
      return this.containing(this.innerText);
    }
    return this.open();
  }
}

/**
 * undo可能なコマンドを実行するオブジェクト
 */
function UndoManager(_maxundo) {
  
  // undo可能な回数 -1以下:無制限 0:undo不可
  this.maxUndo = -1;
  if(typeof(_maxundo) == 'number') {
    this.maxUndo = parseInt(_maxundo);
  }
  
  // 次のUndoで実行されるコマンド
  this.commandToUndo = null;
  
  // 次のRedoで実行されるコマンド
  this.commandToRedo = null;

  // 保存された位置を覚えておくための数字
  this.saveNumber = 0;

  // undo可能, redo可能の状態が変わったときに呼び出される
  this.stateChanged = function(_canUndo, _canRedo, _canSave) {
  }

  // 新しいコマンドを追加+実行
  UndoManager.prototype.execute = function(_cmd) {
    
    // コマンドを実行
    _cmd.execute();

    if(this.maxUndo == 0) {
      // undo不可
      return;
    }
    
    // save可能か
    if(this.commandToUndo) {
      if(this.commandToUndo.saveNumberAfterRedone && 
         this.commandToUndo.saveNumberAfterRedone == this.saveNumber) {
        _cmd.saveNumberAfterUndone = this.saveNumber;
      }
    } else if(this.commandToRedo){
      if(this.commandToRedo.saveNumberAfterUndone &&
         this.commandToRedo.saveNumberAfterUndone == this.saveNumber) {
        _cmd.saveNumberAfterUndone = this.saveNumber;
      }
    } else {
      if(this.saveNumber > 0) {
        _cmd.saveNumberAfterUndone = this.saveNumber;
      }
    }

    // コマンドを連結
    if(this.commandToUndo) {
      this.commandToUndo.nextCommand = _cmd;
    }
    _cmd.prevCommand = this.commandToUndo;
    _cmd.nextCommand = null;
    
    // 最初の状態を保存
    var _canUndo = this.canUndo();
    var _canRedo = this.canRedo();
    var _canSave = this.canSave();

    this.commandToUndo = _cmd;
    this.commandToRedo = null;

    // 古いundoを切り捨てる
    if(0 < this.maxUndo) {
      var count = this.maxUndo;
      for(var cmd = this.commandToUndo; cmd; cmd = cmd.prevCommand) {
        count--;
        if(count == 0) {
          cmd.prevCommand = null;
          break;
        }
      }
    }

    // 状態変更
    if(!_canUndo || _canRedo || !_canSave) {
      this.stateChanged(true, false, true);
    }
  }

  // undo実行
  UndoManager.prototype.undo = function() {
    if(!this.commandToUndo) {
      return;
    }

    // 最初の状態を保存
    var _canRedo = this.canRedo();

    this.commandToUndo.undo();
    this.commandToRedo = this.commandToUndo;
    this.commandToUndo = this.commandToUndo.prevCommand;

    var _canUndo = this.canUndo();
    var _canSave = this.canSave();
    if(!_canUndo || !_canRedo || !_canSave) {
      this.stateChanged(_canUndo, true, _canSave);
    }
  }

  // redo実行
  UndoManager.prototype.redo = function() {
    if(!this.commandToRedo) {
      return;
    }

    // 最初の状態を保存
    var _canUndo = this.canUndo();

    this.commandToRedo.redo();
    this.commandToUndo = this.commandToRedo;
    this.commandToRedo = this.commandToRedo.nextCommand;

    var _canRedo = this.canRedo();
    var _canSave = this.canSave();
    if(!_canUndo || !_canRedo || !_canSave) {
      this.stateChanged(true, _canRedo, _canSave);
    }
  }

  // undo可能か
  UndoManager.prototype.canUndo = function() {
    if(this.commandToUndo) {
      return true;
    }
    return false;
  }

  // redo可能か
  UndoManager.prototype.canRedo = function() {
    if(this.commandToRedo) {
      return true;
    }
    return false;
  }

  // save可能か
  UndoManager.prototype.canSave = function() {
    if(this.shouldSave) {
      return true;
    }
    if(!this.stateSaved()) {
      return true;
    }
    return false;
  }

  // 保存されている状態かか
  UndoManager.prototype.stateSaved = function() {
    if(this.commandToRedo) {
      if(this.commandToRedo.saveNumberAfterUndone && this.commandToRedo.saveNumberAfterUndone == this.saveNumber) {
        return true;
      }
    } else if(this.commandToUndo) {
      if(this.commandToUndo.saveNumberAfterRedone && this.commandToUndo.saveNumberAfterRedone == this.saveNumber) {
        return true;
      }
    } else {
      if(this.saveNumber > 0) {
        return true;
      }
    }

    return false;
  }

  // save不可の状態
  UndoManager.prototype.justSaved = function() {
    this.saveNumber++;
    this.shouldSave = false;
    if(this.commandToRedo) {
      this.commandToRedo.saveNumberAfterUndone = this.saveNumber;
    }
    if(this.commandToUndo) {
      this.commandToUndo.saveNumberAfterRedone = this.saveNumber;
    }
    return this.saveNumber;
  }

  // save可の状態
  UndoManager.prototype.notSaved = function() {
    this.shouldSave = true;
  }
}

/**
 * コマンドをセットにするオブジェクト
 */
function UndoableCommandSet(_presentationName) {

  // このコマンドの表示名
  this.presentationName = '';
  if(_presentationName) this.presentationName = _presentationName;
    
  // 追加されたコマンド
  this.commands = new Array();
  
  // prototype設定
  if(!UndoableCommandSet.initialized) {
    UndoableCommandSet.prototype.add = _add;
    UndoableCommandSet.prototype.execute = _execute;
    UndoableCommandSet.prototype.undo = _undo;
    UndoableCommandSet.prototype.redo = _redo;
    UndoableCommandSet.prototype.undoSize = _undoSize;
    UndoableCommandSet.prototype.redoSize = _redoSize;
    UndoableCommandSet.initialized = true;
  }

  return;

  // コマンドの追加
  function _add(_cmd) {
    this.commands[this.commands.length] = _cmd;
  }

  // execute実行
  function _execute(progressBar) {
    for(var i = 0; i < this.commands.length; i++) {
      this.commands[i].execute(progressBar);
    }
  }

  // undo実行（逆順に実行）
  function _undo(progressBar) {
    for(var i = this.commands.length - 1; i >= 0; i--) {
      this.commands[i].undo(progressBar);
    }
  }

  // redo実行
  function _redo(progressBar) {
    for(var i = 0; i < this.commands.length; i++) {
      this.commands[i].redo(progressBar);
    }
  }

  // undoで実行するコマンドの数
  function _undoSize() {
    var size = 0;
    for(var i = 0; i < this.commands.length; i++) {
      if(this.commands[i].undoSize) {
        size += this.commands[i].undoSize();
      } else {
        size += 1;
      }
    }
    return size;
  }

  // redoで実行するコマンドの数
  function _redoSize() {
    var size = 0;
    for(var i = 0; i < this.commands.length; i++) {
      if(this.commands[i].redoSize) {
        size += this.commands[i].redoSize();
      } else {
        size += 1;
      }
    }
    return size;
  }
}

/**
 * 色名のオブジェクトを生成する
 */
function createColorNames() {
  var colorNames = new Object();

  colorNames.aliceblue =            '#f0f8ff';
  colorNames.antiquewhite =         '#faebd7';
  colorNames.aqua =                 '#00ffff';
  colorNames.aquamarine =           '#7fffd4';
  colorNames.azure =                '#f0ffff';
  colorNames.beige =                '#f5f5dc';
  colorNames.bisque =               '#ffe4c4';
  colorNames.black =                '#000000';
  colorNames.blanchedalmond =       '#ffebcd';
  colorNames.blue =                 '#0000ff';
  colorNames.blueviolet =           '#8a2be2';
  colorNames.brown =                '#a52a2a';
  colorNames.burlywood =            '#deb887';
  colorNames.cadetblue =            '#5f9ea0';
  colorNames.chartreuse =           '#7fff00';
  colorNames.chocolate =            '#d2691e';
  colorNames.coral =                '#ff7f50';
  colorNames.cornflowerblue =       '#6495ed';
  colorNames.cornsilk =             '#fff8dc';
  colorNames.crimson =              '#dc143c';
  colorNames.cyan =                 '#00ffff';
  colorNames.darkblue =             '#00008b';
  colorNames.darkcyan =             '#008b8b';
  colorNames.darkgoldenrod =        '#b8860b';
  colorNames.darkgray =             '#a9a9a9';
  colorNames.darkgreen =            '#006400';
  colorNames.darkkhaki =            '#bdb76b';
  colorNames.darkmagenta =          '#8b008b';
  colorNames.darkolivegreen =       '#556b2f';
  colorNames.darkorange =           '#ff8c00';
  colorNames.darkorchid =           '#9932cc';
  colorNames.darkred =              '#8b0000';
  colorNames.darksalmon =           '#e9967a';
  colorNames.darkseagreen =         '#8fbc8b';
  colorNames.darkslateblue =        '#483d8b';
  colorNames.darkslategray =        '#2f4f4f';
  colorNames.darkturquoise =        '#00ced1';
  colorNames.darkviolet =           '#9400d3';
  colorNames.deeppink =             '#ff1493';
  colorNames.deepskyblue =          '#00bfff';
  colorNames.dimgray =              '#696969';
  colorNames.dodgerblue =           '#1e90ff';
  colorNames.firebrick =            '#b22222';
  colorNames.floralwhite =          '#fffaf0';
  colorNames.forestgreen =          '#228b22';
  colorNames.fuchsia =              '#ff00ff';
  colorNames.gainsboro =            '#dcdcdc';
  colorNames.ghostwhite =           '#f8f8ff';
  colorNames.gold =                 '#ffd700';
  colorNames.goldenrod =            '#daa520';
  colorNames.gray =                 '#808080';
  colorNames.green =                '#008000';
  colorNames.greenyellow =          '#adff2f';
  colorNames.honeydew =             '#f0fff0';
  colorNames.hotpink =              '#ff69b4';
  colorNames.indianred =            '#cd5c5c';
  colorNames.indigo =               '#4b0082';
  colorNames.ivory =                '#fffff0';
  colorNames.khaki =                '#f0e68c';
  colorNames.lavender =             '#e6e6fa';
  colorNames.lavenderblush =        '#fff0f5';
  colorNames.lawngreen =            '#7cfc00';
  colorNames.lemonchiffon =         '#fffacd';
  colorNames.lightblue =            '#add8e6';
  colorNames.lightcoral =           '#f08080';
  colorNames.lightcyan =            '#e0ffff';
  colorNames.lightgoldenrodyellow = '#fafad2';
  colorNames.lightgreen =           '#90ee90';
  colorNames.lightgrey =            '#d3d3d3';
  colorNames.lightpink =            '#ffb6c1';
  colorNames.lightsalmon =          '#ffa07a';
  colorNames.lightseagreen =        '#20b2aa';
  colorNames.lightskyblue =         '#87cefa';
  colorNames.lightslategray =       '#778899';
  colorNames.lightsteelblue =       '#b0c4de';
  colorNames.lightyellow =          '#ffffe0';
  colorNames.lime =                 '#00ff00';
  colorNames.limegreen =            '#32cd32';
  colorNames.linen =                '#faf0e6';
  colorNames.magenta =              '#ff00ff';
  colorNames.maroon =               '#800000';
  colorNames.mediumaquamarine =     '#66cdaa';
  colorNames.mediumblue =           '#0000cd';
  colorNames.mediumorchid =         '#ba55d3';
  colorNames.mediumpurple =         '#9370db';
  colorNames.mediumseagreen =       '#3cb371';
  colorNames.mediumslateblue =      '#7b68ee';
  colorNames.mediumspringgreen =    '#00fa9a';
  colorNames.mediumturquoise =      '#48d1cc';
  colorNames.mediumvioletred =      '#c71585';
  colorNames.midnightblue =         '#191970';
  colorNames.mintcream =            '#f5fffa';
  colorNames.mistyrose =            '#ffe4e1';
  colorNames.moccasin =             '#ffe4b5';
  colorNames.navajowhite =          '#ffdead';
  colorNames.navy =                 '#000080';
  colorNames.oldlace =              '#fdf5e6';
  colorNames.olive =                '#808000';
  colorNames.olivedrab =            '#6b8e23';
  colorNames.orange =               '#ffa500';
  colorNames.orangered =            '#ff4500';
  colorNames.orchid =               '#da70d6';
  colorNames.palegoldenrod =        '#eee8aa';
  colorNames.palegreen =            '#98fb98';
  colorNames.paleturquoise =        '#afeeee';
  colorNames.palevioletred =        '#db7093';
  colorNames.papayawhip =           '#ffefd5';
  colorNames.peachpuff =            '#ffdab9';
  colorNames.peru =                 '#cd853f';
  colorNames.pink =                 '#ffc0cb';
  colorNames.plum =                 '#dda0dd';
  colorNames.powderblue =           '#b0e0e6';
  colorNames.purple =               '#800080';
  colorNames.red =                  '#ff0000';
  colorNames.rosybrown =            '#bc8f8f';
  colorNames.royalblue =            '#4169e1';
  colorNames.saddlebrown =          '#8b4513';
  colorNames.salmon =               '#fa8072';
  colorNames.sandybrown =           '#f4a460';
  colorNames.seagreen =             '#2e8b57';
  colorNames.seashell =             '#fff5ee';
  colorNames.sienna =               '#a0522d';
  colorNames.silver =               '#c0c0c0';
  colorNames.skyblue =              '#87ceeb';
  colorNames.slateblue =            '#6a5acd';
  colorNames.slategray =            '#708090';
  colorNames.snow =                 '#fffafa';
  colorNames.springgreen =          '#00ff7f';
  colorNames.steelblue =            '#4682b4';
  colorNames.tan =                  '#d2b48c';
  colorNames.teal =                 '#008080';
  colorNames.thistle =              '#d8bfd8';
  colorNames.tomato =               '#ff6347';
  colorNames.turquoise =            '#40e0d0';
  colorNames.violet =               '#ee82ee';
  colorNames.wheat =                '#f5deb3';
  colorNames.white =                '#ffffff';
  colorNames.whitesmoke =           '#f5f5f5';
  colorNames.yellow =               '#ffff00';
  colorNames.yellowgreen =          '#9acd32';

  return colorNames;
}

/* 自前splice
 * Arrayにspliceメソッドがない場合に自前のspliceを追加する(IE5.0対応)
 */
function arraySplice(_index, _length) {
  // このメソッドの引数リスト
  var args = arraySplice.arguments;

  // 新しい配列要素
  var newArr = new Array();
  
  // newArrに新しい配列要素を追加し、オブジェクトの古い配列要素を削除
  for(var i = 0; i < this.length; i++) {
    if(i < _index) {
      newArr[newArr.length] = this[i];
    } else if(i == _index) {
      if(args && args.length) {
        for(var j = 2; j < args.length; j++) {
          newArr[newArr.length] = args[j];
        }
      }
    } else if(i < _index + _length) {
      
    } else {
      newArr[newArr.length] = this[i];
    }
    delete this[i];
  }

  // オブジェクトに新しい配列要素を設定
  for(var i = 0; i < newArr.length; i++) {
    this[i] = newArr[i];
  }

  // lengthを新しい配列要素数に更新
  this.length = newArr.length;
}

/**
 * テキストによるプログレスバー
 */
function ProgressText(_max, _barlength, _emp, _fill) {

  ProgressText.prototype.getBar = _getBar;
  ProgressText.prototype.getText = _getText;
  ProgressText.prototype.progress = _progress;
  ProgressText.prototype.toString = _getBar;

  this.current = 0;
  if(typeof(_max) == 'number' && 0 < _max) {
    this.max = _max;
  } else {
    this.max = 100;
  }

  this.length = 10;
  if(typeof(_barlength) != 'undefined') {
    this.length = _barlength;
    //this.toString = function() {return this.getBar();};
  } else {
    //this.toString = function() {return this.getText();};
  }
  
  this.chr0 = '.';
  this.chr1 = '';
  if(typeof(_emp) != 'undefined') {
    this.chr0 = _emp;
  }
  if(typeof(_fill) != 'undefined') {
    this.chr1 = _fill;
  }

  function _progress(_num) {
    if(_num) {
      this.current += _num;
    } else {
      this.current += 1;
    }
    return this;
  }

  function _getText() {
    return this.current + '/' + this.max;
  }

  function _getBar() {
    var len0 = parseInt(this.current * this.length / this.max);
    if(len0 < 0) len0 = 0;
    if(len0 > this.length) len0 = this.length;
    var len1 = this.length - len0;
    var bar = '';
    while(len0 > 0) {
      bar += this.chr1;
      len0 -= 1;
    }
    while(len1 > 0) {
      bar += this.chr0;
      len1 -= 1;
    }

    return bar;
  }
}

/**
 *
 */
function Log(_max) {
  if(_max) {
    this.max = _max;
  } else {
    this.max = 1000;
  }
  this.logs = new Array();
  this.lev = new Object();
  this.immediate = true;
  
  Log.prototype.start = _start;
  Log.prototype.open = _open;
  Log.prototype.close = _close;
  Log.prototype.add = _add;
  Log.prototype.debug = _debug;
  Log.prototype.warn = _warn;
  Log.prototype.clear = _clear;
  
  Log.prototype.toString = _toString;
  Log.prototype.update = _update;
  Log.prototype.print = _print;
  Log.prototype.setOutputElement = _setOutputElement;

  function _start() {
    return 'log already started.';
  }
  
  function _date() {
    var dt = (new Date()).toString();
    var pos = dt.indexOf(':');
    return dt.substring(pos - 2,pos + 6);
    //return dt;
  }
  
  function _clear() {
    this.logs = new Array();
    this.lev = new Object();
    if(this.immediate) {
      this.update();
    }
    return 'ログクリア.';
  }

  function _print(_str) {
    var num = this.logs.length;
    if(num > this.max) {
      this.clear();
      num = 0;
    }
    this.logs[num] = _str;

    if(this.immediate) {
      this.update();
    }
  }

  function _add(_str, _level) {
    var num = this.logs.length;
    if(_level) {
      _level = ' [' + _level + ']';
    } else {
      _level = ' '
    };
    if(!this.lev[_level]) {
      this.lev[_level] = new Array();
    }
    this.lev[_level][this.lev[_level].length] = num;
    this.print(_date() + _level + _str);
  }

  function _debug(_str, _obj) {
    if(_obj) {
      this.add(makeMessage(_str, _obj), 'debug');
    } else {
      this.add(_str, 'debug');
    }
  }

  function _warn(_str, _obj) {
    if(_obj) {
      this.add(makeMessage(_str, _obj), 'warn ');
    } else {
      this.add(_str, 'debug');
    }
  }

  function _toString() {
    var str = '';
    for(var i = 0; i < this.logs.length; i++) {
      str += this.logs[i] + '\n';
    }
    return str;
  }
  
  function _setOutputElement(_element, _attName) {
    this.outputElement = _element;
    if(_attName) {
      this.outputAttribute = _attName;
    } else {
      this.outputAttribute = 'value';
    }
  }

  function _update() {
    if(this.outputElement) {
      try {
        this.outputElement[this.outputAttribute] = this.toString();
      } catch (e) {
        this.outputElement = null;
      }
    }
  }

  function _close() {
    if(this.logWindow) {
      this.logWindow.close();
    }
    log = new UnstartedLog();
    return '';
  }
  
  function _open() {
    //this.logWindow = window.open('about:blank','','width=620,height=360,top=20,left=20,scrollbars=no,resizable=no');
    this.logWindow = window.open('about:blank','', 'width=650,height=400,top=20,left=20,scrollbars=yes,resizable=yes');
    this.logWindow.document.writeln('<html><header><title>Log</title>');
    this.logWindow.document.writeln('<script>\n');
    this.logWindow.document.writeln('function setLog(_log){log = _log}\n');
    this.logWindow.document.writeln('</script>');
    this.logWindow.document.writeln('</header><body onload="doOnLoad">');
    this.logWindow.document.writeln('<table cellspacing="0" cellpadding="0"><tr><td>');
    this.logWindow.document.writeln('<textarea id=out style="width:600px;height:300px;" ></textarea>');
    this.logWindow.document.writeln('</td></tr><tr><td style="text-align:right;">');
    this.logWindow.document.writeln('<input readonly type=text value="M" onclick="log.clear()"  style="font-family:wingdings;font-size:16pt;border:none;width:20;cursor:pointer;">');
    this.logWindow.document.writeln('<input id="handle" value="]" readonly type=text style="font-family:wingdings;font-size:16pt;border:none;width:20;cursor:se-resize;">');
    this.logWindow.document.writeln('</td></tr></table></body></html>');
    var out = this.logWindow.document.getElementById('out');
    this.setOutputElement(out);
    elementResizable(out,this.logWindow, this.logWindow.document.getElementById('handle'));
    this.logWindow.document.body.onunload = function(){log = new UnstartedLog();};
    this.logWindow.setLog(this);
    this.update();
  }
  
  function elementResizable(out,win,handle) {
    var state = {
      mousedown : false,
      clientX : 0,
      clientY : 0,
      width : 0,
      height : 0
    };
    handle.onmousedown = onMouseDown;
    handle.onmousemove = onMouseMove;
    handle.onmouseup = onMouseUp;
    function onMouseDown(e) {
      state.mousedown = true;
      state.clientX = win.event.clientX;
      state.clientY = win.event.clientY;
      state.width = out.offsetWidth;
      state.height = out.offsetHeight;
      //showObject(state);
    }
    function onMouseMove(e) {
      if(state.mousedown == false) return;
      //showObject(win.event);
      out.style.width = state.width + win.event.clientX - state.clientX;
      out.style.height = state.height + win.event.clientY - state.clientY;
    }
    function onMouseUp(event) {
      state.mousedown = false;
    }
  }

}

var log = new UnstartedLog();
function UnstartedLog() {
  this.start = _start;
  this.open = _open;
  this.close = _close;
  this.add = _doNothing;
  this.debug = _doNothing;
  this.warn = _doNothing;
  this.clear = _doNothing;
  
  function _start(_max) {
    log = new Log(_max);
    return 'ログ開始.';
  }

  function _open(_max) {
    log = new Log(_max);
    log.open(_max);
    return 'ログ開始.';
  }

  function _close() {
    return '';
  }

  function _doNothing() {
  }
}


/*
*/
function openVariableFinder() {
  var win = window.open('about:blank','', 'width=550,height=400,top=20,left=20,scrollbars=yes,resizable=yes');
  var contents = '<html><head><title></title>'
    + '<script>'
    + 'function handleOnKeyPress(event) {'
    + '  if(event.keyCode == 10) {'
    + '    opener.variableFinder_printResult(window);'
    + '  }'
    + '}'
    + '</script>'
    + '</head>'
    + '<body>'
    + '<table cellpadding="0" cellspacing="0"><tr><td>'
    + '<textarea id="searchscript" style="width:500;height:200;" onkeypress="handleOnKeyPress(event)"></textarea><br>'
    + '</td></tr><tr><td style="text-align:right;">'
    + '<input id="handle" value="]" readonly type=text style="font-family:wingdings;font-size:16pt;border:none;width:20;cursor:se-resize;">'
    //+ '</td></tr><tr><td style="border:none;background-color:#fafffa;">'
    + '</td></tr></table>'
    + '<pre id="result"></pre>'
    + '</body></html>';
  win.document.write(contents);
  elementResizable(win.document.getElementById('searchscript'), win, win.document.getElementById('handle'));
  function elementResizable(out,win,handle) {
    var state = {
      mousedown : false,
      clientX : 0,
      clientY : 0,
      width : 0,
      height : 0
    };
    handle.onmousedown = onMouseDown;
    handle.onmousemove = onMouseMove;
    handle.onmouseup = onMouseUp;
    function onMouseDown(e) {
      state.mousedown = true;
      state.clientX = win.event.clientX + win.document.body.scrollLeft;
      state.clientY = win.event.clientY + win.document.body.scrollTop;
      state.width = out.offsetWidth;
      state.height = out.offsetHeight;
      //showObject(state);
    }
    function onMouseMove(e) {
      if(state.mousedown == false) return;
      //showObject(win.event);
      out.style.width = state.width + win.event.clientX + win.document.body.scrollLeft - state.clientX;
      out.style.height = state.height + win.event.clientY + win.document.body.scrollTop - state.clientY;
    }
    function onMouseUp(event) {
      state.mousedown = false;
    }
  }
}

/*
 * variableFinderに結果を表示する
 */
function variableFinder_printResult(win) {
  try {
    var scrpt = win.document.getElementById('searchscript').value;
    win.document.getElementById('result').innerText = eval(scrpt);
  } catch (e) {
    win.alert(e.message);
  }
}

/**
 * オブジェクトの内容を文字列にして返す
 */
function inspectObject(obj) {
  var result = '';
  var type = typeof(obj);
  result = 'type:' + type + '\n';
  if(type == 'object') {
    for(var p in obj) {
      var val = obj[p];
      var soeji = p;
      for(var i = 1; i < arguments.length; i++) {
        if(val) {
          val = val[arguments[i]];
          soeji += '.' + arguments[i];
          if(val == undefined) {
            continue;
          }
        } else {
          val = undefined;
          continue;
        }
      }
      if(val == undefined) {
        continue;
      }
      if(typeof(val) == 'function') {
        val = '[function]';
      }
      result += soeji + ' = ' + val + '\n';
    }
  } else {
    result += obj;
  }
  return result;
}

//var getDocumentElementById = document.getElementById;
function getDocumentElementById(id) {
  return document.getElementById(id);
}

/*
 *
 */
function makeMessage(msg, obj) {
  var inf = '';
  if(obj && obj.constructor == Array) {
    for(var i=0; i<obj.length; i++) {
      inf += obj[i] + ', ';
    }
  } else {
    for(var i in obj) {
      inf += i + '=' + obj[i] + ', ';
    }
  }
  if(inf) {
    msg += '(' + inf.substring(0, inf.length - 2) + ')';
  }
  return msg;
}

/*
 *
 */
function alertMessage(msg, obj) {
  alert(makeMessage(msg, obj));
}

/**
 * statusバーに進捗を表示する
 */
function WindowStatusProgressBar(len, _status) {
  this.windowStatus = window.status;
  if(_status != undefined) {
    window.status = _status;
    this.status = _status + ' ';
  } else {
    this.status = this.windowStatus + ' ';
  }
  this.progText = new ProgressText(len);

  WindowStatusProgressBar.prototype.update = _update;
  WindowStatusProgressBar.prototype.release = _release;

  function _update() {
    window.status = this.status + this.progText.progress();
  }

  function _release() {
    window.status = this.windowStatus;
  }
}

/**
 * statusバーに進捗を表示する
 */
function WindowStatusProgressRatio(len, _status) {
  this.windowStatus = window.status;
  if(_status != undefined) {
    window.status = _status;
    this.status = _status + ' (';
  } else {
    this.status = this.windowStatus + ' (';
  }
  this.progText = new ProgressText(len);

  WindowStatusProgressRatio.prototype.update = _update;
  WindowStatusProgressRatio.prototype.release = _release;

  function _update() {
    window.status = this.status + this.progText.progress().getText() + ')';
  }

  function _release() {
    window.status = this.windowStatus;
  }
}

/**
 * 進捗を表示するDummy
 */
function dummyProgressBar() {
  
  if(!DummyProgressBar.instance) {
    DummyProgressBar.prototype.update = _doNothing;
    DummyProgressBar.prototype.release = _doNothing;
    DummyProgressBar.instance = new DummyProgressBar();
  }
  
  return DummyProgressBar.instance;

  function DummyProgressBar() {
  }
  
  function _doNothing() {
  }
}

/*
function VertualModalDialog() {
  VertualModalDialog.prototype.display = display;
  VertualModalDialog.prototype.undisplay = undisplay;
  VertualModalDialog.prototype.onload = onload;
  VertualModalDialog.prototype.onunload = onunload;
  VertualModalDialog.prototype.openModal = openModal;

  this.top = 100;
  this.left = 100;
  this.width = 100;
  this.height = 100;

  function display() {
    if(!VertualModalDialog.div) {
      var parentElement = document.getElementById('FORMSCREEN');
      parentElement.innerHTML += '<div id="VertualModalDialog"></div>';
      VertualModalDialog.div = document.getElementById('VertualModalDialog');
    }
    var modal = '';
    modal += '<div id="VertualModalDialog.modal" style="top:100px;left:300px;width:200px;height:100px;background-color:silver;"></div>';
    VertualModalDialog.div.innerHTML = modal;
  }
  
  function undisplay() {
    if(!VertualModalDialog.div) {
      VertualModalDialog.div.innerHTML = '';
    }
  }
  
  function onload() {
  }
  
  function onunload() {
  }

  function openModal() {
    this.display();
    this.onload();
    this.onunload();
    this.undisplay();
  }
}
*/

/**
 * 特殊文字をJavaScript用にエスケープする
 * @param value
 * @return String
 */
function escapeJavaScript(value){
  if(!value) {
    return '';
  }
  var sb = '';
  for(var i = 0; i < value.length; i++) {
    var c = value.charAt(i);
    switch(c){
    case  '\\':
      sb += '\\\\';
      break;
    case '\'':
      sb += '\\\'';
      break;
    default:
      sb += c;
    }
  }
  return sb;
}

/**
 * 文字列エスケープ処理.
 *
 * @param  value  文字列
 * @return  エスケープ後文字列
 */
function escapeString(value) {
  if(!value) {
    return '';
  }
  var sb = '';
  
  for(var i = 0; i < value.length; i++) {
    var c = value.charAt(i);
    if(c == '<') {
      sb += '&lt;';
    }
    else if(c == '>') {
      sb += '&gt;';
    }
    else if(c == '&') {
      sb += '&amp;';
    }
    else if(c == '"') {
      sb += '&#034;';
    }
    else if(c == '\'') {
      sb += '&#039;';
    }
    else if(c == ' ') {
      sb += '&nbsp;';
    }
    else if(c == '\n') {
      sb += '<br>';
    }
    else {
      sb += c;
    }
  }
  return sb;
}

/*
 * Httpパラメータ
 */
function HttpParameter(url) {
  this.url = '';
  this.params = {};
  this.init(url);
  this.useURLEncode = false;
}

// HttpParameter初期化
initHttpParameter();

/*
 * HttpParameter定義
 */
function initHttpParameter() {
  
  if(!HttpParameter.HttpParameterInitialized) {
    HttpParameter.prototype.init = init;
    HttpParameter.prototype.toString = toString;
    HttpParameter.prototype.getExpression = getExpression;
    HttpParameter.prototype.get = get;
    HttpParameter.prototype.add = add;
    HttpParameter.prototype.set = set;
    HttpParameter.prototype.remove = remove;
    HttpParameter.prototype.urlEncode = urlEncode;
    HttpParameter.HttpParameterInitialized = true;
  }
  
  /*
   * インスタンス初期化
   */
  function init(url) {
    if(url) {
      var splurl = url.split('&');
      var pos = splurl[0].indexOf('?');
      if(pos == 0) {
        splurl[0] = splurl[0].substring(1);
      } else if(pos > 0) {
        this.url = splurl[0].substring(0, pos);
        splurl[0] = splurl[0].substring(pos + 1);
      }
      for(var i = 0; i < splurl.length; i++) {
        var pos = splurl[i].indexOf('=');
        if(pos == -1) {
          this.add('', splurl[i]);
        } else if(pos > 0) {
          this.add(splurl[i].substring(0, pos), splurl[i].substring(pos + 1));
        }
      }
    }
  }

  /*
   * Httpパラメータ文字列を返す
   */
  function toString() {
    log.debug('toString enter');
    var i = 0;
    var str = '';
    for(var p in this.params) {
      var exp = this.getExpression(p);
      str = concat(str, exp, '&');
    }
    str = concat(this.url, str, '?');
    log.debug('toString exit > ' + str);
    return str;
  }

  /*
   * 一つのパラメータ文字列を返す
   */
  function getExpression(paramName) {
    log.debug('getExpression(' + paramName + ') enter');
    var str = '';
    var param = this.params[paramName];
    if(param == undefined) {
    } else if((typeof(param)) == 'object' && (typeof(param.length)) == 'number') {
      for(var i = 0; i < param.length; i++) {
        var exp = concat(paramName, this.urlEncode(param[i]), '=', paramName);
        str = concat(str, exp, '&');
      }
    } else {
      var str = concat(paramName, this.urlEncode(param), '=', paramName);
    }
    log.debug('getExpression exit > ' + str);
    return str;
  }

  /*
   * 文字列をつなげる
   */
  function concat(str1, str2, connector, condition) {
    log.debug('concat(' + str1 + ',' + str2 + ',' + connector + ',' + condition + ') enter');
    var str = str1 + str2;
    if(connector != undefined) {
      if(condition != undefined) {
        if(condition) {
          str = str1 + connector + str2;
        }
      } else {
        if(str1 && str2) {
          str = str1 + connector + str2;
        }
      }
    }
    log.debug('concat exit > ' + str);
    return str;
  }
  
  /*
   * パラメータの値を取得する
   */
  function get(paramName) {
    log.debug('get(' + paramName + ') enter');
    var str = '';
    if(this.params[paramName] != undefined) {
      //str = URLEncode(this.params[paramName]);
      str = this.params[paramName];
    }
    log.debug('get exit > str');
    return str;
  }

  /*
   * パラメータを追加する
   */
  function add(paramName, value) {
    log.debug('add(' + paramName + ',' + value + ') enter');
    if(value == undefined) {
      value = paramName;
      paramName = '';
    }
    var param = this.params[paramName];
    if(param == undefined) {
      this.set(paramName, value);
    } else if((typeof(param)) == 'object' && (typeof(param.length)) == 'number') {
      if(paramName == '') {
        var exists = false;
        for(var i = 0; i < param.length; i++) {
          if(param[i] == value) {
            exists = true;
            break;
          }
        }
        if(!exists) {
          param[param.length] = value;
        }
      } else {
        param[param.length] = value;
      }
    } else {
      if(paramName == '' && param == value) {
      } else {
        this.set(paramName, [param, value]);
      }
    }
    log.debug('add exit');
  }

  /*
   * パラメータを設定する
   */
  function set(paramName, value) {
    log.debug('set enter');
    if(value == undefined) {
      this.add('', paramName);
    } else {
      this.params[paramName] = value;
    }
    log.debug('set exit');
  }

  /*
   * パラメータを削除する
   */
  function remove(paramName) {
    log.debug('remove(' + paramName + ') enter');
    delete this.params[paramName];
    log.debug('remove exit');
  }

  /*
   * パラメータを削除する
   */
  function urlEncode(str) {
    if(this.useURLEncode) {
      return URLEncode(str);
    }
    return str;
  }
}
