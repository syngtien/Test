/*
 * VwMenuBar
 * メニューバー・ツールバー
 */
LAST_MODIFIED('2005.02.08', '1.0.33');

/* 
*/
var RAISED_BORDERCOLOR = 'white gray gray white';
var LOWERED_BORDERCOLOR = 'gray white white gray';

/* リスナのダミー
 *
 */
function VwDummyMenuItemListener() {

  /* メニューアイテムがクリックされた際に呼ばれるactionメソッド */
  VwDummyMenuItemListener.prototype.action = function(menuId, menuItemId) {
    window.status = menuId + '/' + menuItemId;
  }

  /* キーイベント */
  VwDummyMenuItemListener.prototype.keyDown = function(_event) {
    //
  }
}

/* メニューバー
 *
 */
function VwMenuBar(_divId) {
  this.id = _divId;
  this.element = document.getElementById(_divId);
  this.width = 40;
  this.color = '';
  this.className = '';
  this.menuObjects = new Object();
  this.listener = new VwDummyMenuItemListener();
  this.currentOpenMenu = null;
  this.fontSize = '9';
  this.fontFamily = 'MS UI Gothic';
  this.toolBar = null;
  this.instanciated = false;

  this.documentDirty = false;
  this.saveMenuId = 'FILE';
  this.saveMenuItemId = 'SAVE';

  /* キーイベント */
  VwMenuBar.prototype.keyDown = function(_event) {
    this.listener.keyDown(_event);
  }
  
  /* メニュー再表示のときsetTimeoutを使う（mozillaバグ対応） */
  VwMenuBar.prototype.useSetTimeout = function(_variableName) {
    this.variableName = _variableName;
    this.useTimeout = true;
  }

  /* 「保存」メニューアイテムを使用可能にする */
  VwMenuBar.prototype.enableSave = function() {
    if(this.documentDirty) {
      return;
    }
    this.enableMenuItem(this.saveMenuId, this.saveMenuItemId);
    this.documentDirty = true;
  }

  /* 「保存」メニューアイテムを使用不可にする */
  VwMenuBar.prototype.disableSave = function() {
    this.disableMenuItem(this.saveMenuId, this.saveMenuItemId);
    this.documentDirty = false;
  }
      
  /* 開いているメニューを閉じる */
  VwMenuBar.prototype.close = function() {
    if(this.currentOpenMenu) {
      this.currentOpenMenu.close();
    }
  }

  /* メニューの使用不可 */
  VwMenuBar.prototype.lockMenu = function(_menuId, _enableflg) {
    if(this.menuObjects[_menuId]) {
      var menu = this.menuObjects[_menuId];
      menu.locked = false;
      if(typeof(_enableflg) == 'undefined' || _enableflg) {
        this.disableMenu(_menuId);
        menu.locked = true;
      }
      for(var i in menu.menuItems) {
        var menuItem = menu.menuItems[i];
        menuItem.locked = false;
        if(typeof(_enableflg) == 'undefined' || _enableflg) {
          //alert(i);
          this.disableMenuItem(_menuId, i);
          menuItem.locked = true;
        }
      }
    }
  }

  /* メニューの使用不可 */
  VwMenuBar.prototype.lockMenuItem = function(_menuId, _menuItemId, _enableflg) {
    if(this.menuObjects[_menuId]) {
      var menu = this.menuObjects[_menuId];
      if(menu.menuItems[_menuItemId]) {
        var menuItem = menu.menuItems[_menuItemId];
        menuItem.locked = false;
        if(typeof(_enableflg) == 'undefined' || _enableflg) {
          this.disableMenuItem(_menuId, _menuItemId);
          menuItem.locked = true;
        }
      }
    }
  }

  /* メニュの使用可 */
  VwMenuBar.prototype.isEnabled = function(_menuId, _menuItemId) {
    if(this.menuObjects[_menuId]) {
      var menu = this.menuObjects[_menuId];
      if(!_menuItemId) {
        return menu.enabled;
      }
      
      if(menu.menuItems[_menuItemId]) {
        return menu.menuItems[_menuItemId].enabled;
      }
    }
    return false;
  }
  
  /* メニュの使用可 */
  VwMenuBar.prototype.enableMenu = function(_menuId) {
    this.disableMenu(_menuId,true);
  }

  /* メニューの使用不可 */
  VwMenuBar.prototype.disableMenu = function(_menuId, _enableflg) {
    if(this.menuObjects[_menuId]) {
      var menu = this.menuObjects[_menuId];
      if(menu.locked) {
        return;
      }
      if(_enableflg) {
        menu.enabled = true;
        menu.currentTextColor = menu.textColor
      } else {
        menu.enabled = false;
        menu.currentTextColor = menu.disabledTextColor
      }
      
      if(this.instanciated) {
        if(this.useTimeout) {
          setTimeout(this.variableName + '.show();',0);
        } else {
          this.show()
        }
      }
    }
  }

  /* メニューの使用不可 */
  VwMenuBar.prototype.checkMenuEnabled = function(_menu) {
    if(_menu.locked) {
      return;
    }
    var isEnabled = false;
    for(var i in _menu.menuItems) {
      if(_menu.menuItems[i].enabled) {
        isEnabled = true;
        break;
      }
    }
    if(_menu.enabled == isEnabled) {
      return;
    }
    if(isEnabled) {
      _menu.enabled = true;
      _menu.currentTextColor = _menu.textColor
    } else {
      _menu.enabled = false;
      _menu.currentTextColor = _menu.disabledTextColor
    }
  }

  /* メニュー使用可・不可かをメニューアイテムを調べる */
  VwMenuBar.prototype.enableMenuItem = function(_menuId,_menuItemId) {
    this.disableMenuItem(_menuId,_menuItemId,true);
  }

  /* メニューアイテムの使用不可 */
  VwMenuBar.prototype.disableMenuItem = function(_menuId,_menuItemId,_enableflg) {
    if(this.menuObjects[_menuId]) {
      var menu = this.menuObjects[_menuId];
      if(menu.menuItems[_menuItemId]) {
        var menuItem = menu.menuItems[_menuItemId];
        if(menuItem.locked) {
          return;
        }
        
        var changed = (menuItem.enabled != _enableflg);
        if(_enableflg) {
          menuItem.enabled = true;
          menuItem.textColor = menu.textColor;
          menuItem.activeTextColor = menu.activeTextColor;
        } else {
          menuItem.enabled = false;
          menuItem.textColor = menu.disabledTextColor;
          menuItem.activeTextColor = menu.disabledTextColor;
        }
        
        if(changed) {
          this.checkMenuEnabled(menu);
          if(this.instanciated) {
            if(this.useTimeout) {
              //menu.updateMenu();
              //setTimeout(this.variableName + '.show();',0);
              setTimeout(this.variableName + '.menuObjects[\'' + _menuId + '\'].updateMenu();',0);
              
            } else {
              //menu.updateMenu();
              //this.show()
              
            }
          }
        }
      
        if(changed && this.toolBar) {
          this.toolBar.disableToolIcon(_menuId,_menuItemId,_enableflg);
        }
        
      }
    }
  }

  /* リスナの設定 */
  VwMenuBar.prototype.setListener = function(_listener) {
    this.listener = _listener;
    for(var menu in this.menuObjects) {
      this.menuObjects[menu].setListener(_listener);
    }
  }

  /* メニューバーの表示 */
  VwMenuBar.prototype.show = function() {

    var divMenuBar = '<div style="top : 0px;left : 0px; position : absolute; visibility : hidden;';
    if(this.color) {
      divMenuBar += 'background-color :' + this.color + ';';
    }
    divMenuBar += 'border-style : solid;border-width : 1px;border-color :gray gray gray gray;"';
    if(this.className) {
      divMenuBar += ' class="' + this.className + '"';
    }
    divMenuBar += ' id="' + this.id +  '.MENUBAR"  onmousedown="this.menuBar.close();"';
    divMenuBar += '  onkeydown="this.menuBar.keyDown(event);">\n';
    divMenuBar += '\t<table height="25"><tbody><tr>\n';
    divMenuBar += '\t<td id="' + this.id + '.MENUBAR.TD" onmousedown="this.menuBar.close();"><font size="larger"></font></td>\n\t</tr></tbody></table></div>\n\n';

    var right = 10;
    for(var menu in this.menuObjects) {
      if(right < this.menuObjects[menu].left + this.menuObjects[menu].width) { 
        right = this.menuObjects[menu].left + this.menuObjects[menu].width;
      }
      divMenuBar += '<div style="top : 1px;left : ' + this.menuObjects[menu].left + 'px; ';
      divMenuBar += 'position : absolute; visibility : visible;"'
                   + ' id="' + this.id +  '.' + this.menuObjects[menu].id + '">\n';
      divMenuBar += '\t<table bgcolor="' + this.color + '" height="25"><tbody><tr>\n';
      divMenuBar += '\t<td id="' + this.id +  '.' + this.menuObjects[menu].id + '.TD"';
      divMenuBar += ' height="20" width="' + (this.menuObjects[menu].width - 2) + '"';
      divMenuBar += ' style="font-size: ' + this.fontSize + 'pt;font-family:' + this.fontFamily + ';color:' + this.menuObjects[menu].currentTextColor + ';';
      divMenuBar += ' cursor:default;border-style : solid;border-width : 1px;border-color : ' + VwMenuBar_noBorder(this.color) + '"';
      divMenuBar += ' onMouseDown="this.menuObject.onMouseDown(this);"';
      divMenuBar += ' onMouseOver="this.menuObject.onMouseOver(this);"';
      divMenuBar += ' onMouseOut="this.menuObject.onMouseOut(this);"';
      divMenuBar += ' onKeyDown="this.menuObject.menuBar.keyDown(event);"';
      divMenuBar += ' onClick="this.menuObject.onClick(this);"><nobr>';
      divMenuBar += this.menuObjects[menu].name + '</nobr></td></tr></tbody></table></div>\n\n';

      divMenuBar += this.menuObjects[menu].menuItemsInnerHTML();
    }

    if(this.width < right + 10) {
      this.width = right + 10;
    }
    this.element.innerHTML = divMenuBar;
    document.getElementById(this.id + '.MENUBAR').menuBar = this;
    document.getElementById(this.id + '.MENUBAR.TD').menuBar = this;
    document.getElementById(this.id + '.MENUBAR').style.width = this.width;
    document.getElementById(this.id + '.MENUBAR').style.backgroundColor = this.color;
    for(var menu in this.menuObjects) {
      document.getElementById(this.id +  '.' + this.menuObjects[menu].id + '.TD').menuObject = this.menuObjects[menu];
      this.menuObjects[menu].menuItemsElement = document.getElementById(this.id +  '.' + this.menuObjects[menu].id + '.ITEMS');
      for(var item in this.menuObjects[menu].menuItems) {
        var menuItem = this.menuObjects[menu].menuItems[item];
        if(!menuItem.isSeparator) {
          var elementId = this.id +  '.' + this.menuObjects[menu].id +  '.' + menuItem.id;
                    
          document.getElementById(elementId).menuItem = menuItem;
          document.getElementById(elementId).bgElement = document.getElementById(elementId + '.BG');
        }
      }
    }

    document.getElementById(this.id + '.MENUBAR').style.visibility = 'visible';

    this.instanciated = true;
  }

  /* メニューの追加 */
  VwMenuBar.prototype.addMenu = function(_menuObject, _left) {
    if(_left) {
      _menuObject.left = _left;
    }

    this.menuObjects[_menuObject.id] = _menuObject;
    _menuObject.menuBar = this;
    _menuObject.setListener(this.listener);

  }
}

/* メニュー
 *
 */
function VwMenu(_menuId, _caption) {
  this.id = _menuId;
  if(_caption) {
    this.name = _caption;
  } else {
    this.name = _menuId;
  }
  this.left = 10;
  this.width = 20;
  this.itemsWidth = 100;
  this.menuItemInnerWidth = 100;
  this.menuItemCheckWidth = 6;
  this.menuIteSpaceWidth = 10;
  
  this.color = 'white';
  this.className = '';
  this.textColor = 'black';
  this.activeColor = '#000080';
  this.activeTextColor = 'white';
  this.disabledTextColor = 'gray';
  this.currentTextColor = this.textColor;
  
  this.menuBar = null;
  this.menuItems = new Object();
  this.listener = null;
  this.enabled = true;
  
  this.isOpen = false;
  this.menuElement = null;
  this.menuItemsElement = null;
  
  this.separator = new Object();
  this.separator.isSeparator = true;
  this.separator.count = 0;
  
  /* リスナの設定 */
  VwMenu.prototype.setListener = function(_listener) {
    this.listener = _listener;
    for(var item in this.menuItems) {
      if(!this.menuItems[item].isSeparator) {
        this.menuItems[item].setListener(_listener);
      }
    }
  }
  
  /* メニューアイテムの追加 */
  VwMenu.prototype.addMenuItem = function(_menuItem) {

    this.menuItems[_menuItem.id] = _menuItem;
    _menuItem.menu = this;
    _menuItem.setListener(this.listener);

    var tmpWidth = 0;
    tmpWidth = (this.menuItemCheckWidth) + _menuItem.nameWidth + _menuItem.shortCutWidth;
    if(0 < _menuItem.shortCutWidth) {
      tmpWidth += this.menuItemCheckWidth + this.menuIteSpaceWidth;
    }
    if(this.menuItemInnerWidth < tmpWidth) {
      this.menuItemInnerWidth = tmpWidth;
    }
    
  }
  
  /* メニューアイテムの追加 */
  VwMenu.prototype.addSeparator = function() {

    this.menuItems['SEPARATOR' + this.separator.count] = this.separator;
    this.separator.count++;
  }
  
  /* メニューのonMouseOver */
  VwMenu.prototype.onMouseOver = function(_element) {
    if(!this.enabled) {
      return;
    }
    if(!this.isOpen) {
      this.menuElement = _element;
      _element.style.borderColor = RAISED_BORDERCOLOR;
      if(this.menuBar.currentOpenMenu) {
        this.menuBar.currentOpenMenu.close();
        this.open();
      }
    }
  }

  /* メニューのonMouseOut */
  VwMenu.prototype.onMouseOut = function(_element) {
    if(!this.isOpen) {
      _element.style.borderColor = VwMenuBar_noBorder(this.menuBar.color);
    }
  }

  /* メニューのonMouseDown */
  VwMenu.prototype.onMouseDown = function(_element) {
    if(!this.enabled) {
      this.menuBar.close();
    }
  }

  /* メニューのonClick */
  VwMenu.prototype.onClick = function(_element) {
    if(!this.enabled) {
      return;
    }
    this.menuElement = _element;
    if(this.isOpen) {
      this.close();
      this.onMouseOver(this.menuElement);
    } else {
      
      this.open();
    }
  }

  /* メニューのopen */
  VwMenu.prototype.open = function() {
    if(!this.menuBar.useTimeout) {
      this.updateMenu();
    }
    this.isOpen = true;
    this.menuElement.style.borderColor = LOWERED_BORDERCOLOR;
    this.menuItemsElement.style.visibility = 'visible';
    this.menuBar.currentOpenMenu = this;
  }

  /* メニューのclose */
  VwMenu.prototype.close = function() {
    this.isOpen = false;
    this.onMouseOut(this.menuElement);
    this.menuItemsElement.style.visibility = 'hidden';
    this.menuBar.currentOpenMenu = null;
  }

  /* メニューアイテムのdivのinnerHTML */
  VwMenu.prototype.updateMenu = function() {
//    var element =  document.getElementById(this.menuBar.id + '.' + this.id +  '.ITEMS');
    var element = this.menuItemsElement;
    element.innerHTML = this.getMenuItemsInnerHTML();
    //element.style.visibility = 'visible';
    //element.style.visibility = 'hidden';
    
    for(var item in this.menuItems) {
      var menuItem = this.menuItems[item];
      if(!menuItem.isSeparator) {
        var elementId = this.menuBar.id +  '.' + this.id +  '.' + menuItem.id;
                  
        document.getElementById(elementId).menuItem = menuItem;
        document.getElementById(elementId).bgElement = document.getElementById(elementId + '.BG');
      }
    }
  }
  
  /* メニューアイテムのdivのinnerHTML */
  VwMenu.prototype.menuItemsInnerHTML = function() {
    var divMenuBar = '<div style="top : 26px;left : ' + this.left + 'px; position : absolute;';
    divMenuBar += ' visibility : hidden;border-style : solid;border-width : 1px;border-color : black;"'
    divMenuBar += ' id="' + this.menuBar.id + '.' + this.id +  '.ITEMS"';
    divMenuBar += ' >\n';
    divMenuBar += this.getMenuItemsInnerHTML();
    divMenuBar += '\t</tbody></table></div>\n\n';

    return divMenuBar;
  }
  
  /* メニューアイテムのdivのinnerHTML */
  VwMenu.prototype.getMenuItemsInnerHTML = function() {
    var divMenuBar = '<table class="' + this.className + '" width="' + this.itemsWidth + '" bgcolor="' + this.color + '"';
    divMenuBar +=  ' style="border-style : solid;border-width : 1px;border-color : ' + RAISED_BORDERCOLOR + ';"><tbody>\n';

    var right = 10;
    for(var item in this.menuItems) {
      if(this.menuItems[item].isSeparator) {
        divMenuBar += '\t\t<tr><td><hr style="text-align:left;width:' + this.menuItemInnerWidth + ';"></td></tr>\n';
      } else {
        divMenuBar += '\t\t<tr><td id="' + this.menuBar.id + '.' + this.id + '.' + this.menuItems[item].id + '.BG"';
        divMenuBar += ' height="25" width="' + this.itemsWidth + '"';
        divMenuBar += ' style="font-size:' + this.menuBar.fontSize + 'pt;font-family:' + this.menuBar.fontFamily + ';color:black;';
        //divMenuBar += ' cursor:default;border-style : solid;border-width : 1px;border-color : ' + this.color + '"';
        divMenuBar += ' cursor:default; border-style : none;"';
        //divMenuBar += ' bgColor="' + this.color + '"';
        divMenuBar += '>';
        divMenuBar += this.menuItems[item].innerHTML() + '</td></tr>\n';
      }
    }
    divMenuBar += '\t</tbody></table>\n\n';

    return divMenuBar;
  }
}

/* メニューアイテム
 *
 */
function VwMenuItem(_itemId, _caption, _shortCut, _check) {
  this.id = _itemId;
  if(_caption) {
    this.name = _caption;
  } else {
    this.name = _itemId;
  }
  this.nameWidth = VwMenuBar_getStringWidth(this.name);
  
  if(_shortCut) {
    this.shortCut = _shortCut;
  } else {
    this.shortCut = '';
  }
  this.shortCutWidth = VwMenuBar_getStringWidth(this.shortCut);

  if(_check) {
    this.check = _check;
  } else {
    this.check = '';
  }
  
  this.menu = null;
  this.listener = null;
  this.enabled = true;
  this.activeTextColor = 'white';
  this.textColor = 'black';
  
  /* メニューアイテムの表示HTML */
  VwMenuItem.prototype.innerHTML = function() {
    this.color = this.menu.color;
    var innerHtml = '';
    
    innerHtml += '<table cellspacing="0" width="' 
              + this.menu.menuItemInnerWidth + 'px" style="color:' 
              + this.textColor
              + ';font-size: ' + this.menu.menuBar.fontSize 
              + 'pt;font-family:' + this.menu.menuBar.fontFamily + ';" id="' 
              + this.menu.menuBar.id + '.' + this.menu.id + '.' + this.id 
              + '" onMouseOver="this.menuItem.onMouseOver(this);"'
              + ' onMouseOut="this.menuItem.onMouseOut(this);"'
              + ' onClick="this.menuItem.onClick(this);"><tr><td width="' 
              + this.menu.menuItemCheckWidth + 'px">';
    if(this.check == '') {
      innerHtml += '&nbsp;';
    } else if(this.check == 'checked') {
      innerHtml += '<span style="width:12px;font-family:Webdings,Marlett;"';
      innerHtml += ' id="' + this.menu.menuBar.id + '.' + this.menu.id + '.' + this.id + '.check">a</span>';
    } else {
      innerHtml += '<span style="width:12px;font-family:Webdings,Marlett;"';
      innerHtml += ' id="' + this.menu.menuBar.id + '.' + this.menu.id + '.' + this.id + '.check">&nbsp;</span>';
    }      
    innerHtml += '</td>';
    innerHtml += '<td width="' + (this.menu.menuItemInnerWidth
                                   - this.menu.menuItemCheckWidth
                                   - this.menu.menuItemCheckWidth
                                   - this.shortCutWidth) + 'px">';
    innerHtml += '<nobr>';
    innerHtml += this.name;
    innerHtml += '</nobr>';
    innerHtml += '</td><td width="' + this.shortCutWidth + 'px" align="right">' + this.shortCut + '</td>';
    innerHtml += '<td width="' + this.menu.menuItemCheckWidth + 'px">&nbsp;</td>';
    innerHtml += '</tr></table>';

    return innerHtml;
  }
  
  /* リスナの設定 */
  VwMenuItem.prototype.setListener = function(_listener) {
    this.listener = _listener;
  }
  
  /* メニューアイテムのonMouseOver */
  VwMenuItem.prototype.onMouseOver = function(_element) {
    //_element.bgElement.bgColor = this.menu.activeColor;
    _element.bgElement.style.backgroundColor = this.menu.activeColor;
    _element.style.color = this.activeTextColor;
    if(this.check == '') {
      return;
    }
  }

  /* メニューアイテムのonMouseOut */
  VwMenuItem.prototype.onMouseOut = function(_element) {
    //_element.bgElement.bgColor = this.menu.color;
    _element.bgElement.style.backgroundColor = '';
    _element.style.color = this.textColor;
    if(this.check == '') {
      return;
    }
  }

  /* メニューアイテムのonClick */
  VwMenuItem.prototype.onClick = function(_element) {
    if(!this.enabled) {
      return;
    }
    this.menu.close();
    if(this.check == 'checked' ) {
      return ;
    }
    if(this.check != '') {
      for(var item in this.menu.menuItems) {
        if(this.menu.menuItems[item].check == 'checked') {
          this.menu.menuItems[item].check = 'unchecked';
        }
      }
      this.check = 'checked';
    }
    this.menu.menuBar.show();

    var ids = _element.id.split('.');
    this.listener.action(ids[1],ids[2]);
  }
}

/* ツールバー
 *
 */
function VwToolBar(_divId) {
  this.id = _divId;
  this.element = document.getElementById(_divId);
  this.width = 40;
  this.color = '';
  this.className = '';
  this.toolIconObjects = new Object();
  this.listener = new VwDummyMenuItemListener();

  this.separator = new Object();
  this.separator.isSeparator = true;
  this.separator.count = 0;
  this.separator.imageSrc = '';
  
  this.instanciated = false;

  /* メニューアイテムの使用可 */
  VwToolBar.prototype.enableToolIcon = function(_menu,_menuItem) {
    this.disableToolIcon(_menu,_menuItem,true);
  }

    
  /* メニューアイテムの使用不可 */
  VwToolBar.prototype.disableToolIcon = function(_menu,_menuItem,_enableflg) {
    if(this.toolIconObjects[_menu + '.' + _menuItem]) {
      var toolIcon = this.toolIconObjects[_menu + '.' + _menuItem];
      if(_enableflg) {
        toolIcon.enabled = true;
        toolIcon.src = toolIcon.enabledImageSrc;
      } else {
        toolIcon.enabled = false;
        toolIcon.src = toolIcon.disabledImageSrc;
      }
      if(this.instanciated) {
        var element = document.getElementById(this.id + '.' + toolIcon.id);
        if(element) {
          element.src = toolIcon.src;
          element.style.borderColor = VwMenuBar_noBorder(this.color);
        }
      }
    }
  }

  
  /* リスナの設定 */
  VwToolBar.prototype.setListener = function(_listener) {
    this.listener = _listener;
    for(var icon in this.toolIconObjects) {
      if(!this.toolIconObjects[icon].isSeparator) {
        this.toolIconObjects[icon].setListener(_listener);
      }
    }
  }

  /* ツールバーの表示 */
  VwToolBar.prototype.show = function() {

    var divToolBar = '<div style="text-size:4pt;top : 0px;height:28;left : 0px; position : absolute; visibility : hidden;';
    if(this.color) {
      divToolBar += 'background-color :' + this.color + ';';
    }
    divToolBar += 'border-style : solid;border-width : 1px;border-color :gray gray gray gray;"';
    if(this.className) {
      divToolBar += ' class="' + this.className + '"';
    }
    divToolBar += ' id="' + this.id +  '.TOOLBAR">\n';
    divToolBar += ' </div><div style=";top : 0px;left : 0px; position : absolute; visibility : hidden;"';
    divToolBar += ' id="' + this.id +  '.TOOLBAR.ICONS">\n';
    divToolBar += '<table height="20" width="20" cellspacing="2"><tr>';
    var right = 10;
    for(var icon in this.toolIconObjects) {
      if(this.toolIconObjects[icon].isSeparator) {
        divToolBar += '\t\t<td width="8px" height="20" valign="center">';
        if(this.separator.imageSrc) {
          divToolBar += '<img alt="|" src="' + this.separator.imageSrc + '" width="2" height="20">';
        } else {
          divToolBar += '<input type="text" style="width:2px;height:20px;border:1px solid white;border-color:' 
            + LOWERED_BORDERCOLOR + ';margin:0px;padding:0px;">';
        }
        divToolBar += '</td>\n';
      } else {
        if(right < this.toolIconObjects[icon].left + this.toolIconObjects[icon].width) { 
          right = this.toolIconObjects[icon].left + this.toolIconObjects[icon].width;
        }
        divToolBar += '<td height="22px" width="22px">\n';
        divToolBar += '<img style="text-size:4pt;border-style:solid;border-color:' + VwMenuBar_noBorder(this.color) + ';border-width:1px;" ';
        divToolBar += ' width="' + this.toolIconObjects[icon].width +  'px"';
        divToolBar += ' height="' + this.toolIconObjects[icon].height +  'px"';
        divToolBar += ' id="' + this.id +  '.' + this.toolIconObjects[icon].id + '" ';
        divToolBar += ' onmouseover="this.toolIconObject.onMouseOver(this);" ';
        divToolBar += ' onmouseout="this.toolIconObject.onMouseOut(this);"';
        divToolBar += ' onmousedown="this.toolIconObject.onMouseDown(this);" ';
        divToolBar += ' onmouseup="this.toolIconObject.onMouseUp(this);"';
        divToolBar += ' onClick="this.toolIconObject.onClick(this);"';
        divToolBar += ' src="' + this.toolIconObjects[icon].src + '"';
        divToolBar += ' alt="' + this.toolIconObjects[icon].name + '">';
        divToolBar += '</td>\n\n';
      }
    }

    divToolBar += '<tr></table>';
    divToolBar += '</div>\n\n';

    if(this.width < right + 10) {
      this.width = right + 10;
    }
    this.element.innerHTML = divToolBar;
    document.getElementById(this.id + '.TOOLBAR').style.width = this.width;
    document.getElementById(this.id + '.TOOLBAR').style.backgroundColor = this.color;
    
    for(var icon in this.toolIconObjects) {
      if(!this.toolIconObjects[icon].isSeparator) {
        document.getElementById(this.id +  '.' + this.toolIconObjects[icon].id).toolIconObject = this.toolIconObjects[icon];
      }
    }

    document.getElementById(this.id + '.TOOLBAR').style.visibility = 'visible';
    document.getElementById(this.id + '.TOOLBAR.ICONS').style.visibility = 'visible';

    this.instanciated = true;
  }

  /* ツールアイコンの追加 */
  VwToolBar.prototype.addToolIcon = function(_toolIconObject, _left) {
    if(_left) {
      _toolIconObject.left = _left;
    }

    this.toolIconObjects[_toolIconObject.id] = _toolIconObject;
    _toolIconObject.toolBar = this;
    _toolIconObject.setListener(this.listener);

  }

  /* セパレータの追加 */
  VwToolBar.prototype.addSeparator = function(img) {

    this.toolIconObjects['SEPARATOR' + this.separator.count] = this.separator;
    this.separator.count++;
    if(img) {
      this.separator.imageSrc = img;
    }
  }

}

/* ツールアイコン
 *
 */
function VwToolIcon(_menuId, _menuItemId, _src, _caption, _disabledImageSrc) {
  this.id = _menuId + '.' + _menuItemId;
  if(_caption) {
    this.name = _caption;
  } else {
    this.name = this.id;
  }
  this.src = _src;
  this.enabledImageSrc = _src;
  if(_disabledImageSrc) {
    this.disabledImageSrc = _disabledImageSrc;
  } else {
    this.disabledImageSrc = _src;
  }
  this.enabled = true;
   
  this.left = 10;
  this.width = 20;
  this.height = 20;

  this.toolBar = null;
  this.listener = null;
  
  this.separator = new Object();
  this.separator.isSeparator = true;
  this.separator.count = 0;
  
  /* リスナの設定 */
  VwToolIcon.prototype.setListener = function(_listener) {
    this.listener = _listener;
  }
  
  /* アイコンのonMouseOver */
  VwToolIcon.prototype.onMouseOver = function(_element) {
    if(!this.enabled) {
      return;
    }
    _element.style.borderColor = RAISED_BORDERCOLOR;
    _element.style.cursor = 'hand';
  }

  /* アイコンのonMouseOut */
  VwToolIcon.prototype.onMouseOut = function(_element) {
    if(!this.enabled) {
      return;
    }
    _element.style.borderColor = VwMenuBar_noBorder(this.toolBar.color);
    _element.style.cursor = 'auto';
  }

  /* アイコンのonMouseDown */
  VwToolIcon.prototype.onMouseDown = function(_element) {
    if(!this.enabled) {
      return;
    }
    _element.style.borderColor = LOWERED_BORDERCOLOR;
  }

  /* アイコンのonMouseUp */
  VwToolIcon.prototype.onMouseUp = function(_element) {
    if(!this.enabled) {
      return;
    }
    _element.style.borderColor = VwMenuBar_noBorder(this.toolBar.color);
  }

  /* アイコンのonClick */
  VwToolIcon.prototype.onClick = function(_element) {
    if(!this.enabled) {
      return;
    }
    var ids = _element.id.split('.');
    this.listener.action(ids[1],ids[2]);
  }
}

/**
 * 概要　　　文字列のおおよその幅（px）を求める
 * 引数　　　str：幅を求める文字列
 * 戻り値　　文字列の幅（px）
 */
function VwMenuBar_getStringWidth(str){
  var cnt = str.length;
  var chk;
  var width = 0;
  
  if(str == null) return 0;
  
  for(i=0;i<str.length;++i){

      chk = str.charAt(i);

      if(VwMenuBar_isHankaku(chk)){

        if(chk == '.') {
          width += 2;
        } else if(0 == chk.toString().search(/[a-z]/)) {
          // 小文字英字
          width += 6;
        } else {
          // 大文字英字
          width += 8;
        }

      } else { 
        //全角;
        width += 14;
      }
  }
  
  //return cnt * 7;
  return width;
  
  function VwMenuBar_isHankaku(ch) {
      var escstr = escape(ch);
      
      if (escstr == ch){
          
          return true;

      }else if (escstr.length == 3){

          code = escstr.charAt(1) + escstr.charAt(2);
          nm = parseInt(code, 16);

          if (nm > 0 && nm < 127) {
              return true;
          }
      }
      return false;
  }
}

function VwMenuBar_noBorder(color) {
  if(color == '' || color == 'transparent') {
    if(navigator.appName == 'Netscape') {
      return 'transparent';
    } else {
      return '#d2d0cc';
    }
  }
  return color;
}
