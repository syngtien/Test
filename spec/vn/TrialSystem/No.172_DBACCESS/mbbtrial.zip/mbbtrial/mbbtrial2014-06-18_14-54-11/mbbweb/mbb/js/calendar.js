/**
 * カレンダー画面を開く。
 * @param fieldId カレンダー上で選択した日付をセットするテキストボックスのID
 */
function calendarHelp(fieldId) {
	var x=0;
	var y=0;
	var width = 200;
	var height = 220;
	x = parseInt((window.screen.width - width)/2);
	y = parseInt((window.screen.height - height)/2);
	var win = window.open("appcontroller?APPLICATIONID=SysCalendarHelpAp&ID="+fieldId, "calendar", "scrollbars=no,width="+width+",height="+height+",screenX="+x+",screenY="+y+",left="+x+",top="+y);
}


