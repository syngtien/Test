function _getXMLHttp() {
  var xmlhttp;
  try {
    xmlhttp = new ActiveXObject("Msxml2.XMLHTTP");
  } catch (e) {
    try {
      xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
    } catch (E) {
      xmlhttp = false;
    }
  }
  if(!xmlhttp && typeof XMLHttpRequest!='undefined') {
    xmlhttp = new XMLHttpRequest();
  }
  return xmlhttp;
}

function Queue() {
  this._queue = new Array();
}
Queue.prototype.enqueue = function(o) {
  this._queue.push(o);
}
Queue.prototype.dequeue = function() {
  if( this._queue.length > 0 ) {
    return this._queue.shift();
  }
  return null;
}
Queue.prototype.size = function() {
  return this._queue.length;
} 

var _CMD_MOVE      = 0;
var _CMD_DISABLE   = 1;
var _CMD_ENABLE    = 2;
var _CMD_DELETE    = 3;
var _CMD_RENAME    = 4;
var _CMD_ADDITEM   = 5;
var _CMD_ADDFOLDER = 6;

var queue = new Queue();

// 即座にajaxで更新を呼び出すと、連続で呼び出す場合に順番が不安定なのでqueueに溜めて最後に順番に実行する
function doItemUpdate(item, itemKey2, name, cmd) {
  var itemKey1 = item.title;
  var ids1 = itemKey1.split(',');
  var ids2 = itemKey2.split(',');
  var newId = null;
  if(ids2.length<4){
    newId = ids1[0]+','+ids2[2]+','+ids2[0];
  }else{
    newId = ids1[0]+','+ids2[4]+','+ids2[0];
  }
//alert('itemKey1='+itemKey1+';itemKey2='+itemKey2+'; '+item.id+' ---> '+newId);
  item.id = newId;
  if(ids1.length >= 4) {//メニュー参照の場合はtitleの最後にメニューIDを追加する
    item.title = item.id+','+ids1[3];
  } else {
    item.title = item.id;
  }
//alert('itemKey1='+itemKey1+' -> ' + itemKey2);
//return;
  var langid=document.getElementById('_DISPLANGID').value;
  var postdata='PROCESSID=&PAGEID=&JSPID=jsp/SysMenuEdit&_UPDATEKEY1='+itemKey1+'&_UPDATEKEY2='+itemKey2+'&_DISPLANGID='+langid;
  if(cmd == _CMD_DISABLE) {
    postdata=postdata+'&_CMD=disable';
  } else if(cmd == _CMD_ENABLE) {
    postdata=postdata+'&_CMD=enable';
  } else if(cmd == _CMD_DELETE) {
    postdata=postdata+'&_CMD=delete';
  } else if(cmd == _CMD_RENAME) {
    postdata=postdata+'&_CMD=rename&_NAME='+name.replace(/=/g,'＝');
  } else if(name != null){
    postdata=postdata+'&_NAME='+name.replace(/=/g,'＝');
  }
  queue.enqueue(postdata);
}

// queueに溜めた更新対象について更新を実行する
function doItemUpdateFlush() {
  return doUpdateItemPost(queue.dequeue());
}

function doUpdateItemPost(data) {
  var _xmlhttp = _getXMLHttp();
  _xmlhttp.open('POST', 'appcontroller', true);
  _xmlhttp.setRequestHeader('Content-Type' , 'application/x-www-form-urlencoded');
  _xmlhttp.onreadystatechange = function() 
  {
    if(_xmlhttp.readyState == 4) {
      if(_xmlhttp.status == 200) {
        var xmlDoc = _xmlhttp.responseXML;
        var result = xmlDoc.text;
        if(result == 'OK') {
          if(queue.size() > 0) {
            var postdata = queue.dequeue();
            return doUpdateItemPost(postdata);
          }
          return true;
        } else {
          alert(result + '\n更新に失敗しました。再表示をおこなってください。');
          return false;
        }
      }
    }
  }
  _xmlhttp.send(encodeURI(data));
  return true;
}

var selectItem = null;
var targetItem = null;
var targetAbove = false;
var lastSelectedItem = null;

function getParentFolderElement(item) {
  if(item == null) {
    return null;
  }
  item = getItemElement(item);
  if(isFolder(item)) {
    var parent = item.parentNode.parentNode.parentNode.parentNode;
    if(!parent||parent.tagName=='NOBR'||parent.id=='root') {
      // rootの場合はnullを返す
      return null;
    }
    return getFolderElement(parent);
  } else {
    if(item.parentNode&&item.parentNode.parentNode&&item.parentNode.parentNode.parentNode) {
      var folder = item.parentNode.parentNode.parentNode;
      if(folder.id == 'root') {
        return null;
      }
      if(isFolder(folder)||isFolder(folder.childNodes[0])) {
        return getFolderElement(folder);
      }
      if(isFolder(folder.parentNode)) {
        return getFolderElement(folder.parentNode);
      }
      return getFolderElement(folder.parentNode.parentNode);
    }
  }
  return null;
}
// class=folderのSPANタグを返す
function getFolderElement(item) {
  if(isFolder(item)) {
    if(item.tagName=='DIV') {
      if(item.childNodes[0].tagName=='SPAN') {
        return item.childNodes[0];
      } else {
        return item.childNodes[0].childNodes[0];
      }
    } else if(item.tagName=='SPAN'){
      return item;
    }
  } else {
    if(item.tagName=='DIV'&&item.childNodes[0]) {
      if(isFolder(item.childNodes[0])) {
        return getFolderElement(item.childNodes[0]);
      } else if(item.childNodes[0].className=='itemgroup') {
        return getFolderElement(item.childNodes[0].childNodes[0]);
      }
    }
  }
  return null;
}

function getItemElements(folder) {
  if(folder == null) {
    return null;
  }
  if(folder.tagName == 'NOBR') {
    folder = document.getElementById('root');
    return folder.childNodes;
  }
  folder = getFolderElement(folder);
  if(!isFolder(folder)) {
    return null;
  }
  return folder.parentNode.parentNode.childNodes[1].childNodes;
}

// class=itemまたはfolderのSPANタグを返す
function getItemElement(elm) {
  if(!elm||!elm.parentNode) {
    return null;
  }
  if(elm.tagName == 'DIV') {
    if(elm.className=='folder') {
      return elm.childNodes[0];
    } else if(elm.className=='item') {
      return elm.childNodes[0];
    } else if(elm.childNodes[0]) {
      return getItemElement(elm.childNodes[0]);
    }
  } else if(elm.tagName == 'SPAN') {
    if(elm.className == 'folder' || elm.className == 'item') {
      if(!elm.title&&elm.parentNode.title){
        return elm.parentNode;
      }
      return elm;
    } else if(elm.parentNode && elm.parentNode.tagName == 'SPAN'
            && (elm.parentNode.className == 'folder' || elm.parentNode.className == 'item')) {
      return elm.parentNode;
    }
  }
  if(elm.parentNode.parentNode.className=='item') {
    return getItemElement(elm.parentNode.parentNode);
  } else if(elm.parentNode.className=='folder') {
    return getItemElement(elm.parentNode);
  }
  return null;
}

function isFolder(item) {
  if(!item) {
    return false;
  }
  if(item.className=='item') {
    return false;
  } else if(item.className=='folder') {
    return true;
  }
  return false;
}
function isItem(item) {
  if(!item) {
    return false;
  }
  if(item.className=='item') {
    return true;
  } else if(item.className=='folder') {
    return false;
  }
  return false;
}
function isFolderOpened(item) {
  if(!item||!isFolder(item)) {
    return false;
  }
  if(item.tagName=='SPAN'&&item.parentNode&&item.parentNode.parentNode&&item.parentNode.parentNode.className=='itemgroup'){
    if(item.parentNode.parentNode.childNodes[1].style.display=='none') {
      return false;
    }else{
      return true;
    }
  }else{
//    alert(item.outerHTML);
  }
  return false;
}
// folderの中にitemが含まれるかチェック
function isContainsItem(folder, item) {
  var items = getItemElements(folder);
  if(items != null) {
    for (var i=0,j=items.length;i<j;++i){
      var t = getItemElement(items[i]);
      if(t == getItemElement(item)) {
        return true;
      }
      if(isFolder(t)) {
        // フォルダの場合は再帰チェック
        var c = isContainsItem(t, item);
        if(c) {
          return true;
        }
      }
    }
  }
  return false;
}

function removeItem(item) {
  if(isFolder(item)) {
    item = item.parentNode.parentNode;
    if(item.className != 'itemgroup') {
      item = item.parentNode;
    }
  } else {
    item = item.parentNode;
    if(item.className != 'item') {
      item = item.parentNode;
    }
  }
  item.parentNode.removeChild(item);
  return item;
}

// itemをtargetの下へ挿入
function appendItem(target, item) {
  target = getItemElement(target);
  if(isFolder(target)&&isFolderOpened(target)) {
    //フォルダの中へ移動
    var items = getItemElements(getFolderElement(target));
    if(items.length > 0) {
      items[0].parentNode.insertBefore(item, items[0]);
      return;
    } else {
      target.parentNode.parentNode.childNodes[1].appendChild(item);
      return;
    }
  }
  var folder = getParentFolderElement(target);
  var nextItem = getNextItem(target);
  if(nextItem) {
    if(folder == null) {
      // rootの場合
      if(isFolder(nextItem)) {
        nextItem.parentNode.parentNode.parentNode.insertBefore(item, nextItem.parentNode.parentNode);
      } else {
        nextItem.parentNode.parentNode.insertBefore(item, nextItem.parentNode);
      }
    } else {
      if(isFolder(nextItem)) {
        nextItem.parentNode.parentNode.parentNode.insertBefore(item, nextItem.parentNode.parentNode);
      } else {
        nextItem.parentNode.parentNode.insertBefore(item, nextItem.parentNode);
      }
    }
  } else {
    // 次のアイテムが無い場合
    target.parentNode.parentNode.appendChild(item);
  }
}

// itemをtargetの前へ挿入
function insertItem(target, item) {
  var folder = getParentFolderElement(target);
  if(isFolder(getItemElement(target))) {
    // フォルダの前へ挿入
    if(folder == null || folder.tagName == 'NOBR') {
      // ルートアイテムの場合
      if(target.tagName == 'SPAN') {
        // フォルダの前へ追加
        target.parentNode.parentNode.parentNode.insertBefore(item, target.parentNode.parentNode);
        return;
      } else {
        // フォルダの中へ追加
        target.parentNode.insertBefore(item, target);
        return;
      }
    } else {
      // root以外のフォルダ
      var items = getItemElements(folder);
      for (var i=0,j=items.length;i<j;++i){
        if(getItemElement(items[i])==getItemElement(target)){
          if(target.tagName == 'SPAN') {
            target.parentNode.parentNode.parentNode.insertBefore(item, target.parentNode.parentNode);
          } else {
            target.parentNode.insertBefore(item, target);
          }
          return;
        }
      }
    }
  } else {
    target.parentNode.parentNode.insertBefore(item, target.parentNode);
  }
}

function getItemId(elm) {
  return elm.childNodes[0].id;
}

function getNextItem(item) {
  if(item == null) {
    return null;
  }
  item = getItemElement(item);
  var folder = getParentFolderElement(item);
  if(folder == null) {
    // rootの場合
    var parent;
    if(isFolder(item)) {
      parent = item.parentNode.parentNode.parentNode;
    } else {
      parent = item.parentNode.parentNode;
    }
    for(var i=0,j=parent.childNodes.length;i<j-1;++i){
      var child = getItemElement(parent.childNodes[i]);
      if(item == child) {
        return getItemElement(parent.childNodes[i+1]);
      }
    }
    return null;
  }
  //if(getItemElement(folder) == item) {
  //  folder = getParentFolderElement(folder);
  //}
  var items = getItemElements(folder);
  if(items == null) {
    return null;
  }
  for(var i=0,j=items.length;i<j-1;++i) {
    if(getItemElement(items[i])==item) {
      return getItemElement(items[i+1]);
    }
  }
  return null;
}

function getNextItemId(elm) {
  var item = getNextItem(elm);
  if(item != null) {
    return getItemId(item);
  }
  return null;
}

function getPrevItem(item) {
  if(item == null) {
    return null;
  }
  item = getItemElement(item);
  var folder = getParentFolderElement(item);
  if(folder == null) {
    // root配下の場合
    var parent;
    if(isFolder(item)) {
      parent = item.parentNode.parentNode.parentNode;
    } else {
      parent = item.parentNode.parentNode;
    }
    for(var i=1,j=parent.childNodes.length;i<j;++i){
      var child = getItemElement(parent.childNodes[i]);
      if(item == child) {
        return getItemElement(parent.childNodes[i-1]);
      }
    }
    return null;
  }
  if(getItemElement(folder) == item) {
    folder = getParentFolderElement(folder);
  }
  var items = getItemElements(folder);
  if(items == null) {
    return getParentFolderElement(item);
  }
  var lastItem = folder;
  for(var i=0,j=items.length;i<j-1;++i) {
    if(getItemElement(items[i])==item) {
      return lastItem;
    }
    lastItem = getItemElement(items[i]);
  }
  return lastItem;
}

function setItemColor(item, color) {
  if(isFolder(item)) {
    item.childNodes[1].style.color=color;
  } else {
    //item.childNodes[0].childNodes[1].style.color=color;
    item.style.color=color;
  }
}

function selectTargetItem(item, above) {
  if(item == null) {
    return null;
  }
  if(isFolder(item)) {
    if(above) {
      item.parentNode.style.borderTop = 'dashed 1px #808080';
      item.style.borderBottom = '';
    } else {
      item.parentNode.style.borderTop = '';
      item.style.borderBottom = 'dashed 1px #808080';
    }
  } else {
    item.style.borderBottom = 'dashed 1px #808080';
  }
}
function unselectTargetItem(item) {
  if(isFolder(item)) {
    item.parentNode.style.borderTop = '';
  }
  item.style.borderBottom = '';
}

// 移動するアイテムの選択開始
function doDragStart(elm) {
  selectItem = getItemElement(elm);
  setItemColor(selectItem, '#808080');
  doSelectItem(selectItem);
}

function doSelectItem(item) {
  if(lastSelectedItem != null) {
    lastSelectedItem.style.backgroundColor='';
  }
  if(event&&event.ctrlKey&&lastSelectedItem==item) {
    // ctrlキーで再選択された場合は選択解除
    lastSelectedItem = null;
  } else {
    lastSelectedItem = item;
    lastSelectedItem.style.backgroundColor=selectedColor;
  }
}

// 移動中の処理
function doDragMove(elm) {
  if(selectItem == null) {
    return;
  }
  elm = getItemElement(elm);
  if(elm == selectItem) {
    // 選択中のアイテム上
    if(targetItem != null) {
      unselectTargetItem(targetItem);
      targetItem = null;
    }
  } else if(elm == getPrevItem(selectItem)) {
    // 直前のアイテム上
    if(isFolder(elm)) {
      if(event&&event.offsetY) {
        if(event.offsetY < 10) {
          targetAbove = true;
        } else {
          targetAbove = false;
        }
      }
      if(targetItem != null) {
        unselectTargetItem(targetItem);
        targetItem = null;
      }
      targetItem = elm;
      selectTargetItem(targetItem, targetAbove);
    } else {
      if(targetItem != null) {
        unselectTargetItem(targetItem);
        targetItem = null;
      }
    }
  } else {
    // 上記以外のアイテム上
    if(targetItem != elm && selectItem != getNextItem(elm)) {
      // 新しいアイテム上
      if(targetItem != null) {
        unselectTargetItem(targetItem);
      }
      targetItem = elm;
      if(isFolder(selectItem)&&isContainsItem(selectItem, targetItem)) {
        // 自分の階層配下の場合はキャンセル
        unselectTargetItem(targetItem);
        targetItem = null;
        return;
      }
      selectTargetItem(targetItem, false);
    } else if(isFolder(targetItem)) {
      // フォルダ上
      if(event&&event.offsetY) {
        if(event.offsetY < 10) {
          targetAbove = true;
        } else {
          targetAbove = false;
        }
      }
      if(targetItem == getNextItem(selectItem) && targetAbove) {
        // 選択の次のフォルダの前指定の場合
        unselectTargetItem(targetItem);
        targetItem = null;
      } else {
        selectTargetItem(targetItem, targetAbove);
      }
    }
  }
  if(event) {
    // 上下の端で自動スクロール
    if(event.clientY > document.body.offsetHeight - 40) {
      document.body.scrollTop += 10;
    } else if(event.clientY < 30 && document.body.scrollTop > 0) {
      document.body.scrollTop -= 10;
    }
  }
}

// 移動終了
function doDragEnd(item) {
  if(targetItem != null) {
    // 移動
    if(isFolder(selectItem)&&isContainsItem(selectItem, targetItem)) {
      // 自分の階層配下の場合はキャンセル
      unselectTargetItem(targetItem);
      targetItem = null;
      return;
    }
    var oldkeys = selectItem.title.split(',');
    if(isFolder(targetItem)) {
      if(targetAbove) {
        // フォルダの前に移動
        insertItem(targetItem, removeItem(selectItem));
      } else {
        // フォルダの中に移動
        appendItem(targetItem, removeItem(selectItem));
      }
    } else {
      // アイテムの下に移動
      appendItem(targetItem, removeItem(selectItem));
    }
    var keys = targetItem.title.split(',');
    var prev = getNextItem(selectItem);
    var id = null;
    if(getNextItem(selectItem)==null&&getPrevItem(selectItem)==getParentFolderElement(selectItem)){
      // 空フォルダへ移動の場合はIDを変更しない
      id = oldkeys[2];
    } else {
      id = getDefaultNextId(keys[2]); // 推奨のID
    }
    if(document.getElementById(keys[0]+','+keys[1]+','+id)) {
      id = null;
      // 既に使用されていた場合
      if(prev==null){
        // 下のアイテムが無い場合
        if(keys[2]<oldkeys[2]){
          id = oldkeys[2];
        }
      } else {
        // 下のアイテムがある場合
        if(keys[2]<oldkeys[2]&&oldkeys[2]<prev.title.split(',')[2]){
          // ID変更不要
          id = oldkeys[2];
        }
      }
    }
    if (id == null) {
      id = getNewId(selectItem,keys);
    }
    var cnt = 0;
    while (id == null) {
      // 番号に空きが無い場合は、次のアイテムを変更することが可能かチェック
      cnt++;
      var next = getNextItem(prev);
      id = getNewId2(null,prev,next,keys);
      if(id == null) {
        if(next == null) {
          alert('新しい番号が割り振れません！');
          break;
        }
        prev = next;
      } else {
        // 後ろの方で番号が変更できた場合
        while (cnt > 0) {
          updateItem(prev, id);
          next = prev;
          prev = getPrevItem(prev);
          if(prev == selectItem){
            break;
          }
          id = getNewId2(null,prev,next,keys);
          if(id == null) {
            alert('id割当不可：prev=' + prev.title + ',next='+next.title);
          }
          cnt--;
        }
        id = getNewId(selectItem,keys);
        if(id == null) {
          alert('id割当不可：selectItem=' + selectItem.title);
        }
        break;
      }
    }
    updateItem(selectItem, id);
    doItemUpdateFlush();
    selectItem.id=keys[0]+','+keys[1]+','+id;
    selectItem.title=keys[0]+','+keys[1]+','+id;
    unselectTargetItem(targetItem);
    targetItem = null;
  }
  if(selectItem != null) {
    setItemColor(selectItem, '');
    selectItem = null;
  }
}
function updateItem(item, id) {
  if(id==null){
    return;
  }
  var keys = id.split(',');
  item = getItemElement(item);
  var newText = item.innerText.replace(/^ +/,'').replace(/^[^ ]+/,id);
  var parent = getParentFolderElement(item);
  var parentkey = getParentItemKey(item);
  item.childNodes[1].innerHTML='&nbsp;'+newText;
  //alert(item.title+' / ' + id + ',' + parentkey);
  var name = newText.replace(/^[^ ]+ /,'');
  doItemUpdate(item, id+','+parentkey, name, _CMD_MOVE);
}
function getParentItemKey(item) {
  var parent = getParentFolderElement(item);
  var parentkey;
  if(parent&&parent.title) {
    parentkey = parent.title;
  } else {
    // rootにあるアイテムの場合
    parentkey = document.getElementById('COMPANYID').value + ',' + document.getElementById('MENUID').value;
  }
  return parentkey;
}
function getDefaultNextId(id) {
  var prefix = id.replace(/^(\D+)(\d+)$/,'$1');
  prefix=prefix.replace(/^\d+/,'');
  var num = id.replace(/^\D+/,'');
  var numLen = num.length;
  var newnum = '0000000000'+(Number(num)+10);
  return prefix+newnum.substring(newnum.length-numLen);
}
function getNewId(item, keys) {
  if(getNextItem(item)==null&&getPrevItem(item)==getParentFolderElement(item)){
    //空フォルダへ移動の場合は、元のIDそのままを返す
    return item.id.split(',')[2];
  }
  return getNewId2(item, getPrevItem(item), getNextItem(item), keys);
}
function getNewId2(item, previtem, nextitem, keys) {
  var prev = previtem;
  var next = nextitem;
  var prevId = null;
  var nextId = null;
  if(prev) {
    if(prev==getParentFolderElement(item)){ //フォルダ内の先頭の場合
      prevId = '';
      prev=null;
    }else{
      prevId = getMenuItemId(prev);
    }
  }else{
    prev = getParentFolderElement(previtem);
    if(prev) {
      prevId = getMenuItemId(prev);
    } else {
      prevId = '';
    }
  }
  if(next == null) {
    var parent = getParentFolderElement(prev);
    if(parent) {
      next = getNextItem(parent);
    }
  }
  if(next) {
    nextId = getMenuItemId(next);
  } else {
    nextId = '';
  }
  var prefix = prevId.replace(/^(\D+)(\d+)$/,'$1');
  if(prefix == '' || prefix.replace(/\d+/,'') == '') {
    prefix = nextId.replace(/^(\D+)(\d+)$/,'$1');
  }
  var prevNum = getMenuItemNo(prev);
  var nextNum = getMenuItemNo(next);
  var numLen = nextNum.length;
  if(numLen == 0) {
    numLen = prevNum.length;
  }
  if(prefix.replace(/\d+/,'') == '') {
    prefix = '';
  }
  var num1 = null;
  var num2 = null;
  if(prevNum == '') {
    num1 = 0;
  } else {
    num1 = Number(prevNum);
  }
  if(nextNum == '') {
    num2 = Number("9999999999".substring(0,numLen));
  } else {
    num2 = Number(nextNum);
  }
  var numNum = 0;
  if(num1 > num2 && isFolder(prev) && prev==getParentFolderElement(next)) {
    num1 = 0;
  }
  var adj = 0;
  for(var i = 0; i < 10; ++i) {
    if(num2 - num1 < 0) {
      var m = 10;
      for (var x=0;x<numLen&&(((num1 % (m*10)) == 0) && ((num2 % (m*10)) == 0));++x) {
        m *= 10;
      }
      if((num2 % m) != 0) {
        newNum = num2 % m;
      } else {
        newNum = num2 - m;
      }
    } else if(num2 - num1 <= 1) {
      // 間に入らないので後ろをずらす必要がある
      return null;
    } else if(num2 - num1 > 10) {
      var m = 10;
      for (var x=0;x<numLen&&(((num1 % (m*10)) == 0) && ((num2 % (m*10)) == 0));++x) {
        m *= 10;
      }
      if(num1 + m >= num2) {
        if(m > 100) {
          // 間が空いていない場合は桁を落とす
          m /= 10;
        }
      }
      // 10以上間が空く場合は10^n刻みにする
      if(isFolder(prev)&&isItem(next)) {
        // 直前がフォルダで後ろがアイテムの場合はアイテムの前の番号
        if((num2 % m) != 0) {
          newNum = (num2 % m);
        } else {
          newNum = (num2 - m);
        }
      } else {
        newNum = num1 - (num1 % m) + m + adj;
      }
    } else {
      newNum = (num1 + Math.floor((num2 - num1) / 2));
    }
    if(newNum < 0) {
      newNum = 0;
    }
    var newNumx = "000000000"+newNum;
    var newId = prefix + newNumx.substring(newNumx.length-numLen);
    var newKey;
    if(keys.length == 3) {
      newKey = keys[0]+','+keys[1]+','+newId;
    } else {
      newKey = keys[0]+','+keys[3]+','+newId;
    }
    if(document.getElementById(newKey)) {
      // 新しいIDが既に存在する場合
      if(isFolder(prev)) {
        var items = getItemElements(prev);
        if(items.length > 0) {
          prev = getItemElement(items[items.length - 1]);
          var n = getMenuItemNo(prev);
          if(n > num1) {
            num1 = n;
            continue;
          }
        }
      }
      if(isFolder(next)&&(num2-num1>10)) {
        if(num2 % 10 != 0) {
          num2 = num2 % 10;
        } else {
          if(num2 - (num1 - num1 % 10) > 10) {
            num2 = (num1 - num1 % 10) + 10;
          } else {
            num2 = num2 - 10;
          }
        }
        continue;
      }
      adj++;
      continue;
    }
    return newId;
  }
  return null;
}
function getMenuItemId(item) {
  if(item&&item.title) {
    var items = item.title.split(',');
    return items[2];
  }
  return '';
}
function getMenuItemNo(item) {
  if(item&&item.title) {
    var items = item.title.split(',');
    if(items.length >= 3) {
      var id = items[2];
      return id.replace(/^\D+/,'');
    }
  }
  return '';
}
function addNewItem(applicationId, applicationName) {
  var root=document.getElementById('root');
  var firstNode=root.childNodes(0);
  var br=document.createElement('BR');
  var div=document.createElement('DIV');
  var span1=document.createElement('SPAN');
  var text=document.createTextNode('(新規) ' + applicationName);
  if(applicationId!=null) {
    span1.id=document.getElementById('COMPANYID').value+','+document.getElementById('MENUID').value+',,'+applicationId;
  }else{
    span1.id=document.getElementById('COMPANYID').value+','+document.getElementById('MENUID').value+',';
  }
  span1.title=span1.id;
  div.appendChild(span1);
  var img=document.createElement('IMG');
  if(applicationId==null) {
    div.className='folder';
    span1.className='folder';
    img.src=imagefile[0];
  }else{
    div.className='item';
    span1.className='item';
    img.src=imagefile[2];
  }
  var span2=document.createElement('SPAN');
  span2.onselectstart=function(){return false;};
  span2.onmousedown=function(){doDragStart(this);};
  span2.onmousemove=function(){doDragMove(this);};
  span2.onmouseup=function(){doDragEnd(this);};
  span2.appendChild(text);
  span1.appendChild(img);
  span1.appendChild(span2);
  if(applicationId==null){
    var itemgrp=document.createElement('DIV');
    itemgrp.className='itemgroup';
    itemgrp.appendChild(div);
    div = itemgrp;
    var div2=document.createElement('DIV');
    div2.style.display='';
    div.appendChild(div2);
  }
  root.insertBefore(div, firstNode);
  //選択された位置へ移動
  var newItem = getItemElement(div);
  setItemColor(newItem, '#cccc00');
  if(lastSelectedItem != null){
    targetItem=lastSelectedItem;
    selectItem=newItem;
    doDragEnd(newItem);
    doSelectItem(newItem);
  }
}
function addNewFolder() {
  var txt = window.prompt('新規フォルダ名を入力してください','');
  if(txt == null) {
    return true;
  }
  addNewItem(null, txt);
}
var _contextmenu = null;
var _contextmenuitem = null;
var _body_onclick = null;

function showContextMenu(evt) {
  if(!evt)evt=event;
  var elm=evt.srcElement;
  if(!elm&&event.target)elm=evt.target;
  _contextmenuitem=getItemElement(elm);
  if(_contextmenuitem!=null) {
    var disable=false;
    if(_contextmenuitem.childNodes&&_contextmenuitem.childNodes.length==1&&_contextmenuitem.parentNode.id=='root'){
      return false;
    }
    if(_contextmenuitem.childNodes&&_contextmenuitem.childNodes[1].className.match(/disable/)){
      disable=true;
    }
    if(_contextmenu==null){
      _contextmenu = document.createElement('TABLE');
      _contextmenu.id='_contextmenu';
      _contextmenu.className='vw-table';
      _contextmenu.border='0';
      _contextmenu.cellSpacing='0';
      _contextmenu.style.position='absolute';
      _contextmenu.style.width='200px';
      _contextmenu.style.fontSize='10pt';
      _contextmenu.style.backgroundColor='#ffffff';
      _contextmenu.style.borderWidth='1px';
      _contextmenu.style.borderStyle='solid';
      _contextmenu.style.borderColor='#000000';
      document.body.appendChild(_contextmenu);
      var row=_contextmenu.insertRow(0);
      row.insertCell(0);
      row=_contextmenu.insertRow(1);
      row.insertCell(0);
      row=_contextmenu.insertRow(2);
      row.insertCell(0);
      row=_contextmenu.insertRow(3);
      row.insertCell(0);
      row=_contextmenu.insertRow(4);
      row.insertCell(0);
      _body_onclick=document.body.onclick;
      document.body.onclick=function(){_bodyClick();};
    }
    _contextmenu.style.display='';
    _contextmenu.style.left=evt.clientX+document.body.scrollLeft;
    _contextmenu.style.top=evt.clientY+document.body.scrollTop;
    if(disable) {
      _contextmenu.cells[0].innerHTML='<nobr><span class="vw-string cellitem" onclick="contextMenuClick(this,_CMD_ENABLE)" onmouseover="contextMenuFocus(this)" onmouseout="contextMenuBlur(this)">'
         +_contextmenuitem.innerText+' を有効にする</span></nobr>';
    }else{
      _contextmenu.cells[0].innerHTML='<nobr><span class="vw-string cellitem" onclick="contextMenuClick(this,_CMD_DISABLE)" onmouseover="contextMenuFocus(this)" onmouseout="contextMenuBlur(this)">'
         +_contextmenuitem.innerText+' を無効にする</span></nobr>';
     }
    _contextmenu.cells[1].innerHTML='<nobr><span class="vw-string cellitem" onclick="contextMenuClick(this,_CMD_DELETE)" onmouseover="contextMenuFocus(this)" onmouseout="contextMenuBlur(this)">'
       +_contextmenuitem.innerText+' を削除する</span></nobr>';
    _contextmenu.cells[2].innerHTML='<nobr><span class="vw-string cellitem" onclick="contextMenuClick(this,_CMD_RENAME)" onmouseover="contextMenuFocus(this)" onmouseout="contextMenuBlur(this)">'
       +_contextmenuitem.innerText+' の名称を変更する</span></nobr>';
    _contextmenu.cells[3].innerHTML='<nobr><span class="vw-string cellitem" onclick="contextMenuClick(this,_CMD_ADDITEM)" onmouseover="contextMenuFocus(this)" onmouseout="contextMenuBlur(this)">'
       +'新規アプリケーションを追加する</span></nobr>';
    _contextmenu.cells[4].innerHTML='<nobr><span class="vw-string cellitem" onclick="contextMenuClick(this,_CMD_ADDFOLDER)" onmouseover="contextMenuFocus(this)" onmouseout="contextMenuBlur(this)">'
       +'新規フォルダを追加する</span></nobr>';
    
    return false;
  }
  return true;
}
function hideContextMenu() {
  if(_contextmenu){
    _contextmenu.style.display='none';
  }
}
function contextMenuFocus(elm) {
  if(elm){
    if(elm.style.backgroundColor=='') {
      elm.style.backgroundColor='#0000ff';
      elm.style.color='#ffffff';
    }
  }
}
function contextMenuBlur(elm) {
  if(elm){
    elm.style.backgroundColor='';
    elm.style.color='#000000';
  }
}
function contextMenuClick(elm,cmd) {
  var id = _contextmenuitem.id;
  var ids = id.split(',');
  var item = getItemElement(document.getElementById(id));
  var parentKey = getParentItemKey(item);
  hideContextMenu();
  if(cmd == _CMD_DISABLE) { // アイテムを無効化
    if(!confirm(item.innerText+' を無効にします。よろしいですか?')) {
      return true;
    }
    doItemUpdate(item, ids[2]+','+parentKey, null, _CMD_DISABLE);
    if(!item.childNodes[1].className){
      item.childNodes[1].className='disable';
    } else {
      item.childNodes[1].className=item.childNodes[1].className + ' disable';
    }
  } else if(cmd == _CMD_ENABLE) { // 無効化アイテムを有効化
    if(!confirm(item.innerText+' を有効にします。よろしいですか?')) {
      return true;
    }
    doItemUpdate(item, ids[2]+','+parentKey, null, _CMD_ENABLE);
    if(item.childNodes[1].className) {
      if(item.childNodes[1].className=='disable'){
        item.childNodes[1].className='';
      }
    }
  } else if(cmd == _CMD_DELETE) { // アイテムの削除
    if(!confirm(item.innerText+' を削除します。よろしいですか?')) {
      return true;
    }
    doItemUpdate(item, ids[2]+','+parentKey, null, _CMD_DELETE);
    removeItem(item);
    lastSelectedItem=null;
  } else if(cmd == _CMD_RENAME) { // アイテム名の変更
    var oldtitle=item.innerText.replace(/^ [0-9A-Z]+ /,'');
    var txt = window.prompt('メニューアイテム名称を入力してください',oldtitle);
    if(txt == null||txt==oldtitle) {
      return true;
    }
    doItemUpdate(item, ids[2]+','+parentKey, txt, _CMD_RENAME);
    item.childNodes[1].innerText=' '+ids[2]+' '+txt;
  } else if(cmd == _CMD_ADDITEM) { // 新規アイテムの追加
    document.getElementById('additembtn').click(); // 選択したらaddNewItem()が呼び出される
    return true;
  } else if(cmd == _CMD_ADDFOLDER) { // 新規フォルダの追加
    document.getElementById('addfolderbtn').click();
    return true;
  }
  doItemUpdateFlush();
}
function _bodyClick(evt) {
  if(!evt)evt=event;
  var elm=evt.srcElement;
  if(!elm&&event.target)elm=evt.target;
  hideContextMenu();
  if(_body_onclick)_body_onclick();
}
