package sample3;

import java.sql.*;

import jp.co.bbs.unit.item.mst.Table;
import jp.co.bbs.unit.tools.html.*;


public class QRCode extends PageElement {
	
	// �p�����[�^
	private String value = null;
	
	public void setValue(String value) {
		this.value = value;
	}

	public QRCode() {
	}
	
	@Override
	public String toString() {
		int width = getWidth();
		int height = getHeight();
		return "<img id=\"qrcode\" src=\"appcontroller?JSPID=jsp/sample3/QRImage&width=" + width + "&height=" + height + "&value=" + value + "\" alt=\"" + value + "\">";
	}
	
}
