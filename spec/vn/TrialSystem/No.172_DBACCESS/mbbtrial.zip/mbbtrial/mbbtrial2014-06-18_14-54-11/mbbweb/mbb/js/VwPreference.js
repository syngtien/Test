/*
 * VwPreference
 * 環境設定
 */

/*
pref.edit.table.caption          = USE;
pref.edit.table.captionfontsize  = USE;
pref.edit.table.captionfontcolor = USE;
pref.edit.table.captionalign     = USE;
pref.edit.table.cellspacing      = USE;
pref.edit.table.cellpadding      = USE;
pref.edit.table.tdborderwidth    = USE;
pref.edit.table.tdborderstyle    = USE;
pref.edit.table.tdbordercolor    = USE;
pref.edit.table.tdstyle          = USE;
pref.edit.table.cellvisibility   = USE;
pref.edit.table.cellstyle        = USE;
pref.edit.table.onclick          = USE;
pref.edit.table.ondblclick       = USE;
pref.edit.table.onmousedown      = USE;
pref.edit.table.onmouseup        = USE;
pref.edit.table.onmouseover      = USE;
pref.edit.table.onmouseout       = USE;
pref.edit.table.onmousemove      = USE;
pref.edit.table.onkeypress       = USE;
pref.edit.table.onkeydown        = USE;
pref.edit.table.onkeyup          = USE;
pref.edit.table.tableclass       = USE;

pref.edit.string.ondblclick        = USE;
pref.edit.label.ondblclick        = USE;
pref.edit.text.ondblclick      = USE;
pref.edit.text.onmousedown     = USE;
pref.edit.text.onmouseup       = USE;
pref.edit.text.onmouseover     = USE;
pref.edit.text.onmouseout      = USE;
pref.edit.text.onmousemove     = USE;
pref.edit.text.onkeydown       = USE;
pref.edit.text.onkeyup         = USE;
pref.edit.text.onchange        = USE;
pref.edit.textarea.ondblclick      = USE;
pref.edit.textarea.onmousedown     = USE;
pref.edit.textarea.onmouseup       = USE;
pref.edit.textarea.onmouseover     = USE;
pref.edit.textarea.onmouseout      = USE;
pref.edit.textarea.onmousemove     = USE;
pref.edit.textarea.onkeydown       = USE;
pref.edit.textarea.onkeyup         = USE;
pref.edit.file.fontfamily        = USE;
pref.edit.file.ondblclick        = USE;
pref.edit.button.fontfamily      = USE;
pref.edit.button.ondblclick      = USE;
pref.edit.button.onmousedown     = USE;
pref.edit.button.onmouseup       = USE;
pref.edit.button.onmouseover     = USE;
pref.edit.button.onmouseout      = USE;
pref.edit.button.onmousemove     = USE;
pref.edit.button.onkeypress      = USE;
pref.edit.button.onkeydown       = USE;
pref.edit.button.onkeyup         = USE;
pref.edit.check.ondblclick      = USE;
pref.edit.check.onmousedown     = USE;
pref.edit.check.onmouseup       = USE;
pref.edit.check.onmouseover     = USE;
pref.edit.check.onmouseout      = USE;
pref.edit.check.onmousemove     = USE;
pref.edit.check.onkeypress      = USE;
pref.edit.check.onkeydown       = USE;
pref.edit.check.onkeyup         = USE;
pref.edit.check.onchange        = USE;
pref.edit.image.ondblclick      = USE;
pref.edit.radio.onclick         = USE;
pref.edit.combo.fontfamily      = USE;
pref.edit.combo.onfocus         = USE;
pref.edit.combo.onblur          = USE;
pref.edit.list.fontfamily       = USE;
pref.edit.list.onfocus          = USE;
pref.edit.list.onblur           = USE;

pref.edit.radio.backgroundcolorr      = USE;
pref.edit.radio.backgroundcolort      = USE;

pref.edit.check.heightc      = USE;
pref.edit.check.heightt      = USE;
pref.edit.check.backgroundcolort = USE;
pref.edit.check.optionvalue0     = USE;

pref.edit.iframe.style      = USE;

pref.edit.form.groupid      = USE;
pref.edit.form.fieldid      = USE;
pref.edit.label.groupid      = USE;
pref.edit.label.fieldid      = USE;

pref.edit.text.groupid      = USE;
pref.edit.text.fieldid      = USE;

pref.edit.password.groupid      = USE;
pref.edit.password.fieldid      = USE;

pref.edit.textarea.groupid      = USE;
pref.edit.textarea.fieldid      = USE;

pref.edit.file.groupid      = USE;
pref.edit.file.fieldid      = USE;

pref.edit.button.groupid      = USE;
pref.edit.button.fieldid      = USE;

pref.edit.check.groupid      = USE;
pref.edit.check.fieldid      = USE;

pref.edit.hide.groupid      = USE;
pref.edit.hide.fieldid      = USE;

pref.edit.radio.groupid      = USE;
pref.edit.radio.fieldid      = USE;
pref.edit.combo.groupid      = USE;
pref.edit.combo.fieldid      = USE;
pref.edit.list.groupid      = USE;
pref.edit.list.fieldid      = USE;
pref.edit.applet.groupid      = USE;
pref.edit.applet.fieldid      = USE;
pref.edit.embed.groupid      = USE;
pref.edit.embed.fieldid      = USE;
pref.edit.object.groupid      = USE;
pref.edit.object.fieldid      = USE;

pref.edit.applet.name      = USE;
pref.edit.embed.name      = USE;
pref.edit.object.name      = USE;

pref.edit.text.fieldvalue      = EDITTYPE.LONGTEXT;
pref.edit.string.fieldvalue      = EDITTYPE.LONGTEXT;
*/

pref.init.panel.width     = 740;
pref.init.table.width     = 740;
pref.edit.table.tdborderwidth    = USE;
pref.edit.table.tdborderstyle    = USE;
pref.edit.table.tdbordercolor    = USE;
pref.edit.table.tdstyle          = USE;
pref.edit.table.cellstyle        = USE;

pref.edit.check.optionvalue0   = USE;

pref.edit.label.onchange       = USE;
pref.edit.hide.onchange        = USE;
pref.edit.radio.onchange       = USE;
pref.edit.radio.onclick        = USE;
pref.edit.string.onmouseover   = USE;
pref.edit.string.onmouseout    = USE;

pref.edit.string.textid        = USE;
pref.edit.button.textid        = USE;
pref.edit.check.textid         = USE;

pref.edit.label.tooltip        = USE;
pref.edit.table.tableclass     = USE;
