﻿function openSortHelp(sortIDs, orderFieldId, nameFieldId) {
	openHelp('CmSortHelpAp', orderFieldId, nameFieldId, 'OFFICIALNAME', '',
                 '&ORDER='+document.getElementById(orderFieldId).value+'&ORDERITEMIDARRAY='+sortIDs,
                 'width=600,height=450');
}

function makeSelectOption(optionIDs, optionNames, separator) {
    var selectedNo = 1;
    var fieldId = "";
    var type = "";

    var elementSize = document.forms[0].elements.length;
    for (index = 0; index < elementSize; index++) {
        var elementObject = document.forms[0].elements[index];

        if (elementObject.id == "FIELDID_" + selectedNo) {
          fieldId = elementObject.value.split(" ")[0];
        } else if (elementObject.id == "TYPE_" + selectedNo) {
          if (elementObject.value.split(" ").length != 1) {
            type = "DESC";
          } else if (elementObject.value == "DESC") {
            type = "DESC";
          } else {
            type = "";
          }
        } else if (elementObject.id == "ORDERITEM.FIELDID_" + selectedNo) {
             //option要素を親要素に追加する前にすでに子要素があるときはそれを削除.
             var size = elementObject.length;
             for (i = 0; i < size; i++) {
                 elementObject.removeChild(elementObject.childNodes[i]);
             }

             //optionArrayのセパレート.
             var optionIdArray = optionIDs.split(separator);
             var optionNameArray = optionNames.split(separator);

             var size = optionIdArray.length;
             for (i = 0; i < size; i++) { 
                 addingOption = document.createElement('option');
                 elementObject.appendChild(addingOption);

                 //option要素のvalue属性にインデックスの値を設定.
                 addingOption.setAttribute('value', optionIdArray[i]);
                 if (fieldId == optionIdArray[i]) {
                    addingOption.setAttribute('selected', 'true');
                 }

                 //option要素の子要素にobjArray配列の値をテキストとして作成.
                 addingOptionText = document.createTextNode(optionNameArray[i]);

                //作成したテキストを親要素（option）へ追加.
                addingOption.appendChild(addingOptionText);
            }

            //select要素の個数を設定する.
            elementObject.length = size;
        } else if (elementObject.id.indexOf("ORDERITEM.TYPE_" + selectedNo) != -1) {
            if (elementObject.id == "ORDERITEM.TYPE_" + selectedNo) {
               elementObject.value = type;
               selectedNo++;
            } else {
                //昇順・降順の設定.
                if (elementObject.value == type) {
                   elementObject.checked = true;
                }
            }
        }
    }

	return 0;
}

function makeOrder(separator) {
    var orderItemArray = "";
    var alertMessage = "";
    document.forms[0].ORDER.value = "";

    var elementSize = document.forms[0].elements.length;
    for (index = 0; index < elementSize; index++) {
        var elementObject = document.forms[0].elements[index];
        if (elementObject.type.indexOf("select") != -1) {
            if (document.forms[0].ORDER.value.length != 0) {
              document.forms[0].ORDER.value += separator;
            }
            document.forms[0].ORDER.value += elementObject.options[elementObject.selectedIndex].value;

            if (orderItemArray.indexOf(separator + elementObject.options[elementObject.selectedIndex].value + separator) != -1) {
              if (alertMessage.length != 0) {
                alertMessage += separator + " ";
              }
              alertMessage += elementObject.options[elementObject.selectedIndex].text;
            }
            orderItemArray += separator + elementObject.options[elementObject.selectedIndex].value + separator;
        } else if (elementObject.type.indexOf("radio") != -1 && elementObject.checked && elementObject.value == "DESC") {
            document.forms[0].ORDER.value += " DESC";
        }
    }

    if (alertMessage.length != 0) {
      return alert("指定されたソート項目が重複しています.\n\n" + alertMessage);
    }

    return setDataToOpener(document.forms[0].ORDER.value, null);
}
