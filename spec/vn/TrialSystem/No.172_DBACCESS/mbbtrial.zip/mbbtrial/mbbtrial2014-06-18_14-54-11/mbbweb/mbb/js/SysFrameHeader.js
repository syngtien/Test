
var _menustate = 1; // 1:open 0:close;
var _menuwidth = 180;
var _menuinterval;

function doMenuOpenClose(menu) {
  if (_menustate == 1) {
    menu.innerText='メニュー表示';
    _menustate = 0;
    _menuinterval = setInterval("doMenuInterval()", 10);
    menu.blur();
  } else {
    menu.innerText='メニュー非表示';
    _menustate = 1;
    _menuinterval = setInterval("doMenuInterval()", 10);
    menu.blur();
  }
  return false;
}

function doMenuInterval() {
  if (_menustate == 1) {
    if (_menuwidth >= 180) {
      clearInterval(_menuinterval);
    } else {
      _menuwidth += 10;
    }
  } else {
    if (_menuwidth <= 0) {
      clearInterval(_menuinterval);
    } else {
      _menuwidth -= 10;
    }
  }
  parent.document.getElementsByTagName('FRAMESET').item(1).cols = _menuwidth + ',*';
}

function doDefaultAp() {
  parent.main.location = 'appcontroller?APPLICATIONID=SysDefaultAp';
}

function doLogoutAp() {
  var xmlhttp;
  try {
    xmlhttp = new ActiveXObject('Msxml2.XMLHTTP');
  } catch (e) {
    try {
      xmlhttp = new ActiveXObject('Microsoft.XMLHTTP');
    } catch (E) {
      xmlhttp = false;
    }
  }
  if (!xmlhttp && typeof XMLHttpRequest!='undefined') {
    xmlhttp = new XMLHttpRequest();
  }
  try {
    var postdata = 'APPLICATIONID=SysLogout&PROCESSMODE=1';
    postdata = encodeURI(postdata);
    xmlhttp.open('POST', 'appcontroller', true);
    xmlhttp.setRequestHeader('Content-Type' , 'application/x-www-form-urlencoded');
    xmlhttp.send(postdata);
    locked = true;
  } catch (e) {
  }
}
window.onunload=doLogoutAp;
