package sample2;

import java.sql.*;

import jp.co.bbs.unit.item.mst.Table;
import jp.co.bbs.unit.tools.html.*;


public class TableList extends PageElement {
	
	// �p�����[�^
	private String tableId = null;
	
	public void setTableId(String tableId) {
		this.tableId = tableId;
	}

	public TableList() {
	}
	
	@Override
	public String toString() {
		
		HTMLSelectElement select = new HTMLSelectElement(this);
		select.addOption("", "�e�[�u����I�����Ă�������...");
		if (this.tableId != null) {
			String[] tables = this.tableId.split(",");
			for (int i = 0; i < tables.length; ++i) {
				Table table = (Table)newInstance(new Table());
				table.setRawValue(tables[i]);
				select.addOption(tables[i], tables[i] + " " + table.getName("OFFICIALNAME").getRawValue());
			}
		}
		select.setId("tableList");
		select.setAttribute("onchange", "replacePageElement(document.getElementById('tablelayout').childNodes[0],'sample2.TableLayout','tableId='+this.value);");

		return select.toString();
		
	}

	
}
