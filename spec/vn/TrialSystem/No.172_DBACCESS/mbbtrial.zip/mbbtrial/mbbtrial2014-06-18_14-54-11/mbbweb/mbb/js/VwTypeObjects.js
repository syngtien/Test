/**
 * VwTypeObjects
 * 項目TYPE毎のオブジェクト定義
 *
 * @todo 文字列結合回数減らす
 */

/*
 * 全項目TYPEのTypeObject配列 配列
 */

//TypeObjectの生成
// 2003.05.13 VwMasterDataSet.jsのm_ publicInputTypeArrayから項目タイプを取得に変更
/** 全項目タイプのtypeObject */
var m_objType = new Array();
//var tmpTypeLen = m_ publicInputTypeArray.length;
//for(var i=0; i<tmpTypeLen; i++){
//  m_objType[m_ publicInputTypeArray[i]] = new typeObjects(m_ publicInputTypeArray[i]);
//}
for(var typeid in m_objectTypes) {
  m_objType[typeid] = new typeObjects(typeid);
}

//page(form)のTypeObject作成
m_oldCurrentElement = m_currentElement;
m_currentElement = CONSTTEMPFORMID;
m_objType['FORM'] = new typeObjects('FORM');

/**
 * LINKプロパティ設定エレメントのオリジナルのスタイル格納オブジェクト オブジェクト
 */
var m_oldStyle = new Object();

/**
 * 色名と"#FFFFFF"形式のデータ紐付け定義配列 配列
 */
var m_colorTable = new Array();

/**
 * 各項目TYPE毎のtypeObject実装クラス
 * @param  :strType 文字型 項目TYPE文字列
 * @return :
 */

function typeObjects(strType){
  //property
  this.type = strType;

  if(this.type == 'FORM'){
    if(m_currentElement == CONSTTEMPFORMID){
      targetObject = new objectPage();
    }else{
      targetObject = new objectForm();
    }
  }else if(this.type == 'FRAME'){
    targetObject = new objectFrame();
  }else if(this.type == 'PANEL'){
    targetObject = new objectPanel();
  }else if(this.type == 'TABLE'){
    targetObject = new objectTable();
  }else if(this.type == 'COMBO'){
    targetObject = new objectCombo();
  }else if(this.type == 'LIST'){
    targetObject = new objectList();
  }else if(this.type == 'RADIO'){
    targetObject = new objectRadio();
  }else if(this.type == 'BUTTON'){
    targetObject = new objectButton();
  }else if(this.type == 'IMAGE'){
    targetObject = new objectImage();
  }else if(this.type == 'FILE'){
    targetObject = new objectFile();
  }else if(this.type == 'HIDE'){
    targetObject = new objectHide();
  }else if(this.type == 'CHECK'){
    targetObject = new objectCheck();
  }else if(this.type == 'LABEL'){
    targetObject = new objectLabel();
  }else if(this.type == 'STRING'){
    targetObject = new objectString();
  }else if(this.type == 'TEXTAREA'){
    targetObject = new objectTextarea();
  }else if(this.type == 'TEXT'){
    targetObject = new objectText();
  }else if(this.type == 'PASSWORD'){
    targetObject = new objectPassword();
  }else if(this.type == 'APPLET'){
    targetObject = new objectApplet();
  }else if(this.type == 'EMBED'){
    targetObject = new objectEmbed();
  }else if(this.type == 'OBJECT'){
    targetObject = new objectObject();
  }else if(this.type == 'SUBMIT'){
    targetObject = new objectSubmit();
  }else if(this.type == 'RESET'){
    targetObject = new objectReset();
  }else if(this.type == 'IFRAME'){
    targetObject = new objectIframe();
  }

  this.targetObj = targetObject;
  this.customProperties = targetObject.customProperties;

  if(targetObject.defaultvaluePropertyId) {
    this.defaultvaluePropertyId = targetObject.defaultvaluePropertyId;
  }

  //public method
  typeObjects.prototype.createPropertyTable   = fnCreatePropertyTable;
  typeObjects.prototype.setPropertyTable      = fnSetPropertyTable;
  typeObjects.prototype.setDefaultProperty    = fnSetDefaultProperty;
  typeObjects.prototype.getPropertiesHtml     = fnGetPropertiesHtml;

  //プロパティテーブル作成
  function fnCreatePropertyTable(elementId, tdElementId){

    var strTblHead = '<table id="fld_createPropTable" border="1" cellspacing="0" cellpadding="0" width="200px" style="table-layout:fixed; font-size:9pt; border-top:0px;">';
    var strTblBody = this.targetObj.createPropertyTable(elementId, tdElementId);
    var strTblFoot = '</table>';
    document.getElementById('fld_showPropertyTable_div_type').innerHTML = strTblHead + strTblBody + strTblFoot;

    // ## カスタマイズ時：全プロパティ非表示時、「プロパティ」以下を全て非表示にする
    if(parseInt(m_monitorEditStatus) == 2){
      var tmpJudgeFlg = false;
      var docNodes = document.getElementById('fld_createPropTable').childNodes.item(0).childNodes;
      var childLen = docNodes.length;
      for(var i=0; i<childLen; i++){
        if(docNodes.item(i).style.display != 'none'){
          tmpJudgeFlg = true;
        }
      }
      if(!tmpJudgeFlg){
        document.getElementById('fld_property_head_td').style.display           = 'none';
        document.getElementById('fld_showPropertyTable_div').style.display      = 'none';
        document.getElementById('fld_showPropertyTable_div_type').style.display = 'none';
      }else{
        document.getElementById('fld_property_head_td').style.display           = '';
        document.getElementById('fld_showPropertyTable_div').style.display      = '';
        document.getElementById('fld_showPropertyTable_div_type').style.display = '';
      }
      //カスタマイズ可能時、disabled解除
      var tmpObjCustomSet = m_objDataSet[elementId].getCustomizableItems();
      if(tmpObjCustomSet.mobility){
        _setElementAttribute('fld_customize-mobility', 'disabled', false);
      }
      if(tmpObjCustomSet.visibility){
        _setElementAttribute('fld_customize-visibility', 'disabled', false);
      }
      if(tmpObjCustomSet.defaultvalue){
        _setElementAttribute('fld_customize-defaultvalue', 'disabled', false);
      }
      if(tmpObjCustomSet.maxlines){
        _setElementAttribute('fld_customize-maxlines', 'disabled', false);
      }
    }

  }
  
  // 
  function _setElementAttribute(id, attname, value) {
    var element = document.getElementById(id);
    if(element && element[attname]) {
      element[attname] = value;
    }
  }

  //デフォルトプロパティセット
  function fnSetDefaultProperty(strId){
    this.targetObj.setDefaultProperty(strId);
  }

  //HTML文字列作成
  function fnGetPropertiesHtml(objDs){
    return this.targetObj.getPropertiesHtml(objDs);
  }

}

/**
 * Page情報を含むFormタイプのtypeObject実装クラス
 * @param  :
 * @return :作成したHTML文字列
 */
function objectPage(){
  this.customProperties        = new Array();
  this.customPropertiesLiteral = new Array();

  objectPage.prototype.createPropertyTable = fnCreatePropertyTable;
  objectPage.prototype.setDefaultProperty  = fnSetDefaultProperty;
  objectPage.prototype.getPropertiesHtml   = fnGetPropertiesHtml;

  function fnCreatePropertyTable(elementId){

    // ## 表示・非表示
    var dispFlg = true;
    if(parseInt(m_monitorEditStatus) == 2){
      dispFlg = false;
    }

    var rtnHTML  = '';
        rtnHTML += createTextTypeProperty('property.pagetitle', 'pagecaption', 'left', 'auto', dispFlg);
        rtnHTML += createTextTypeProperty('property.pagewidth_px', 'pagewidth', 'right', 'disabled', dispFlg);
        rtnHTML += createTextTypeProperty('property.pageheight_px', 'pageheight', 'right', 'disabled', dispFlg);
        rtnHTML += createColorTypeProperty('property.backgroundcolor', 'stylebgcolor', dispFlg);
        rtnHTML += createImageNameProperty('property.backgroundimage', 'background', dispFlg);
        rtnHTML += createLongStringProperty('property.action', 'action', dispFlg);
        rtnHTML += createSelectTypeProperty('property.method', 'method', m_methodDefArray, false, dispFlg);
        rtnHTML += createTextTypeProperty('property.target', 'target', 'left', 'disabled', dispFlg);
        rtnHTML += createSelectTypeProperty('property.enctype', 'enctype', m_enctypeDefArray, false, dispFlg);
        rtnHTML += createColorTypeProperty('property.textcolor', 'textcolor', dispFlg);
        rtnHTML += createColorTypeProperty('property.linkcolor', 'linkcolor', dispFlg);
        rtnHTML += createColorTypeProperty('property.vlinkcolor', 'vlinkcolor', dispFlg);
        rtnHTML += createColorTypeProperty('property.alinkcolor', 'alinkcolor', dispFlg);
        rtnHTML += createLongStringProperty('property.style', 'style', dispFlg);
        rtnHTML += createEventTypeProperty('property.onload', 'onload', dispFlg);
        rtnHTML += createEventTypeProperty('property.onunload', 'onunload', dispFlg);
        rtnHTML += createEventTypeProperty('property.onsubmit', 'onsubmit', dispFlg);
        rtnHTML += createEventTypeProperty('property.onreset', 'onreset', dispFlg);
        rtnHTML += createButtonTypeProperty('property.jsfile', 'jsfilename', 'jsfileOpen()', dispFlg);
    return rtnHTML;

  }

  function fnSetDefaultProperty(strId){
    var objDS = m_objDataSet[strId];
    objDS.setProperty('pageheight', CONSTPAGEHEIGHT);
    objDS.setProperty('pagewidth', CONSTPAGEWIDTH);
    objDS.setProperty('action', CONSTACTIONDEFVALUE);
    objDS.setProperty('method', CONSTMETHODDEFVALUE);
  }

  function fnGetPropertiesHtml(objDs){
    return;
  }

}

/**
 * FormタイプのtypeObject実装クラス
 * @param  :
 * @return :作成したHTML文字列
 */
function objectForm(){
  this.customProperties        = new Array();
  this.customPropertiesLiteral = new Array();

  objectForm.prototype.createPropertyTable = fnCreatePropertyTable;
  objectForm.prototype.setDefaultProperty  = fnSetDefaultProperty;
  objectForm.prototype.getPropertiesHtml   = fnGetPropertiesHtml;

  function fnCreatePropertyTable(elementId){

    // ## 表示・非表示
    var dispFlg = true;
    if(parseInt(m_monitorEditStatus) == 2){
      dispFlg = false;
    }

    var rtnHTML  = '';
        rtnHTML += createLongStringProperty('property.action', 'action', dispFlg);
        rtnHTML += createSelectTypeProperty('property.method', 'method', m_methodDefArray, false, dispFlg);
        rtnHTML += createTextTypeProperty('property.target', 'target', 'left', 'disabled', dispFlg);
        rtnHTML += createSelectTypeProperty('property.enctype', 'enctype', m_enctypeDefArray, false, dispFlg);
        rtnHTML += createEventTypeProperty('property.onload', 'onload', dispFlg);
        rtnHTML += createEventTypeProperty('property.onunload', 'onunload', dispFlg);
    return rtnHTML;
  }

  function fnSetDefaultProperty(strId){
    var objDS = m_objDataSet[strId];
    objDS.setProperty('action', CONSTACTIONDEFVALUE);
    objDS.setProperty('method', CONSTMETHODDEFVALUE);
  }

  function fnGetPropertiesHtml(objDs){
    return;
  }

}

/**
 * FrameタイプのtypeObject実装クラス
 * @param  :
 * @return :作成したHTML文字列
 */
function objectFrame(){
  this.customProperties        = new Array();
  this.customPropertiesLiteral = new Array();

  objectFrame.prototype.createPropertyTable = fnCreatePropertyTable;
  objectFrame.prototype.setDefaultProperty  = fnSetDefaultProperty;
  objectFrame.prototype.getPropertiesHtml   = fnGetPropertiesHtml;

  function fnCreatePropertyTable(elementId){
    return '';
  }

  function fnSetDefaultProperty(){
    return;
  }

  function fnGetPropertiesHtml(objDs){
    return;
  }

}

/**
 * PanelタイプのtypeObject実装クラス
 * @param  :
 * @return :作成したHTML文字列
 */
function objectPanel(){
  this.customProperties        = new Array('customize-visibility');
  this.customPropertiesLiteral = new Array('visibility');

  objectPanel.prototype.createPropertyTable = fnCreatePropertyTable;
  objectPanel.prototype.setDefaultProperty  = fnSetDefaultProperty;
  objectPanel.prototype.getPropertiesHtml   = fnGetPropertiesHtml;

  function fnCreatePropertyTable(elementId){

    // ## 表示・非表示
    var dispFlg = true;
    if(parseInt(m_monitorEditStatus) == 2){
      dispFlg = false;
    }

    var rtnHTML  = '';
        rtnHTML += createTextTypeProperty('property.width_px', 'width', 'right', 'disabled', dispFlg);
        rtnHTML += createTextTypeProperty('property.height_px', 'height', 'right', 'disabled', dispFlg);
        rtnHTML += createColorTypeProperty('property.bordercolor', 'bordercolor', dispFlg);
        rtnHTML += createColorTypeProperty('property.backgroundcolor', 'bgcolor', dispFlg);
        rtnHTML += createImageNameProperty('property.backgroundimage', 'background', dispFlg);
        rtnHTML += createCustomCheckProperty(this.customProperties, this.customPropertiesLiteral);
    return rtnHTML;
  }

  function fnSetDefaultProperty(strId){
    var objDS = m_objDataSet[strId];
    var defTblPnlWidth = parseInt(m_objDataSet[CONSTTEMPFORMID].getProperty('pagewidth')) - 40;
    objDS.setProperty('width', defTblPnlWidth);
    objDS.setProperty('height', CONSTPANELHEIGHT);
    objDS.setProperty('bordercolor', CONSTPANELBORDERCOLOR);
    objDS.setProperty('visibility', CONSTDEFAULTVISIBILITY);
    objDS.setProperty('customize-mobility', 'disabled');
    objDS.setProperty('customize-visibility', 'disabled');
  }

  function fnGetPropertiesHtml(objDs){
    var strCursor  = getCursorType(objDs);
    var strBgcolor = getBgcolorType(objDs, 1);
    var strBorderColor = objDs.getProperty('bordercolor');

    if(-1 < strBgcolor.indexOf('<%')) {
      strBgcolor = '';
    }

    if(-1 < strBorderColor.indexOf('<%')) {
      strBorderColor = '';
    }

    var strHTML  = '<TABLE border="1"'
      + ' id="' + objDs.getProperty('id') + '"'
      + ' width="' + objDs.getProperty('width') + 'px"'
      + ' height="' + objDs.getProperty('height') + 'px"'
      + ' bgcolor="' + strBgcolor + '"'
      + ' cellspacing="0" cellpadding="0"'
      + ' style="cursor:' + strCursor + ';'
      + 'border-color:' + strBorderColor + ';';
    if(CONSTPREVIEWBACKGROUNDIMAGE) {
      strHTML += 'background-image:url(' + objDs.getProperty('background') + ');';
    }
    strHTML += '"><TR><TD>&nbsp;</TD></TR></TABLE>';

    return strHTML;
  }

}

/**
 * TableタイプのtypeObject実装クラス
 * @param  :
 * @return :作成したHTML文字列
 */
function objectTable(){
  this.customProperties        = new Array('customize-visibility', 'customize-maxlines');
  this.customPropertiesLiteral = new Array('visibility', 'maxlines');

  objectTable.prototype.createPropertyTable = fnCreatePropertyTable;
  objectTable.prototype.setDefaultProperty  = fnSetDefaultProperty;
  objectTable.prototype.getPropertiesHtml   = fnGetPropertiesHtml;

  function fnCreatePropertyTable(elementId,tdElementId){

    // ## 編集モードによる表示切替
    var tmpDisplayString = '';
    var strFuncParaDispFlg = true;
    if(parseInt(m_monitorEditStatus) == 2){
      tmpDisplayString = 'none';
      strFuncParaDispFlg = false;
    }

    var rtnHTML  = '<tr style="display:' + tmpDisplayString + ';"><td width="100px">' + getLiteral('property.tablemode');
        rtnHTML += '</td><td width="100px"><select id="fld_mode" style="width:100%; font-size: 9pt;" onchange="changeTableMode(this.value, true)" onfocus="setCurrentPropId(this.id)"><option value="MODE_SIMPLE">';
        rtnHTML += getLiteral('tablemode.simple');
        rtnHTML += '</option><option value="MODE_COPY">' + getLiteral('tablemode.copy');
        rtnHTML += '</option><option value="MODE_LINE">' + getLiteral('tablemode.line');
        rtnHTML += '</option></select></td></tr>';
        rtnHTML += createTextTypeProperty('property.colsize', 'maxcols', 'right', 'disabled', strFuncParaDispFlg);
        rtnHTML += '<tr id="fld_maxrows_tr" style="display:' + tmpDisplayString + ';"><td width="100px">';
        rtnHTML += getLiteral('property.rowsize');
        rtnHTML += '</td><td width="100px"><input type="text" id="fld_maxrows" style="font-size: 9pt; width:98px; text-align:right; ime-mode:disabled;" onchange="setStyle(this.id, this.value, \'' + elementId + '\',\'' + tdElementId + '\',\'' + tdElementId + '\')" onfocus="setCurrentPropId(this.id)" onselectstart="selectableOnSelectStart(event)"></td></tr>';

        // ## カスタマイズ時：行数カスタマイズの可否による制御
        var tmpDispStr = 'none';
        if(parseInt(m_monitorEditStatus) == 2){
          var tmpLineFlg = m_objDataSet[m_currentElement].getCustomizableItems().maxlines;
          if(tmpLineFlg){
            tmpDispStr = '';
          }
        }
        rtnHTML += '<tr id="fld_maxlines_tr" style="display:' + tmpDispStr + ';"><td width="100px">';
        rtnHTML += getLiteral('property.rowsize');
        rtnHTML += '</td><td width="100px"><input type="text" id="fld_maxlines" style="font-size: 9pt; width:98px; text-align:right; ime-mode:disabled;" onchange="setStyle(this.id, this.value, \'' + elementId + '\',\'' + tdElementId + '\')" onfocus="setCurrentPropId(this.id)" onselectstart="selectableOnSelectStart(event)"></td></tr>';
        rtnHTML += createTextTypeProperty('property.borderwidth', 'borderwidth', 'right', 'disabled', strFuncParaDispFlg);
        rtnHTML += '<tr style="display:' + tmpDisplayString + ';"><td width="100px">';
        rtnHTML += getLiteral('property.borderstyle');

        rtnHTML += '</td><td width="100px"><select id="fld_borderstyle" style="width:100%; font-size: 9pt;" onfocus="setCurrentPropId(this.id)" onchange="setStyle(this.id, this.value, \'' + elementId + '\',\'' + tdElementId + '\',\'' + tdElementId + '\')">';
        rtnHTML += getOptionHtml('borderstyle', m_borderstyleDefArray);
        rtnHTML += '</select></td></tr>';

        rtnHTML += createColorTypeProperty('property.bordercolor', 'bordercolor', strFuncParaDispFlg);
        rtnHTML += createColorTypeProperty('property.backgroundcolor', 'bgcolor', strFuncParaDispFlg);
        rtnHTML += createImageNameProperty('property.backgroundimage', 'background', strFuncParaDispFlg);
        rtnHTML += '<tr id="fld_maxrows_td_tr" style="display:' + tmpDisplayString + ';"><td width="100px">';
        rtnHTML += getLiteral('property.cellrow');
        rtnHTML += '</td><td width="100px"><input type="text" id="fld_tdrow" style="cursor:default; font-size: 9pt; width:98px; text-align:right;" readonly></td></tr>';
        rtnHTML += '<tr id="fld_maxrows_td_tr" style="display:' + tmpDisplayString + ';"><td width="100px">';
        rtnHTML += getLiteral('property.cellcol');
        rtnHTML += '</td><td width="100px"><input type="text" id="fld_tdcol" style="cursor:default; font-size: 9pt; width:98px; text-align:right;" readonly></td></tr>';

        rtnHTML += createTextTypeProperty('property.cellwidth_px', 'tdwidth', 'right', 'disabled', strFuncParaDispFlg);
        rtnHTML += createTextTypeProperty('property.cellheight_px', 'tdheight', 'right', 'disabled', strFuncParaDispFlg);
        rtnHTML += createColorTypeProperty('property.cellbordercolor', 'tdbordercolor', strFuncParaDispFlg);
        rtnHTML += createColorTypeProperty('property.cellbackgroundcolor', 'tdbgcolor', strFuncParaDispFlg);
        rtnHTML += createImageNameProperty('property.cellbackgroundimage', 'tdbackground', strFuncParaDispFlg, tdElementId);
        rtnHTML += createCustomCheckProperty(this.customProperties, this.customPropertiesLiteral);

    return rtnHTML;
  }

  function fnSetDefaultProperty(strId){
    var objDS = m_objDataSet[strId];
    var objDSTD = m_objDataSet[strId + '_td_1_1'];
    var defTblPnlWidth = parseInt(m_objDataSet[CONSTTEMPFORMID].getProperty('pagewidth')) - 40;
    objDS.setProperty('maxcols', CONSTTABLEMAXCOLS);
    objDS.setProperty('mode', CONSTTABLEMODE);
    objDS.setProperty('maxrows', CONSTTABLEMAXROWS);
    objDS.setProperty('borderwidth', CONSTTABLEBORDERWIDTH);
    objDS.setProperty('borderstyle', CONSTTABLEBORDERSTYLE);
    objDSTD.setProperty('tdwidth', defTblPnlWidth);
    objDSTD.setProperty('tdheight', CONSTTDHEIGHT);
    objDSTD.setProperty('parenttableid', strId);
    objDS.setProperty('visibility', CONSTDEFAULTVISIBILITY);
    objDS.setProperty('customize-mobility', 'disabled');
    objDS.setProperty('customize-visibility', 'disabled');
  }

  function fnGetPropertiesHtml(objDs){

    //TABLEのID取得
    var tmpTblId = objDs.getProperty('id');

    //作成する行数、列数取得
    var createCols = objDs.getProperty('maxcols');
    if(objDs.getProperty('mode') == 'MODE_SIMPLE'){
      var createRows = objDs.getProperty('maxrows');
    }else{
      var createRows = 1;
    }

    var strBgcolor = getBgcolorType(objDs, 1);
    var strCursor  = getCursorType(objDs);

    var bordercolor = objDs.getProperty('bordercolor');
    if(bordercolor != '' && -1 == bordercolor.indexOf('<%')){
    } else {
      bordercolor = '#000000';
    }
    
    var hiddenColor = '';
    if(objDs.getProperty('visibility') == 'hidden'){
      hiddenColor =       ' BGCOLOR="' + CONSTHIDDENCOLOR + '" ';
    }
    
    //TABLEとTDPANELのm_objDataSetからHTML文字列作成
    var strHTML = '';
    strHTML += '<TABLE ID="' + tmpTblId;

    if(-1 == strBgcolor.indexOf('<%')) {
      strHTML +=  '" BGCOLOR="' + strBgcolor;
    }

    strHTML +=  '" BORDER="1" cellspacing="0" cellpadding="0" ';
    strHTML +=  'STYLE="cursor:' + strCursor + '; border-collapse:collapse; border-style:solid; border-color:';
    strHTML +=         bordercolor;
    strHTML +=   ';font-size:1px;';
    if(CONSTPREVIEWBACKGROUNDIMAGE) {
      strHTML += 'background-image:url(' + objDs.getProperty('background') + ');';
    }
    strHTML += '"><CAPTION ID="' + tmpTblId + '_caption_top"></CAPTION><TBODY>';

    var windowStatusKeep = window.status;
    for(var i=1; i<=createRows; i++){
      strHTML +=   '<TR>';

      for(var j=1; j<=createCols; j++){
        var tmpHtml = '';
        window.status = windowStatusKeep + ' (行:' + i + ' 列:' + j + ')';
        //TDPANELのID生成
        var tmpTdPanelId = tmpTblId + '_td_' + i + '_' + j;
        //TDPANELのdataSetObject保存
        var tmpTdObjDS   = m_objDataSet[tmpTdPanelId];

        tmpHtml +=   '<TD STYLE="border-color:' + bordercolor + ';">'
                +  '<TABLE ID="' + tmpTdPanelId + '" ';

        if(hiddenColor != ''){
          tmpHtml +=       hiddenColor;
        }else{

          var bgcolor = tmpTdObjDS.getProperty('tdbgcolor');
          if(-1 == bgcolor.indexOf('<%')) {
            tmpHtml +=       'BGCOLOR="' + bgcolor + '" ';
          }
        }

        tmpHtml +=       'cellspacing="0" cellpadding="0" ';

        var tdbordercolor = tmpTdObjDS.getProperty('tdbordercolor');
        if(-1 < tdbordercolor.indexOf('<%')) {
          tdbordercolor = 'silver';
        }

        if(tdbordercolor != ''){
          tmpHtml += 'WIDTH="' + (parseInt(tmpTdObjDS.getProperty('tdwidth')) - 1) + 'px" '
                  + 'HEIGHT="' + (parseInt(tmpTdObjDS.getProperty('tdheight')) - 1) + 'px" '
                  + 'BORDER="1" BORDERCOLOR="' + tdbordercolor + '" ';
        }else{
          tmpHtml += 'WIDTH="' + (parseInt(tmpTdObjDS.getProperty('tdwidth')) - 1) + 'px" '
                  +  'HEIGHT="' + (parseInt(tmpTdObjDS.getProperty('tdheight')) - 1) + 'px" '
                  +  'BORDER="0" ';
        }

        tmpHtml += 'STYLE="cursor:' + strCursor + '; border-collapse:collapse;font-size:1px;';
        if(CONSTPREVIEWBACKGROUNDIMAGE) {
          tmpHtml += 'background-image:url(' + tmpTdObjDS.getProperty('tdbackground') + ');';
        }
        tmpHtml += '"><TR><TD>&nbsp;</TD></TR></TABLE></TD>';

        strHTML += tmpHtml;
      }
      strHTML +=   '</TR>';
    }
    strHTML +=   '</TBODY></TABLE>';

    window.status = windowStatusKeep;
    return strHTML;
  }

}

/**
 * ComboタイプのtypeObject実装クラス
 * @param  :
 * @return :作成したHTML文字列
 */
function objectCombo(){
  this.customProperties        = new Array('customize-visibility', 'customize-mobility', 'customize-defaultvalue');
  this.customPropertiesLiteral = new Array('visibility', 'location', 'initialvalue');
  this.defaultvaluePropertyId  = 'value';

  objectCombo.prototype.createPropertyTable = fnCreatePropertyTable;
  objectCombo.prototype.setDefaultProperty  = fnSetDefaultProperty;
  objectCombo.prototype.getPropertiesHtml   = fnGetPropertiesHtml;

  function fnCreatePropertyTable(elementId){

    // ## 表示・非表示
    var dispFlg = true;
    if(parseInt(m_monitorEditStatus) == 2){
      dispFlg = false;
    }

    var rtnHTML  = '';
        rtnHTML += createTextTypeProperty('property.width_px', 'stylewidth', 'right', 'disabled', dispFlg);
        rtnHTML += createTextTypeProperty('property.height_px', 'styleheight', 'right', 'disabled', dispFlg);

        if(!dispFlg){
          rtnHTML += createTextTypeProperty('property.initialvalue', 'value', 'left', 'auto', m_objDataSet[elementId].getCustomizableItems().defaultvalue);
        }else{
          rtnHTML += createTextTypeProperty('property.initialvalue', 'value', 'left', 'auto', dispFlg);
        }

        rtnHTML += createButtonTypeProperty('property.selection', 'option', 'optionOpen()', dispFlg);
        rtnHTML += createTextTypeProperty('property.fontsize_pt', 'fontsize', 'right', 'disabled', dispFlg);
        rtnHTML += createColorTypeProperty('property.fontcolor', 'fontcolor', dispFlg);
        rtnHTML += createColorTypeProperty('property.backgroundcolor', 'stylebgcolor', dispFlg);
        rtnHTML += createSelectTypeProperty('property.accesskey', 'accesskey', m_accessKeyDefArray, false, dispFlg);
        rtnHTML += createLongStringProperty('property.style', 'style', dispFlg);
        rtnHTML += createEventTypeProperty('property.onchange', 'onchange', dispFlg);
        rtnHTML += createCustomCheckProperty(this.customProperties, this.customPropertiesLiteral);
    return rtnHTML;
  }

  function fnSetDefaultProperty(strId){
    var objDS = m_objDataSet[strId];
    objDS.setProperty('stylewidth', CONSTCOMBOWIDTH);
    objDS.setProperty('visibility', CONSTDEFAULTVISIBILITY);
    objDS.setProperty('customize-mobility', 'disabled');
    objDS.setProperty('customize-visibility', 'disabled');
    objDS.setProperty('customize-defaultvalue', 'disabled');
    objDS.setProperty('fontsize', CONSTDEFAULTFONTSIZE);
  }

  function fnGetPropertiesHtml(objDs){

    var strComboId = objDs.getProperty('id');
    var strBgcolor = getBgcolorType(objDs, 0);
    var strCursor  = getCursorType(objDs);
    if(-1 < strBgcolor.indexOf('<%')) {
      strBgcolor = 'white';
    }
    var strHTML = '';
    strHTML += '<table cellspacing="0" cellpadding="0" id="' + strComboId + '"';
    strHTML +=   ' style="width:' + objDs.getProperty('stylewidth') + 'px;">';
    strHTML +=     '<tr><td id="' + strComboId + '_SETWIDTH" align="right" ';
    strHTML +=         'style="cursor:' + strCursor + '; ';
    if(strBgcolor == ''){
      strHTML +=       'background-color:white; ';
    }else{
      strHTML +=       'background-color:' + strBgcolor + '; ';
    }
    strHTML +=         'width:100%; height:0px; border:2px inset white;">';
    strHTML +=       '<table cellspacing="0" cellpadding="0"><tr>';
    strHTML +=           '<td id="' + strComboId + '_SETSIZE" ';
    if(objDs.getProperty('fontsize').length != 0){
      strHTML +=               'style="font-size : ' + objDs.getProperty('fontsize') + 'pt;';
    }else{
      strHTML +=               'style="font-size : ' + CONSTCOMBOVIEWFONTSIZE + 'pt;';
    }
    strHTML +=           '">&nbsp;</td><td id="' + strComboId + '_SETHEIGHT" valign="center" align="center" ';
    strHTML +=               'style="background-color:silver; width:14px; ';
    strHTML +=               'height:' + objDs.getProperty('styleheight') + 'px; ';
    strHTML +=               'border:2px outset white;">';
    strHTML +=             '<img src="' + CONSTCOMBOIMAGE + '"></td></tr></table></td></tr></table>';
    return strHTML;
  }

}

/**
 * ListタイプのtypeObject実装クラス
 * @param  :
 * @return :作成したHTML文字列
 */
function objectList(){
  this.customProperties        = new Array('customize-visibility', 'customize-mobility', 'customize-defaultvalue');
  this.customPropertiesLiteral = new Array('visibility', 'location', 'initialvalue');
  this.defaultvaluePropertyId = 'value';

  objectList.prototype.createPropertyTable = fnCreatePropertyTable;
  objectList.prototype.setDefaultProperty  = fnSetDefaultProperty;
  objectList.prototype.getPropertiesHtml   = fnGetPropertiesHtml;

  function fnCreatePropertyTable(elementId){

    // ## 表示・非表示
    var dispFlg = true;
    if(parseInt(m_monitorEditStatus) == 2){
      dispFlg = false;
    }

    var rtnHTML  = '';
        rtnHTML += createTextTypeProperty('property.width_px', 'stylewidth', 'right', 'disabled', dispFlg);
        rtnHTML += createTextTypeProperty('property.height_px', 'styleheight', 'right', 'disabled', dispFlg);

        if(!dispFlg){
          rtnHTML += createTextTypeProperty('property.initialvalue', 'value', 'left', 'auto', m_objDataSet[elementId].getCustomizableItems().defaultvalue);
        }else{
          rtnHTML += createTextTypeProperty('property.initialvalue', 'value', 'left', 'auto', dispFlg);
        }


        rtnHTML += createCheckTypeProperty('property.selectmode', 'multiple', 'true', 'selectmode.multiple', dispFlg);
        rtnHTML += createButtonTypeProperty('property.selection', 'option', 'optionOpen()', dispFlg);
        rtnHTML += createTextTypeProperty('property.listsize', 'size', 'right', 'disabled', dispFlg);
        rtnHTML += createTextTypeProperty('property.fontsize_pt', 'fontsize', 'right', 'disabled', dispFlg);
        rtnHTML += createColorTypeProperty('property.fontcolor', 'fontcolor', dispFlg);
        rtnHTML += createColorTypeProperty('property.backgroundcolor', 'stylebgcolor', dispFlg);
        rtnHTML += createSelectTypeProperty('property.accesskey', 'accesskey', m_accessKeyDefArray, false, dispFlg);
        rtnHTML += createLongStringProperty('property.style', 'style', dispFlg);
        rtnHTML += createEventTypeProperty('property.onchange', 'onchange', dispFlg);
        rtnHTML += createCustomCheckProperty(this.customProperties, this.customPropertiesLiteral);
    return rtnHTML;
  }

  function fnSetDefaultProperty(strId){
    var objDS = m_objDataSet[strId];
    objDS.setProperty('stylewidth', CONSTLISTWIDTH);
    objDS.setProperty('size', CONSTLISTSIZE);
    objDS.setProperty('visibility', CONSTDEFAULTVISIBILITY);
    objDS.setProperty('customize-mobility', 'disabled');
    objDS.setProperty('customize-visibility', 'disabled');
    objDS.setProperty('customize-defaultvalue', 'disabled');
    objDS.setProperty('fontsize', CONSTDEFAULTFONTSIZE);
  }

  function fnGetPropertiesHtml(objDs){

    var strBgcolor = getBgcolorType(objDs, 0);
    var strCursor  = getCursorType(objDs);
    var strHTML = '';
    strHTML += '<SELECT ';
    strHTML +=   'ID="' + objDs.getProperty('id') + '" ';
    strHTML +=   'SIZE="' + objDs.getProperty('size') + '" ';
    if(objDs.getProperty('multiple')){
      strHTML += 'MULTIPLE ';
    }
    strHTML +=   'STYLE="width:' + objDs.getProperty('stylewidth') + 'px; cursor:' + strCursor + '; ';
    strHTML +=   'height:' + objDs.getProperty('styleheight') + 'px; ';
    strHTML +=   'font-size:' + objDs.getProperty('fontsize') + 'pt; ';
    strHTML +=   'color:' + objDs.getProperty('fontcolor') + '; ';
    strHTML +=   'background-color:' + strBgcolor + ';">';
    strHTML += '</SELECT>';
    return strHTML;
  }

}

/**
 * RadioタイプのtypeObject実装クラス
 * @param  :
 * @return :作成したHTML文字列
 */
function objectRadio(){
  this.customProperties        = new Array('customize-visibility', 'customize-mobility', 'customize-defaultvalue');
  this.customPropertiesLiteral = new Array('visibility', 'location', 'initialvalue');
  this.defaultvaluePropertyId = 'value';

  objectRadio.prototype.createPropertyTable = fnCreatePropertyTable;
  objectRadio.prototype.setDefaultProperty  = fnSetDefaultProperty;
  objectRadio.prototype.getPropertiesHtml   = fnGetPropertiesHtml;

  function fnCreatePropertyTable(elementId){

    // ## 表示・非表示
    var dispFlg = true;
    if(parseInt(m_monitorEditStatus) == 2){
      dispFlg = false;
    }

    var rtnHTML  = '';
        rtnHTML += createTextTypeProperty('property.width_px', 'stylewidth', 'right', 'disabled', dispFlg);
        rtnHTML += createTextTypeProperty('property.height_px', 'styleheight', 'right', 'disabled', dispFlg);

        if(!dispFlg){
          rtnHTML += createTextTypeProperty('property.initialvalue', 'value', 'left', 'auto', m_objDataSet[elementId].getCustomizableItems().defaultvalue);
        }else{
          rtnHTML += createTextTypeProperty('property.initialvalue', 'value', 'left', 'auto', dispFlg);
        }

        rtnHTML += createButtonTypeProperty('property.selection', 'option', 'optionOpen(\'acckey\')', dispFlg);
        rtnHTML += createTextTypeProperty('property.colsize', 'radiomaxcols', 'right', 'disabled', dispFlg);
        rtnHTML += createTextTypeProperty('property.rowsize', 'radiomaxrows', 'right', 'disabled', dispFlg);
        rtnHTML += createTextTypeProperty('property.fontsize_pt', 'radiofontsize', 'right', 'disabled', dispFlg);
        rtnHTML += createSelectTypeProperty('property.fontfamily', 'fontfamily', m_fontDefineArray, false, dispFlg);
        rtnHTML += createSelectTypeProperty('property.fontweight', 'fontweight', m_fontweightDefArray, false, dispFlg);
        rtnHTML += createCheckTypeProperty('property.fontstyle', 'fontstyle', 'italic', 'fontstyle.italic', dispFlg);
        rtnHTML += createColorTypeProperty('property.fontcolor', 'radiofontcolor', dispFlg);
        rtnHTML += createColorTypeProperty('property.backgroundcolor', 'stylebgcolor', dispFlg);
        rtnHTML += createLongStringProperty('property.style', 'style', dispFlg);
        rtnHTML += createCustomCheckProperty(this.customProperties, this.customPropertiesLiteral);
    return rtnHTML;
  }

  function fnSetDefaultProperty(strId){
    var objDS = m_objDataSet[strId];
    objDS.setProperty('radiomaxcols', CONSTRADIOCOLS);
    objDS.setProperty('radiomaxrows', CONSTRADIOROWS);
    objDS.setProperty('stylewidth', CONSTRADIOWIDTH);
    objDS.setProperty('visibility', CONSTDEFAULTVISIBILITY);
    objDS.setProperty('customize-mobility', 'disabled');
    objDS.setProperty('customize-visibility', 'disabled');
    objDS.setProperty('customize-defaultvalue', 'disabled');
    objDS.setProperty('radiofontsize', CONSTDEFAULTFONTSIZE);
    objDS.setProperty('fontweight', CONSTDEFAULTFONTWEIGHT);
  }

  function fnGetPropertiesHtml(objDs){
    var radios = new Array();
    var radioIndex = 0;
    var col = 0;
    var options = objDs.getProperty('option');

    //id取得
    var tmpId = objDs.getProperty('id');

    if(options.length > 0){
      //「選択肢」の数分RADIOを作成
      for(var i in options) {
        col += 1;
        radios[radioIndex] = new Object();
        radios[radioIndex].radio = '<INPUT TYPE="radio" ID="_refer_' + tmpId + '">';
        radios[radioIndex].text  = options[i].substring(0, options[i].indexOf('::'));

        if(!isNaN(objDs.getProperty('radiomaxcols')) && parseInt(objDs.getProperty('radiomaxcols')) <= col) {
            radios[radioIndex].br = true;
            col = 0;
        } else {
            radios[radioIndex].br = false;
        }
        radioIndex++;
      }
    }else{
      radios[radioIndex] = new Object();
      radios[radioIndex].radio = '<INPUT TYPE="radio" ID="_refer_' + tmpId + '">';
      radios[radioIndex].text  = '';
    }

    //HTML文字列作成
    radioIndex = 0;

    var setWidth = '';
    if(objDs.getProperty('stylewidth') != ''){
      var setWidth = ' width:' + objDs.getProperty('stylewidth') + 'px;';
    }

    var setHeight = '';
    if(objDs.getProperty('styleheight') != ''){
      var setHeight = ' height:' + objDs.getProperty('styleheight') + 'px;';
    }

    //背景色取得
    var strBgcolor = getBgcolorType(objDs, 0);
    //カーソルタイプ取得
    var strCursor  = getCursorType(objDs);

    var strHTML = '';
    strHTML += '<TABLE ID="' + tmpId + '"';
    strHTML += ' STYLE="cursor:' + strCursor + '; border:1px blue dotted;' + setWidth + setHeight;
    strHTML += ' background-color:' + strBgcolor + ';';
    if(objDs.getProperty('fontfamily').length != 0){
      strHTML += ' font-family:' + objDs.getProperty('fontfamily') + ';';
    }
    if(objDs.getProperty('fontstyle').length != 0){
      strHTML += ' font-style:' + objDs.getProperty('fontstyle') + ';';
    }
    if(objDs.getProperty('fontweight').length != 0){
      strHTML += ' font-weight:' + objDs.getProperty('fontweight') + ';';
    }
    if(objDs.getProperty('radiofontsize').length != 0){
      strHTML += ' font-size:' + objDs.getProperty('radiofontsize') + 'pt; ';
    }else{
      strHTML += ' font-size:' + CONSTVIEWDEFAULTFONTSIZE + '; ';
    }
    strHTML += 'color:' + objDs.getProperty('radiofontcolor') + ';"';
    strHTML += ' >';
    for(var row = 0; row < objDs.getProperty('radiomaxrows'); row++) {
        strHTML += '<TR ID="_refer_' + tmpId + '">';
        for(var col = 0; col < objDs.getProperty('radiomaxcols'); col++) {
            strHTML += '<TD width="14" ID="_refer_' + tmpId + '">';
            if(radios[radioIndex]) {
              strHTML += radios[radioIndex].radio;
              strHTML += '</TD><TD align="left" ID="_refer_' + tmpId + '">';
              strHTML += radios[radioIndex].text;
              radioIndex++;
            }else{
              strHTML += '</TD><TD align="left" ID="_refer_' + tmpId + '">';
              row = objDs.getProperty('radiomaxrows');
            }
            strHTML += '</TD>';
        }
        strHTML += '</TR>';
    }
    strHTML += '</TABLE>';
    return strHTML;
  }

}

/**
 * ButtonタイプのtypeObject実装クラス
 * @param  :
 * @return :作成したHTML文字列
 */
function objectButton(){
  this.customProperties        = new Array('customize-visibility', 'customize-mobility');
  this.customPropertiesLiteral = new Array('visibility', 'location');

  objectButton.prototype.createPropertyTable = fnCreatePropertyTable;
  objectButton.prototype.setDefaultProperty  = fnSetDefaultProperty;
  objectButton.prototype.getPropertiesHtml   = fnGetPropertiesHtml;

  function fnCreatePropertyTable(elementId){

    // ## 表示・非表示
    var dispFlg = true;
    if(parseInt(m_monitorEditStatus) == 2){
      dispFlg = false;
    }

    var rtnHTML  = '';
        rtnHTML += createTextTypeProperty('property.width_px', 'stylewidth', 'right', 'disabled', dispFlg);
        rtnHTML += createTextTypeProperty('property.height_px', 'styleheight', 'right', 'disabled', dispFlg);
        rtnHTML += createTextTypeProperty('property.buttonlabel', 'value', 'left', 'auto', dispFlg);
        rtnHTML += createTextTypeProperty('property.fontsize_pt', 'fontsize', 'right', 'disabled', dispFlg);
        rtnHTML += createColorTypeProperty('property.fontcolor', 'fontcolor', dispFlg);
        rtnHTML += createColorTypeProperty('property.backgroundcolor', 'stylebgcolor', dispFlg);
        rtnHTML += createSelectTypeProperty('property.accesskey', 'accesskey', m_accessKeyDefArray, false, dispFlg);
        rtnHTML += createLongStringProperty('property.style', 'style', dispFlg);
        rtnHTML += createEventTypeProperty('property.onclick', 'onclick', dispFlg);
        rtnHTML += createCustomCheckProperty(this.customProperties, this.customPropertiesLiteral);
    return rtnHTML;
  }

  function fnSetDefaultProperty(strId){
    var objDS = m_objDataSet[strId];
    objDS.setProperty('stylewidth', CONSTBUTTONWIDTH);
    objDS.setProperty('styleheight', CONSTBUTTONHEIGHT);
    objDS.setProperty('visibility', CONSTDEFAULTVISIBILITY);
    objDS.setProperty('customize-mobility', 'disabled');
    objDS.setProperty('customize-visibility', 'disabled');
    objDS.setProperty('fontsize', CONSTDEFAULTFONTSIZE);
  }

  function fnGetPropertiesHtml(objDs){

    var strBgcolor = getBgcolorType(objDs, 0);
    var strCursor  = getCursorType(objDs);

    var strHTML  = '<INPUT TYPE="BUTTON" ID="';
        strHTML += objDs.getProperty('id');
        strHTML += '" VALUE="' + objDs.getProperty('value');
        strHTML += '" STYLE="width:' + objDs.getProperty('stylewidth');
        strHTML += 'px; cursor:' + strCursor;
        strHTML += '; height:' + objDs.getProperty('styleheight');
        strHTML += 'px; font-size:' + objDs.getProperty('fontsize');
        strHTML += 'pt; color:' + objDs.getProperty('fontcolor');
        strHTML += '; background-color:' + strBgcolor + ';">';

    return strHTML;
  }

}

/**
 * ImageタイプのtypeObject実装クラス
 * @param  :
 * @return :作成したHTML文字列
 */
function objectImage(){
  this.customProperties        = new Array('customize-visibility', 'customize-mobility');
  this.customPropertiesLiteral = new Array('visibility', 'location');

  objectImage.prototype.createPropertyTable = fnCreatePropertyTable;
  objectImage.prototype.setDefaultProperty  = fnSetDefaultProperty;
  objectImage.prototype.getPropertiesHtml   = fnGetPropertiesHtml;

  function fnCreatePropertyTable(elementId){

    // ## 表示・非表示
    var dispFlg = true;
    if(parseInt(m_monitorEditStatus) == 2){
      dispFlg = false;
    }

    var rtnHTML  = '';
        rtnHTML += createTextTypeProperty('property.width_px', 'stylewidth', 'right', 'disabled', dispFlg);
        rtnHTML += createTextTypeProperty('property.height_px', 'styleheight', 'right', 'disabled', dispFlg);
        rtnHTML += createImageNameProperty('property.imagesrc', 'src', dispFlg);
        rtnHTML += createTextTypeProperty('property.imagealt', 'alt', 'left', 'auto', dispFlg);
        rtnHTML += createTextTypeProperty('property.borderwidth', 'border', 'right', 'disabled', dispFlg);
        rtnHTML += createColorTypeProperty('property.bordercolor', 'bordercolor', dispFlg);
        rtnHTML += createColorTypeProperty('property.fontcolor', 'fontcolor', dispFlg);
        rtnHTML += createColorTypeProperty('property.backgroundcolor', 'stylebgcolor', dispFlg);
        rtnHTML += createSelectTypeProperty('property.align', 'textalign', m_textalignDefArray, false, dispFlg);
        rtnHTML += createLongStringProperty('property.link', 'link', dispFlg);
        rtnHTML += createTextTypeProperty('property.target', 'target', 'left', 'auto', dispFlg);
        rtnHTML += createSelectTypeProperty('property.accesskey', 'accesskey', m_accessKeyDefArray, false, dispFlg);
        rtnHTML += createEventTypeProperty('property.onclick', 'onclick', dispFlg);
        rtnHTML += createCustomCheckProperty(this.customProperties, this.customPropertiesLiteral);
    return rtnHTML;
  }

  function fnSetDefaultProperty(strId){
    var objDS = m_objDataSet[strId];
    objDS.setProperty('visibility', CONSTDEFAULTVISIBILITY);
    objDS.setProperty('customize-mobility', 'disabled');
    objDS.setProperty('customize-visibility', 'disabled');
    objDS.setProperty('textalign', CONSTDEFAULTTEXTALIGN);
  }

  function fnGetPropertiesHtml(objDs){

    var strBgcolor = getBgcolorType(objDs, 0);
    var strCursor  = getCursorType(objDs);
    var strSrc = objDs.getProperty('src');

    var strHTML = '';
    strHTML += '<IMG ';
    strHTML +=   'ID="' + objDs.getProperty('id') + '" ';
    if(strSrc == '' && m_browserType.isIE) {
      strHTML +=   'SRC="' + CONSTIMAGETPIMAGE + '" ';
    } else {
      strHTML +=   'SRC="' + strSrc + '" ';
    }
    strHTML +=   'ALT="' + objDs.getProperty('alt') + '" ';
    strHTML +=   'BORDER="' + objDs.getProperty('border') + '" ';
    strHTML +=   'STYLE="width:' + objDs.getProperty('stylewidth') + 'px; ';
    strHTML +=   'height:' + objDs.getProperty('styleheight') + 'px; ';
    if(strSrc == '' && m_browserType.isIE) {
      strHTML +=   CONSTIMAGEUNSPECIFIEDSTYLE;
    }
    strHTML +=   'cursor:' + strCursor + '; ';
    strHTML +=   'color:' + objDs.getProperty('fontcolor') + '; ';
    strHTML +=   'background-color:' + strBgcolor + '; ';
    strHTML +=   'border-color:' + objDs.getProperty('bordercolor') + '; ';
    strHTML +=   'text-align:' + objDs.getProperty('textalign') + ';" ';
    //strHTML +=   'onmousedown="funcOnImageMouseDown(this,null);" ';
    strHTML +=   ' onmousemove="return false;">';
    
    //strHTML += '<input onmousedown="funcOnImageMouseDown(\'' + objDs.getProperty('id') + '\',this);" readonly id="' + objDs.getProperty('id') + '_input" style="position:absolute;top:0;left:0;width:10;height:10;cursor:pointer;background-color:transparent;border:none;">';
    return strHTML;
  }

}

//mozilla対応
/*
function resetImageInput(_element,_input,_retry) {
  var element = _element;
  var input = _input;
  if(!_element) return;
  if(typeof(_element) == 'string') {
    element = document.getElementById(_element);
  }
  if(!_input) {
    input = document.getElementById(element.id + '_input');
  }
  element.src = CONSTIMAGEIMAGE;
  input.style.width = 1;
  input.style.height = 1;
}
*/
//mozilla対応
/*
function funcOnImageMouseDown(_element,_input,_retry) {
  var element = _element;
  var input = _input;
  if(!_element) return;
  if(typeof(_element) == 'string') {
    element = document.getElementById(_element);
  }
  if(!element.complete) {
    if(typeof(_retry) == 'undefined') {
      setTimeout('funcOnImageMouseDown(\'' + element.id + '\',null,5)',100);
      return;
    } else if(_retry > 0){
      setTimeout('funcOnImageMouseDown(\'' + element.id + '\',null,' + _retry + ')',100);
      return;
    } else {
      alert('image not complete.');
      return
    }
  }
  if(!_input) {
    input = document.getElementById(element.id + '_input');
  }
  if(element.src != '' && element.naturalWidth && element.naturalHeight) {
    if(typeof(_retry) == 'undefined' && element.naturalWidth == 1) {
    //    alert(element.offsetWidth + '/' + element.offsetHeight);
      setTimeout('funcOnImageMouseDown(\'' + element.id + '\',null,5)',1000);
      return;
    }
    //if(input.style.width == (element.offsetWidth+'px')&& 
    //   input.style.height == (element.offsetHeight+'px')) {
    //  if(typeof(_retry) == 'undefined') {
    //    alert(element.offsetWidth + '/' + element.offsetHeight);
    //    setTimeout('funcOnImageMouseDown(\'' + element.id + '\',null,5)',100);
    //    return;
    //  } else if(_retry > 0){
    //    setTimeout('funcOnImageMouseDown(\'' + element.id + '\',null,' + (_retry - 1) + ')',100);
    //    return;
    //  } else {
    //    alert(element.offsetWidth + '/' + element.offsetHeight);
    //    element.src = '';
    //    input.style.width = 10;
    //    input.style.height = 10;
    //  }
    //} else {
    //    alert('@@:' + element.offsetWidth + '/' + element.offsetHeight
    //     + ' \n@@:' + input.style.width + '/' + input.style.height);
    //}
    //alert(element.src + ':' + element.width + '/' + element.height);
    //showObject(element);
    input.style.width = element.naturalWidth;
    input.style.height = element.naturalHeight;
  } else {
    element.src = CONSTIMAGEIMAGE;
    input.style.width = 22;
    input.style.height = 22;
  }
  //alert('input.style.width:' + input.style.width);
  input.focus();
}
*/

/**
 * FileタイプのtypeObject実装クラス
 * @param  :
 * @return :作成したHTML文字列
 */
function objectFile(){
  this.customProperties        = new Array('customize-visibility', 'customize-mobility');
  this.customPropertiesLiteral = new Array('visibility', 'location');
  this.defaultvaluePropertyId = 'text';

  objectFile.prototype.createPropertyTable = fnCreatePropertyTable;
  objectFile.prototype.setDefaultProperty  = fnSetDefaultProperty;
  objectFile.prototype.getPropertiesHtml   = fnGetPropertiesHtml;

  function fnCreatePropertyTable(elementId){

    // ## 表示・非表示
    var dispFlg = true;
    if(parseInt(m_monitorEditStatus) == 2){
      dispFlg = false;
    }

    var rtnHTML  = '';
        rtnHTML += createTextTypeProperty('property.width_px', 'stylewidth', 'right', 'disabled', dispFlg);
        rtnHTML += createTextTypeProperty('property.height_px', 'styleheight', 'right', 'disabled', dispFlg);
        rtnHTML += createTextTypeProperty('property.textcols', 'textcols', 'right', 'disabled', dispFlg);
//        rtnHTML += createTextTypeProperty('property.maxlength', 'maxlength', 'right', 'disabled', dispFlg);
        rtnHTML += createTextTypeProperty('property.fontsize_pt', 'fontsize', 'right', 'disabled', dispFlg);
        rtnHTML += createColorTypeProperty('property.fontcolor', 'fontcolor', dispFlg);
        rtnHTML += createColorTypeProperty('property.backgroundcolor', 'stylebgcolor', dispFlg);
        rtnHTML += createSelectTypeProperty('property.align', 'textalign', m_textalignDefArray, false, dispFlg);
        rtnHTML += createSelectTypeProperty('property.accesskey', 'accesskey', m_accessKeyDefArray, false, dispFlg);
        rtnHTML += createLongStringProperty('property.style', 'style', dispFlg);
        rtnHTML += createCustomCheckProperty(this.customProperties, this.customPropertiesLiteral);
    return rtnHTML;
  }

  function fnSetDefaultProperty(strId){
    var objDS = m_objDataSet[strId];
    objDS.setProperty('stylewidth', CONSTFILEWIDTH);
    objDS.setProperty('visibility', CONSTDEFAULTVISIBILITY);
    objDS.setProperty('customize-mobility', 'disabled');
    objDS.setProperty('customize-visibility', 'disabled');
    objDS.setProperty('fontsize', CONSTDEFAULTFONTSIZE);
    objDS.setProperty('textalign', CONSTDEFAULTTEXTALIGN);
  }

  function fnGetPropertiesHtml(objDs){

    var strFileId  = objDs.getProperty('id');
    var strBgcolor = getBgcolorType(objDs, 0);
    var strCursor  = getCursorType(objDs);
    var strWidth   = objDs.getProperty('stylewidth');
    var styleWidth = '';
    if(strWidth) {
      if((parseInt(strWidth) -  56) < 0){
        styleWidth = 'width:0px; ';
      }else{
        styleWidth = 'width:' + (parseInt(strWidth) -  56) + 'px; ';
      }
    }
    
    var strHTML = '';
    strHTML += '<table id="' + strFileId + '" border="0" cellpadding="0" cellspacing="0" style="cursor:' + strCursor + ';">';
    strHTML +=   '<tr id="' + strFileId + '_FILETBL">';
    strHTML +=     '<td id="' + strFileId + '_FILETBL">';
    strHTML +=       '<input type="text" ';
    strHTML +=              'id="' + strFileId + '_FILETEXT" ';
    strHTML +=              'SIZE="' + objDs.getProperty('textcols') + '" ';
    strHTML +=              'style="cursor:' + strCursor + '; ';
    strHTML +=            styleWidth;
    strHTML +=                     'height:' + objDs.getProperty('styleheight') + 'px; ';
    strHTML +=                     'font-size:' + objDs.getProperty('fontsize') + 'pt; ';
    strHTML +=                     'color:' + objDs.getProperty('fontcolor') + '; ';
    strHTML +=                     'background-color:' + strBgcolor + '; ';
    strHTML +=                     'text-align:' + objDs.getProperty('textalign') + ';" readonly>';
    strHTML +=     '</td>';
    strHTML +=     '<td id="' + strFileId + '_FILETBL">';
    strHTML +=       '<input type="button" id="' + strFileId + '_FILEBUTTON" ';
    strHTML +=              'style="width:52px; text-align:center; ';
    strHTML +=                     'height:' + objDs.getProperty('styleheight') + '; ';
    strHTML +=                     'margin-left:2px; cursor:' + strCursor + ';" value="' + getLiteral('element.file.browsebuttonlabel') + '...">';
    strHTML +=     '</td>';
    strHTML +=   '</tr>';
    strHTML +='</table>';
    return strHTML;
  }

}

/**
 * HideタイプのtypeObject実装クラス
 * @param  :
 * @return :作成したHTML文字列
 */
function objectHide(){
  this.customProperties        = new Array('customize-mobility', 'customize-defaultvalue');
  this.customPropertiesLiteral = new Array('location', 'initialvalue');
  this.defaultvaluePropertyId = 'value';

  objectHide.prototype.createPropertyTable = fnCreatePropertyTable;
  objectHide.prototype.setDefaultProperty  = fnSetDefaultProperty;
  objectHide.prototype.getPropertiesHtml   = fnGetPropertiesHtml;

  function fnCreatePropertyTable(elementId){

    // ## 表示・非表示
    var dispFlg = true;
    if(parseInt(m_monitorEditStatus) == 2){
      dispFlg = false;
    }

    var rtnHTML  = '';
        if(!dispFlg){
          rtnHTML += createTextTypeProperty('property.value', 'hidevalue', 'left', 'auto', m_objDataSet[elementId].getCustomizableItems().defaultvalue);
        }else{
          rtnHTML += createTextTypeProperty('property.value', 'hidevalue', 'left', 'auto', dispFlg);
        }

        rtnHTML += createCustomCheckProperty(this.customProperties, this.customPropertiesLiteral);
    return rtnHTML;
  }

  function fnSetDefaultProperty(strId){
    var objDS = m_objDataSet[strId];
    objDS.setProperty('stylewidth', CONSTHIDEWIDTH);
    objDS.setProperty('customize-mobility', 'disabled');
  }

  function fnGetPropertiesHtml(objDs){
    var strCursor  = getCursorType(objDs);
/*
    var strHTML = '';
    strHTML += '<INPUT TYPE="TEXT" ID="' + objDs.getProperty('id') + '" hidden=true STYLE="cursor:' + strCursor + '; width:15px; border:1px #1e32e3 ridge; background-color:' + CONSTHIDDENCOLOR + ';" readonly>';
    return strHTML;
*/
    return '<INPUT TYPE="TEXT" ID="' + objDs.getProperty('id') + '" hidden=true STYLE="cursor:' + strCursor + '; width:15px; border:1px #1e32e3 ridge; background-color:' + CONSTHIDDENCOLOR + ';" readonly>';
  }

}

/**
 * CheckタイプのtypeObject実装クラス
 * @param  :
 * @return :作成したHTML文字列
 */
function objectCheck(){
  this.customProperties        = new Array('customize-visibility', 'customize-mobility', 'customize-defaultvalue');
  this.customPropertiesLiteral = new Array('visibility', 'location', 'initialvalue');
  this.defaultvaluePropertyId = 'selvalue';

  objectCheck.prototype.createPropertyTable = fnCreatePropertyTable;
  objectCheck.prototype.setDefaultProperty  = fnSetDefaultProperty;
  objectCheck.prototype.getPropertiesHtml   = fnGetPropertiesHtml;

  function fnCreatePropertyTable(elementId){

    // ## 表示・非表示
    var dispFlg = true;
    if(parseInt(m_monitorEditStatus) == 2){
      dispFlg = false;
    }

    var rtnHTML  = '';
        rtnHTML += createTextTypeProperty('property.width_px', 'stylewidth', 'right', 'disabled', dispFlg);
        rtnHTML += createTextTypeProperty('property.height_px', 'styleheight', 'right', 'disabled', dispFlg);
        rtnHTML += createTextTypeProperty('property.text', 'text', 'left', 'auto', dispFlg);

        if(!dispFlg){
          rtnHTML += createTextTypeProperty('property.initialvalue', 'selvalue', 'left', 'auto', m_objDataSet[elementId].getCustomizableItems().defaultvalue);
        }else{
          rtnHTML += createTextTypeProperty('property.initialvalue', 'selvalue', 'left', 'auto', dispFlg);
        }

        rtnHTML += createTextTypeProperty('property.value', 'value', 'left', 'auto', dispFlg);
        rtnHTML += createTextTypeProperty('property.fontsize_pt', 'fontsize', 'right', 'disabled', dispFlg);
        rtnHTML += createSelectTypeProperty('property.fontfamily', 'fontfamily', m_fontDefineArray, false, dispFlg);
        rtnHTML += createSelectTypeProperty('property.fontweight', 'fontweight', m_fontweightDefArray, false, dispFlg);
        rtnHTML += createCheckTypeProperty('property.fontstyle', 'fontstyle', 'italic', 'fontstyle.italic', dispFlg);
        rtnHTML += createColorTypeProperty('property.fontcolor', 'fontcolor', dispFlg);
        rtnHTML += createColorTypeProperty('property.backgroundcolor', 'stylebgcolor', dispFlg);
        rtnHTML += createSelectTypeProperty('property.accesskey', 'accesskey', m_accessKeyDefArray, false, dispFlg);
        rtnHTML += createLongStringProperty('property.style', 'style', dispFlg);
        rtnHTML += createCustomCheckProperty(this.customProperties, this.customPropertiesLiteral);
    return rtnHTML;
  }

  function fnSetDefaultProperty(strId){
    var objDS = m_objDataSet[strId];
    objDS.setProperty('fontsize', CONSTCHECKFONTSIZE);
    objDS.setProperty('stylewidth', CONSTCHECKWIDTH);
    objDS.setProperty('visibility', CONSTDEFAULTVISIBILITY);
    objDS.setProperty('customize-mobility', 'disabled');
    objDS.setProperty('customize-visibility', 'disabled');
    objDS.setProperty('customize-defaultvalue', 'disabled');
    objDS.setProperty('fontsize', CONSTDEFAULTFONTSIZE);
    objDS.setProperty('fontweight', CONSTDEFAULTFONTWEIGHT);
  }

  function fnGetPropertiesHtml(objDs){

    var strCheckId = objDs.getProperty('id');
    var strBgcolor = getBgcolorType(objDs, 0);
    var strCursor  = getCursorType(objDs);
    var strFontSize = objDs.getProperty('fontsize');
    if(strFontSize == '' ) {
      strFontSize = CONSTVIEWDEFAULTFONTSIZE;
    } else {
      strFontSize += 'pt';
    }

    var strHTML = '';
    strHTML += '<TABLE ID="' + strCheckId + '" CELLPADDING="0" CELLSPACING="0" BORDER="0" STYLE="';
    if(objDs.getProperty('stylewidth') != ''){
      strHTML +=      'width:' + objDs.getProperty('stylewidth') + 'px; ';
    }
    strHTML +=        'height:' + objDs.getProperty('styleheight') + 'px; border:1px #88bbff dotted; ';
    strHTML +=        'cursor:' + strCursor + '; ';
    strHTML +=        'font-size:' + strFontSize + '; ';
    strHTML +=        'color:' + objDs.getProperty('fontcolor') + '; ';
    strHTML +=        'background-color:' + strBgcolor + '; ';
    strHTML +=        'font-family:' + objDs.getProperty('fontfamily') + '; ';
    strHTML +=        'font-weight:' + objDs.getProperty('fontweight') + '; ';
    strHTML +=        'font-style:' + objDs.getProperty('fontstyle');
    strHTML +=   ';"><TR><TD valign="top" width="14px">';
    strHTML +=       '<INPUT TYPE="checkbox" ID="_refer_' + strCheckId + '" STYLE="cursor:' + strCursor + ';" value="ON"></TD><TD>';
    strHTML +=       '<DIV ID="_refer_' + strCheckId + '"  STYLE="cursor:' + strCursor + '; ';
    strHTML +=            'height:' + objDs.getProperty('styleheight') + 'px; ';
    strHTML +=            'background-color:' + strBgcolor + ';">';
    strHTML +=          objDs.getProperty('text');
    strHTML +=       '</DIV></TD></TR></TABLE>';
    return strHTML;
  }

}

/**
 * LablelタイプのtypeObject実装クラス
 * @param  :
 * @return :作成したHTML文字列
 */
function objectLabel(){
  this.customProperties        = new Array('customize-visibility', 'customize-mobility');
  this.customPropertiesLiteral = new Array('visibility', 'location');
  this.defaultvaluePropertyId = 'text';

  objectLabel.prototype.createPropertyTable = fnCreatePropertyTable;
  objectLabel.prototype.setDefaultProperty  = fnSetDefaultProperty;
  objectLabel.prototype.getPropertiesHtml   = fnGetPropertiesHtml;

  function fnCreatePropertyTable(elementId){

    // ## 表示・非表示
    var dispFlg = true;
    if(parseInt(m_monitorEditStatus) == 2){
      dispFlg = false;
    }

    var rtnHTML  = '';
        rtnHTML += createTextTypeProperty('property.width_px', 'stylewidth', 'right', 'disabled', dispFlg);
        rtnHTML += createTextTypeProperty('property.height_px', 'styleheight', 'right', 'disabled', dispFlg);
        rtnHTML += createTextTypeProperty('property.text', 'value', 'left', 'auto', dispFlg);
        rtnHTML += createTextTypeProperty('property.fontsize_pt', 'fontsize', 'right', 'disabled', dispFlg);
        rtnHTML += createSelectTypeProperty('property.fontfamily', 'fontfamily', m_fontDefineArray, false, dispFlg);
        rtnHTML += createSelectTypeProperty('property.fontweight', 'fontweight', m_fontweightDefArray, false, dispFlg);
        rtnHTML += createCheckTypeProperty('property.fontstyle', 'fontstyle', 'italic', 'fontstyle.italic', dispFlg);
        rtnHTML += createCheckTypeProperty('property.underline', 'underline', 'underline', 'underline.underline', dispFlg);
        rtnHTML += createColorTypeProperty('property.fontcolor', 'fontcolor', dispFlg);
        rtnHTML += createColorTypeProperty('property.backgroundcolor', 'stylebgcolor', dispFlg);
        rtnHTML += createSelectTypeProperty('property.align', 'textalign', m_textalignDefArray, false, dispFlg);
        rtnHTML += createLongStringProperty('property.style', 'style', dispFlg);
        rtnHTML += createCustomCheckProperty(this.customProperties, this.customPropertiesLiteral);
    return rtnHTML;
  }

  function fnSetDefaultProperty(strId){
    var objDS = m_objDataSet[strId];
    objDS.setProperty('stylewidth', CONSTLABELWIDTH);
    objDS.setProperty('visibility', CONSTDEFAULTVISIBILITY);
    objDS.setProperty('customize-mobility', 'disabled');
    objDS.setProperty('customize-visibility', 'disabled');
    objDS.setProperty('fontsize', CONSTDEFAULTFONTSIZE);
    objDS.setProperty('fontweight', CONSTDEFAULTFONTWEIGHT);
    objDS.setProperty('textalign', CONSTDEFAULTTEXTALIGN);
  }

  function fnGetPropertiesHtml(objDs){

    var strBgcolor = getBgcolorType(objDs, 0);
    var strCursor  = getCursorType(objDs);

  var strHTML  = '<INPUT TYPE="TEXT" ID="' + objDs.getProperty('id');
      strHTML += '" VALUE="' + objDs.getProperty('value');
      strHTML += '" readonly STYLE="cursor:' + strCursor;
      strHTML += '; border:1px #33FFCC dashed; width:' + objDs.getProperty('stylewidth');
      strHTML += 'px; height:' + objDs.getProperty('styleheight');
      if(strBgcolor != ''){
        strHTML += 'px; background-color:' + strBgcolor;
      }else{
        strHTML += 'px; background-color:transparent';
      }
      strHTML += '; font-size:' + objDs.getProperty('fontsize');
      strHTML += 'pt; color:' + objDs.getProperty('fontcolor');
      strHTML += '; font-family:' + objDs.getProperty('fontfamily');
      strHTML += '; font-weight:' + objDs.getProperty('fontweight');
      strHTML += '; font-style:' + objDs.getProperty('fontstyle');
      strHTML += '; text-decoration:' + objDs.getProperty('underline');
      strHTML += '; text-align:' + objDs.getProperty('textalign') + ';">';

    return strHTML;
  }

}

/**
 * StringタイプのtypeObject実装クラス
 * @param  :
 * @return :作成したHTML文字列
 */
function objectString(){
  this.customProperties        = new Array('customize-visibility', 'customize-mobility');
  this.customPropertiesLiteral = new Array('visibility', 'location');
  this.defaultvaluePropertyId = 'text';

  objectString.prototype.createPropertyTable = fnCreatePropertyTable;
  objectString.prototype.setDefaultProperty  = fnSetDefaultProperty;
  objectString.prototype.getPropertiesHtml   = fnGetPropertiesHtml;

  function fnCreatePropertyTable(elementId){

    // ## 表示・非表示
    var dispFlg = true;
    if(parseInt(m_monitorEditStatus) == 2){
      dispFlg = false;
    }

    var rtnHTML  = '';
        rtnHTML += createTextTypeProperty('property.width_px', 'stylewidth', 'right', 'disabled', dispFlg);
        rtnHTML += createTextTypeProperty('property.height_px', 'styleheight', 'right', 'disabled', dispFlg);
        rtnHTML += createTextTypeProperty('property.text', 'textvalue', 'left', 'auto', dispFlg);
        rtnHTML += createTextTypeProperty('property.textid', 'textid', 'left', 'auto', dispFlg);
        rtnHTML += createTextTypeProperty('property.tooltip', 'tooltip', 'left', 'auto', dispFlg);
        rtnHTML += createTextTypeProperty('property.fontsize_pt', 'fontsize', 'right', 'disabled', dispFlg);
        rtnHTML += createSelectTypeProperty('property.fontfamily', 'fontfamily', m_fontDefineArray, false, dispFlg);
        rtnHTML += createSelectTypeProperty('property.fontweight', 'fontweight', m_fontweightDefArray, false, dispFlg);
        rtnHTML += createCheckTypeProperty('property.fontstyle', 'fontstyle', 'italic', 'fontstyle.italic', dispFlg);
        rtnHTML += createCheckTypeProperty('property.underline', 'underline', 'underline', 'underline.underline', dispFlg);
        rtnHTML += createColorTypeProperty('property.fontcolor', 'fontcolor', dispFlg);
        rtnHTML += createColorTypeProperty('property.backgroundcolor', 'stylebgcolor', dispFlg);
        rtnHTML += createSelectTypeProperty('property.align', 'textalign', m_textalignDefArray, false, dispFlg);
        rtnHTML += createLongStringProperty('property.link', 'link', dispFlg);
        rtnHTML += createTextTypeProperty('property.target', 'target', 'left', 'auto', dispFlg);
        rtnHTML += createSelectTypeProperty('property.accesskey', 'accesskey', m_accessKeyDefArray, false, dispFlg);
        rtnHTML += createLongStringProperty('property.style', 'style', dispFlg);
        rtnHTML += createEventTypeProperty('property.onclick', 'onclick', dispFlg);
        rtnHTML += createCustomCheckProperty(this.customProperties, this.customPropertiesLiteral);
    return rtnHTML;
  }

  function fnSetDefaultProperty(strId){
    var objDS = m_objDataSet[strId];
    objDS.setProperty('stylewidth', CONSTSTRINGWIDTH);
    objDS.setProperty('visibility', CONSTDEFAULTVISIBILITY);
    objDS.setProperty('customize-mobility', 'disabled');
    objDS.setProperty('customize-visibility', 'disabled');
    objDS.setProperty('fontsize', CONSTDEFAULTFONTSIZE);
    objDS.setProperty('fontweight', CONSTDEFAULTFONTWEIGHT);
    objDS.setProperty('textalign', CONSTDEFAULTTEXTALIGN);
  }

  function fnGetPropertiesHtml(objDs){

    var strBgcolor = getBgcolorType(objDs, 0);
    var strCursor  = getCursorType(objDs);

    var strHTML  = '<INPUT TYPE="TEXT" ID="';
        strHTML += objDs.getProperty('id');
        strHTML += '" VALUE="' + objDs.getProperty('textvalue');
        strHTML += '" readonly STYLE="cursor:' + strCursor;
        strHTML += '; border:1px #CCCCFF dashed; width:' + objDs.getProperty('stylewidth');
        strHTML += 'px; height:' + objDs.getProperty('styleheight');
        if(strBgcolor != ''){
          strHTML += 'px; background-color:' + strBgcolor;
        }else{
          strHTML += 'px; background-color:transparent';
        }
        strHTML += '; font-size:' + objDs.getProperty('fontsize');
        if(objDs.getProperty('link').length != 0 && objDs.getProperty('fontcolor').length == 0){
          strHTML += 'pt; color:#0000FF';
        }else{
          strHTML += 'pt; color:' + objDs.getProperty('fontcolor');
        }
        strHTML += '; font-family:' + objDs.getProperty('fontfamily');
        strHTML += '; font-weight:' + objDs.getProperty('fontweight');
        strHTML += '; font-style:' + objDs.getProperty('fontstyle');
        if(objDs.getProperty('link').length != 0){
          strHTML += '; text-decoration:underline';
        }else{
          strHTML += '; text-decoration:' + objDs.getProperty('underline');
        }
        strHTML += '; text-align:' + objDs.getProperty('textalign') + ';">';

    return strHTML;
  }

}

/**
 * TextareaタイプのtypeObject実装クラス
 * @param  :
 * @return :作成したHTML文字列
 */
function objectTextarea(){
  this.customProperties        = new Array('customize-visibility', 'customize-mobility', 'customize-defaultvalue');
  this.customPropertiesLiteral = new Array('visibility', 'location', 'initialvalue');
  this.defaultvaluePropertyId = 'text';

  objectTextarea.prototype.createPropertyTable = fnCreatePropertyTable;
  objectTextarea.prototype.setDefaultProperty  = fnSetDefaultProperty;
  objectTextarea.prototype.getPropertiesHtml   = fnGetPropertiesHtml;

  function fnCreatePropertyTable(elementId){

    // ## 表示・非表示
    var dispFlg = true;
    if(parseInt(m_monitorEditStatus) == 2){
      dispFlg = false;
    }

    var rtnHTML  = '';
        rtnHTML += createTextTypeProperty('property.width_px', 'stylewidth', 'right', 'disabled', dispFlg);
        rtnHTML += createTextTypeProperty('property.height_px', 'styleheight', 'right', 'disabled', dispFlg);
        rtnHTML += createTextTypeProperty('property.textcols', 'textcols', 'right', 'disabled', dispFlg);
        rtnHTML += createTextTypeProperty('property.textrows', 'textrows', 'right', 'disabled', dispFlg);

        if(!dispFlg){
          rtnHTML += createTextTypeProperty('property.initialvalue', 'value', 'left', 'auto', m_objDataSet[elementId].getCustomizableItems().defaultvalue);
        }else{
          rtnHTML += createTextTypeProperty('property.initialvalue', 'value', 'left', 'auto', dispFlg);
        }


        rtnHTML += createTextTypeProperty('property.fontsize_pt', 'fontsize', 'right', 'disabled', dispFlg);
        rtnHTML += createSelectTypeProperty('property.fontfamily', 'fontfamily', m_fontDefineArray, false, dispFlg);
        rtnHTML += createSelectTypeProperty('property.fontweight', 'fontweight', m_fontweightDefArray, false, dispFlg);
        rtnHTML += createCheckTypeProperty('property.fontstyle', 'fontstyle', 'italic', 'fontstyle.italic', dispFlg);
        rtnHTML += createColorTypeProperty('property.fontcolor', 'fontcolor', dispFlg);
        rtnHTML += createColorTypeProperty('property.backgroundcolor', 'stylebgcolor', dispFlg);
        rtnHTML += createSelectTypeProperty('property.align', 'textalign', m_textalignDefArray, false, dispFlg);
        rtnHTML += createCheckTypeProperty('property.editmode', 'editmode', 'readonly', 'editmode.reaedonly', dispFlg);
        rtnHTML += createSelectTypeProperty('property.accesskey', 'accesskey', m_accessKeyDefArray, false, dispFlg);
        rtnHTML += createLongStringProperty('property.style', 'style', dispFlg);
        rtnHTML += createEventTypeProperty('property.onblur', 'onblur', dispFlg);
        rtnHTML += createEventTypeProperty('property.onchange', 'onchange', dispFlg);
        rtnHTML += createEventTypeProperty('property.onkeypress', 'onkeypress', dispFlg);
        rtnHTML += createCustomCheckProperty(this.customProperties, this.customPropertiesLiteral);
    return rtnHTML;
  }

  function fnSetDefaultProperty(strId){
    var objDS = m_objDataSet[strId];
    objDS.setProperty('stylewidth', CONSTTEXTAREAWIDTH);
    objDS.setProperty('visibility', CONSTDEFAULTVISIBILITY);
    objDS.setProperty('customize-mobility', 'disabled');
    objDS.setProperty('customize-visibility', 'disabled');
    objDS.setProperty('customize-defaultvalue', 'disabled');
    objDS.setProperty('fontsize', CONSTDEFAULTFONTSIZE);
    objDS.setProperty('fontweight', CONSTDEFAULTFONTWEIGHT);
    objDS.setProperty('textalign', CONSTDEFAULTTEXTALIGN);
  }

  function fnGetPropertiesHtml(objDs){

    var strBgcolor = getBgcolorType(objDs, 0);
    var strCursor  = getCursorType(objDs);
    var strFontSize = objDs.getProperty('fontsize');
    if(strFontSize == '' ) {
      strFontSize = CONSTVIEWDEFAULTFONTSIZE;
    } else {
      strFontSize += 'pt';
    }

    var strHTML = '';
    strHTML += '<TEXTAREA ID="' + objDs.getProperty('id') + '" readonly ';
    strHTML +=    'COLS="' + objDs.getProperty('textcols') + '" ';
    strHTML +=    'ROWS="' + objDs.getProperty('textrows') + '" ';
    strHTML +=    'STYLE="width:' + objDs.getProperty('stylewidth') + 'px; ';
    strHTML +=           'cursor:' + strCursor + '; ';
    strHTML +=           'height:' + objDs.getProperty('styleheight') + 'px; ';
    strHTML +=           'font-family:' + objDs.getProperty('fontfamily') + '; ';
    strHTML +=           'font-size:' + strFontSize + '; ';
    strHTML +=           'font-weight:' + objDs.getProperty('fontweight') + '; ';
    strHTML +=           'font-style:' + objDs.getProperty('fontstyle') + '; ';
    strHTML +=           'color:' + objDs.getProperty('fontcolor') + '; ';
    strHTML +=           'background-color:' + strBgcolor + '; ';
    strHTML +=           'text-align:' + objDs.getProperty('textalign') + ';">';
    strHTML +=     objDs.getProperty('value');
    strHTML += '</TEXTAREA>';
    return strHTML;
  }

}

/**
 * TextタイプのtypeObject実装クラス
 * @param  :
 * @return :作成したHTML文字列
 */
function objectText(){
  this.customProperties        = new Array('customize-visibility', 'customize-mobility', 'customize-defaultvalue');
  this.customPropertiesLiteral = new Array('visibility', 'location', 'initialvalue');
  this.defaultvaluePropertyId = 'text';

  objectText.prototype.createPropertyTable = fnCreatePropertyTable;
  objectText.prototype.setDefaultProperty  = fnSetDefaultProperty;
  objectText.prototype.getPropertiesHtml   = fnGetPropertiesHtml;

  function fnCreatePropertyTable(elementId){

    // ## 表示・非表示
    var dispFlg = true;
    if(parseInt(m_monitorEditStatus) == 2){
      dispFlg = false;
    }

    var rtnHTML  = '';
        rtnHTML += createTextTypeProperty('property.width_px', 'stylewidth', 'right', 'disabled', dispFlg);
        rtnHTML += createTextTypeProperty('property.height_px', 'styleheight', 'right', 'disabled', dispFlg);
        rtnHTML += createTextTypeProperty('property.textcols', 'textcols', 'right', 'disabled', dispFlg);
        rtnHTML += createTextTypeProperty('property.maxlength', 'maxlength', 'right', 'disabled', dispFlg);

        if(!dispFlg){
          rtnHTML += createTextTypeProperty('property.initialvalue', 'value', 'left', 'auto', m_objDataSet[elementId].getCustomizableItems().defaultvalue);
        }else{
          rtnHTML += createTextTypeProperty('property.initialvalue', 'value', 'left', 'auto', dispFlg);
        }

        rtnHTML += createTextTypeProperty('property.fontsize_pt', 'fontsize', 'right', 'disabled', dispFlg);
        rtnHTML += createSelectTypeProperty('property.fontfamily', 'fontfamily', m_fontDefineArray, false, dispFlg);
        rtnHTML += createSelectTypeProperty('property.fontweight', 'fontweight', m_fontweightDefArray, false, dispFlg);
        rtnHTML += createCheckTypeProperty('property.fontstyle', 'fontstyle', 'italic', 'fontstyle.italic', dispFlg);
        rtnHTML += createColorTypeProperty('property.fontcolor', 'fontcolor', dispFlg);
        rtnHTML += createColorTypeProperty('property.backgroundcolor', 'stylebgcolor', dispFlg);
        rtnHTML += createSelectTypeProperty('property.align', 'textalign', m_textalignDefArray, false, dispFlg);
        rtnHTML += createSelectTypeProperty('property.accesskey', 'accesskey', m_accessKeyDefArray, false, dispFlg);
        rtnHTML += createLongStringProperty('property.style', 'style', dispFlg);
        rtnHTML += createEventTypeProperty('property.onblur', 'onblur', dispFlg);
        rtnHTML += createEventTypeProperty('property.onchange', 'onchange', dispFlg);
        rtnHTML += createEventTypeProperty('property.onkeypress', 'onkeypress', dispFlg);
        rtnHTML += createCustomCheckProperty(this.customProperties, this.customPropertiesLiteral);
    return rtnHTML;
  }

  function fnSetDefaultProperty(strId){
    var objDS = m_objDataSet[strId];
    objDS.setProperty('stylewidth', CONSTTEXTWIDTH);
    objDS.setProperty('visibility', CONSTDEFAULTVISIBILITY);
    objDS.setProperty('customize-mobility', 'disabled');
    objDS.setProperty('customize-visibility', 'disabled');
    objDS.setProperty('customize-defaultvalue', 'disabled');
    objDS.setProperty('fontsize', CONSTDEFAULTFONTSIZE);
    objDS.setProperty('fontweight', CONSTDEFAULTFONTWEIGHT);
    objDS.setProperty('textalign', CONSTDEFAULTTEXTALIGN);
  }

  function fnGetPropertiesHtml(objDs){

    var strBgcolor = getBgcolorType(objDs, 0);
    var strCursor  = getCursorType(objDs);

    var strHTML  = '<INPUT TYPE="TEXT" ID="';
        strHTML += objDs.getProperty('id');
        strHTML += '" VALUE="' + objDs.getProperty('value');
        strHTML += '" SIZE="' + objDs.getProperty('textcols');
        strHTML += '" MAXLENGTH="' + objDs.getProperty('maxlength');
        strHTML += '" readonly STYLE="width:' + objDs.getProperty('stylewidth');
        strHTML += 'px; cursor:' + strCursor;
        strHTML += '; height:' + objDs.getProperty('styleheight');
        strHTML += 'px; font-family:' + objDs.getProperty('fontfamily');
        strHTML += '; font-size:' + objDs.getProperty('fontsize');
        strHTML += 'pt; font-weight:' + objDs.getProperty('fontweight');
        strHTML += '; font-style:' + objDs.getProperty('fontstyle');
        strHTML += '; color:' + objDs.getProperty('fontcolor');
        strHTML += '; background-color:' + strBgcolor;
        strHTML += '; text-align:' + objDs.getProperty('textalign') + ';">';

    return strHTML;
  }

}

/**
 * PasswordタイプのtypeObject実装クラス
 * @param  :
 * @return :作成したHTML文字列
 */
function objectPassword(){
  this.customProperties        = new Array('customize-visibility', 'customize-mobility');
  this.customPropertiesLiteral = new Array('visibility', 'location');
  this.defaultvaluePropertyId = 'text';

  objectPassword.prototype.createPropertyTable = fnCreatePropertyTable;
  objectPassword.prototype.setDefaultProperty  = fnSetDefaultProperty;
  objectPassword.prototype.getPropertiesHtml   = fnGetPropertiesHtml;

  function fnCreatePropertyTable(elementId){

    // ## 表示・非表示
    var dispFlg = true;
    if(parseInt(m_monitorEditStatus) == 2){
      dispFlg = false;
    }

    var rtnHTML  = '';
        rtnHTML += createTextTypeProperty('property.width_px', 'stylewidth', 'right', 'disabled', dispFlg);
        rtnHTML += createTextTypeProperty('property.height_px', 'styleheight', 'right', 'disabled', dispFlg);
        rtnHTML += createTextTypeProperty('property.textcols', 'textcols', 'right', 'disabled', dispFlg);
        rtnHTML += createTextTypeProperty('property.maxlength', 'maxlength', 'right', 'disabled', dispFlg);
        rtnHTML += createTextTypeProperty('property.fontsize_pt', 'fontsize', 'right', 'disabled', dispFlg);
        rtnHTML += createSelectTypeProperty('property.fontfamily', 'fontfamily', m_fontDefineArray, false, dispFlg);
        rtnHTML += createSelectTypeProperty('property.fontweight', 'fontweight', m_fontweightDefArray, false, dispFlg);
        rtnHTML += createCheckTypeProperty('property.fontstyle', 'fontstyle', 'italic', 'fontstyle.italic', dispFlg);
        rtnHTML += createColorTypeProperty('property.fontcolor', 'fontcolor', dispFlg);
        rtnHTML += createColorTypeProperty('property.backgroundcolor', 'stylebgcolor', dispFlg);
        rtnHTML += createSelectTypeProperty('property.align', 'textalign', m_textalignDefArray, false, dispFlg);
        rtnHTML += createSelectTypeProperty('property.accesskey', 'accesskey', m_accessKeyDefArray, false, dispFlg);
        rtnHTML += createLongStringProperty('property.style', 'style', dispFlg);
        rtnHTML += createEventTypeProperty('property.onblur', 'onblur', dispFlg);
        rtnHTML += createEventTypeProperty('property.onchange', 'onchange', dispFlg);
        rtnHTML += createEventTypeProperty('property.onkeypress', 'onkeypress', dispFlg);
        rtnHTML += createCustomCheckProperty(this.customProperties, this.customPropertiesLiteral);
    return rtnHTML;
  }

  function fnSetDefaultProperty(strId){
    var objDS = m_objDataSet[strId];
    objDS.setProperty('stylewidth', CONSTPASSWORDWIDTH);
    objDS.setProperty('visibility', CONSTDEFAULTVISIBILITY);
    objDS.setProperty('customize-mobility', 'disabled');
    objDS.setProperty('customize-visibility', 'disabled');
    objDS.setProperty('fontsize', CONSTDEFAULTFONTSIZE);
    objDS.setProperty('fontweight', CONSTDEFAULTFONTWEIGHT);
    objDS.setProperty('textalign', CONSTDEFAULTTEXTALIGN);
  }

  function fnGetPropertiesHtml(objDs){

    var strBgcolor = getBgcolorType(objDs, 0);
    var strCursor  = getCursorType(objDs);

    var strHTML = '';
    strHTML += '<INPUT TYPE="PASSWORD" ';
    strHTML +=        'ID="' + objDs.getProperty('id') + '" ';
    strHTML +=        'SIZE="' + objDs.getProperty('textcols') + '" ';
    strHTML +=        'MAXLENGTH="' + objDs.getProperty('maxlength') + '" ';
    strHTML +=        'readonly ';
    strHTML +=        'STYLE="width:' + objDs.getProperty('stylewidth') + 'px; ';
    strHTML +=               'cursor:' + strCursor + '; ';
    strHTML +=               'height:' + objDs.getProperty('styleheight') + 'px; ';
    strHTML +=               'font-family:' + objDs.getProperty('fontfamily') + '; ';
    strHTML +=               'font-size:' + objDs.getProperty('fontsize') + 'pt; ';
    strHTML +=               'font-weight:' + objDs.getProperty('fontweight') + '; ';
    strHTML +=               'font-style:' + objDs.getProperty('fontstyle') + '; ';
    strHTML +=               'color:' + objDs.getProperty('fontcolor') + '; ';
    strHTML +=               'background-color:' + strBgcolor + '; ';
    strHTML +=               'text-align:' + objDs.getProperty('textalign') + ';">';
    return strHTML;
  }

}

/**
 * AppletタイプのtypeObject実装クラス
 * @param  :
 * @return :作成したHTML文字列
 */
function objectApplet(){
  this.customProperties        = new Array('customize-visibility', 'customize-mobility');
  this.customPropertiesLiteral = new Array('visibility', 'location');

  objectApplet.prototype.createPropertyTable = fnCreatePropertyTable;
  objectApplet.prototype.setDefaultProperty  = fnSetDefaultProperty;
  objectApplet.prototype.getPropertiesHtml   = fnGetPropertiesHtml;

  function fnCreatePropertyTable(elementId){

    // ## 表示・非表示
    var dispFlg = true;
    if(parseInt(m_monitorEditStatus) == 2){
      dispFlg = false;
    }

    var rtnHTML  = '';
        rtnHTML += createTextTypeProperty('property.width_px', 'stylewidth', 'right', 'disabled', dispFlg);
        rtnHTML += createTextTypeProperty('property.height_px', 'styleheight', 'right', 'disabled', dispFlg);
        rtnHTML += createTextTypeProperty('property.objectcode', 'code', 'left', 'auto', dispFlg);
        rtnHTML += createLongStringProperty('property.objectcodebase', 'codebase', dispFlg);
        rtnHTML += createTextTypeProperty('property.imagealt', 'alt', 'left', 'auto', dispFlg);
        rtnHTML += createLongStringProperty('property.objectarchive', 'archive', dispFlg);
        rtnHTML += createTextTypeProperty('property.objecttitle', 'title', 'left', 'auto', dispFlg);
        rtnHTML += createSelectTypeProperty('property.align', 'textalign', m_textalignDefArray, false, dispFlg);
        rtnHTML += createButtonTypeProperty('property.parameter', 'params', 'paramOpen(\'params\',\'property.parameter\');', dispFlg);
        rtnHTML += createButtonTypeProperty('property.attributes', 'otherparams', 'paramOpen(\'otherparams\',\'property.attributes\');', dispFlg);
        rtnHTML += createCustomCheckProperty(this.customProperties, this.customPropertiesLiteral);
    return rtnHTML;
  }

  function fnSetDefaultProperty(strId){
    var objDS = m_objDataSet[strId];
    objDS.setProperty('stylewidth', CONSTAPPLETWIDTH);
    objDS.setProperty('styleheight', CONSTAPPLETHEIGHT);
    objDS.setProperty('visibility', CONSTDEFAULTVISIBILITY);
    objDS.setProperty('customize-mobility', 'disabled');
    objDS.setProperty('customize-visibility', 'disabled');
    objDS.setProperty('textalign', CONSTDEFAULTTEXTALIGN);
  }

  function fnGetPropertiesHtml(objDs){

    var strBgcolor = getBgcolorType(objDs, 0);
    var strCursor  = getCursorType(objDs);

    var strHTML = '';
    strHTML += '<INPUT TYPE="TEXT" ';
    strHTML +=        'ID="' + objDs.getProperty('id') + '" ';
    //strHTML +=        'TITLE="' + getLiteral('pageitemtype.applet') + '" ';
    strHTML +=        'STYLE="cursor:' + strCursor + '; border:1px #FFCC99 solid; background-image:url(' + CONSTAPPLETIMAGE + '); ';
    strHTML +=               'width:' + objDs.getProperty('stylewidth') + 'px; height:' + objDs.getProperty('styleheight') + 'px; ';
    strHTML +=               'background-color:' + strBgcolor + '; '
    strHTML +=               'background-repeat: no-repeat; background-position: center center;" readonly>';
    return strHTML;
  }
}

/**
 * EmbedタイプのtypeObject実装クラス
 * @param  :
 * @return :作成したHTML文字列
 */
function objectEmbed(){
  this.customProperties        = new Array('customize-visibility', 'customize-mobility');
  this.customPropertiesLiteral = new Array('visibility', 'location');

  objectEmbed.prototype.createPropertyTable = fnCreatePropertyTable;
  objectEmbed.prototype.setDefaultProperty  = fnSetDefaultProperty;
  objectEmbed.prototype.getPropertiesHtml   = fnGetPropertiesHtml;

  function fnCreatePropertyTable(elementId){

    // ## 表示・非表示
    var dispFlg = true;
    if(parseInt(m_monitorEditStatus) == 2){
      dispFlg = false;
    }

    var rtnHTML  = '';
        rtnHTML += createTextTypeProperty('property.width_px', 'stylewidth', 'right', 'disabled', dispFlg);
        rtnHTML += createTextTypeProperty('property.height_px', 'styleheight', 'right', 'disabled', dispFlg);
        rtnHTML += createLongStringProperty('property.objectsrc', 'src', dispFlg);
        rtnHTML += createTextTypeProperty('property.objectcode', 'code', 'left', 'auto', dispFlg);
        rtnHTML += createLongStringProperty('property.objectcodebase', 'codebase', dispFlg);
        rtnHTML += createTextTypeProperty('property.imagealt', 'alt', 'left', 'auto', dispFlg);
        rtnHTML += createTextTypeProperty('property.objecttitle', 'title', 'left', 'auto', dispFlg);
        rtnHTML += createSelectTypeProperty('property.align', 'textalign', m_textalignDefArray, false, dispFlg);
        rtnHTML += createButtonTypeProperty('property.parameter', 'params', 'paramOpen(\'params\',\'property.parameter\');', dispFlg);
        rtnHTML += createButtonTypeProperty('property.attributes', 'otherparams', 'paramOpen(\'otherparams\',\'property.attributes\');', dispFlg);
        rtnHTML += createCustomCheckProperty(this.customProperties, this.customPropertiesLiteral);
    return rtnHTML;
  }

  function fnSetDefaultProperty(strId){
    var objDS = m_objDataSet[strId];
    objDS.setProperty('stylewidth', CONSTEMBEDWIDTH);
    objDS.setProperty('styleheight', CONSTEMBEDHEIGHT);
    objDS.setProperty('visibility', CONSTDEFAULTVISIBILITY);
    objDS.setProperty('customize-mobility', 'disabled');
    objDS.setProperty('customize-visibility', 'disabled');
    objDS.setProperty('textalign', CONSTDEFAULTTEXTALIGN);
  }

  function fnGetPropertiesHtml(objDs){

    var strBgcolor = getBgcolorType(objDs, 0);
    var strCursor  = getCursorType(objDs);

    var strHTML = '';
    strHTML += '<INPUT TYPE="TEXT" ';
    strHTML +=        'ID="' + objDs.getProperty('id') + '" ';
    //strHTML +=        'TITLE="' + getLiteral('pageitemtype.embed') + '" ';
    strHTML +=        'STYLE="cursor:' + strCursor + '; border:1px #FFCC99 solid; background-image:url(' + CONSTEMBEDIMAGE + '); ';
    strHTML +=               'width:' + objDs.getProperty('stylewidth') + 'px; height:' + objDs.getProperty('styleheight') + 'px; ';
    strHTML +=               'background-color:' + strBgcolor + '; '
    strHTML +=               'background-repeat: no-repeat; background-position: center center; " readonly>';
    return strHTML;
  }

}

/**
 * ObjectタイプのtypeObject実装クラス
 * @param  :
 * @return :作成したHTML文字列
 */
function objectObject(){
  this.customProperties        = new Array('customize-visibility', 'customize-mobility');
  this.customPropertiesLiteral = new Array('visibility', 'location');

  objectObject.prototype.createPropertyTable = fnCreatePropertyTable;
  objectObject.prototype.setDefaultProperty  = fnSetDefaultProperty;
  objectObject.prototype.getPropertiesHtml   = fnGetPropertiesHtml;

  function fnCreatePropertyTable(elementId){

    // ## 表示・非表示
    var dispFlg = true;
    if(parseInt(m_monitorEditStatus) == 2){
      dispFlg = false;
    }

    var rtnHTML  = '';
        rtnHTML += createTextTypeProperty('property.width_px', 'stylewidth', 'right', 'disabled', dispFlg);
        rtnHTML += createTextTypeProperty('property.height_px', 'styleheight', 'right', 'disabled', dispFlg);
        rtnHTML += createLongStringProperty('property.objectclassid', 'classid', dispFlg);
        rtnHTML += createTextTypeProperty('property.objectcode', 'code', 'left', 'auto', dispFlg);
        rtnHTML += createLongStringProperty('property.objectcodebase', 'codebase', dispFlg);
        rtnHTML += createTextTypeProperty('property.imagealt', 'alt', 'left', 'auto', dispFlg);
        rtnHTML += createLongStringProperty('property.objectarchive', 'archive', dispFlg);
        rtnHTML += createTextTypeProperty('property.objecttitle', 'title', 'left', 'auto', dispFlg);
        rtnHTML += createSelectTypeProperty('property.align', 'textalign', m_textalignDefArray, false, dispFlg);
        rtnHTML += createButtonTypeProperty('property.parameter', 'params', 'paramOpen(\'params\',\'property.parameter\');', dispFlg);
        rtnHTML += createButtonTypeProperty('property.attributes', 'otherparams', 'paramOpen(\'otherparams\',\'property.attributes\');', dispFlg);
        rtnHTML += createLongStringProperty('property.embedsrc', 'embedsrc', dispFlg);
        rtnHTML += createButtonTypeProperty('property.embedparameter', 'embedparams', 'paramOpen(\'embedparams\',\'property.embedparameter\');', dispFlg);
        rtnHTML += createButtonTypeProperty('property.embedattributes', 'embedotherparams', 'paramOpen(\'embedotherparams\',\'property.embedattributes\');', dispFlg);
        rtnHTML += createCustomCheckProperty(this.customProperties, this.customPropertiesLiteral);
    return rtnHTML;
  }

  function fnSetDefaultProperty(strId){
    var objDS = m_objDataSet[strId];
    objDS.setProperty('stylewidth', CONSTOBJECTWIDTH);
    objDS.setProperty('styleheight', CONSTOBJECTHEIGHT);
    objDS.setProperty('visibility', CONSTDEFAULTVISIBILITY);
    objDS.setProperty('customize-mobility', 'disabled');
    objDS.setProperty('customize-visibility', 'disabled');
    objDS.setProperty('textalign', CONSTDEFAULTTEXTALIGN);
  }

  function fnGetPropertiesHtml(objDs){

    var strBgcolor = getBgcolorType(objDs, 0);
    var strCursor  = getCursorType(objDs);

    var strHTML = '';
    strHTML += '<INPUT TYPE="TEXT" ';
    strHTML +=        'ID="' + objDs.getProperty('id') + '" ';
    //strHTML +=        'TITLE="' + getLiteral('pageitemtype.object') + '" ';
    strHTML +=        'STYLE="cursor:' + strCursor + '; border:1px #FFCC99 solid; background-image:url(' + CONSTOBJECTIMAGE + '); ';
    strHTML +=               'width:' + objDs.getProperty('stylewidth') + 'px; height:' + objDs.getProperty('styleheight') + 'px; ';
    strHTML +=               'background-color:' + strBgcolor + '; '
    strHTML +=               'background-repeat: no-repeat; background-position: center center; " readonly>';
    return strHTML;
  }

}

/**
 * SubmitタイプのtypeObject実装クラス
 * @param  :
 * @return :作成したHTML文字列
 */
function objectSubmit(){
  this.customProperties        = new Array('customize-visibility', 'customize-mobility');
  this.customPropertiesLiteral = new Array('visibility', 'location');

  objectSubmit.prototype.createPropertyTable = fnCreatePropertyTable;
  objectSubmit.prototype.setDefaultProperty  = fnSetDefaultProperty;
  objectSubmit.prototype.getPropertiesHtml   = fnGetPropertiesHtml;

  function fnCreatePropertyTable(elementId){

    // ## 表示・非表示
    var dispFlg = true;
    if(parseInt(m_monitorEditStatus) == 2){
      dispFlg = false;
    }

    var rtnHTML  = '';
        rtnHTML += createTextTypeProperty('property.width_px', 'stylewidth', 'right', 'disabled', dispFlg);
        rtnHTML += createTextTypeProperty('property.height_px', 'styleheight', 'right', 'disabled', dispFlg);
        rtnHTML += createTextTypeProperty('property.buttonlabel', 'value', 'left', 'auto', dispFlg);
        rtnHTML += createTextTypeProperty('property.fontsize_pt', 'fontsize', 'right', 'disabled', dispFlg);
        rtnHTML += createColorTypeProperty('property.fontcolor', 'fontcolor', dispFlg);
        rtnHTML += createColorTypeProperty('property.backgroundcolor', 'stylebgcolor', dispFlg);
        rtnHTML += createSelectTypeProperty('property.accesskey', 'accesskey', m_accessKeyDefArray, false, dispFlg);
        rtnHTML += createLongStringProperty('property.style', 'style', dispFlg);
        rtnHTML += createEventTypeProperty('property.onclick', 'onclick', dispFlg);
        rtnHTML += createCustomCheckProperty(this.customProperties, this.customPropertiesLiteral);
    return rtnHTML;
  }

  function fnSetDefaultProperty(strId){
    var objDS = m_objDataSet[strId];
    objDS.setProperty('stylewidth', CONSTBUTTONWIDTH);
    objDS.setProperty('styleheight', CONSTBUTTONHEIGHT);
    objDS.setProperty('visibility', CONSTDEFAULTVISIBILITY);
    objDS.setProperty('value', getLiteral('initialvalue.submit.value'));
    objDS.setProperty('customize-mobility', 'disabled');
    objDS.setProperty('customize-visibility', 'disabled');
    objDS.setProperty('fontsize', CONSTDEFAULTFONTSIZE);
  }

  function fnGetPropertiesHtml(objDs){

    var strBgcolor = getBgcolorType(objDs, 0);
    var strCursor  = getCursorType(objDs);

    var strHTML = '';
    strHTML += '<INPUT TYPE="BUTTON" ';
    strHTML +=        'ID="' + objDs.getProperty('id') + '" ';
    strHTML +=        'VALUE="' + objDs.getProperty('value') + '" ';

    strHTML +=        'onmousedown="" ';

    strHTML +=        'STYLE="width:' + objDs.getProperty('stylewidth') + 'px; ';
    strHTML +=               'cursor:' + strCursor + '; ';
    strHTML +=               'height:' + objDs.getProperty('styleheight') + 'px; ';
    strHTML +=               'font-size:' + objDs.getProperty('fontsize') + 'pt; ';
    strHTML +=               'color:' + objDs.getProperty('fontcolor') + '; ';
    strHTML +=               'background-color:' + strBgcolor + ';">';
    return strHTML;
  }

}

/**
 * ResetタイプのtypeObject実装クラス
 * @param  :
 * @return :作成したHTML文字列
 */
function objectReset(){
  this.customProperties        = new Array('customize-visibility', 'customize-mobility');
  this.customPropertiesLiteral = new Array('visibility', 'location');

  objectReset.prototype.createPropertyTable = fnCreatePropertyTable;
  objectReset.prototype.setDefaultProperty  = fnSetDefaultProperty;
  objectReset.prototype.getPropertiesHtml   = fnGetPropertiesHtml;

  function fnCreatePropertyTable(elementId){

    // ## 表示・非表示
    var dispFlg = true;
    if(parseInt(m_monitorEditStatus) == 2){
      dispFlg = false;
    }

    var rtnHTML  = '';
        rtnHTML += createTextTypeProperty('property.width_px', 'stylewidth', 'right', 'disabled', dispFlg);
        rtnHTML += createTextTypeProperty('property.height_px', 'styleheight', 'right', 'disabled', dispFlg);
        rtnHTML += createTextTypeProperty('property.buttonlabel', 'value', 'left', 'auto', dispFlg);
        rtnHTML += createTextTypeProperty('property.fontsize_pt', 'fontsize', 'right', 'disabled', dispFlg);
        rtnHTML += createColorTypeProperty('property.fontcolor', 'fontcolor', dispFlg);
        rtnHTML += createColorTypeProperty('property.backgroundcolor', 'stylebgcolor', dispFlg);
        rtnHTML += createSelectTypeProperty('property.accesskey', 'accesskey', m_accessKeyDefArray, false, dispFlg);
        rtnHTML += createLongStringProperty('property.style', 'style', dispFlg);
        rtnHTML += createEventTypeProperty('property.onclick', 'onclick', dispFlg);
        rtnHTML += createCustomCheckProperty(this.customProperties, this.customPropertiesLiteral);
    return rtnHTML;
  }

  function fnSetDefaultProperty(strId){
    var objDS = m_objDataSet[strId];
    objDS.setProperty('stylewidth', CONSTBUTTONWIDTH);
    objDS.setProperty('styleheight', CONSTBUTTONHEIGHT);
    objDS.setProperty('visibility', CONSTDEFAULTVISIBILITY);
    objDS.setProperty('value', getLiteral('initialvalue.reset.value'));
    objDS.setProperty('customize-mobility', 'disabled');
    objDS.setProperty('customize-visibility', 'disabled');
    objDS.setProperty('fontsize', CONSTDEFAULTFONTSIZE);
  }

  function fnGetPropertiesHtml(objDs){

    var strBgcolor = getBgcolorType(objDs, 0);
    var strCursor  = getCursorType(objDs);

    var strHTML = '';
    strHTML += '<INPUT TYPE="BUTTON" ';
    strHTML +=        'ID="' + objDs.getProperty('id') + '" ';
    strHTML +=        'VALUE="' + objDs.getProperty('value') + '" ';

    strHTML +=        'onmousedown="" ';

    strHTML +=        'STYLE="width:' + objDs.getProperty('stylewidth') + 'px; ';
    strHTML +=               'cursor:' + strCursor + '; ';
    strHTML +=               'height:' + objDs.getProperty('styleheight') + 'px; ';
    strHTML +=               'font-size:' + objDs.getProperty('fontsize') + 'pt; ';
    strHTML +=               'color:' + objDs.getProperty('fontcolor') + '; ';
    strHTML +=               'background-color:' + strBgcolor + ';">';
    return strHTML;
  }

}

/**
 * IframeタイプのtypeObject実装クラス
 * @param  :
 * @return :作成したHTML文字列
 */
function objectIframe(){
  this.customProperties        = new Array('customize-visibility', 'customize-mobility');
  this.customPropertiesLiteral = new Array('visibility', 'location');

  objectIframe.prototype.createPropertyTable = fnCreatePropertyTable;
  objectIframe.prototype.setDefaultProperty  = fnSetDefaultProperty;
  objectIframe.prototype.getPropertiesHtml   = fnGetPropertiesHtml;

  function fnCreatePropertyTable(elementId){

    // ## 表示・非表示
    var dispFlg = true;
    if(parseInt(m_monitorEditStatus) == 2){
      dispFlg = false;
    }

    var rtnHTML  = '';
        rtnHTML += createTextTypeProperty('property.width_px', 'stylewidth', 'right', 'disabled', dispFlg);
        rtnHTML += createTextTypeProperty('property.height_px', 'styleheight', 'right', 'disabled', dispFlg);
        rtnHTML += createTextTypeProperty('property.framename', 'framename', 'left', 'disabled', dispFlg);
        rtnHTML += createLongStringProperty('property.framesrc', 'src', dispFlg);
        rtnHTML += createSelectTypeProperty('property.framescrolling', 'scrolling', m_framescrollingDefArray, false, dispFlg);
        //rtnHTML += createTextTypeProperty('property.borderwidth', 'border', 'right', 'disabled', dispFlg);
        //rtnHTML += createColorTypeProperty('property.bordercolor', 'bordercolor', dispFlg);
        rtnHTML += createCustomCheckProperty(this.customProperties, this.customPropertiesLiteral);
    return rtnHTML;
  }

  function fnSetDefaultProperty(strId){
    var objDS = m_objDataSet[strId];
    objDS.setProperty('visibility', CONSTDEFAULTVISIBILITY);
    objDS.setProperty('customize-mobility', 'disabled');
    objDS.setProperty('customize-visibility', 'disabled');
    objDS.setProperty('stylewidth', CONSTIFRAMEWIDTH);
    objDS.setProperty('styleheight', CONSTIFRAMEHEIGHT);
    objDS.setProperty('scrolling', 'auto');
    //objDS.setProperty('framename', strId);
  }

  function fnGetPropertiesHtml(objDs){

    var strBgcolor = getBgcolorType(objDs, 0);
    //var strBgcolor = 'white';
    var strCursor  = getCursorType(objDs);
    var width = objDs.getProperty('stylewidth');
    var height = objDs.getProperty('styleheight');
    if(!width) {
      width = CONSTIFRAMEWIDTH;
    }
    if(!height) {
      height = CONSTIFRAMEHEIGHT;
    }

    var strHTML = '';
    strHTML += '<INPUT TYPE="TEXT" ';
    strHTML +=        'ID="' + objDs.getProperty('id') + '" ';
    strHTML +=        'VALUE="' + objDs.getProperty('src') + '" ';
    //strHTML +=        'TITLE="' + getLiteral('pageitemtype.iframe') + '" ';
    strHTML +=        'STYLE="cursor:' + strCursor + '; ';
    strHTML +=               'font-size:10pt; '
    strHTML +=               'background-color:' + strBgcolor + '; '
    strHTML +=               'width:' + width + 'px; height:' + height + 'px;" readonly>';
    return strHTML;

  }

}


/**
 * データ保持オブジェクトからプロパティ値を取得し、プロパティテーブルに書き込む
 * @param  :attType 文字型 プロパティタイプ名
 * @return :
 */
function fnSetPropertyTable(attType, objDS){
  //各属性：ハードコーディング
  var attVal;
//  var objDS = m_objDataSet[m_currentElement];
  var attType = attType.toLowerCase()
  switch(attType){
//共通(複数使用)

    case 'maxlength':
      attVal = objDS.getProperty(attType);
      if(attVal >= 500){
        attVal = 10;
        document.getElementById(m_currentElement).maxLength = 10;
      }
      break;

    case 'bgcolor':
    case 'stylebgcolor':
    case 'textcolor':
    case 'linkcolor':
    case 'vlinkcolor':
    case 'alinkcolor':
    case 'fontcolor':
      attVal = objDS.getProperty(attType);
      setElementStyleBackgroundColor(document.getElementById('fld_' + attType + '_span'), attVal);
      break;
    
    case 'bordercolor':
      attVal = objDS.getProperty(attType);
      if(!attVal) attVal = '';
      objDS.setProperty('bordercolor', attVal);
      setElementStyleBackgroundColor(document.getElementById('fld_bordercolor_span'), attVal);
      break;
      
    case 'fontstyle':
    case 'underline':
      if(objDS.getProperty(attType).length != 0){
        document.getElementById('fld_' + attType).checked = true;
      }else{
        document.getElementById('fld_' + attType).checked = false;
      }
      break;
    
    case 'textalign':
      attVal = objDS.getProperty(attType).toLowerCase();
      break;
    
    case 'src':
      try{
        attVal = objDS.getProperty(attType);
      }catch(e){
        attVal = '';
      }
      break;
      
//カスタマイズ
    case 'customize-visibility':
    case 'customize-mobility':
    case 'customize-defaultvalue':
      attVal = objDS.getProperty(attType);
      if(attVal == 'enabled'){
        document.getElementById('fld_' + attType).checked = true;
      }else{
        document.getElementById('fld_' + attType).checked = false;
      }
      break;
    
    case 'customize-maxlines':
      attVal = objDS.getProperty(attType);
      //ラインモード時のみ設定可能
      if(objDS.getProperty('mode') == 'MODE_LINE'){
        document.getElementById('fld_' + attType).parentNode.parentNode.style.display = '';
        document.getElementById('fld_customize-visibility').parentNode.parentNode.childNodes.item(0).rowSpan = 2;
        if(attVal == 'enabled'){
          document.getElementById('fld_' + attType).checked = true;
        }else{
          document.getElementById('fld_' + attType).checked = false;
        }
      }else{
        document.getElementById('fld_' + attType).parentNode.parentNode.style.display = 'none';
        document.getElementById('fld_customize-visibility').parentNode.parentNode.childNodes.item(0).rowSpan = 1;
        attVal = 'disabled';
      }
      break;
      
//FORM(PAGE)
    case 'pageheight':
      attVal = objDS.getProperty(attType);
      if(attVal == ''){
        attVal = document.getElementById(CONSTTEMPFORMID).style.height.toString().replace('px','');
      }
      break;
      
    case 'pagewidth':
      attVal = objDS.getProperty('pagewidth');
      if(attVal == ''){
        attVal = document.getElementById(CONSTTEMPFORMID).style.width.toString().replace('px','');
      }
      break;
      
    case 'action':
      attVal = objDS.getProperty(attType);
      //actionのデフォルト値をconstから取得
      if(!attVal){
        attVal = CONSTACTIONDEFVALUE.toLowerCase();
      }
      break;
      
    case 'method':
      attVal = objDS.getProperty(attType);
      //methodのデフォルト値をconstから取得
      if(!attVal){
        attVal = CONSTMETHODDEFVALUE;
      }
      break;
      
//PANEL
    case 'width':
      attVal = objDS.getProperty(attType).toString();
      if(attVal == 0){
        attVal = 100;
      }
      if(objDS.getProperty('type') == 'PANEL'){
        attVal = document.getElementById(m_currentElement).offsetWidth;
      }
      break;
      
//LIST
    case 'multiple':
      if(objDS.getProperty('multiple') == 'multiple'){
        document.getElementById('fld_' + attType).checked = true;
      }else{
        document.getElementById('fld_' + attType).checked = false;
      }
      break;
      
    case 'size':
      attVal = objDS.getProperty(attType);
      if(attVal.length == 0){
        attVal = 2;
        document.getElementById(m_currentElement).size = attVal;
      }
      break;
      
//RADIO
    case 'radiofontcolor':
      attVal = objDS.getProperty(attType);
      if(!attVal) attVal = '';
      objDS.setProperty(attType, attVal);
      setElementStyleBackgroundColor(document.getElementById('fld_' + attType + '_span'), attVal);
      break;
      
//TEXTAREA
    case 'editmode':
      attVal = objDS.getProperty(attType);
      if(attVal == ''){
        document.getElementById('fld_' + attType).checked = false;
      }else{
        document.getElementById('fld_' + attType).checked = true;
      }
      break;
      
//TABLE
    case 'cellspacing':
      attVal = objDS.getProperty(attType);
      if(attVal.length == 0){
        attVal = 0;
      }
      break;
      
    case 'cellpadding':
      attVal = objDS.getProperty(attType);
      if(attVal.length == 0){
        attVal = 0;
      }
      break;
      
    case 'borderwidth':
      attVal = objDS.getProperty(attType).toString();
      //if(attVal.length == 0){
      //  attVal = 1;
      //}
      break;
      
    case 'mode':
      attVal = objDS.getProperty(attType);
      if(attVal == ''){
        attVal = 'MODE_SIMPLE';
      }

      // ##
      if(parseInt(m_monitorEditStatus) != 2){
        if(attVal == 'MODE_SIMPLE'){
          document.getElementById('fld_maxrows_tr').style.display = '';
          document.getElementById('fld_maxlines_tr').style.display = 'none';
        }else if(attVal == 'MODE_COPY'){
          document.getElementById('fld_maxrows_tr').style.display = 'none';
          document.getElementById('fld_maxlines_tr').style.display = 'none';
        }else{
          document.getElementById('fld_maxrows_tr').style.display = 'none';
          document.getElementById('fld_maxlines_tr').style.display = '';
        }
      }
      break;
      
    case 'maxcols':
      attVal = objDS.getProperty(attType);
      if(attVal.length == 0){
        attVal = 1;
      }
      break;
      
    case 'maxrows':
    case 'maxlines':
      attVal = objDS.getProperty(attType);
      if(attVal.length == 0){
        attVal = 1;
      }
      break;
      
    case 'captionalign':
      attVal = objDS.getProperty(attType);
      if(attVal.length == 0){
        attVal = 'top';
      }
      break;
      
    case 'tdrow':
    case 'tdcol':
      if(m_currentTdObjectId.length != 0){
        attVal = m_objDataSet[m_currentTdObjectId].getProperty(attType);
        if(!attVal) attVal = '';
        m_objDataSet[m_currentTdObjectId].setProperty(attType, attVal);
      }else{
        attVal='';
      }
      break;
      
    case 'tdwidth':
      if(m_currentTdObjectId.length != 0){
        attVal = m_objDataSet[m_currentTdObjectId].getProperty(attType);
        if(attVal.length == 0){
          attVal = document.getElementById(m_currentTdObjectId).offsetWidth;
        }
        m_objDataSet[m_currentTdObjectId].setProperty(attType, attVal);
      }else{
        attVal='';
      }
      break;
      
    case 'tdheight':
      if(m_currentTdObjectId.length != 0){
        attVal = m_objDataSet[m_currentTdObjectId].getProperty(attType);
        if(attVal.length == 0){
          attVal = document.getElementById(m_currentTdObjectId).offsetHeight;
        }
        m_objDataSet[m_currentTdObjectId].setProperty(attType, attVal);
      }else{
        attVal='';
      }
      break;
      
    case 'tdbackground':
      if(m_currentTdObjectId.length != 0){
        attVal = m_objDataSet[m_currentTdObjectId].getProperty(attType);
        if(!attVal) attVal = '';
        m_objDataSet[m_currentTdObjectId].setProperty(attType, attVal);
      }else{
        attVal='';
      }
      break;
      
    case 'tdbgcolor':
    case 'tdbordercolor':
      if(m_currentTdObjectId.length != 0){
        attVal = m_objDataSet[m_currentTdObjectId].getProperty(attType);
        if(!attVal) attVal = '';
        m_objDataSet[m_currentTdObjectId].setProperty(attType, attVal);
      }else{
        attVal='';
      }
      setElementStyleBackgroundColor(document.getElementById('fld_' + attType + '_span'), attVal);
      break;
      
    case 'rows':
      attVal = objDS.getProperty(attType);
      if(attVal*1 == 0){
        attVal = 2;
      }
      break;
      
    case 'cols':
      attVal = objDS.getProperty(attType);
      if(attVal*1 == 0){
        attVal = 20;
      }
      break;
      
    case 'height':
    case 'stylewidth':
    case 'styleheight':
    case 'fontsize':
      attVal = objDS.getProperty(attType).toString();
      if(attVal == 0) attVal = '';
      break;
    
    case 'alt':
    case 'target':
      attVal = objDS.getProperty(attType);
      if(!attVal){
        attVal = '';
      }
      break;
      
    case 'background':
    case 'fontweight':
    default:
      attVal = objDS.getProperty(attType);
    break;
  }

  try{
    if(document.getElementById('fld_' + attType).type != 'button'){
      document.getElementById('fld_' + attType).value = attVal;
    }
  }catch(e){
//    var errMessageArray = new Array('VwTypeObjects.js','fnSetPropertyTable','TYPE=' + m_objDataSet[m_currentElement].getProperty('type'),'PROPERTY=' + attType,'VALUE=' + attVal);
//    printHandlingError(e, errMessageArray);
  }

}

/**
*/
function selectableOnSelectStart(_e) {
  _e.cancelBubble = true;
  _e.returnValue = true;
  return _e.returnValue;
}

///function
/**
 * text入力タイプのプロパティテーブル作成
 * @param  :strLabel     文字型  プロパティ表示名
 *          strTypeId    文字型  プロパティタイプID
 *          strTextAlign 文字型  入力エリアのテキスト水平位置
 *          boolDisplay  ブール  表示・非表示フラグ(true時表示)
 * @return :作成したHTML文字列
 */
function createTextTypeProperty(strLabel, strTypeId, strTextAlign, strIme, boolDisplay){
  //表示・非表示

  var strDisp = ';"><td width="100px">';
  if(!boolDisplay){
    strDisp   = '; display:none;"><td width="100px">';
  }
  var rtnHTML  = '<tr style="background-color:' + CONSTPROPTABLECOLOR + strDisp;
      rtnHTML += getLiteral(strLabel);
      rtnHTML += '</td><td width="100px"><input type="text" id="fld_' + strTypeId + '" style="width:98px; font-size: 9pt; text-align:' + strTextAlign + '; ime-mode:' + strIme + ';" value="" onchange="setStyle(this.id, this.value, \'' + m_currentElement + '\',\'' + m_currentTdObjectId + '\')" onfocus="setCurrentPropId(this.id)" onkeypress="return" onselectstart="selectableOnSelectStart(event)"></td></tr>';

  return rtnHTML;

}

/**
 * check入力タイプのプロパティテーブル作成
 * @param  :strLabel    文字型 プロパティ表示名
 *          strTypeId   文字型 プロパティタイプID
 *          strValue    文字型 チェック時の値
 *          strText     文字型 表示テキスト
 *          boolDisplay ブール  表示・非表示フラグ(true時表示)
 * @return :作成したHTML文字列
 */
function createCheckTypeProperty(strLabel, strTypeId, strValue, strText, boolDisplay){
  //表示・非表示

  var strDisp = ';"><td width="100px">';
  if(!boolDisplay){
    strDisp   = '; display:none;"><td width="100px">';
  }
  var rtnHTML  = '<tr style="background-color:' + CONSTPROPTABLECOLOR + strDisp;
      rtnHTML += getLiteral(strLabel);
      rtnHTML += '</td><td width="100px"><input type="checkbox" id="fld_' + strTypeId + '" style="font-size: 9pt; vertical-align:bottom;" onclick="setStyle(this.id, this.value, \'' + m_currentElement + '\',\'' + m_currentTdObjectId + '\')" value="' + strValue + '"><span style="vertical-align:bottom;">';
      rtnHTML += getLiteral(strText);
      rtnHTML += '</span></td></tr>';

  return rtnHTML;
}

/**
 * select入力タイプのプロパティテーブル作成
 * @param :strLabel    文字型       プロパティ表示名
 *         strTypeId   文字型       プロパティタイプID
 *         objData     オブジェクト value配列
 *         langFlg     ブール       getLiteralを行うかどうかのフラグ
 *         numDisplay  ブール       true時表示
 * @return :作成したHTML文字列
 */
function createSelectTypeProperty(strLabel, strTypeId, objData, langFlg, numDisplay){

  //表示・非表示
  var strDisp = ';"><td width="100px">';
  if(!numDisplay){
    strDisp = '; display:none;"><td width="100px">';
  }

  var rtnHTML  = '<tr style="background-color:' + CONSTPROPTABLECOLOR + strDisp + getLiteral(strLabel);
      rtnHTML += '</td><td width="100px"><select id="fld_' + strTypeId + '" style="width:100%; font-size: 9pt;" onchange="setStyle(this.id, this.value, \'' + m_currentElement + '\',\'' + m_currentTdObjectId + '\')">';

      rtnHTML += getOptionHtml(strTypeId, objData, langFlg) + '</select></td></tr>';

  return rtnHTML;
}

/**
 * 作成済みの文字列を保存する
 */
var m_storedHtmlString = new Object();

/**
 * <select>の<option>部分文字列作成
 * @param  :strTypeId  文字型  文字列を保存するキー
 *          objData    配列型  optionの配列
 *          langFlg    ブール  getLiteralを使用するか
 * @return :作成したHTML文字列
 */
function getOptionHtml(strTypeId, objData, langFlg) {

  if(m_storedHtmlString[strTypeId]) {
    // 文字列はすでに作成済み
    return m_storedHtmlString[strTypeId];
  }

  var rtnHTML  = '';
  var tmpGetLiteral = getLiteral;
  if(!langFlg){
    tmpGetLiteral = function(key){return key;};
  }

  for(var i in objData){
    if(objData[i] == ''){
      rtnHTML += '<option value="' + i + '">　　　　　　　　　</option>';
    }else{
      rtnHTML += '<option value="' + i + '">' + tmpGetLiteral(objData[i]) + '</option>';
    }
  }

  // 文字列保存
  m_storedHtmlString[strTypeId] = rtnHTML;

  return rtnHTML;
}

/**
 * button入力タイプのプロパティテーブル作成
 * @param  :strLabel    文字型 プロパティ表示名
 *          strTypeId   文字型 プロパティタイプID
 *          strOnclick  文字型 onclick時の処理
 *          boolDisplay ブール  表示・非表示フラグ(true時表示)
 * @return :作成したHTML文字列
 */
function createButtonTypeProperty(strLabel, strTypeId, strOnClick, boolDisplay){
  //表示・非表示

  var strDisp = ';"><td width="100px">';
  if(!boolDisplay){
    strDisp   = '; display:none;"><td width="100px">';
  }
  var rtnHTML  = '<tr style="background-color:' + CONSTPROPTABLECOLOR + strDisp;
      rtnHTML += getLiteral(strLabel);
      rtnHTML += '</td><td width="100px"><input type="button" id="fld_' + strTypeId + '" style="width:100%; font-size:9pt;' + CONSTPROPBUTTONSTYLECOLOR + '" onclick="' + strOnClick + '" value="' + getLiteral('common.editbutton') + '..."></td></tr>';

  return rtnHTML;
}

/**
 * 色入力タイプのプロパティテーブル作成
 * @param  :strLabel    文字型 プロパティ表示名
 *          strTypeId   文字型 プロパティタイプID
 *          boolDisplay ブール 表示・非表示フラグ(true時表示)
 * @return :作成したHTML文字列
 */
function createColorTypeProperty(strLabel, strTypeId, boolDisplay){

  var inputHtml  = '<input type="text" id="fld_' + strTypeId;
      inputHtml += '" style="width:70px; font-size: 9pt; text-align:left; ime-mode:disabled;" value="" onchange="setStyleColor(this.id, this.value, \'';
      inputHtml += m_currentElement + '\',\'' + m_currentTdObjectId + '\');" onfocus="setCurrentPropColorId(this.id)" onselectstart="selectableOnSelectStart(event)">';

  //表示・非表示
  var strDisp = ';"><td width="100px">';
  if(!boolDisplay){
      strDisp = '; display:none;"><td width="100px">';
  }

  var rtnHTML  = '<tr style="background-color:' + CONSTPROPTABLECOLOR + strDisp;
      rtnHTML += getLiteral(strLabel);
      rtnHTML += '</td><td width="100px"><table cellspacing="0" cellpadding="0" width="98px" height="18px" bgcolor="white"><tr><td height="1px" bgcolor="' + CONSTPROPTABLECOLOR + '"></td><td rowspan="3" style="font-size:1px;" bgcolor="' + CONSTPROPTABLECOLOR + '">';
      rtnHTML += inputHtml;
      rtnHTML += '</td></tr><tr><td width="100%" height="100%" onclick="openColorDlg(\'' + strTypeId + '\')" style="font-size:1px; background-color:white; border:1px black solid;cursor:default;" id="fld_' + strTypeId + '_span">&nbsp;</td></tr><tr><td height="1px" bgcolor="' + CONSTPROPTABLECOLOR + '"></td></tr></table></td></tr>';

  return rtnHTML;
}

/**
 * eventタイプのプロパティテーブル作成
 * @param  :strLabel     文字型 プロパティ表示名
 *          strTypeId    文字型 プロパティタイプID
 *          boolDisplay  ブール 表示・非表示フラグ(true時表示)
 * @return :作成したHTML文字列
 */
function createEventTypeProperty(strLabel, strTypeId, boolDisplay){

  //表示・非表示
  var strDisp = ';"><td width="100px">';
  if(!boolDisplay){
    strDisp = '; display:none;"><td width="100px">';
  }

  var rtnHTML  = '<tr style="background-color:' + CONSTPROPTABLECOLOR + strDisp;
      rtnHTML += getLiteral(strLabel);
      rtnHTML += '</td><td width="100px"><input type="text" id="fld_' + strTypeId + '" style="width:82px; font-size: 9pt; ime-mode:auto;" value="" onchange="setStyle(this.id, this.value, \'' + m_currentElement + '\',\'' + m_currentTdObjectId + '\')" onfocus="setCurrentPropId(this.id)" onselectstart="selectableOnSelectStart(event)">';
      rtnHTML += '<input type="button" id="fld_' + strTypeId + '_btn" style="width:16px; height:20px; font-size: 9pt;' + CONSTPROPBUTTONSTYLECOLOR + '" value="..." onclick="eventOpen(\'' + strTypeId + '\')"></td></tr>';

  return rtnHTML;
}

/**
 * ファイル名、URL入力タイプのプロパティテーブル作成
 * @param  :strLabel     文字型 プロパティ表示名
 *          strTypeId    文字型 プロパティタイプID
 *          boolDisplay  ブール 表示・非表示フラグ(true時表示)
 * @return :
 */
function createLongStringProperty(strLabel, strTypeId, boolDisplay, elementId, _dialog){

  //表示・非表示
  var strDisp = ';"><td width="100px">';
  if(!boolDisplay){
    strDisp = '; display:none;"><td width="100px">';
  }

  if(strTypeId == 'style'){
    var strIme = 'ime-mode:disabled;';
  }else{
    var strIme = 'ime-mode:auto;';
  }

  if(!elementId) {
    elementId = '';
  }

  var param_dialog = '';
  if(_dialog) {
    param_dialog = ',\'' + _dialog + '\'';
  }
    
  var rtnHTML  = '<tr style="background-color:' + CONSTPROPTABLECOLOR + strDisp;
      rtnHTML += getLiteral(strLabel);
      rtnHTML += '</td><td width="100px"><input type="text" id="fld_' + strTypeId + '" style="width:82px; font-size: 9pt; ' + strIme + '" value="" onchange="setStyle(this.id, this.value, \'' + m_currentElement + '\',\'' + m_currentTdObjectId + '\')" onfocus="setCurrentPropId(this.id)" onselectstart="selectableOnSelectStart(event)">';
      rtnHTML += '<input type="button" id="fld_' + strTypeId + '_btn" style="width:16px; height:20px; font-size: 9pt;' + CONSTPROPBUTTONSTYLECOLOR + '" value="..." onclick="longStringOpen(\'' + strTypeId + '\',\'' + getLiteral(strLabel) + '\',\'' + elementId + '\'' + param_dialog + ')"></td></tr>';

  return rtnHTML;
}

/**
 * ファイル名、URL入力タイプのプロパティテーブル作成
 * @param  :strLabel     文字型 プロパティ表示名
 *          strTypeId    文字型 プロパティタイプID
 *          boolDisplay  ブール 表示・非表示フラグ(true時表示)
 * @return :
 */
function createImageNameProperty(strLabel, strTypeId, boolDisplay, elementId){
  return createLongStringProperty(strLabel, strTypeId, boolDisplay, elementId, 'IMAGELIST');
}

/**
 * カスタマイズ用プロパティテーブル作成
 * @param  :properties        配列 プロパティ文字列
 *          propertiesLiteral 配列 プロパティリテラル文字列
 * @return :
 */
function createCustomCheckProperty(properties, propertiesLiteral){

  var rtnHTML  = '';

  // ## カスタマイズ編集時は作成時にdisabledに設定しておく

  var tmpPropLen = properties.length;
  if(parseInt(m_monitorEditStatus) == 2){
      rtnHTML += '<tr><td rowspan="' + properties.length + '">' + getLiteral('property.customized');
      rtnHTML += '</td><td><input id="fld_' + properties[0] + '" type="checkbox" style="vertical-align:bottom;" value="enable" onclick="setOrgValue(this.id)" disabled>';
      rtnHTML += '<span style="vertical-align:bottom;">' + getLiteral('customized.' + propertiesLiteral[0]) + '</span></td></tr>';
      for(var i=1; i<tmpPropLen; i++){
        rtnHTML += '<tr><td><input id="fld_' + properties[i] + '" type="checkbox" style="vertical-align:bottom;" value="enable" onclick="setOrgValue(this.id)" disabled>';
        rtnHTML += '<span style="vertical-align:bottom;">' + getLiteral('customized.' + propertiesLiteral[i]) + '</span></td></tr>';
      }
  }else{
      rtnHTML += '<tr><td rowspan="' + properties.length + '">' + getLiteral('property.customizable');
      rtnHTML += '</td><td><input id="fld_' + properties[0] + '" type="checkbox" style="vertical-align:bottom;" value="enable" onclick="setStyle(this.id, this.value, \'' + m_currentElement + '\',\'' + m_currentTdObjectId + '\')">';
      rtnHTML += '<span style="vertical-align:bottom;">' + getLiteral('customizable.' + propertiesLiteral[0]) + '</span></td></tr>';
      for(var i=1; i<tmpPropLen; i++){
        rtnHTML += '<tr><td><input id="fld_' + properties[i] + '" type="checkbox" style="vertical-align:bottom;" value="enable" onclick="setStyle(this.id, this.value, \'' + m_currentElement + '\')">';
        rtnHTML += '<span style="vertical-align:bottom;">' + getLiteral('customizable.' + propertiesLiteral[i]) + '</span></td></tr>';
      }
  }

  return rtnHTML;

}

/**
 * エレメントの色を取得
 * @param  :objDs        オブジェクト dataSetObject
 *          numColorProp 数値型       背景色設定プロパティ(0:stylebgcolor,1:bgcolor)
 * @return :
 */
function getBgcolorType(objDs, numColorProp){
  if(objDs.getProperty('visibility') == 'hidden'){
    return CONSTHIDDENCOLOR;
  }else{
    if(numColorProp == 0){
      return objDs.getProperty('stylebgcolor');
    }else{
      return objDs.getProperty('bgcolor');
    }
  }
}

/**
 * エレメントonmouseover時のカーソル形状を決定する
 * @param  :objDs オブジェクト dataSetObject
 * @return :      文字型       カーソル形状
 */
function getCursorType(objDs){
  // ## カーソル形状取得 カスタマイズ編集時にカスタマイズ不可場合に矢印を使用
  var strCursor = 'pointer';
  if(parseInt(m_monitorEditStatus) == 2){
    if(!objDs.getItemCustomizable()){
      strCursor = 'default';
    }
  }
  return strCursor;
}


