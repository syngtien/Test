/**
 * バックグラウンド処理クラス。
 * 処理は複数の場合、前の処理が終わってから、次の処理が始まるように修正した。
 */
function BGProcess() {
  this.currentWin = null;
  this.currentPageId = null;
  this.currentPageMsg = null;
  this.processKeys = new Array();
  //画面表示中に承認完了した場合、障害を対応ため、バックアップする
  this.processKeysBak = new Array();
  this.processValues = new Array();
  this.running = false;
  //最後に削除されたキー、isProcessingに使う
  this.lastKey = null;
  return this;
}

/**
 * 現在処理するページ情報を設定。
 * @param win windowオブジェクト
 * @param pageId ページID（終了時に表示されるので、日本語のページタイトルでよい）
 */
BGProcess.prototype.setCurrent = function (win, pageId) {
  this.currentWin = win;
  this.currentPageId = pageId;
}

/**
 * 現在処理するページ情報の設定は正しくかをチェック。
 */
BGProcess.prototype.checkCurrentSet = function () {
  if(!this.currentWin || !this.currentWin.document || !this.currentWin.document.forms) {
    alert('バックグラウンド処理のwindowを設定してください。');
    return fasle;
  }
  if(!this.currentPageId || this.currentPageId == '') {
    alert('バックグラウンド処理のpageIdを設定してください。');
    return false;
  }
  return true;
}

/**
 * バックグラウンド実行する。
 * @param title 情報表示に使う
 * @param processid 実行するプロセスID
 * @param processmode 実行するプロセスモード
 * @param optionparams 実行するプロセスのパラメータ
 * @param key 処理する項目のキー（伝票種別ID+伝票番号など）
 * @param errorinfo エラーが発生する場合、表示する情報
 */
BGProcess.prototype.run = function (title, processid, processmode, optionparams, key, errorinfo) {
  if (!this.checkCurrentSet()) {
    return false;
  }
  this.addProcessInfo(this.currentPageId + '|' + key, title, processid, processmode, optionparams, key, errorinfo);
  window.status='バックグラウンド処理実行中：'+this.processKeys.length+'...';
  if (this.running) {
    //前のプロセスが完了したら自動で起動
    return true;
  }
  this.running = true;
  this.runRealStart(title, processid, processmode, optionparams, key, errorinfo);
  return true;
}

/**
 * バックグラウンド実行する。
 * @param title 情報表示に使う
 * @param processid 実行するプロセスID
 * @param processmode 実行するプロセスモード
 * @param optionparams 実行するプロセスのパラメータ
 * @param key 処理する項目のキー（伝票種別ID+伝票番号など）
 * @param errorinfo エラーが発生する場合、表示する情報
 */
BGProcess.prototype.runRealStart = function (title, processid, processmode, optionparams, key, errorinfo) {
  //ローカル変数を待避する、必要
  var thisobj = this;
  thisobj.running = true;
  var pageid = thisobj.currentPageId;

  var xmlhttp = thisobj.getXMLHttp();
  xmlhttp.open("POST", "appcontroller", true);
  xmlhttp.setRequestHeader("Content-Type" , "application/x-www-form-urlencoded");
  var postdata = "PROCESSID="+processid+"&PROCESSMODE="+processmode+"&PAGEID=NULL&JSPID=jsp/XML&ERRORJSPID=jsp/XML&"+optionparams;

  /**
   * 非同期処理がサーバから戻ったらの続き。（内部変数はthisobjで使う）
   */
  xmlhttp.onreadystatechange = function() 
  {
    if (xmlhttp.readyState == 4) {
      thisobj.lastKey = pageid + '|' + key;
      thisobj.removeProcessInfo(pageid + '|' + key);

      if (xmlhttp.status != 200) {
        thisobj.lastKey = null;
        var errmsg = title + 'の実行でエラーが発生しました。\n'+errorinfo+'\nエラー内容:エラーコード='+xmlhttp.status;
        alert(errmsg+'\n'+xmlhttp.responseText);
        window.status=errmsg;
      } else {
        var xmlDoc = xmlhttp.responseXML;
        var status = xmlDoc.getElementsByTagName('status')[0].firstChild.nodeValue; // MBB終了コード： 0=正常,1=情報,2=警告,3=エラー
        if (status == '3') {
          // エラーが発生した場合
          thisobj.lastKey = null;
          var errmsg = '';
          for (i = 0; i < xmlDoc.getElementsByTagName('error').length; ++i) {
            errmsg = errmsg + xmlDoc.getElementsByTagName('error')[i].firstChild.nodeValue + '\n';
          }
          errmsg = title + 'の実行でエラーが発生しました。\n'+errorinfo+'\nエラー内容:'+errmsg;
          alert(errmsg);
          if (thisobj.processKeys.length == 0) {
            window.status=errmsg;
          }
        } else {
          // 警告・情報は無視して正常終了とする
          if (thisobj.processKeys.length > 0) {
            window.status='バックグラウンド処理実行中：'+thisobj.processKeys.length+'...';
          } else {
            window.status=title+'('+errorinfo+')は正常終了しました。';
          }
        }
      }
      //if (thisobj.processKeys.length == 0) {
      //  alert('バックグラウンドプロセスは全て終了しました。');
      //}
      if (!thisobj.isProcessingPage(pageid)){
        thisobj.lastKey = null;
        alert(pageid+'のバックグラウンドプロセスは全て終了しました。');
      }
      //次プロセスを起動
      thisobj.running = false;
      if (thisobj.processKeys.length > 0) {
        var nextProcess = thisobj.processValues[0];
        thisobj.runRealStart(nextProcess[0], nextProcess[1], nextProcess[2], nextProcess[3], nextProcess[4], nextProcess[5]);
      }
    }
  }
  xmlhttp.send(encodeURI(postdata));
  return true;
}

/**
 * 非同期処理XMLHTTPを取得する。
 */
BGProcess.prototype.getXMLHttp = function () {
  var xmlhttp;
  try {
    xmlhttp = new ActiveXObject("Msxml2.XMLHTTP");
  } catch (e) {
    try {
      xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
    } catch (E) {
      xmlhttp = false;
    }
  }
  if (!xmlhttp && typeof XMLHttpRequest!='undefined') {
    xmlhttp = new XMLHttpRequest();
  }
  return xmlhttp;
}

/**
 * 指定キーを追加する
 * @param key runするに指定したキー。
 * @param 二番目以降 はこのキーに関する情報。
 */
BGProcess.prototype.addProcessInfo = function (key, title, processid, processmode, optionparams, key2, errorinfo) {
  var nCurrentCount = this.processKeys.length;
  this.processKeys[nCurrentCount] = key;
  this.processValues[nCurrentCount] = new Array(title, processid, processmode, optionparams, key2, errorinfo);
}

/**
 * 指定キーを削除する
 * @param key runするに指定したキー。
 */
BGProcess.prototype.removeProcessInfo = function (key) {
  for (var i = this.processKeys.length - 1; i >= 0; i--) {
    if (this.processKeys[i] == key) {
      //バックアップする
      var nCurrentCountBak = this.processKeysBak.length;
      this.processKeysBak[nCurrentCountBak] = key;
      for (var j = i; j < this.processKeys.length - 1; j++) {
        this.processKeys[j] = this.processKeys[j + 1];
        this.processValues[j] = this.processValues[j + 1];
      }
      this.processKeys.length--;
      this.processValues.length--;
      return true;
    }
  }
  return false;
}

/**
 * 指定キーの項目は処理中かどうかを判断する。
 *     １、setCurrentにpageIdは設定されたことは前提です。
 *     ２、パラメータのkeyは「runするに指定したキー」実際比較するキーはrealkeyです。
 * @param key runするに指定したキー。
 */
BGProcess.prototype.isProcessing = function (key) {
  //最後から探す
  realkey = this.currentPageId + '|' + key;
  if (realkey == this.lastKey) {
    //最後に処理されたキーは画面にあったら非活性化する
    return true;
  }
  for (var i = this.processKeys.length - 1; i >= 0; i--) {
    if (this.processKeys[i] == realkey) {
      return true;
    }
  }
  //バックアップリストからもう一回チェックする
  for (var i = this.processKeysBak.length - 1; i >= 0; i--) {
    if (this.processKeysBak[i] == realkey) {
      for (var j = i; j < this.processKeysBak.length - 1; j++) {
        this.processKeysBak[j] = this.processKeysBak[j + 1];
      }
      this.processKeysBak.length--;
      return true;
    }
  }
  return false;
}

/**
 * 指定ページIDの処理はすべて終わったかどうかを判断する。
 * @param pageId ページID。
 */
BGProcess.prototype.isProcessingPage = function (pageId) {
  //最後から探す
  realkey = pageId + '|';
  for (var i = this.processKeys.length - 1; i >= 0; i--) {
    if (this.processKeys[i].indexOf(realkey) == 0) {
      return true;
    }
  }
  return false;
}

/**
 * 一覧（リスト）にcheckbox項目はチェックオン項目数。
 * @param checkboxID checkbox項目のID。'checkbox名'または'checkbox名_check'両方対応。
 * @return チェックオン項目数。
 */
BGProcess.prototype.getListCheckedCount = function (checkboxID) {
  if (!this.checkCurrentSet()) {
    return 0;
  }
  var cnt = 0;
  //_checkは勝てに付いてる
  var obj = this.currentWin.document.getElementsByName(checkboxID + '_check');
  if (!obj || obj.length <= 0) {
    obj = this.currentWin.document.getElementsByName(checkboxID);
  }
  for (i = 0; i < obj.length; i++) {
    if (!obj[i].disabled && obj[i].checked) {
      cnt++;
    }
  }
  return cnt;
}

/**
 * 一覧（リスト）の処理中項目を非活性化する。
 * @param index リストのindex、0から。
 * @param 二番目以降 非活性化項目ID。
 *            １、checkboxの場合、'checkbox名'または'checkbox名_check'両方対応
 *            ２、linkの場合、'link名'
 *            ３、非活性化に可能の項目タイプ：button,input,optgroup,option,select,textarea
 */
BGProcess.prototype.disableListItems = function (index) {
  if (!this.checkCurrentSet()) {
    return false;
  }
  //一つ目はindex
  for (var i = 1; i < arguments.length; i++) {
    obj = this.currentWin.document.getElementsByName(arguments[i] + '_check');
    if (!obj || obj.length <= 0) {
      obj = this.currentWin.document.getElementsByName(arguments[i]);
    }
    if (obj && obj[index] && typeof(obj[index].disabled) == 'boolean') {
      obj[index].disabled = "true";
    }
    else {
      //<a href="..." class="detaillink" style="..."><span id="LINE.SLIPNOLINK_5">...</span></a>
      obj = this.currentWin.document.getElementById(arguments[i] + '_' + (index + 1));
      if (obj && obj.parentNode && obj.parentNode.href) {
        obj.parentNode.href = "javascript:void(0);";
        obj.parentNode.disabled='true';
      }
    }
  }
}

/**
 * リストではない（単独）の処理中項目を非活性化する。
 * @param 一番目以降 非活性化項目ID。
 */
BGProcess.prototype.disableAloneItem = function () {
  if (!this.checkCurrentSet()) {
    return false;
  }
  for (var i = 0; i < arguments.length; i++) {
    var obj = this.currentWin.document.getElementById(arguments[i] + '_check');
    if (!obj) {
      obj = this.currentWin.document.getElementById(arguments[i]);
    }
    if (obj && typeof(obj.disabled) == 'boolean') {
      obj.disabled = "true";
    }
    else if (obj && obj.parentNode && obj.parentNode.href) {
      obj.parentNode.href = "javascript:void(0);";
      obj.parentNode.disabled='true';
    }
  }
}

/**
 * バックグラウンド処理中の場合、ブラウザーを閉じる、別URLに飛ばすなどに、メッセージを提示する。
 * （内部変数はbgprocessで使う）
 */
BGProcess.prototype.doOnbeforeunload = function (evt) {
  if (bgprocess.processKeys.length > 0) {
    var msg = '==================== バックグラウンド処理 ====================\n\n';
    msg += 'バックグラウンドで処理が実行中です。\n';
    msg += '残り：' + bgprocess.processKeys.length + '件があります。\n';
    //title, processid, processmode, optionparams, key, errorinfo
    for (var i = 0; i < bgprocess.processKeys.length; i++) {
      msg += '' + (i+1) + ', ' + bgprocess.processValues[i][0] + ', '+ bgprocess.processValues[i][5] + '\n';
    }
    msg += '\n[キャンセル]をクリックしてください。';
    msg += '\n\n==================== バックグラウンド処理 ====================';
    evt = (evt) ? evt : event;
    if (!evt.clientY) {
      // Window Closing in FireFox
      return msg;
    }
    else {
      // Window Closing in IE
      event.returnValue = msg;
      return void(0);
    }
  }
}

//バックグラウンド処理クラスのグローバル変数を初期化する。
var bgprocess = new BGProcess();

//バックグラウンド処理中の場合、ブラウザーを閉じる、別URLに飛ばすなどに、メッセージを提示する。
window.onbeforeunload=bgprocess.doOnbeforeunload;







/**
 * =============================================================================
 * 以下は古いバージョンのバックグラウンド処理
 * =============================================================================
 */
var _bgprocesscount = 0;
var _logoutstate = false;

function runbgprocess(title, processid, processmode, optionparams, errorinfo) {
  var xmlhttp = _getXMLHttp();
  xmlhttp.open("POST", "appcontroller", true);
  xmlhttp.setRequestHeader("Content-Type" , "application/x-www-form-urlencoded");
  var postdata = "PROCESSID="+processid+"&PROCESSMODE="+processmode+"&PAGEID=NULL&JSPID=jsp/XML&ERRORJSPID=jsp/XML&"+optionparams;
  
  _bgprocesscount++;
  window.status='バックグラウンド処理実行中：'+_bgprocesscount+'...';

  xmlhttp.onreadystatechange = function() 
  {
    if (xmlhttp.readyState == 4) {
      _bgprocesscount--;
      if (xmlhttp.status != 200) {
        var errmsg = title + 'の実行でエラーが発生しました。\nエラー内容:エラーコード='+xmlhttp.status;
        alert(errmsg+'\n'+xmlhttp.responseText);
        window.status=errmsg;
      } else {
        var xmlDoc = xmlhttp.responseXML;
        var status = xmlDoc.getElementsByTagName('status')[0].firstChild.nodeValue; // MBB終了コード： 0=正常,1=情報,2=警告,3=エラー
        if (status == '3') {
          // エラーが発生した場合
          var errmsg = '';
          for (i = 0; i < xmlDoc.getElementsByTagName('error').length; ++i) {
            errmsg = errmsg + xmlDoc.getElementsByTagName('error')[i].firstChild.nodeValue + '\n';
          }
          errmsg = title + 'の実行でエラーが発生しました。\n'+errorinfo+'\nエラー内容:'+errmsg;
          alert(errmsg);
          if (_bgprocesscount == 0) {
            window.status=errmsg;
          }
        } else {
          // 警告・情報は無視して正常終了とする
          if (_bgprocesscount > 0) {
            window.status='バックグラウンド処理実行中：'+_bgprocesscount+'...';
          } else {
            window.status=title+'('+errorinfo+')は正常終了しました。';
          }
        }
      }
      if (_logoutstate && _bgprocesscount == 0) {
        alert('バックグラウンドプロセスは全て終了しました。');
      }
    }
  }
  xmlhttp.send(encodeURI(postdata));
}

function _doframeunload() {
  if (_bgprocesscount > 0) {
    _logoutstate = true;
    alert('バックグラウンドで処理が実行中です。終了メッセージが表示されてから[OK]ボタンを押してください。');
  }
//  var xmlhttp = _getXMLHttp();
//  var postdata = "APPLICATIONID=SysLogout";
//  postdata = encodeURI(postdata);
//  xmlhttp.open("POST", "appcontroller", true);
//  xmlhttp.setRequestHeader("Content-Type" , "application/x-www-form-urlencoded");
//  xmlhttp.send(postdata);
}

function _getXMLHttp() {
  var xmlhttp;
  try {
    xmlhttp = new ActiveXObject("Msxml2.XMLHTTP");
  } catch (e) {
    try {
      xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
    } catch (E) {
      xmlhttp = false;
    }
  }
  if (!xmlhttp && typeof XMLHttpRequest!='undefined') {
    xmlhttp = new XMLHttpRequest();
  }
  return xmlhttp;
}

window.onunload=_doframeunload;
