package sample4;

import jp.co.bbs.unit.tools.html.*;
import java.io.*;
import java.text.DateFormat;
import java.util.Calendar;
import java.util.Locale;

import org.apache.log4j.Logger;

public class DownloadSample extends PageElement {
	private static Logger log = Logger.getLogger(DownloadSample.class);

	private static final String SESSION_KEY = "APPLICATION_PATH";
	private static final String ARCHIVE_FILE_NAME = "mbbtrial.zip";
	@Override
	public String toString() {
		String text = "MBB�]���ŃA�[�J�C�u �_�E�����[�h...";
		String applicationPath = (String)getSessionData().get(SESSION_KEY);
		if (applicationPath == null || applicationPath.trim().length() == 0) {
			return disabledLink(text, "�Z�b�V��������[" + SESSION_KEY + "]�̏�񂪎擾�ł��܂���");
		}
		File mbbtrial_zip = new File(new File(applicationPath).getParentFile().getParentFile().getParentFile(), ARCHIVE_FILE_NAME);
		if (mbbtrial_zip.exists()) {
			Calendar cal = Calendar.getInstance(Locale.JAPAN);
			cal.setTimeInMillis(mbbtrial_zip.lastModified());
			String info = "&nbsp;(�T�C�Y�F" + mbbtrial_zip.length() / (1024*1024) + "MB�A�X�V���F" + DateFormat.getDateInstance(DateFormat.LONG, Locale.JAPAN).format(cal.getTime()) + ")";
			return "<nobr><a href=\"appcontroller?JSPID=jsp/SysDownload&CLASSNAME=sample4.DownloadSample\" title=\"" + mbbtrial_zip.getName() + "���_�E�����[�h���܂�\">" + text + "</a>" + info + "</nobr>";
		} else {
			return disabledLink(text, mbbtrial_zip.getAbsolutePath() + "�ɃA�N�Z�X�ł��܂���");
		}
	}
	
	@Override
	public boolean handle() {
		String applicationPath = (String) getSessionData().get(
				SESSION_KEY);
		File documentPath = new File(new File(applicationPath).getParentFile()
				.getParentFile(), "mbbdoc");
		File mbbtrial_zip = new File(new File(applicationPath).getParentFile().getParentFile().getParentFile(), ARCHIVE_FILE_NAME);
		if (mbbtrial_zip.exists()) {
			response.setContentType("application/octet-stream");
			response.setHeader(
					"Content-Disposition",
					"attachment; filename=" + ARCHIVE_FILE_NAME);
			try {
				writeToResponse(mbbtrial_zip);
			} catch (IOException e) {
				log.error("", e);
			}
			return true;
		}

		return false;
	}
	
	private static String disabledLink(String text, String title) {
		return "<a href=\"#\" title=\"" + title + "\" disabled>" + text + "</a>";
	}

}
