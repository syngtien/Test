/*
 * VwTypeImage
 * 項目タイプ表示（画像他）
 */
LAST_MODIFIED('2010.05.20', '1.0.30');

/*
 * 使用するタイプを登録する
 */
registerViewObject(TYPE.IMAGE,  ViewObjectImage);
registerViewObject(TYPE.APPLET, ViewObjectApplet);
registerViewObject(TYPE.OBJECT, ViewObjectObject);
registerViewObject(TYPE.EMBED,  ViewObjectEmbed);
registerViewObject(TYPE.IFRAME, ViewObjectIframe);
registerViewObject(TYPE.HR,     ViewObjectHr);
registerViewObject(TYPE.BUTTON, ViewObjectImageButton);
registerViewObject(TYPE.SUBMIT, ViewObjectImageButton);
registerViewObject(TYPE.RESET,  ViewObjectImageButton);

/**
 * ImageタイプのtypeObject実装クラス
 * @param  :
 * @return :作成したHTML文字列
 */
function ViewObjectImage(){

  ViewObjectImage.prototype.setDefaultProperty  = fnSetDefaultProperty_common;
  ViewObjectImage.prototype.getPropertiesHtml   = fnGetPropertiesHtml;

  function fnGetPropertiesHtml(objDs){

    var strBgcolor = getBgcolorType(objDs, 0);
    var strCursor  = getCursorType(objDs);
    var strSrc = objDs.getProperty('src');
    if(strSrc == '' && m_browserType.isIE) {
      var additionalStyle = 'background-image : url(' + IMAGEURL_IMAGE + ');'
         + 'background-repeat : no-repeat;'
         + 'background-attachment : fixed;'
         + 'background-position : 4px 3px;'
         + cancelStyle();

      strSrc = IMAGEURL_IMAGETP;
    } else {
      var additionalStyle = cancelStyle();
    }
    
    if(strSrc == 'BARCODE') {
      strSrc = IMAGEURL_IMAGEBC;
    }

    var strHTML = '<img id="' + objDs.getProperty('id') 
      + '" src="' + strSrc
      + '" class="vw-image" style="width:' + objDs.getProperty('width') 
      + 'px; height:' + objDs.getProperty('height') 
      + 'px; ' + additionalStyle
      + 'cursor:' + strCursor 
      + '; color:' + objDs.getProperty('fontcolor') 
      + '; background-color:' + strBgcolor 
      + '; border-color:' + objDs.getProperty('bordercolor')
      + '; text-align:' + objDs.getProperty('align') 
      + ';" onmousemove="return false;">';
    
    return strHTML;
  }

  /** 
   * 表示更新メソッド群 
   */
  this.setter = new Setter();

  function Setter() {
    Setter.prototype.src = _src;
    Setter.prototype.border = _border;

    // 画像ソース
    function _src(newValue, elementId, dataset, cellElementId, cellDataset) {
      var img = getDocumentElementById(elementId);
      var addedImage = addImageFileBuffer(newValue);
      if(newValue != '') {
        if(newValue == 'BARCODE'){
          img.src = IMAGEURL_IMAGEBC;
        } else {
          img.src = newValue;
        }
        img.style.backgroundImage = '';
      } else {
        if(m_browserType.isIE) {
          img.src = IMAGEURL_IMAGETP;
          img.style.backgroundRepeat = 'no-repeat';
          img.style.backgroundAttachment = 'fixed';
          img.style.backgroundPosition = '4px 3px';
          img.style.backgroundImage = getImageSrcUrl(IMAGEURL_IMAGE);
        } else {
          img.src = newValue;
          img.style.backgroundImage = '';
        }
      }
      if(dataset.getProperty('width') == '' || dataset.getProperty('height') == '') {
        return flags(newValue, 'resized');
      } else {
        return flags(newValue);
      }
    }

    // 枠
    function _border(newValue, elementId, dataset, cellElementId, cellDataset) {
      //getDocumentElementById(elementId).border = newValue;
      //return flags(newValue, 'resized');
      return flags(newValue);
    }
  }
}


/**
 * AppletタイプのtypeObject実装クラス
 * @param  :
 * @return :作成したHTML文字列
 */
function ViewObjectApplet(){

  ViewObjectApplet.prototype.setDefaultProperty  = fnSetDefaultProperty_common;
  ViewObjectApplet.prototype.getPropertiesHtml   = fnGetPropertiesHtml;

  function fnGetPropertiesHtml(objDs){
    return getEmbedPropertiesHtml(objDs, IMAGEURL_APPLET);
  }
}

function getEmbedPropertiesHtml(objDs, imageName){

  var strBgcolor = getBgcolorType(objDs, 0);
  var strCursor  = getCursorType(objDs);
  var strType = objDs.type.value.toLowerCase();
  
  var strHTML = '<input type="TEXT" id="' + objDs.getProperty('id') 
    + '" class="vw-' + strType + '" style="cursor:' + strCursor 
    + '; background-repeat: no-repeat; background-position: center center'
    + '; background-image:url(' + imageName 
    + '); width:' + objDs.getProperty('width') 
    + 'px; height:' + objDs.getProperty('height') 
    + 'px; background-color:' + strBgcolor + ';' + cancelStyle() + '" readonly>';

  return strHTML;
}

/**
 * EmbedタイプのtypeObject実装クラス
 * @param  :
 * @return :作成したHTML文字列
 */
function ViewObjectEmbed(){

  ViewObjectEmbed.prototype.setDefaultProperty  = fnSetDefaultProperty_common;
  ViewObjectEmbed.prototype.getPropertiesHtml   = fnGetPropertiesHtml;

  function fnGetPropertiesHtml(objDs){
    return getEmbedPropertiesHtml(objDs, IMAGEURL_EMBED);
  }

}

/**
 * ObjectタイプのtypeObject実装クラス
 * @param  :
 * @return :作成したHTML文字列
 */
function ViewObjectObject(){

  ViewObjectObject.prototype.setDefaultProperty  = fnSetDefaultProperty_common;
  ViewObjectObject.prototype.getPropertiesHtml   = fnGetPropertiesHtml;

  function fnGetPropertiesHtml(objDs){
    return getEmbedPropertiesHtml(objDs, IMAGEURL_OBJECT);
  }

}

/**
 * IframeタイプのtypeObject実装クラス
 * @param  :
 * @return :作成したHTML文字列
 */
function ViewObjectIframe(){

  ViewObjectIframe.prototype.setDefaultProperty  = fnSetDefaultProperty_common;
  ViewObjectIframe.prototype.getPropertiesHtml   = fnGetPropertiesHtml;

  function fnGetPropertiesHtml(objDs){

    var strBorderStyle = objDs.getProperty('borderstyle');
    var strBorderColor = tagFree(objDs.getProperty('bordercolor'), '');
    var strBorderWidth = objDs.getProperty('borderwidth');

    var strBgcolor = getBgcolorType(objDs, 0);
    var strCursor  = getCursorType(objDs);
    var width = objDs.getProperty('width');
    var height = objDs.getProperty('height');
    var strHTML = '<input type="TEXT" id="' + objDs.getProperty('id') 
      + '" value="' + objDs.getProperty('src') 
      + '" class="vw-iframe ' + getNonTextElementClassProperty(objDs)
      + '" style="cursor:' + strCursor 
      + '; border-style:' + strBorderStyle
      + '; border-width:' + strBorderWidth
      + '; border-color:' + strBorderColor
      + '; font-size:10pt; background-color:' + strBgcolor 
      + '; width:' + width + 'px; height:' + height
      + 'px;' + cancelStyle() + '" readonly>';
    return strHTML;

  }
  
  /** 
   * 表示更新メソッド群 
   */
  this.setter = new Setter();

  function Setter() {
    Setter.prototype.src = _src;
    Setter.prototype.borderwidth = _borderwidth;
    Setter.prototype.borderstyle = _borderstyle;

    function _src(newValue, elementId, dataset, cellElementId, cellDataset) {
      getDocumentElementById(elementId).value = newValue;
      return flags(newValue);
    }

    function _borderwidth(newValue, elementId, dataset, cellElementId, cellDataset) {
      var element = getDocumentElementById(elementId);
      element.style.borderWidth = newValue;
      return flags(newValue/*, 'resized'*/);
    }

    function _borderstyle(newValue, elementId, dataset, cellElementId, cellDataset) {
      getDocumentElementById(elementId).style.borderStyle = newValue;
      return flags(newValue/*, 'resized'*/);
    }

  }
}

/**
 * HrタイプのtypeObject実装クラス
 * @param  :
 * @return :作成したHTML文字列
 */
function ViewObjectHr(){

  ViewObjectHr.prototype.setDefaultProperty  = fnSetDefaultProperty_common;
  ViewObjectHr.prototype.getPropertiesHtml   = fnGetPropertiesHtml;
  //ViewObjectHr.prototype.repaint   = fnRepaint;

  function fnGetPropertiesHtml(objDs){

    var strCursor  = getCursorType(objDs);
    var hrcolor = objDs.getProperty('hrcolor');
    var thickness = objDs.getProperty('thickness');
    var borderstyle = 'inset';
    //if(objDs.getProperty('shade') == 'noshade') {
    //  borderstyle = 'solid';
    //}
    
    var strHTML = '<span id="' + objDs.getProperty('id') +
      '"><hr id="' + objDs.getProperty('id') +
      '.hr" align="left" ' + objDs.getProperty('shade') +
      ' width="' + objDs.getProperty('width') +
      '" size="' + thickness +
      '" color="' + objDs.getProperty('hrcolor') +
      '" class="vw-hr ' + getNonTextElementClassProperty(objDs) +
      '" style="cursor:' + strCursor +
      '; background-color:' + hrcolor +
      '; border-color:' + hrcolor +
      ';" readonly></span>';

    return strHTML;
  }
  
  /** 
   * 表示更新メソッド群 
   */
  this.setter = new Setter();

  function Setter() {
    Setter.prototype.width = _width;
    Setter.prototype.thickness = _thickness;
    Setter.prototype.shade = _shade;
    Setter.prototype.hrcolor = _hrcolor;

    function _width(newValue, elementId, dataset, cellElementId, cellDataset) {
      var modified = '';
      if(newValue != '' && newValue < 1) {
        newValue = 1;
        modified = 'modified';
      }
      dataset.setProperty('width', newValue);
      updateHrElement(elementId, dataset);
      return flags(newValue, 'resized', 'updated', 'reconstructed', modified);
    }

    function _thickness(newValue, elementId, dataset, cellElementId, cellDataset) {
      var modified = '';
      if(newValue != '' && newValue < 1) {
        newValue = 1;
        modified = 'modified';
      }
      dataset.setProperty('thickness', newValue);
      updateHrElement(elementId, dataset);
      return flags(newValue, 'resized', 'updated', 'reconstructed', modified);
    }

    function _shade(newValue, elementId, dataset, cellElementId, cellDataset) {
      //if(getDocumentElementById('fld_shade').checked){
      //  newValue = 'noshade';
      //}else{
      //  newValue = '';
      //}
      dataset.setProperty('shade', newValue);
      updateHrElement(elementId, dataset);
      return flags(newValue, 'resized', 'updated', 'reconstructed');
    }
    
    function _hrcolor(newValue, elementId, dataset, cellElementId, cellDataset) {
      dataset.setProperty('hrcolor', newValue);
      updateHrElement(elementId, dataset);
      return flags(newValue, 'resized', 'updated', 'reconstructed');
    }

  }

  /**
   *
   */
  function updateHrElement(elementId, dataset) {
    var span = getDocumentElementById(elementId + '_span');
    var html = fnGetPropertiesHtml(dataset);
    span.innerHTML = html;
    setResizeHandle(elementId);
   
  } 

  /**
   *
   */
  function fnRepaint(elementId, dataset) {
    updateHrElement(elementId, dataset);
    return null;
  }
}

/**
 * ButtonタイプのtypeObject実装クラス
 * @param  :
 * @return :作成したHTML文字列
 */
function ViewObjectImageButton(type){

  ViewObjectImageButton.prototype.getPropertiesHtml   = fnGetPropertiesHtml;
  ViewObjectImageButton.prototype.setDefaultProperty = fnSetDefaultProperty_common;
  
  if(type == TYPE.SUBMIT) {
    this.setDefaultProperty = fnSetDefaultPropertySubmit;
  }

  if(type == TYPE.RESET) {
    this.setDefaultProperty = fnSetDefaultPropertyReset;
  }

  /**
   * 属性初期化
   */
  function fnSetDefaultPropertySubmit(objDS){
    objDS.setProperty('labeltext', getLiteral('initialvalue.submit.value'));
    fnSetDefaultProperty_common(objDS);
  }

  /**
   * 属性初期化
   */
  function fnSetDefaultPropertyReset(objDS){
    objDS.setProperty('labeltext', getLiteral('initialvalue.reset.value'));
    fnSetDefaultProperty_common(objDS);
  }
  
  /**
   * 配置されるオブジェクトHTML生成
   */
  function fnGetPropertiesHtml(objDs){
    var id = objDs.getProperty('id');
    var src = objDs.getProperty('src');
    var labeltext =  htmlEscape(objDs.getProperty('labeltext'));
    var strText = '<span id="' + id + '.text">' + labeltext + '</span>';
    
    var strBgcolor = getBgcolorType(objDs, 0);
    var strCursor  = getCursorType(objDs);
    var strContent;
    if(src) {
      var imagewidth = objDs.getProperty('imagewidth');
      var imageheight = objDs.getProperty('imageheight');
      var imageposition = objDs.getProperty('imageposition');
      var strImg = '<img id="' + id + '.image" src="' + src + '" border="0"';
      if(imagewidth) {
        strImg += ' width="' + imagewidth + '"';
      }
      if(imageheight) {
        strImg += ' height="' + imageheight + '"';
      }
      strImg += ' style="vertical-align: middle;">';
      
      switch (imageposition.toLowerCase()) {
      case 'above':
        strContent = strImg + '<br>' + strText;
        break;
      case 'right':
        strContent = strText + strImg;
        break;
      case 'below':
        strContent = strText + '<br>' + strImg;
        break;
      default:
        strContent = strImg + strText;
      }
    } else {
      strContent = strText;
    }
    var align = objDs.getProperty('align');
    if(!align) {
      align = 'center';
    }
    strContent = '<div id="' + id + '.div" style="text-align:' + align + ';">' + strContent + '</div>';

    var strHTML  = '<button type="button" id="' + id + 
    '" class="vw-' + objDs.type.value.toLowerCase() + ' ' + getTextElementClassProperty(objDs) +
    '" style="width:' + objDs.getProperty('width') +
    'px; height:' + objDs.getProperty('height') +
    'px; cursor:' + strCursor +
    '; background-color:' + strBgcolor +
    '; font-size:' + objDs.getProperty('fontsize') +
    'pt; color:' + objDs.getProperty('fontcolor') +
    '; font-family:' + objDs.getProperty('fontfamily') +
    ';' + cancelStyle() + 'padding:0px;"'
    + ' onclick="return false;" onmousedown="return false;">'
    + strContent + '</button>';
 
    return strHTML;
  }

  this.setter = new Setter();
  function Setter() {
    Setter.prototype.src = _src;
    Setter.prototype.imagewidth = _imagewidth;
    Setter.prototype.imageheight = _imageheight;
    Setter.prototype.imageposition = _imageposition;
    Setter.prototype.labeltext = _labeltext;
    Setter.prototype.width = _width;
    Setter.prototype.height = _height;
    Setter.prototype.fontsize = _fontsize;
    Setter.prototype.fontcolor = _fontcolor;
    Setter.prototype.backgroundcolor = _backgroundcolor;
    Setter.prototype.align = _align;

    function _src(newValue, elementId, dataset, cellElementId, cellDataset) {
      var element = null;
      if(newValue) {
        element = getDocumentElementById(elementId + '.images');
      }
      if(newValue != '') {
        setButtonImagePropertyDisplay('');
      } else {
        setButtonImagePropertyDisplay('none');
      }
      if(element) {
        element.src = newValue;
        return flags(newValue);
      } else {
        return flags(newValue, 'repaint');
      }
    }

    function _imagewidth(newValue, elementId, dataset, cellElementId, cellDataset) {
      var element = getDocumentElementById(elementId + '.images');
      if(element) {
        element.width = newValue;
        return flags(newValue);
      } else {
        return flags(newValue, 'repaint');
      }
    }

    function _imageheight(newValue, elementId, dataset, cellElementId, cellDataset) {
      var element = getDocumentElementById(elementId + '.images');
      if(element) {
        element.height = newValue;
        return flags(newValue);
      } else {
        return flags(newValue, 'repaint');
      }
    }

    function _imageposition(newValue, elementId, dataset, cellElementId, cellDataset) {
      var element = getDocumentElementById(elementId + '.images');
      return flags(newValue, 'repaint');
    }

    function _labeltext(newValue, elementId, dataset, cellElementId, cellDataset) {
      var element = getDocumentElementById(elementId + '.text');
      element.innerHTML = htmlEscape(newValue);
      return flags(newValue);
    }

    function _width(newValue, elementId, dataset, cellElementId, cellDataset) {
      var element = getDocumentElementById(elementId);
      element.style.width = newValue;

      repaintButtonStyle(element, dataset, 'width', newValue);

      return flags(newValue, 'resized', 'border');
    }

    function _height(newValue, elementId, dataset, cellElementId, cellDataset) {
      var element = getDocumentElementById(elementId);
      element.style.height = newValue;

      repaintButtonStyle(element, dataset, 'height', newValue);

      return flags(newValue, 'resized');
    }

    function _fontsize(newValue, elementId, dataset, cellElementId, cellDataset) {
      var val = '';
      if(newValue != '') {
        val = newValue + 'pt';
      }
      var element = getDocumentElementById(elementId);
      element.style.fontSize = val;

      repaintButtonStyle(element, dataset, 'fontsize', newValue);

      return flags(newValue, 'resized');
    }

    // 文字の色
    function _fontcolor(newValue, elementId, dataset, cellElementId, cellDataset) {
      var element = getDocumentElementById(elementId);
      setElementStyleFontColor(element, newValue);

      repaintButtonStyle(element, dataset, 'fontcolor', newValue);
      return flags(newValue);
    }

    // 背景色
    function _backgroundcolor(newValue, elementId, dataset, cellElementId, cellDataset) {
      dataset.setProperty('backgroundcolor', newValue);
      if(dataset.getProperty('visibility') != 'hidden'){
        var element = getDocumentElementById(elementId);
        element.style.backgroundColor = newValue;
    /* @todo */
        repaintButtonStyle(element, dataset, '', '');
      }
      return flags(newValue, 'updated');
    }

    // 水平位置
    function _align(newValue, elementId, dataset, cellElementId, cellDataset) {
      var element = getDocumentElementById(elementId + '.div');
      if(!element) {
        element = getDocumentElementById(elementId);
      }
      element.style.textAlign = newValue;
      return flags(newValue);
    }


    function repaintButtonStyle(element, dataset, propertyId, newValue) {
      var obj = new Object();
      obj.width  = dataset.getProperty('width');
      obj.height = dataset.getProperty('height');
      obj.fontsize    = dataset.getProperty('fontsize');
      obj.fontcolor   = dataset.getProperty('fontcolor');
      obj.bgcolor     = getBgcolorType(dataset, 0);
      obj[propertyId] = newValue;
      var style = 'width:'     + obj.width + 'px; '
                + 'height:'    + obj.height + 'px; '
                + 'font-size:' + obj.fontsize + 'pt; '
                + 'color:'     + obj.fontcolor + '; '
                + 'cursor:'    + getCursorType(dataset) + '; '
                + 'background-color:' + obj.bgcolor + ';';
      element.setAttribute('style', style);
    }

  }
}