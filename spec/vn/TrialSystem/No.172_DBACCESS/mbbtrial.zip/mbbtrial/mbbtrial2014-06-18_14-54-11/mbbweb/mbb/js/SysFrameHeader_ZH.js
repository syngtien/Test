﻿
var _menustate = 1; // 1:open 0:close;
var _menuwidth = 180;
var _menuinterval;

function doMenuOpenClose(menu) {
  if (_menustate == 1) {
    menu.innerText='显示菜单';
    _menustate = 0;
    _menuinterval = setInterval("doMenuInterval()", 10);
    menu.blur();
  } else {
    menu.innerText='隐藏菜单';
    _menustate = 1;
    _menuinterval = setInterval("doMenuInterval()", 10);
    menu.blur();
  }
  return false;
}

function doMenuInterval() {
  if (_menustate == 1) {
    if (_menuwidth >= 180) {
      clearInterval(_menuinterval);
    } else {
      _menuwidth += 10;
    }
  } else {
    if (_menuwidth <= 0) {
      clearInterval(_menuinterval);
    } else {
      _menuwidth -= 10;
    }
  }
  parent.document.getElementsByTagName('FRAMESET').item(1).cols = _menuwidth + ',*';
}

//document.onselectstart=function(){return false;};
