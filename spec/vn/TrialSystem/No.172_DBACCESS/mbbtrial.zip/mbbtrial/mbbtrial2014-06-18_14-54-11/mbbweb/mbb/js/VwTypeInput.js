/*
 * VwTypeInput
 * 項目タイプ表示（入力系）
 */
LAST_MODIFIED('2005.02.08', '1.0.33');

/*
 * 使用するタイプを登録する
 */
registerViewObject(TYPE.STRING,   ViewObjectString);
registerViewObject(TYPE.LABEL,    ViewObjectLabel);
registerViewObject(TYPE.TEXT,     ViewObjectText);
registerViewObject(TYPE.PASSWORD, ViewObjectPassword);
registerViewObject(TYPE.TEXTAREA, ViewObjectTextarea);
registerViewObject(TYPE.FILE,     ViewObjectFile);
registerViewObject(TYPE.HIDE,     ViewObjectHide);

// リンクのテキストの色
var LINKTEXTCOLOR = '#0000ff';

/**
 * StringタイプのtypeObject実装クラス
 * @param  :
 * @return :作成したHTML文字列
 */
function ViewObjectString(){

  ViewObjectString.prototype.setDefaultProperty  = fnSetDefaultProperty_common;
  ViewObjectString.prototype.getPropertiesHtml   = fnGetPropertiesHtml;

  function fnGetPropertiesHtml(objDs){

    var strBgcolor = getBgcolorType(objDs, 0);
    var strCursor  = getCursorType(objDs);
    var strColor = objDs.getProperty('fontcolor');
    if(objDs.getProperty('link').length != 0 && objDs.getProperty('fontcolor').length == 0){
      strColor = LINKTEXTCOLOR;
    }
    var strTextDeco = objDs.getProperty('underline');
    if(objDs.getProperty('link').length != 0){
      strTextDeco = 'underline';
    }
    // value="&quot;あ&quot;" はmozillaでは「"あ"」でなく「あ」と表示される
    // value="&quot;あ&quot; " とすると「"あ" 」と表示される
    var strValue = nnQuotEscape(htmlEscape(objDs.getProperty('fieldvalue')),'align',objDs);
    var strClass = 'vw-string ' + getTextElementClassProperty(objDs);
    var strStyle = 'width:' + objDs.getProperty('width') +
              'px; height:' + objDs.getProperty('height') +
           'px; font-size:' + objDs.getProperty('fontsize') +
         'pt; font-family:' + objDs.getProperty('fontfamily') +
           '; font-weight:' + objDs.getProperty('fontweight') +
            '; font-style:' + objDs.getProperty('fontstyle') +
       '; text-decoration:' + strTextDeco +
            '; text-align:' + objDs.getProperty('align') +
                 '; color:' + strColor +
      '; background-color:' + strBgcolor +
                '; cursor:' + strCursor +
                '; ' + cancelStyle();
      
    var strHTML = '<input type="TEXT" readonly id="' + objDs.getProperty('id') +
      '" class="' + strClass +
      '" style="' + strStyle +
      '" value="' + strValue + '">';

    return strHTML;
  }

  /** 
   * 表示更新メソッド群 
   */
  this.setter = new Setter();

  function Setter() {
    Setter.prototype.fieldvalue = _fieldvalue;
    Setter.prototype.fontcolor = _fontcolor;
    Setter.prototype.underline = _textdecoration;
    Setter.prototype.backgroundcolor = string_backgroundcolor;
    Setter.prototype.link = _link;

    // テキスト
    function _fieldvalue(newValue, elementId, dataset, cellElementId, cellDataset) {
      var docNode = getDocumentElementById(elementId);
      var val = nnQuotEscape(newValue,'align',dataset);
      docNode.value = val;

      // 2003.05.15 mozillaにてinput type="text"使用の項目タイプにおいてvalue設定時にhtml文字列に反映されない問題の暫定対処
      //            domのsetAttributeメソッドで強制的にhtml文字列に組み込む
      docNode.setAttribute('value', val);
      applyLinkStyle(docNode, dataset, newValue, dataset.getProperty('link'));
      return flags(newValue);
    }

    // 文字の色
    function _fontcolor(newValue, elementId, dataset, cellElementId, cellDataset) {
      var element = getDocumentElementById(elementId);
      setElementStyleFontColor(element, newValue);
      if(dataset.getProperty('fieldvalue').length != 0 && 
         dataset.getProperty('link').length != 0 && 
         newValue.length == 0){
        
        element.style.color = LINKTEXTCOLOR;
      }
      return flags(newValue);
    }

    // 下線
    function _textdecoration(newValue, elementId, dataset, cellElementId, cellDataset) {
      var val = '';
      if(newValue == 'underline') {
        val = 'underline';
      }else{
        if(dataset.getProperty('fieldvalue').length != 0 && 
           dataset.getProperty('link').length != 0){
          val = 'underline';
        }  
      }
      getDocumentElementById(elementId).style.textDecoration = val;

      return flags(newValue);
    }

    // リンク
    function _link(newValue, elementId, dataset, cellElementId, cellDataset) {
      var element = getDocumentElementById(elementId);
      applyLinkStyle(element, dataset, dataset.getProperty('fieldvalue'), newValue);
      return flags(newValue);
    }

    // リンクの場合のスタイル
    function applyLinkStyle(element, dataset, fieldValue, link) {
      if(fieldValue.length != 0 && link.length != 0){
        element.style.textDecoration = 'underline';
        if(dataset.getProperty('fontcolor').length == 0){
          element.style.color = LINKTEXTCOLOR;
        }else{
          setElementStyleFontColor(element, dataset.getProperty('fontcolor'));
        }    
      } else {
        element.style.textDecoration = dataset.getProperty('underline');
        setElementStyleFontColor(element, dataset.getProperty('fontcolor'));
      }
    }
  }
}

/**
 * LablelタイプのtypeObject実装クラス
 * @param  :
 * @return :作成したHTML文字列
 */
function ViewObjectLabel(){

  ViewObjectLabel.prototype.setDefaultProperty  = fnSetDefaultProperty_common;
  ViewObjectLabel.prototype.getPropertiesHtml   = fnGetPropertiesHtml;

  function fnGetPropertiesHtml(objDs){

    var strBgcolor = getBgcolorType(objDs, 0);
    var strCursor  = getCursorType(objDs);
    var strTextDecoration = objDs.getProperty('underline');

    // value="&quot;あ&quot;" はmozillaでは「"あ"」でなく「あ」と表示される
    // value="&quot;あ&quot; " とすると「"あ" 」と表示される
    var strValue = nnQuotEscape(htmlEscape(objDs.getProperty('fieldvalue')),'align',objDs);
    var strClass = 'vw-label ' + getTextElementClassProperty(objDs);
    var strStyle = 'width:' + objDs.getProperty('width') + 
              'px; height:' + objDs.getProperty('height') +
           'px; font-size:' + objDs.getProperty('fontsize') +
         'pt; font-family:' + objDs.getProperty('fontfamily') +
           '; font-weight:' + objDs.getProperty('fontweight') +
            '; font-style:' + objDs.getProperty('fontstyle') +
       '; text-decoration:' + strTextDecoration +
            '; text-align:' + objDs.getProperty('align') + 
                 '; color:' + objDs.getProperty('fontcolor') +
      '; background-color:' + strBgcolor +
                '; cursor:' + strCursor +
                '; ' + cancelStyle();
    var strHTML  = '<input type="TEXT" readonly id="' + objDs.getProperty('id') + 
      '" class="' + strClass +
      '" style="' + strStyle +
      '" value="' + strValue + '">';
      
    return strHTML;
  }

  /** 
   * 表示更新メソッド群 
   */
  this.setter = new Setter();

  function Setter() {
    //Setter.prototype.width = _width;
    //Setter.prototype.height = _height;
    Setter.prototype.backgroundcolor = string_backgroundcolor;
    Setter.prototype.fieldvalue = _fieldvalue;

    function _width(newValue, elementId, dataset, cellElementId, cellDataset) {
      if(newValue != '' && newValue < 1) {
        newValue = 1;
        getDocumentElementById(elementId).style.width = newValue;
        return flags(newValue, 'resized', 'modified', 'border');
      }
      getDocumentElementById(elementId).style.width = newValue;
      return flags(newValue, 'resized', 'border');
    }
    
    function _height(newValue, elementId, dataset, cellElementId, cellDataset) {
      if(newValue != '' && newValue < 1) {
        newValue = 1;
        getDocumentElementById(elementId).style.height = newValue;
        return flags(newValue, 'resized', 'modified');
      }
      getDocumentElementById(elementId).style.height = newValue;
      return flags(newValue, 'resized');
    }

    // 値
    function _fieldvalue(newValue, elementId, dataset, cellElementId, cellDataset) {
      var element = getDocumentElementById(elementId);
      var val = nnQuotEscape(newValue,'align',dataset);
      element.value = val;
      element.setAttribute('value', val);

      //カスタマイズ時：カスタマイズ自動チェック
      customizedDefaultValueChecker(dataset, newValue, 'fieldvalue', elementId);

      return flags(newValue);
    }
  }
}

/**
 * TextタイプのtypeObject実装クラス
 * @param  :
 * @return :作成したHTML文字列
 */
function ViewObjectText(){

  ViewObjectText.prototype.setDefaultProperty  = fnSetDefaultProperty_common;
  ViewObjectText.prototype.getPropertiesHtml   = fnGetPropertiesHtml_text;

  /** 
   * 表示更新メソッド群 
   */
  this.setter = new Setter();

  function Setter() {
    Setter.prototype.textcols = text_textcols;
    Setter.prototype.fieldvalue = text_fieldvalue;
  }
}

// 値
function text_fieldvalue(newValue, elementId, dataset, cellElementId, cellDataset) {
  var element = getDocumentElementById(elementId);
  var val = nnQuotEscape(newValue,'align',dataset);
  element.value = val;
  element.setAttribute('value', val);

  //カスタマイズ時：カスタマイズ自動チェック
  customizedDefaultValueChecker(dataset, newValue, 'fieldvalue', elementId);

  return flags(newValue);
}

/**
 * PasswordタイプのtypeObject実装クラス
 * @param  :
 * @return :作成したHTML文字列
 */
function ViewObjectPassword(){

  ViewObjectPassword.prototype.setDefaultProperty  = fnSetDefaultProperty_common;
  ViewObjectPassword.prototype.getPropertiesHtml   = fnGetPropertiesHtml_text;

  /** 
   * 表示更新メソッド群 
   */
  this.setter = new Setter();

  function Setter() {
    Setter.prototype.textcols = text_textcols;
    Setter.prototype.fieldvalue = text_fieldvalue;
  }

  /** 再描画メソッド */  
  ViewObjectText.prototype.repaint = common_repaint;

}

/**
 * text,password共通のオブジェクト描画関数
 */
function fnGetPropertiesHtml_text(objDs){
  var strBgcolor = getBgcolorType(objDs, 0);
  var strCursor  = getCursorType(objDs);
  // value="&quot;あ&quot;" はmozillaでは「"あ"」でなく「あ」と表示される
  // value="&quot;あ&quot; " とすると「"あ" 」と表示される
  var strValue = nnQuotEscape(htmlEscape(objDs.getProperty('fieldvalue')),'align',objDs);
  var strClass = 'vw-' + objDs.type.value.toLowerCase() + ' ' + getTextElementClassProperty(objDs);
  var strStyle = 'width:' + objDs.getProperty('width') +
            'px; height:' + objDs.getProperty('height') +
         'px; font-size:' + objDs.getProperty('fontsize') +
       'pt; font-weight:' + objDs.getProperty('fontweight') +
         '; font-family:' + objDs.getProperty('fontfamily') +
          '; font-style:' + objDs.getProperty('fontstyle') +
          '; text-align:' + objDs.getProperty('align') +
               '; color:' + objDs.getProperty('fontcolor') +
    '; background-color:' + strBgcolor +
              '; cursor:' + strCursor + ';' + cancelStyle();
  var strHTML = '<input type="TEXT" readonly id="' + objDs.getProperty('id') +
         '" size="' + objDs.getProperty('textcols') +
        '" value="' + strValue +
        '" class="' + strClass +
        '" style="' + strStyle + '">'

  return strHTML;
}


/**
 * TextareaタイプのtypeObject実装クラス
 * @param  :
 * @return :作成したHTML文字列
 */
function ViewObjectTextarea(){

  ViewObjectTextarea.prototype.setDefaultProperty  = fnSetDefaultProperty_common;
  ViewObjectTextarea.prototype.getPropertiesHtml   = fnGetPropertiesHtml;

  function fnGetPropertiesHtml(objDs){

    var strBgcolor = getBgcolorType(objDs, 0);
    var strCursor  = getCursorType(objDs);
    var strValue = htmlEscape(objDs.getProperty('fieldvalue'));
    var strClass = 'vw-textarea ' + getTextElementClassProperty(objDs);
    var strStyle = 'width:' + objDs.getProperty('width') +
              'px; height:' + objDs.getProperty('height') +
           'px; font-size:' + objDs.getProperty('fontsize') +
         'pt; font-family:' + objDs.getProperty('fontfamily') +
           '; font-weight:' + objDs.getProperty('fontweight') +
            '; font-style:' + objDs.getProperty('fontstyle') +
            '; text-align:' + objDs.getProperty('align') +
                 '; color:' + objDs.getProperty('fontcolor') +
      '; background-color:' + strBgcolor +
                '; cursor:' + strCursor + ';' + cancelStyle();
    var strHTML = '<textarea readonly id="' + objDs.getProperty('id') +
       '" cols="' + objDs.getProperty('textcols') +
       '" rows="' + objDs.getProperty('textrows') +
      '" class="' + strClass +
      '" style="' + strStyle + '">' + strValue + '</textarea>';
    return strHTML;
  }

  /** 
   * 表示更新メソッド群 
   */
  this.setter = new Setter();

  function Setter() {
    Setter.prototype.editmode = _editmode;
    Setter.prototype.textcols = _textcols;
    Setter.prototype.textrows = _textrows;
    Setter.prototype.fieldvalue = _fieldvalue;
    
    // 値
    function _fieldvalue(newValue, elementId, dataset, cellElementId, cellDataset) {
      var element = getDocumentElementById(elementId);
      element.value = newValue;
      element.setAttribute('value', newValue);

      //カスタマイズ時：カスタマイズ自動チェック
      customizedDefaultValueChecker(dataset, newValue, 'fieldvalue', elementId);

      return flags(newValue);
    }

    // 編集不可
    function _editmode(newValue, elementId, dataset, cellElementId, cellDataset) {
      //newValue = '';
      //if(getDocumentElementById('fld_editmode').checked){
      //  newValue = 'readonly';
      //}
      return flags(newValue);
    }

    // 幅（文字数）
    function _textcols(newValue, elementId, dataset, cellElementId, cellDataset) {
      var val = newValue;
      if(newValue < 1) {
        val = 20;
      } else {
        val = newValue;
      }
      getDocumentElementById(elementId).cols = val;
      return flags(newValue, 'resized', 'border');
    }

    // 高さ（文字数）
    function _textrows(newValue, elementId, dataset, cellElementId, cellDataset) {
      if(newValue < 1) {
        getDocumentElementById(elementId).rows = 2;
      } else {
        getDocumentElementById(elementId).rows = newValue;
      }
      return flags(newValue, 'resized');
    }
  }
}

/**
 * FileタイプのtypeObject実装クラス
 * @param  :
 * @return :作成したHTML文字列
 */
function ViewObjectFile(){

  ViewObjectFile.prototype.setDefaultProperty  = fnSetDefaultProperty_common;
  ViewObjectFile.prototype.getPropertiesHtml   = fnGetPropertiesHtml;

  function fnGetPropertiesHtml(objDs){

    var strFileId  = objDs.getProperty('id');
    var strBgcolor = getBgcolorType(objDs, 0);
    var strCursor  = getCursorType(objDs);
    var strWidth   = objDs.getProperty('width');
    var styleWidth = '';
    if(strWidth != '') {
      if(strWidth >  56) {
        styleWidth = 'width:' + (strWidth -  56) + 'px; ';
      }else{
        styleWidth = 'width:1px; ';
      }
    }
    var strHeight   = objDs.getProperty('height');
    var styleHeight = '';
    if(strHeight != '') {
      if(strHeight > 2) {
        styleHeight = 'height:' + (strHeight - 2) + 'px; ';
      } else {
        styleHeight = 'height:0px; ';
      }
    }

    var strClass = 'vw-file ' + getTextElementClassProperty(objDs);
    var strOmitStyle = 'border:2px outset white;padding:0px;background:' + pref.view.get('popupbuttoncolor') + ';font-size:8pt;margin:0px 0px 0px 2px;';
    var strInput = '<input type="text" readonly id="' + strFileId 
      + '_FILETEXT" size="' + objDs.getProperty('textcols') + 
      '" class="' + strClass +
      '" style="' + styleWidth + styleHeight +
               'font-size:' + objDs.getProperty('fontsize') + 
               'pt; color:' + objDs.getProperty('fontcolor') + 
            '; text-align:' + objDs.getProperty('align') + 
      '; background-color:' + strBgcolor + 
                '; cursor:' + strCursor + ';' + cancelStyle() + '">';
    var strButton = '<input class="' + strClass + '" type="text" id="' + strFileId
      + '_FILEBUTTON" style="width:52px; ' + styleHeight + strOmitStyle + 
      ' text-align:center; cursor:' + strCursor + 
      ';" value="' + getLiteral('element.file.browsebuttonlabel') + 
      '..." readonly>';
    var strHTML = '<table border="0" cellpadding="0" cellspacing="0" id="' + strFileId +
      '" style="cursor:' + strCursor + 
      ';"><tr><td>' + strInput
      + '</td><td>' + strButton 
      + '</td></tr></table>';
    return strHTML;
  }

  this.setter = new Setter();
  function Setter() {
    Setter.prototype.width = _width;
    Setter.prototype.height = _height;
    Setter.prototype.fontsize = _fontsize;
    Setter.prototype.fontcolor = _fontcolor;
    Setter.prototype.align = _align;
    Setter.prototype.backgroundcolor = _backgroundcolor;
    Setter.prototype.textcols = _textcols;

    // 幅
    function _width(newValue, elementId, dataset, cellElementId, cellDataset) {
      var modified = '';
      var val = '';
      if(newValue != '') {
        if(newValue < 1) {
          newValue = 1;
          modified = 'modified';
        }
        if(newValue > 56) {
          val = (newValue - 56) + 'px';
        } else {
          val = '1px';
        }
      }
      getDocumentElementById(elementId + '_FILETEXT').style.width = val;
      return flags(newValue, 'resized', modified, 'border');
    }
    
    // 高さ
    function _height(newValue, elementId, dataset, cellElementId, cellDataset) {
      var modified = '';
      var val = '';
      if(newValue != '') {
        if(newValue < 1) {
          newValue = 1;
          modified = 'modified';
        }
        if(newValue > 2) {
          val = (newValue - 2) + 'px';
        } else {
          val = '1px';
        }
      }
      getDocumentElementById(elementId + '_FILETEXT').style.height = val;
      getDocumentElementById(elementId + '_FILEBUTTON').style.height = val;
      return flags(newValue, 'resized', modified);
    }
    
    // 文字のサイズ
    function _fontsize(newValue, elementId, dataset, cellElementId, cellDataset) {
      var val = '';
      if(newValue != '') {
        val = newValue + 'pt';
      }
      var textelement = getDocumentElementById(elementId + '_FILETEXT');
      textelement.style.fontSize = val;
      getDocumentElementById(elementId + '_FILEBUTTON').style.height = textelement.offsetHeight;

      // 再描画
      var sizval = dataset.getProperty('textcols');
      if(sizval == '' || sizval < 1) {
        sizval = 20;
      }
      textelement.size = sizval + 1;
      textelement.size = sizval;
      
      return flags(newValue, 'resized', 'border');
    }

    // 文字の色
    function _fontcolor(newValue, elementId, dataset, cellElementId, cellDataset) {
      setElementStyleFontColor(getDocumentElementById(elementId + '_FILETEXT'), newValue);
      return flags(newValue);
    }

    // 水平位置
    function _align(newValue, elementId, dataset, cellElementId, cellDataset) {
      getDocumentElementById(elementId + '_FILETEXT').style.textAlign = newValue;
      return flags(newValue);
    }
    
    // 背景色
    function _backgroundcolor(newValue, elementId, dataset, cellElementId, cellDataset) {
      if(dataset.getProperty('visibility') != 'hidden'){
        getDocumentElementById(elementId + '_FILETEXT').style.backgroundColor = newValue;
        //setElementStyleBackgroundColor(getDocumentElementById(elementId + '_FILETEXT'), newValue);
      }
      return flags(newValue);
    }

    // 幅（文字数）
    function _textcols(newValue, elementId, dataset, cellElementId, cellDataset) {
      var val = newValue;
      if(newValue < 1) {
        val = 20;
      } else {
        val = newValue;
      }
      getDocumentElementById(elementId + '_FILETEXT').size = val;
      return flags(newValue, 'resized', 'border');
    }
  }
}


/**
 * HideタイプのtypeObject実装クラス
 * @param  :
 * @return :作成したHTML文字列
 */
function ViewObjectHide(){

  ViewObjectHide.prototype.setDefaultProperty  = fnSetDefaultProperty_common;
  ViewObjectHide.prototype.getPropertiesHtml   = fnGetPropertiesHtml;

  function fnGetPropertiesHtml(objDs){
    var strCursor  = getCursorType(objDs);
/*
    var strHTML = '';
    strHTML += '<INPUT TYPE="TEXT" ID="' + objDs.getProperty('id') + '" hidden=true STYLE="cursor:' + strCursor + '; width:15px; border:1px #1e32e3 ridge; background-color:' + pref.view.get('hiddencolor') + ';" readonly>';
    return strHTML;
*/
    return '<INPUT TYPE="TEXT" ID="' + objDs.getProperty('id') + '" hidden=true STYLE="cursor:' + strCursor + '; width:15px; border:1px #1e32e3 ridge; background-color:' + pref.view.get('hiddencolor') + ';" readonly>';
  }

  /** 
   * 表示更新メソッド群 
   */
  this.setter = new Setter();

  function Setter() {
    Setter.prototype.fieldvalue = _fieldvalue;

    function _fieldvalue(newValue, elementId, dataset, cellElementId, cellDataset) {
      customizedDefaultValueChecker(dataset, newValue, 'fieldvalue', elementId);
      return flags(newValue);
    }
  }
}


// 背景色
function string_backgroundcolor(newValue, elementId, dataset, cellElementId, cellDataset) {
  if(dataset.getProperty('visibility') != 'hidden'){
    if(newValue == ''){
      getDocumentElementById(elementId).style.backgroundColor = '';
    }else{
      setElementStyleBackgroundColor(getDocumentElementById(elementId), newValue);
    }
  }
  return flags(newValue);
}

// 幅（文字数）
function text_textcols(newValue, elementId, dataset, cellElementId, cellDataset) {
  var val = newValue;
  if(newValue < 1) {
    val = 20;
  } else {
    val = newValue;
  }
  getDocumentElementById(elementId).size = val;
  return flags(newValue, 'resized', 'border');
}
