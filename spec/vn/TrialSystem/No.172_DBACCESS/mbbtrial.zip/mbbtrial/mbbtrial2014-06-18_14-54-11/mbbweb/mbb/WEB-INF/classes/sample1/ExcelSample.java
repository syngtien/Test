package sample1;

import jp.co.bbs.unit.sys.ProcessException;
import java.util.Date;
import java.sql.*;

public class ExcelSample extends jp.co.bbs.unit.proc.tool.excel.exec.ExcelFileDownload {

	@Override
	public void doExecute() throws ProcessException {
		setExcelTeplate("sample1/sampletemplate");
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try {
			stmt = getConnection().prepareStatement("SELECT * FROM ITEMDEFINITIONMASTER ORDER BY ITEMDEFINITIONID, ITEMID");
			rs = stmt.executeQuery();
			int cols = rs.getMetaData().getColumnCount();
			int line = 0;
			int sheetNo = 0;
			int sheetLineNo = 1;
			while (rs.next()) {
				++line;
				putCellData(sheetLineNo, 0, line);
				for (int i = 1; i <= cols; ++i) {
					putCellData(sheetLineNo, i, rs.getString(i));
				}
				++sheetLineNo;
				if (sheetLineNo > 65535) {
					sheetLineNo = 0;
					// �V�K�V�[�g�̍쐬
					setActiveSheetAt(++sheetNo);
					// �擪�s�̕���
					styleCopy(getSheetAt(sheetNo-1), sheetLineNo, getSheetAt(sheetNo), sheetLineNo);
					valueCopy(getSheetAt(sheetNo-1), sheetLineNo, getSheetAt(sheetNo), sheetLineNo);
					++sheetLineNo;
				}
			}
			setActiveSheetAt(0);
		} catch (SQLException e) {
			throw new ProcessException("EM0017", e.getMessage());
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {}
			}
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {}
			}
		}
		write();
	}

}
