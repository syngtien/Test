function _getXMLHttp() {
  var xmlhttp;
  try {
    xmlhttp = new ActiveXObject("Msxml2.XMLHTTP");
  } catch (e) {
    try {
      xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
    } catch (E) {
      xmlhttp = false;
    }
  }
  if (!xmlhttp && typeof XMLHttpRequest!='undefined') {
    xmlhttp = new XMLHttpRequest();
  }
  return xmlhttp;
}

function doItemChange(item,userCompanyId,userId,companyId,menuId,menuItemId){
  var uid=userCompanyId+','+userId;
  var mid=companyId+','+menuId+','+menuItemId;
  var a=document.getElementById(mid);
  var span=a.childNodes[0];
  var value=item.value;
  if(value=='1'){
    span.className='';
  }else if(value=='2'){
    span.className='readonly';
  }else if(value=='3'){
    span.className='disabled';
  }
  var xmlhttp = _getXMLHttp();
  xmlhttp.open('POST', 'appcontroller', true);
  xmlhttp.setRequestHeader('Content-Type' , 'application/x-www-form-urlencoded');
  var postdata = 'PROCESSID=&PAGEID=&JSPID=jsp/SysMenuPEdit&_UPDATEKEY='+uid+','+mid+'&_UPDATE='+value;
  xmlhttp.onreadystatechange = function() 
  {
    if (xmlhttp.readyState == 4) {
      if (xmlhttp.status == 200) {
        var xmlDoc = xmlhttp.responseXML;
        return true;
      }
    }
  }
  xmlhttp.send(encodeURI(postdata));
  return true;
}

function doCopyUserPermission() {
  var userCompanyId=getFieldValue('COMPANYID');
  var userId=getFieldValue('USERID');
  var fromUserCompanyId=getFieldValue('COPYUSERCOMPANYID');
  var fromUserId=getFieldValue('COPYUSERID');
  var fromUserName=getFieldValue('COPYUSERNAME');
  if(confirm('['+fromUserId+' ' + fromUserName + ']の権限設定情報を複写します。よろしいですか？')) {
    document.forms[0].submit();
  }else{
    setFieldValue('COPYUSERCOMPANYID','');
  }
}
function doAssignPermission(key,text) {
  if(confirm('権限['+text+']を追加します。よろしいですか？')) {
    document.getElementById('ADDROLEPERMISSION').value=key;
    document.forms[0].submit();
  }
}
function doRevokePermission(key,text) {
  if(confirm('権限['+text+']を削除します。よろしいですか？')) {
    document.getElementById('DELROLEPERMISSION').value=key;
    document.forms[0].submit();
  }
}
function doClearUserPermission() {
  var userCompanyId=getFieldValue('COMPANYID');
  var userId=getFieldValue('USERID');
  if(confirm('個別権限設定情報をクリアしてロール権限設定情報に初期化します。よろしいですか？')) {
    document.getElementById('COPYUSERCOMPANYID').value=userCompanyId;
    document.getElementById('COPYUSERID').value=userId;
    document.getElementById('COPYUSERNAME').value='';
    document.forms[0].submit();
  }
}
function closeHelpWindow(){
  if(confirm('選択内容を保存します。よろしいですか？')) {
    var xmlhttp = _getXMLHttp();
    xmlhttp.open('POST', 'appcontroller', true);
    xmlhttp.setRequestHeader('Content-Type' , 'application/x-www-form-urlencoded');
    var postdata = 'PROCESSID=&PAGEID=&JSPID=jsp/SysMenuViewHelp&_UPDATE=1&COMPANYID='+document.getElementById('COMPANYID').value+'&ROLEID='+document.getElementById('ROLEID').value+'&PERMISSIONID='+document.getElementById('PERMISSIONID').value;
    var items = document.getElementsByTagName('INPUT');
    for(var i=0;i<items.length;++i){
      if(items[i].checked){
        postdata += '&_ITEM='+items[i].value;
      }
    }
    xmlhttp.onreadystatechange = function() 
    {
      if (xmlhttp.readyState == 4) {
        if (xmlhttp.status == 200) {
          var xmlDoc = xmlhttp.responseXML;
          window.opener.document.getElementById('REFRESH').click();
          (window.open('','_top').opener=top).close();
          return true;
        }
      }
    }
    xmlhttp.send(encodeURI(postdata));
  }
}

function doMenuInitialize() {
  var items = document.getElementsByTagName('INPUT');
  var alt = 0;
  if(autoScroll) {
    autoScroll=false;
  }
  for(var i=0;i<items.length;++i){
    if(items[i].checked){
      var f=getParentFolder(items[i]);
      while(f&&!isFolderOpend(f)){
        f.click();
        f=getParentFolder(f);
      }
    }
  }
}
function getParentFolder(item) {
  if(item.parentNode&&item.parentNode.parentNode&&item.parentNode.parentNode.parentNode) {
    for(var i=0,j=item.parentNode.parentNode.parentNode.childNodes.length;i<j;++i){
      if(item.parentNode.parentNode.parentNode.childNodes[i].className=='folder'){
        return item.parentNode.parentNode.parentNode.childNodes[i];
      }
    }
  }
  return null;
}

function doUserLogin(companyId, userId) {
  //doInitializeProcess(document.forms[0], 'SysDebugLoginP', 'SysDebugLogin', '', '', '', 'main', 'DEBUGCOMPANYID='+companyId+'&DEBUGUSERID='+userId);
  window.opener.location='appcontroller?PROCESSID=SysDebugLoginP&PAGEID=SysDebugLogin&DEBUGCOMPANYID='+companyId+'&DEBUGUSERID='+userId;
  (window.open('','_top').opener=top).close();
  return false;
}

function doRolePermission(roleId, userId) {
  window.opener.location='appcontroller?PROCESSID=MmRolePermissionListP&PAGEID=MmRolePermissionLD&SKEY.COMPANYID=MBB&SKEY.ROLEID='+roleId+'&SKEY.USERID='+userId;
  (window.open('','_top').opener=top).close();
  return false;
}
