/**
 * VwPropertyFunctions
 * 属性編集
 */
LAST_MODIFIED('2005.02.08', '1.0.33');
 
//////
//global

/**
 * 追加したエレメントのID 配列
 */
var m_addElementArray = new Array();
if(!m_addElementArray.splice) {
  m_addElementArray.splice = arraySplice;
}

/**
 * DataSetの配列 配列
 */
var m_objDataSet = new Array();

/**
 * 削除した項目のID 配列
 */
var m_deleteElementArray = new Array();
if(!m_deleteElementArray.splice) {
  m_deleteElementArray.splice = arraySplice;
}

/**
 * フォーカスを持っているプロパティ設定項目のID 文字型
 */
var m_focusedPropId = '';

/**
 * フォーカスを持っているプロパティ設定項目の最後に更新された値 文字型
 */
var m_focusedPropValue = '';

/**
 * 色名と"#FFFFFF"形式のデータ紐付け定義配列 配列
 */
var m_colorNames = createColorNames();

/**
 * DataSetObjectを取得
 */
function getDataSet(id) {
  if(id) {
    return m_objDataSet[id];
  } else {
    return null;
  }
}

/**
 * DataSetObjectを取得
 */
function createDataSet(id, type, name) {
  return m_objDataSet[id] = new DataSet(id, type, name);
}

/**
 * DataSetObjectを取得
 */
function addDataSet(id, dataset) {
  return m_objDataSet[id] = dataset;
}

/**
 * DataSetObjectを削除する
 */
function deleteDataSet(id) {
  delete m_objDataSet[id];
}

/**
 * 複製を返す
 */
function duplicateDataSet(objDS){
  setDS = new Object();
  for(var i in objDS){
    if(typeof(objDS[i]) == 'function'){
      //メソッドのコピー
      setDS[i] = objDS[i];
    }else{
      //プロパティのコピー
      setDS[i] = new Object();
      for(var j in objDS[i]){
        if(isArrayValue(i)){
          setDS[i][j] = new Array();
          for(var k in objDS[i][j]){
            setDS[i][j][k] = objDS[i][j][k];
          }
        }else{
          setDS[i][j] = objDS[i][j];
        }
      }
    }
  }
  return setDS;
}

/**
 * プロパティテーブルの値及びデータ保持オブジェクトの値設定
 * @param  :strTypeId  文字型 設定するプロパティー設定INPUTのID
 *          colorValue        設定する値
 * @return :
 */
function onKeyUpColorProperty(strTypeId, colorValue, _event){
  if(_event.keyCode < KEYCODE.DELETE && _event.keyCode != KEYCODE.BACKSPACE) return;
  onChangeColorProperty(strTypeId, colorValue);
}


/**
 * プロパティテーブルの値及びデータ保持オブジェクトの値設定
 * @param  :fldId  文字型 設定するプロパティー設定INPUTのID
 *          objVal        設定する値
 *          elementId  文字型 プロパティを設定するオブジェクトID
 * @return :
 */
function onClickCheckboxProperty(fldId, objValue, checked, elementId ,cellid){
  if(checked) {
    changeProperty(fldId, objValue, elementId ,cellid);
  } else {
    changeProperty(fldId, '', elementId ,cellid);
  };
}

/**
 * プロパティテーブルの値及びデータ保持オブジェクトの値設定
 * @param  :fldId  文字型 設定するプロパティー設定INPUTのID
 *          objVal        設定する値
 *          elementId  文字型 プロパティを設定するオブジェクトID
 * @return :
 */
function onClickCustomProperty(fldId, checked, elementId ,cellid){
  if(checked) {
    changeProperty(fldId, 'enabled', elementId ,cellid);
  } else {
    changeProperty(fldId, 'disabled', elementId ,cellid);
  };
}

/**
 * プロパティテーブルの値及びデータ保持オブジェクトの値設定
 * @param  :fldId  文字型 設定するプロパティー設定INPUTのID
 *          objVal        設定する値
 *          elementId  文字型 プロパティを設定するオブジェクトID
 * @return :
 */
function doChangeProperty(fldId, objValue, elementId ,cellid, logmsg){
  //log.debug('doChangeProperty(' + [fldId, objValue, elementId ,cellid] + ')  ' + logmsg);
  changeProperty(fldId, objValue, elementId ,cellid);
}

/**
 * プロパティテーブルの値及びデータ保持オブジェクトの値設定
 * @param  :fldId  文字型 設定するプロパティー設定INPUTのID
 *          objVal        設定する値
 *          elementId  文字型 プロパティを設定するオブジェクトID
 * @return :
 */
function onChangeProperty(fldId, objValue, elementId ,cellid){
  //log.debug('onChangeProperty(' + [fldId, objValue, elementId ,cellid] + ')');
  changeProperty(fldId, objValue, elementId ,cellid);
}

/**
 * プロパティテーブルの値及びデータ保持オブジェクトの値設定
 * @param  :fldId  文字型 設定するプロパティー設定INPUTのID
 *          objVal        設定する値
 *          elementId  文字型 プロパティを設定するオブジェクトID
 * @return :
 */
function changeProperty(fldId, objValue, elementId ,cellid){
  log.debug('changeProperty:enter (fldId:'+fldId + ')'); //@@

  //オブジェクトIDのチェック
  if(elementId){
    if(elementId != m_selection.front){
      log.warn('onChangeProperty:' + fldId + '/' + objValue + '/' + elementId + '!=' + m_selection.front);
      return;
    }
  }
  if(cellid){
    if(cellid != m_selection.cell){
      log.warn('onChangeProperty:' + fldId + '/' + objValue + '/' + cellid + '!=' + m_selection.cell);
      return;
    }
  }
  
  updateValueForUpdateList(fldId, objValue);

  //onFocusProperty(fldId);
  
  var shouldUpdatePropertyArea = false;
  if(m_selection.cell != m_selection.current.cell) {
    //log.debug(fldId + ': ' + m_selection.cell + '  != ' + m_selection.current.cell);
    shouldUpdatePropertyArea = true;
  } else {

    switch(fldId) {
    case 'fld_tablemode':
    case 'fld_tablecols':
    case 'fld_tablerows':
    case 'fld_titlecols':
    case 'fld_titlerows':
      //log.debug('fldId : ' + fldId);
      shouldUpdatePropertyArea = true;
    }
  }

  if(shouldUpdatePropertyArea) {
    //log.debug('updating property area. [VwPropertyFunction.js/changeProperty]');
    m_selection.updatePropertyArea(fldId);
  }
}

/**
 * DataSetへの値セット及び、編集画面上項目の表示変更
 * @param  :fldId        文字型 設定するプロパティー設定INPUTのID
 *          objVal              設定する値
 *          strId        文字型 プロパティを設定するオブジェクトID
 * @return :
 */
function updateValueForUpdateList(fldId, objValue){
  log.debug('updateValueForUpdateList:enter (fldId:'+fldId + ')'); //@@

  // 更新するオブジェクトのリスト
  var list = getUpdateList(fldId.substr(4));
  // コマンドセット
  var cmdSet = new UndoableCommandSet();
  cmdSet.add(new CommandSelect(true));
  
  var prog = new WindowStatusProgressBar(list.length);
  // 更新
  for(var i = 0; i < list.length; i++) {
    prog.update();
    updateValuePerObject(list[i].elementId, list[i].cellElementId, 'fld_' + list[i].propertyId, objValue, '', cmdSet);
  }
  prog.release();

  // Undo登録
  if(cmdSet && cmdSet.commands.length > 1) {
    cmdSet.add(new CommandSelect(false));
    m_undoManager.execute(cmdSet);
  }
}

/**
 * DataSetへの値セット及び、編集画面上項目の表示変更
 * @param  :objId        文字型 設定するプロパティー設定INPUTのID
 *          objVal              設定する値
 * @return :
 */
function getUpdateList(propId, typeId){
  log.debug('getUpdateList:enter (propId:' + propId + ',typeId:' + typeId + ')');
  var list = new Array();

  function addList(elementId, cellElementId, propertyId, datasetId) {
    var obj = new Object();
    obj.elementId = elementId;
    obj.cellElementId = cellElementId;
    obj.propertyId = propertyId;
    if(datasetId) {
      obj.datasetId = datasetId;
    } else {
      obj.datasetId = elementId;
    }
    return obj;
  }
  
  if(!typeId) {
    typeId = getDataSet(m_selection.front).getProperty('type');
  }
  
  if(isCellPropertyId(propId)) {
    // セルの属性は複数できない
    list[list.length] = addList(m_selection.front, m_selection.cell, propId, m_selection.cell);

  } else {
    for(var elementId in m_selection.elements) {
      var cellElementId = '';
      var toTypeId = getDataSet(elementId).getProperty('type');
      //var propertyId = getConvertiblePropertyId(propId, typeId, toTypeId);
      //if(propertyId != '') {
      //

      // 共通のプロパティ
      var propertyId = propId;
      var editType = getDisplayEditType(toTypeId, propId);
      switch(editType) {
      case DISUSE :
      case HIDDEN :
      case READONLY :
      case EDITTYPE.TEXT_READONLY :
      case EDITTYPE.NUMBER_READONLY :
      case EDITTYPE.CHECK_READONLY :
      case EDITTYPE.COLOR_READONLY :
        break;
      default:
        if(toTypeId == TYPE.TABLE) {
          cellElementId = getCellId(elementId);
        }
        list[list.length] = addList(elementId, cellElementId, propertyId);
      }
    }
  }
  return list;    
}

/**
 * 選択されたオブジェクトの枠表示
 * @param  :elementId              設定するオブジェクト
 * @return :
 */

/**
 * DataSetへの値セット及び、編集画面上項目の表示変更
 * @param  :objId        文字型 設定するプロパティー設定INPUTのID
 *          objVal              設定する値
 *          strId        しようしない
 *          cmdSet ブール コマンドオブジェクト生成フラグ
 * @return :
 */
function updateValuePerObject(elementId, cellElementId, fldId, objValue, strId, cmdSet, pRtn){
  log.debug('updateValuePerObject : enter (elementId:' + elementId + ')'); 
  
  //カレントのDataSet
  var objDS     = getDataSet(elementId);

  //undo&redo用(設定する値と元の値を保持)
  var processOrgVal = objDS.getProperty(fldId.substr(4));
  //tdへの設定時
  if(fldId.match('fld_cell') != null){
    if(cellElementId == '') {
      alert('id of cell is null.');
      return;
    }
    processOrgVal = getDataSet(cellElementId).getProperty(fldId.substr(4));
  }

  var type = objDS.getProperty('type');
  var rtn = getViewObject(type).update(fldId.substr(4), objValue, elementId, objDS, cellElementId, getDataSet(cellElementId, null));
  if(rtn) {
    
    if(!rtn.updated) {
      // datasetは更新されていない
      objDS.setProperty(fldId.substr(4), rtn.value);
    }
    
    if(rtn.modified) {
      // 入力値が訂正されている
      if(elementId == m_selection.current.front) {
        var editField = getDocumentElementById(fldId);
        if(editField) {
          editField.value = rtn.value;
        }
      }
    }

    if(rtn.otherUpdates) {
      // 他のプロパティを更新
      for(var propertyId in rtn.otherUpdates) {
        var newVal = rtn.otherUpdates[propertyId];
        updateValuePerObject(elementId, cellElementId, 'fld_' + propertyId, newVal, strId, cmdSet, rtn);
      }
    }
    
    if(rtn.repaint) {
      if(pRtn) {
        // 親に再描画させる
        pRtn.repaint = true;
      } else {
        // span再描画
        getViewObject(type).repaint(elementId, objDS, cellElementId, getDataSet(cellElementId, null));
      }
    }

    if(rtn.border) {
      if(pRtn) {
        // 親にborder再描画させる
        pRtn.border = true;
      } else {
        // spanのborder再描画
        var spanStyle = getDocumentElementById(elementId + '_span').style;
        var border = spanStyle.border;
        spanStyle.border = 'none';
        spanStyle.border = border;
      }
    }
    
    if(rtn.undoInfos) {
      if(pRtn) {
        // 親に渡す
        pRtn.undoInfos = rtn.undoInfos;
      }
    }

    if(rtn.reconstructed) {
      if(m_selection.has(elementId)) {
        setResizeHandle(elementId);
      }
    } else if(rtn.resized) {
      // サイズが変更されたのでリサイズハンドルの位置を修正
      if(m_selection.has(elementId)) {
        validateResizeHandleLocation(elementId);
      }
    }

    objValue = rtn.value;
  }

  //undo&redo用 onChangeProperty実行時かつ値変更時のみコマンドオブジェクト作成
  if(cmdSet && processOrgVal.toString() != objValue.toString()){
    var cmd = new UndoPropertyEdit(elementId, cellElementId, fldId.substr(4), processOrgVal, objValue, rtn.undoInfos);
    cmdSet.add(cmd);
  }

  if(cmdSet && rtn && rtn.undoTransferCell) {
    cmdSet.add(rtn.undoTransferCell);
  }
    
  //log.debug('updateValuePerObject : exit'); 
}

/**
 * エレメントの項目TYPEを変換する
 * @param  :
 * @return :
 */
function doEditItemType(){
  if(m_selection.front == ELEMENTID_FIRSTFORM) return;
  var curType = getDataSet(m_selection.front).getProperty('type');

  // 更新対象リスト
  var updateList = getUpdateList('type');

  //カレントの項目TYPEによりダイアログへ渡す項目TYPEを作成する
  var objArg = new Object();
  objArg.pageItemTypeIds = new Array();
  objArg.targetObjectId = m_selection.front;
  
  objArg.originalTypeId = curType;
  var curTypeType = getPropertyInfoDef(curType,'type').convertiblePropertyId;
  for(var i in TYPE){
    var typeid = TYPE[i];
    if(getPropertyInfoDef(typeid,'type').convertiblePropertyId == curTypeType){
      objArg.pageItemTypeIds[objArg.pageItemTypeIds.length] = typeid;
    }
  }
      
  objArg.typeNames = new TypeNames();
  objArg.returnOk = onReturnOk;

  openTypeChangeDialog(objArg);
  
  function onReturnOk(rtn){
    if(!rtn.isOk) return;

    // コマンドセット
    var cmdSet = new UndoableCommandSet(getLiteral('command.pageitemchange'));
    
    var cmdSelUndo = new CommandSelect(true,true,'');
    var cmdSelRedo = new CommandSelect(false,true,'');
    cmdSet.add(cmdSelUndo);
    
    m_selection.removeAll();
    // 更新
    
    for(var i = 0; i < updateList.length; i++) {
      
      var elementId = updateList[i].elementId;
      
      // ないオブジェクトを飛ばす。関数内でメッセージを表示
      if(!isPropertyOwnerExists(elementId)) {
        continue;
      }
 
      // データセットオブジェクト
      var dataset = getDataSet(elementId);

      var curType = dataset.getProperty('type');
      if(curType == toTypeCase(rtn.pageItemTypeId)) {
        m_selection.add(elementId);
        cmdSelUndo.add(elementId);
        cmdSelRedo.add(elementId);
        continue;
      }

      //zIndex取得
      var tmpZIndex = getDocumentElementById(elementId + '_span').style.zIndex;
      
      //undo&redo
      var objParam        = new Object();
      objParam.id     = elementId;
      objParam.action = 5;
      objParam.name   = '項目タイプ変換';
      objParam.newtype = rtn.pageItemTypeId;
      objParam.zindex  = tmpZIndex;
      objParam.orgtype = curType;
      //元のDataSetをコピー
      objParam.orgds  = duplicateDataSet(dataset);

      //変換元がTABLE時、全セルのDataSetもコピー(コピーしたセルの配列はインデックスをIDとする)
      if(curType == TYPE.TABLE){
        objParam.orgtds = new Array();
        for(var j=0; j<m_addElementArray.length; j++){
          if(isCellId(m_addElementArray[j], elementId)) {
            objParam.orgtds[m_addElementArray[j]] = duplicateDataSet(getDataSet(m_addElementArray[j]));
          }
        }
      }
      var cmd = createActionCommand(objParam);
      cmdSet.add(cmd);
      
      cmdSelUndo.add(elementId);
      cmdSelRedo.add(elementId);
      
      //ダイアログから取得した項目TYPEへの変換処理
      changeItemType(curType, rtn.pageItemTypeId, elementId);
      
      m_selection.add(elementId);
      
      //zIndex付加
      getDocumentElementById(elementId + '_span').style.zIndex = tmpZIndex;

    }

    // Undo登録
    if(cmdSet && cmdSet.commands.length > 1) {
      cmdSet.add(cmdSelRedo);
      m_undoManager.execute(cmdSet);
    }
    
    if(getDataSet(m_selection.front).isType(TYPE.TABLE)) {
      m_selection.setCell(getCellId(m_selection.front));
    }

    //log.debug('updating property area. [VwPropertyFunction.js/doEditItemType.onReturnOk]');
    m_selection.updatePropertyArea();

  }
}

/**
 * 項目タイプ変換プロセス
 * @param  :curType 文字型 現在の項目タイプ
 *          newType 文字型 変換後の項目タイプ
 * @return :
 */
function changeItemType(curType, newType, id){
  curType = toTypeCase(curType);
  newType = toTypeCase(newType);
  if(newType == TYPE.TABLE || newType == TYPE.PANEL){
    changeContainerType(curType, newType, id);
  }else{
    changeComponentType(curType, newType, id);
  }
}

/**
 * TABLE⇔PANEL間の変換を行う
 * @param  :fromType  文字型 元の項目TYPE
 *          toType 文字型 変換する項目TYPE
 * @return :
 */
function changeContainerType(fromType, toType, id){

  //元データのプロパティを取得(位置・幅・高さ・背景色・枠線の色・枠線の幅)
  var values = getConvertiblePropertyValues(id, fromType);
  
  var objDS      = getDataSet(id);
  var orgWidth   = 0;
  var orgHeight  = 0;

  if(fromType == TYPE.PANEL){
    orgWidth   = parseInt(objDS.getProperty('width'));
    orgHeight  = parseInt(objDS.getProperty('height'));
  }else{
    //行列数取得
    var orgCol = parseInt(objDS.getProperty('tablecols'));
    var orgRow = getDesignTableRows(objDS);

    //1行目の全セルの幅の和をテーブルの幅とする
    for(var i=1; i<orgCol+1; i++){
      orgWidth += parseInt(getDataSet(getCellId(id, 1, i)).getProperty('cellwidth'));
    }

    //1列目の全セルの高さの和をテーブルの高さとする
    for(var i=1; i<orgRow+1; i++){
      orgHeight += parseInt(getDataSet(getCellId(id, i, 1)).getProperty('cellheight'));
    }
  }
  
  //オリジナルのdataSet破棄
  deleteDataSet(id);

  //セルのDataSet破棄(空文字セット、空文字の要素を削除)
  if(fromType == TYPE.TABLE){
    var orgTdIds = new Array();
    for(var i=0; i<m_addElementArray.length; i++){
      if(isCellId(m_addElementArray[i], id)) {
        orgTdIds[orgTdIds.length] = m_addElementArray[i];
        m_addElementArray.splice(i, 1, '');
      }
    }
    for(var i=0; i<orgTdIds.length; i++){
      //セルのdatasetobject破棄
      deleteDataSet(orgTdIds[i]);
      //セルのID削除
      for(var j=0; j<m_addElementArray.length; j++){
        if(m_addElementArray[j] == ''){
          m_addElementArray.splice(j, 1);
        }
      }
    }
  }
  
  //新たに同IDのDataSet生成
  var ds = createDataSet(id, toType, values.name);

  if(toType == TYPE.TABLE){
    var cellid   = getCellId(id);
    m_addElementArray[m_addElementArray.length] = cellid;
    var tdds = createDataSet(cellid, TYPE.CELL);
    tdds.setProperty('cellcol', 1);
    tdds.setProperty('cellrow', 1);
  }

  //デフォルトプロパティセット
  initDataSetByType(ds);

  //オリジナルプロパティ値セット
  setConvertiblePropertyValues(values, id, toType);

  ds.setProperty('originalparentitemid', values.originalparentitemid);

  if(toType == TYPE.TABLE){
    tdds.setProperty('cellwidth', orgWidth);
    tdds.setProperty('cellheight', orgHeight);
  } else {
    ds.setProperty('width', orgWidth);
    ds.setProperty('height', orgHeight);
  }

  //HTML入れ替え
  setOuterHTML(getDocumentElementById(id + '_span'), getElementHtml(ds));
}

/**
 * TABLE,PANEL以外の項目TYPEの変換を行う
 * @param  :fromType  文字型 変換前の項目TYPE
 *          toType 文字型 変換後の項目TYPE
 * @return :
 */
function changeComponentType(fromType, toType, id){

  //元プロパティ取得(該当プロパティがないものは空)
  var cmnProp = getConvertiblePropertyValues(id, fromType);

  //オリジナルのdataSet破棄
  deleteDataSet(id);
  
  //新たに同IDのDataSet生成
  var ds = createDataSet(id, toType, cmnProp.name);

  //デフォルトプロパティセット
  initDataSetByType(ds);
  
  //元プロパティセット
  setConvertiblePropertyValues(cmnProp, id, toType);

  //HTML入れ替え
  setOuterHTML(getDocumentElementById(id + '_span'), getElementHtml(ds));
}

/**
 * オリジナルエレメントのプロパティを取得
 * @return :  オブジェクト 
 */
function getConvertiblePropertyValues(id, fromType){
  var rtnObj = new Object();
  var objOrgDS = getDataSet(id);
  rtnObj.originalparentitemid   = objOrgDS.getProperty('originalparentitemid');
  rtnObj.name = '';

  for(var propid in getTypeInfoDef(fromType)) {
    var convertiblePropertyId = getPropertyInfoDef(fromType,propid).convertiblePropertyId;
    if(convertiblePropertyId.indexOf('.usedefault') > 0) continue;
    rtnObj[convertiblePropertyId] = objOrgDS.getProperty(propid);
  }
  return rtnObj;
}

/**
 * 新たに作成したDataSetに元のプロパティをセット
 */
function setConvertiblePropertyValues(cmnProp, id, toType){
  //変換後のDataSetをキャッシュ
  var objNewDS = getDataSet(id);
  //オリジナルの親ID
  objNewDS.setProperty('originalparentitemid', cmnProp.originalparentitemid);

  for(var propid in getTypeInfoDef(toType)) {
    if(propid == 'type') continue;
    var convertiblePropertyId = getPropertyInfoDef(toType,propid).convertiblePropertyId;
    if(typeof(cmnProp[convertiblePropertyId]) != 'undefined') {
      
      if(getPropertyInfoDef(toType,propid).isArrayValue) {
        var val = createOptionItemsValue(cmnProp[convertiblePropertyId]);
        objNewDS.setProperty(propid, val);
      } else {
        objNewDS.setProperty(propid, cmnProp[convertiblePropertyId]);
      }
    }
  }

  if(toType == TYPE.RADIO){
    if(cmnProp['option']) {
      objNewDS.setProperty('optioncols', cmnProp['option'].length);
    } else {
      objNewDS.setProperty('optioncols', 1);
    }
    objNewDS.setProperty('optionrows', 1);
  }

}

/**
 * @param  :
 * @return :
 */
function createOptionItemsValue(optionItems){
  // Undo用に実行前の値作成
  var val = new Array();
  for(var j in optionItems){
    val[j] = optionItems[j];
  }
  return val;
}

function CommonArguments() {
}

function initCommonArguments() {
  CommonArguments.prototype.getWindow      = _throwWindowNotOpened;
  CommonArguments.prototype.getFormElement = _throwWindowNotOpened;
  CommonArguments.prototype.getListElement = _throwWindowNotOpened;
  CommonArguments.prototype.alert = _alert;
  CommonArguments.prototype.confirm = _confirm;
  CommonArguments.prototype.toSaveValue = _toSaveValue;
  CommonArguments.prototype.toDispValue = _toDispValue;
  CommonArguments.prototype.defineOptionEdit = defineOptionEdit;
  CommonArguments.instance = new CommonArguments;

  function defineOptionEdit(id, caption, edittype, editoption, comment) {
    return {id:id, caption:caption, edittype:edittype, editoption:editoption, comment:comment};
  }

  /* */
  function _throwWindowNotOpened() {
    throw createError('Window has not opened yet or already closed.', 'VwPropertyFunctions.js', 'initCommonArguments.getWindow');
  }

  /* */
  function _alert(p) {
    this.getWindow().alert(p);
  }
  
  /* */
  function _confirm(p) {
    return this.getWindow().confirm(p);
  }
  
  /* 項目の文字列を保存用のescapeされた文字列に変換 */
  function _toSaveValue(_text) {
    var text = _separateFirst(_text, ': ', ' ', 1);
    text = _separateFirst(text, '::', ' ', 1);
    if(text.charAt(text.length - 1) == ':') {
      text = text + ' ';
    }
    return text;
  }

  /* escapeされた 「項目」の文字列を表示用の「項目」の文字列に変換*/  
  function _toDispValue(_text) {
    var text = _replaceFirst(_text, ': ', ':');
    return text;
  }

  /* escape用 ':' → ': ' */
  function _separateFirst(str, kw, sep, seppos){
    var pos = str.indexOf(kw);
    if(pos > -1) {
      return str.substring(0,pos + seppos) + sep + _separateFirst(str.substring(pos + seppos), kw, sep, seppos);
    }
    return str;
  }

  /* unescape用 ': ' → ':' */
  function _replaceFirst(str, bef, aft){
    var pos = str.indexOf(bef);
    if(pos > -1) {
      return str.substring(0,pos) + aft + _replaceFirst(str.substring(pos + bef.length), bef, aft);
    }
    return str;
  } 


}
initCommonArguments();

/**
 * “○○の編集”文字列作成
 */
function getLiteralEditProperty(_propertyid) {
  return getMessage('S0020', new Array(getLiteral('property.' + _propertyid)));
}

/**
 * インクルードするJavaScriptファイルの編集を行う
 * @param  :
 * @return :
 */
function doEditJsfile(){
  JsFileArguments.prototype = CommonArguments.instance;

  var propertyId = 'jsfilename';

  // 更新対象リスト
  //var updateList = getUpdateList(propertyId);
  var targetObjectId = m_selection.front;
  
  //パラメータ作成
  var arg = new JsFileArguments();
  
  openJsfileDialog(arg);

  /** パラメータ */
  function JsFileArguments() {
    this.doOK = doOK;
    this.doCancel      = function () {};
    this.windowTitle  = getLiteral('dialog.jsfileedit.title');
    this.listTitle    = getLiteral('dialog.jsfileedit.listtitle');
    this.listWidth = 300;
    this.optionItems = getDataSet(m_selection.front).getProperty(propertyId);
    this.optionEdits    = [
      this.defineOptionEdit('filename',  getLiteral('dialog.jsfileedit.jsfilepath'),  'text', {'size':50})
    ];
    this.createOption = createOption;
    this.createEditValues = createEditValues;

    /*
     * 最初と、追加ボタン,置換ボタンを押したときに呼ばれる
     * @param obj 入力された内容オブジェクト {変数名:<値> , ... }
     * @param mode 最初'initialize' 追加のとき'add' 置換のとき'replace'
     * @existingList 実行後に追加されたもの以外に存在するもの [{value:<value>,text:<text>}, ...]
     * @return リストに追加するオプション {text:<リストに表示するテキスト>, value:<その値>}
     */
    function createOption(obj, mode, existingList) {

      //名前が空のときエラーとする
      if(obj.filename == '') {
        this.alert(getMessage('A0030'));
        return null;
      }

      //同一の名前があればエラーとする
      for(var listIndex = 0; listIndex < existingList.length; listIndex++){
        var opt = existingList[listIndex].value;
        if(opt == obj.filename){
          this.alert(getMessage('A0031'));
          return null;
        }
      }

      return {text:obj.filename, value:obj.filename};
    }
    
    /*
     * リスト内の１つが選択されたときに呼ばれる
     * @param opt 選ばれた値
     * @return 入力する場所に表示する内容オブジェクト {変数名:<値> , ... }
     */
    function createEditValues(opt) {
      return {filename:opt};
    }
    
    function doOK() {
      // 存在チェック
      if(!isPropertyOwnerExists(targetObjectId)) {
        return;
      }

      var rtn = {};
      rtn.optionItems = [];
      var list = this.getListElement();
      for(var i=0; i < list.length; i++){
        rtn.optionItems[rtn.optionItems.length] = list.options[i].value;
      }

      var orgValue = getDataSet(targetObjectId).getProperty('jsfilename');
      var newValue = createOptionItemsValue(rtn.optionItems);

      var cmd =  new UndoPropertyEdit(targetObjectId,'', 'jsfilename', orgValue, newValue);

      var cmdSet = new UndoableCommandSet(getLiteralEditProperty('jsfile'));
      var cmdSelUndo = new CommandSelect(true,true,'');
      var cmdSelRedo = new CommandSelect(false,true,'');
      cmdSet.add(cmdSelUndo);
      cmdSet.add(cmd);
      cmdSet.add(cmdSelRedo);

      m_undoManager.execute(cmdSet);
      getDataSet(targetObjectId).setProperty('jsfilename', newValue);
    }
  }
}

/**
 * selectの選択肢編集ダイアログを呼び出す
 * @param  :
 * @return :
 */
function doEditOption(_type){
  CellArguments.prototype = CommonArguments.instance;

  // プロパティID
  var propertyId = 'option';
  
  // 更新対象リスト
  var updateList = getUpdateList(propertyId);
  
  // アクセスキーを編集するか
  var _useAccessKeys = false;
  if(pref.edit.radio.acckey) {
    var _usingAccessKeys = false;
    var _disuseAccessKeys = false;
    for(var updateListIndex = 0; updateListIndex < updateList.length; updateListIndex++) {
      var dataset = getDataSet(updateList[updateListIndex].elementId);
      var type = dataset.getProperty('type');
      if(type == TYPE.RADIO) {
        _useAccessKeys = true;
        /*
        if(_type != TYPE.RADIO) {
          var acckey = dataset.getProperty('acckey');
          for(var acckeyIndex = 0; acckeyIndex < acckey.length; acckeyIndex++) {
            if(acckey[acckeyIndex]) {
              _usingAccessKeys = true;
              break;
            }
          }
        }
        */
      } else if(type == TYPE.COMBO || type == TYPE.LIST) {
        _disuseAccessKeys = true;
      }
    }
  }

  //パラメータ作成
  var arg = new CellArguments(_useAccessKeys, _disuseAccessKeys);
  
  openOptionDialog(arg);

  /** パラメータ */
  function CellArguments(_useAccessKeys, _disuseAccessKeys) {
    this.useAccessKeys = _useAccessKeys;
    this.doOK = doOK;
    this.doCancel      = function () {};
    this.windowTitle  = getLiteral('dialog.listitemedit.title');
    this.listTitle    = getLiteral('dialog.listitemedit.listtitle');
    this.listWidth = 300;
    this.optionItems = getDataSet(m_selection.front).getProperty(propertyId);
    this.optionEdits    = [
      this.defineOptionEdit('text',  getLiteral('dialog.listitemedit.text'),  'text', {'size':50}),
      this.defineOptionEdit('value', getLiteral('dialog.listitemedit.value'), 'text', {'size':50})
    ];

    if(this.useAccessKeys) {
      if(_disuseAccessKeys) {
        var accesskeyComment = getMessage('A0044');
      }
      this.optionEdits[this.optionEdits.length] = 
        this.defineOptionEdit('accesskey', 
                              getLiteral('property.accesskey'), 
                              'combo', 
                              pref.valueoption.accesskey,
                              accesskeyComment);
      var accKey = getDataSet(m_selection.front).getProperty('acckey');
      for(var i = 0; i < accKey.length; i++) {
        if(this.optionItems[i]) {
          if(accKey[i]) {
            this.optionItems[i] += '/' + accKey[i];
          } else {
            this.optionItems[i] += '//';
          }
        }
      }
    }
    
    this.createOption = createOption;
    this.createEditValues = createEditValues;

    function createOption(obj, mode, existingList) {
      if(obj.text.indexOf('<$') != -1 || obj.value.indexOf('<$') != -1) {
      } else {
        //同一の名前,同一の値がどちらか1つでもあればエラーとする

        for(var listIndex = 0; listIndex < existingList.length; listIndex++){
          var opt = existingList[listIndex].value;
          if(opt.indexOf('<$') != -1) {
            continue;
          }
          var pos = opt.indexOf('::');
          if(pos != -1) {
            var opttext = this.toDispValue(opt.substring(0, pos));
            var optvalue = opt.substring(pos + 2);
          } else {
            var opttext = opt;
            var optvalue = opt;
          }

          if(this.useAccessKeys) {
            var sep = separateAccessKey(optvalue);
            var optaccesskey = sep.accesskey;
            optvalue = sep.value;
            if(obj.accesskey) {
              if(optaccesskey == obj.accesskey){
                this.alert(getMessage('A0043'));
                return null;
              }
            }
          }
          if(optvalue == obj.value){
            this.alert(getMessage('A0042'));
            return null;
          }
          if(opttext == obj.text){
            if(!this.confirm(getMessage('A0041'))) {
              return null;
            }
          }
        }
      }

      var optiontext = obj.text + '::' + obj.value;
      var optionvalue = this.toSaveValue(obj.text) + '::' + obj.value;
      if(this.useAccessKeys) {
        if(obj.accesskey.length == 1) {
          optiontext += '(' + obj.accesskey + ')';
          optionvalue += '/' + obj.accesskey;
        } else {
          optionvalue += '//';
        }
      }
      return {text:optiontext, value:optionvalue};
    }

    function createEditValues(opt) {
      var pos = opt.indexOf('::');
      if(pos == -1) {
        return {text:opt, value:opt};
      }
      var text = this.toDispValue(opt.substring(0, pos));
      var value = opt.substring(pos + 2);

      if(this.useAccessKeys) {
        var rtn = separateAccessKey(value);
        rtn.text = text;
        return rtn;
      }

      return {text:text, value:value};
    }
    
    function separateAccessKey(value) {
      if(value.length >= 2 && value.charAt(value.length - 2) == '/') {
        var rtn = {};
        rtn.accesskey = value.charAt(value.length - 1);
        if(rtn.accesskey == '/') {
          rtn.accesskey = '';
        }
        rtn.value = value.substring(0, value.length - 2);
        return rtn;
      }
      return {accesskey:'', value:value};
    }
    
    function doOK() {
      var rtn = {};
      rtn.optionItems = [];
      var list = this.getListElement();
      if(this.useAccessKeys) {
        rtn.acckeyItems = [];
        for(var i=0; i < list.length; i++){
          var rtnacc = separateAccessKey(list.options[i].value);
          rtn.optionItems[rtn.optionItems.length] = rtnacc.value;
          rtn.acckeyItems[rtn.acckeyItems.length] = rtnacc.accesskey;
        }
      } else {
        for(var i=0; i < list.length; i++){
          rtn.optionItems[rtn.optionItems.length] = list.options[i].value;
        }
      }
      
      // コマンドセット
      var cmdSet = new UndoableCommandSet(getLiteralEditProperty(propertyId));
      var cmdSelUndo = new CommandSelect(true,true,'');
      var cmdSelRedo = new CommandSelect(false,true,'');
      cmdSet.add(cmdSelUndo);
      
      // 更新
      for(var i = 0; i < updateList.length; i++) {
        
        var elementId = updateList[i].elementId;

        // ないオブジェクトを飛ばす。関数内でメッセージを表示
        if(!isPropertyOwnerExists(elementId)) {
          continue;
        }
        
        cmdSelUndo.add(elementId);
        cmdSelRedo.add(elementId);

        var val = createOptionItemsValue(rtn.optionItems);
        updateValuePerObject(elementId, '', 'fld_' + propertyId, val, '', cmdSet);
        
        if(rtn.acckeyItems) {
          var type = getDataSet(elementId).getProperty('type');
          if(type == TYPE.RADIO) {
            var acc = createOptionItemsValue(rtn.acckeyItems);
            updateValuePerObject(elementId, '', 'fld_acckey', acc, '', cmdSet);
          }
        }
      }

      // Undo登録
      if(cmdSet && cmdSet.commands.length > 1) {
        cmdSet.add(cmdSelRedo);
        m_undoManager.execute(cmdSet);
      }
    }
  }
}

/**
 * APPLET,EMBED,OBJECTのパラメータ編集を行う
 * @param  :strProperty 文字型 プロパティ文字列
 * @return :
 */
function doEditParameter(propertyId, strLabel){
  ParameterArguments.prototype = CommonArguments.instance;

  // 更新対象リスト
  var updateList = getUpdateList(propertyId);
  
  if(strLabel) {
    var listTitle   = getLiteral(strLabel);
    var windowTitle = getLiteral('dialog.parameteredit.title_before') + listTitle 
                    + getLiteral('dialog.parameteredit.title_after');
  } else {
    var listTitle   = getLiteral('dialog.parameteredit.listtitle');
    var windowTitle = getLiteral('dialog.parameteredit.title');
  }

  //パラメータ作成
  var arg = new ParameterArguments();
  
  openParameterDialog(arg);
  
  /** パラメータ */
  function ParameterArguments() {
    this.doOK = doOK;
    this.doCancel      = function () {};
    this.windowTitle  = windowTitle;
    this.listTitle    = listTitle;
    this.listWidth = 300;
    this.optionItems = getDataSet(m_selection.front).getProperty(propertyId);
    this.optionEdits    = [
      this.defineOptionEdit('name',  getLiteral('dialog.parameteredit.name'),  'text', {'size':50}),
      this.defineOptionEdit('value', getLiteral('dialog.parameteredit.value'), 'text', {'size':50})
    ];
    this.createOption = createOption;
    this.createEditValues = createEditValues;

    function createOption(obj, mode, existingList) {

      //名前が空のときエラーとする
      if(obj.name == '') {
        this.alert(getMessage('A0050'));
        return null;
      }

      //同一の名前,同一の値がどちらか1つでもあればエラーとする
      for(var listIndex = 0; listIndex < existingList.length; listIndex++){
        var opt = existingList[listIndex].value;
        var pos = opt.indexOf('::');
        if(pos != -1) {
          var opttext = this.toDispValue(opt.substring(0, pos));
          var optvalue = opt.substring(pos + 2);
        } else {
          var opttext = opt;
          var optvalue = opt;
        }

        if(opttext == obj.name){
          this.alert(getMessage('A0051'));
          return null;
        }
      }

      var optiontext = obj.name + '::' + obj.value;
      var optionvalue = this.toSaveValue(obj.name) + '::' + obj.value;
      return {text:optiontext, value:optionvalue};
    }

    function createEditValues(opt) {
      var pos = opt.indexOf('::');
      if(pos == -1) {
        return {name:opt, value:opt};
      }
      var name = this.toDispValue(opt.substring(0, pos));
      var value = opt.substring(pos + 2);

      return {name:name, value:value};
    }
    
    function doOK() {
      var rtn = {};
      rtn.optionItems = [];
      var list = this.getListElement();
      for(var i=0; i < list.length; i++){
        rtn.optionItems[rtn.optionItems.length] = list.options[i].value;
      }
      
      // コマンドセット
      var cmdSet = new UndoableCommandSet(getLiteralEditProperty(propertyId));
      var cmdSelUndo = new CommandSelect(true,true,'');
      var cmdSelRedo = new CommandSelect(false,true,'');
      cmdSet.add(cmdSelUndo);
      //cmdSet.add(new CommandSelect(true));
      
      // 更新
      for(var i = 0; i < updateList.length; i++) {
        
        var elementId = updateList[i].elementId;
        
        // ないオブジェクトを飛ばす。関数内でメッセージを表示
        if(!isPropertyOwnerExists(elementId)) {
          continue;
        }
        
        cmdSelUndo.add(elementId);
        cmdSelRedo.add(elementId);
        
        var val = createOptionItemsValue(rtn.optionItems);
        updateValuePerObject(elementId, '', 'fld_' + propertyId, val, '', cmdSet)

      }

      // Undo登録
      if(cmdSet && cmdSet.commands.length > 1) {
        cmdSet.add(cmdSelRedo);
        m_undoManager.execute(cmdSet);
      }
    }
  }
}

/**
 * メタデータの編集を行う
 * @param  :strProperty 文字型 プロパティ文字列
 * @return :
 */
function doEditMeta(){
  MetaArguments.prototype = CommonArguments.instance;

  var propertyId = 'meta';

  // 更新対象リスト
  var updateList = getUpdateList(propertyId);
  
  //パラメータ作成
  var arg = new MetaArguments();
  
  openMetaDialog(arg);
  
  /** パラメータ */
  function MetaArguments() {
    this.doOK = doOK;
    this.doCancel      = function () {};
    this.windowTitle  = getLiteral('dialog.metaedit.title');
    this.listTitle    = getLiteral('dialog.metaedit.listtitle');
    this.listWidth = 300;
    this.optionItems = getDataSet(m_selection.front).getProperty(propertyId);
    this.optionEdits    = [
      this.defineOptionEdit('attrname',     getLiteral('dialog.metaedit.attrname'), 'radio', {'http-equiv':'http-equiv', 'name':'name'}),
      this.defineOptionEdit('attrvalue',    getLiteral('dialog.metaedit.attrval'),  'text', {'size':50}),
      this.defineOptionEdit('contentvalue', getLiteral('dialog.metaedit.value'),    'text', {'size':50})
    ];
    this.createOption = createOption;
    this.createEditValues = createEditValues;

    function createOption(obj, mode, existingList) {
      var optiontext = '(' + obj.attrname + ')' + obj.attrvalue + '::' + obj.contentvalue;
      var optionvalue = '(' + obj.attrname + ')' + this.toSaveValue(obj.attrvalue) + '::' + obj.contentvalue;
      return {text:optiontext, value:optionvalue};
    }

    function createEditValues(opt) {
      var pos = opt.indexOf('::');
      if(pos == -1) {
        return {attrname:'http-equiv', attrvalue:opt, contentvalue:opt};
      }
      var attribute = opt.substring(0, pos);
      var contentvalue = opt.substring(pos + 2);
      var pos1 = attribute.indexOf('(');
      var pos2 = attribute.indexOf(')');
      if(pos1 != 0 || pos2 == -1) {
        return {attrname:'http-equiv', attrvalue:attribute, contentvalue:contentvalue};
      }
      var attrname = attribute.substring(1, pos2);
      var attrvalue = this.toDispValue(attribute.substring(pos2 + 1));
      return {attrname:attrname, attrvalue:attrvalue, contentvalue:contentvalue};
    }
    
    function doOK() {
      var rtn = {};
      rtn.optionItems = [];
      var list = this.getListElement();
      for(var i=0; i < list.length; i++){
        rtn.optionItems[rtn.optionItems.length] = list.options[i].value;
      }
      
      // コマンドセット
      var cmdSet = new UndoableCommandSet(getLiteralEditProperty(propertyId));
      var cmdSelUndo = new CommandSelect(true,true,'');
      var cmdSelRedo = new CommandSelect(false,true,'');
      cmdSet.add(cmdSelUndo);
      
      // 更新
      for(var i = 0; i < updateList.length; i++) {
        
        var elementId = updateList[i].elementId;
        
        // ないオブジェクトを飛ばす。関数内でメッセージを表示
        if(!isPropertyOwnerExists(elementId)) {
          continue;
        }
        
        cmdSelUndo.add(elementId);
        cmdSelRedo.add(elementId);
        
        var val = createOptionItemsValue(rtn.optionItems);
        updateValuePerObject(elementId, '', 'fld_' + propertyId, val, '', cmdSet)

      }

      // Undo登録
      if(cmdSet && cmdSet.commands.length > 1) {
        cmdSet.add(cmdSelRedo);
        m_undoManager.execute(cmdSet);
      }
    }
  }
}

/**
 * 各種イベントの編集を行う
 * @param  :strType 文字型 イベント名称文字列
 * @param  :isLink boolean型 ハイパーリンクの設定時true
 * @return :
 */
function doEditEvent(propertyId, isLink){
  // プロパティID
  //var propertyId = 'option';
  
  // 更新対象リスト
  var updateList = getUpdateList(propertyId);

  //パラメータ作成
  var arg = new Object();
  //arg.propertyName  = propertyId;
  arg.isLink  = isLink;
  arg.sourceCode  = getDataSet(m_selection.front).getProperty(propertyId);
  arg.jsfilenames = new Array();
  var refVal = getDataSet(ELEMENTID_FIRSTFORM).getProperty('jsfilename');
  for(var i in refVal){
    arg.jsfilenames[i] = refVal[i];
  }
  // 2003.05.29 読み込んだ項目定義を渡す(未読み込み時は空の配列)
  if(!m_itemDefinitionObject.empty){
    arg.itemDefine  = m_itemDefinitionObject.itemDefineList;
    arg.itemDict = m_itemDefinitionObject.itemDefineDict;
  } else {
    arg.itemDefine = [];
  }
  arg.returnOk = onReturnOk;

  openEventDialog(arg);

  function onReturnOk(rtn){
    if(rtn.isOk){

      // コマンドセット
      var cmdSet = new UndoableCommandSet(getLiteralEditProperty(propertyId));
      var cmdSelUndo = new CommandSelect(true,true,'');
      var cmdSelRedo = new CommandSelect(false,true,'');
      cmdSet.add(cmdSelUndo);
      //cmdSet.add(new CommandSelect(true));
      
      // JS用データセットオブジェクト
      var datasetJs = getDataSet(ELEMENTID_FIRSTFORM);

      // 更新前の値の参照
      var oldValJs = datasetJs.getProperty('jsfilename');

      // Undo用に実行前の値作成
      var orgValue = createOptionItemsValue(oldValJs);

      // Redo用に実行後の値作成
      var newValue = createOptionItemsValue(rtn.jsfilenames);

      var cmdJs =  new UndoPropertyEdit(ELEMENTID_FIRSTFORM, '', 'jsfilename', orgValue, newValue);

      cmdSet.add(cmdJs);

      //データをセット
      datasetJs.setProperty('jsfilename', rtn.jsfilenames);

      // 更新
      for(var i = 0; i < updateList.length; i++) {
        
        var elementId = updateList[i].elementId;
        
        // ないオブジェクトを飛ばす。関数内でメッセージを表示
        if(!isPropertyOwnerExists(elementId)) {
          continue;
        }
        
        updateValuePerObject(elementId, '', 'fld_' + propertyId, rtn.sourceCode, '', cmdSet)

        cmdSelUndo.add(elementId);
        cmdSelRedo.add(elementId);

        //プロパティテーブルにセット
        if(elementId == m_selection.current.front) {
          getPropertyEditElement(propertyId).value = rtn.sourceCode;
        }
      }

      // Undo登録
      if(cmdSet && cmdSet.commands.length > 1) {
        cmdSet.add(cmdSelRedo);
        m_undoManager.execute(cmdSet);
      }
    }
  }
}

var m_imageListListmode = 'preview';
/**
 * ファイル名、URLの編集を行う
 * @param  :propertyId  文字型 イベント名称日本語文字列
            strLabel 文字型 イベント名称日本語文字列
 * @return :
 */
function doEditImageName(propertyId, strLabel, elementId){
  doEditLongString(propertyId, strLabel, elementId, 'IMAGELIST');
}

/**
 * ファイル名、URLの編集を行う
 * @param  :propertyId  文字型 イベント名称日本語文字列
            strLabel 文字型 イベント名称日本語文字列
 * @return :
 */
function doEditLongString(propertyId, strLabel, elementId, _dialog, imeMode){
  // プロパティID
  //var propertyId = 'option';
  
  // 更新対象リスト
  var updateList = getUpdateList(propertyId);

  //パラメータ作成
  var arg = new Object();
  arg.propertyValue = getPropertyEditElement(propertyId).value;
  arg.propertyName  = strLabel;
  arg.imeMode  = imeMode;
  arg.listmode = m_imageListListmode;
  if(elementId) {
    arg.elementId = elementId;
  } else {
    arg.elementId = m_selection.front;
  }
  arg.returnOk = onReturnOk;

  if(_dialog == 'IMAGELIST') {
    openImageListDialog(arg); //2003.09.29 保留
    //openLongStringDialog(arg);
  } else {
    openLongStringDialog(arg);
  }

  function onReturnOk(rtn){
    if(rtn.isOk){
      
      if(_dialog == 'IMAGELIST') {
        //if(rtn.propertyValue) {
        //  addImageFileBuffer(rtn.propertyValue);
        //}
        m_imageListListmode = rtn.listmode;
      }

      // コマンドセット
      var cmdSet = new UndoableCommandSet(getMessage('S0020', new Array(arg.propertyName)));
      var cmdSelUndo = new CommandSelect(true,true,'');
      var cmdSelRedo = new CommandSelect(false,true,'');
      cmdSet.add(cmdSelUndo);
      //cmdSet.add(new CommandSelect(true));
      
      // 更新
      for(var i = 0; i < updateList.length; i++) {
        
        var elementId = updateList[i].elementId;
        var cellElementId = updateList[i].cellElementId;
        var datasetId = updateList[i].datasetId;
        
        // ないオブジェクトを飛ばす。関数内でメッセージを表示
        if(!isPropertyOwnerExists(datasetId)) {
          continue;
        }
        
        updateValuePerObject(elementId, cellElementId, 'fld_' + updateList[i].propertyId, rtn.propertyValue, '', cmdSet);

        cmdSelUndo.add(elementId);
        cmdSelRedo.add(elementId);

        //プロパティテーブルにセット
        if(datasetId == m_selection.current.front || datasetId == m_selection.current.cell) {
          getPropertyEditElement(propertyId).value = rtn.propertyValue;
        }
      }

      // Undo登録
      if(cmdSet && cmdSet.commands.length > 1) {
        //cmdSet.add(new CommandSelect(false));
        cmdSet.add(cmdSelRedo);
        m_undoManager.execute(cmdSet);
      }
    }
  }
}

/**
 * 色選択ダイアログオープン
 * @param  :strTypeId 文字型 色入力のTYPEID
 * @return :
 */
function doEditColor(propertyId){
  // プロパティID
  //var propertyId = 'option';
  
  // 更新対象リスト
  var updateList = getUpdateList(propertyId);

  //ダイアログへのパラメータ作成
  var arg = new Object();
  arg.userColors = m_userColors;
  try{
    var nowColor = getDocumentElementById('fld_' + propertyId + '_span').style.backgroundColor;
  }catch(e){
    var nowColor = '';
  }
  if(!nowColor) nowColor = '';
  //16進数に変換
  if(nowColor != ''){
    nowColor = getHexColor(nowColor);
  }
  arg.colorValue = nowColor;
  arg.returnOk = onReturnOk;

  arg.targetObjectId = m_selection.front;
  arg.targetTdObjectId = m_selection.cell;

  openColorDialog(arg);
  
  function onReturnOk(rtn){

    //戻り値による処理
    if(rtn && rtn.isOk){
      //m_userColorsの初期化
      for(var i=0; i<m_userColors.length; i++){
        m_userColors[i] = '';
      }

      //作成した色をセット
      for(var i=0; i<rtn.userColors.length; i++){
        m_userColors[i] = rtn.userColors[i]
      }

      // コマンドセット
      var cmdSet = new UndoableCommandSet(getMessage('S0020', new Array(arg.propertyName)));
      var cmdSelUndo = new CommandSelect(true,true,'');
      var cmdSelRedo = new CommandSelect(false,true,'');
      cmdSet.add(cmdSelUndo);
      
      // 更新
      for(var i = 0; i < updateList.length; i++) {
        
        var elementId = updateList[i].elementId;
        var cellElementId = updateList[i].cellElementId;
        var datasetId = updateList[i].datasetId;
        
        // ないオブジェクトを飛ばす。関数内でメッセージを表示
        if(!isPropertyOwnerExists(datasetId)) {
          continue;
        }

        updateValuePerObject(elementId, cellElementId, 'fld_' + updateList[i].propertyId, rtn.colorValue, '', cmdSet);

        cmdSelUndo.add(elementId);
        cmdSelRedo.add(elementId);

      }

      // Undo登録
      if(cmdSet && cmdSet.commands.length > 1) {
        cmdSet.add(cmdSelRedo);
        m_undoManager.execute(cmdSet);
      }

      //log.debug('updating property area. [VwPropertyFunction.js/doEditColor.onReturnOk]');
      m_selection.updatePropertyArea();
    }
  }
}

/**
 * 色プロパティをチェックし、16進数で返す
 * @param  :strColor 文字列 色プロパティ
 * @return :
 */
function getHexColor(strColor){
  //16進の場合は加工しないで戻す
  if(strColor.match(/\#[0-f][0-f][0-f][0-f][0-f][0-f]/i) == strColor) return strColor.toLowerCase();

  var val = m_colorNames[strColor.toLowerCase()];
  if(val) {  
    return val;
  } else {
    return strColor;
  }
}

/**
 * プロパティテーブルの値及びデータ保持オブジェクトの値設定
 * @param  :strTypeId  文字型 設定するプロパティー設定INPUTのID
 *          colorValue        設定する値
 * @return :
 */
function onChangeColorProperty(strTypeId, colorValue, strId, cellid){
  log.debug('onChangeColorProperty:enter (strTypeId:'+strTypeId + ')'); //@@

  //プロパティテーブルにセット
  if(!setElementStyleBackgroundColor(getDocumentElementById(strTypeId + '_span'), colorValue)) {
    return;
  }
    
  changeProperty(strTypeId, colorValue, strId, cellid);
}

/**
 * フォーカスを得ているプロパティ設定項目のIDを保持
 * param  :strId 文字型 プロパティ項目のID
 * return :
 */
function onFocusProperty(strId, checkId){
  if(!strId) return;
  m_focusedPropId = strId;
  var element = getDocumentElementById(strId);
  m_focusedPropValue = element.value;

  element.propertyId = strId.substring(4);
  if(pref.onkeypress[element.propertyId]) {
    element.additionalOnKeyPress = pref.onkeypress[element.propertyId];
  } else if(checkId){
    //log.debug('checkId:' + checkId);
    element.additionalOnKeyPress = pref.onkeypress[checkId];
  }
  
  setOnBlur(element);
}

/**
 * フォーカスを得ているプロパティ設定項目のIDを保持(色入力項目)
 * param  :strId 文字型 プロパティ項目のID
 * return :
 */
function onFocusColorProperty(strId){
  m_focusedPropId = strId;
  var element = getDocumentElementById(strId);
  m_focusedPropValue = element.value;
  element.onkeyup = onKeyUpEnterColorProperty;
  element.isColorProperty = true;
  setOnBlur(element);
}

// 入力中の属性値のonFocus時の値
m_elementInitialValue = '';

/**
 * onChangeが発生しない場合のためのonBlur
 */
function setOnBlur(element) {
  if(element.isOnBlurSet) return;
  element.isOnBlurSet = true;
  element.onblur = onBlurOnce;
  m_elementInitialValue = element.value;
}

/**
 * onChangeが発生しなかった場合の処理
 */
function onBlurOnce(e) {
  if(!m_browserType.isIE){
    var element = e.target;
  }else{
    var element = event.srcElement;
  }
  element.isOnBlurSet = false;
  element.onblur = onBlurNone;

  if(m_focusedPropId != element.id) return;

  // onFocus時とonBlur時で値が違っていればonChangeが処理をしてくれる
  if(m_elementInitialValue != element.value) return;
  
  // 属性値欄の値と現在の値は同じなので更新する必要なし
  if(element.value == m_focusedPropValue) return;
  
  // 更新を実行
  if(element.isColorProperty) {
    onChangeColorProperty(element.id, element.value, m_selection.front, m_selection.cell);
  } else {
    doChangeProperty(element.id, element.value, m_selection.front, m_selection.cell, 'onBlur');
  }

  element.isOnBlurSet = false;
  element.onblur = onBlurNone;
}

/**
 * フォーカスを失った後用のダミー
 * onBlurでの値更新処理は不要なのでこれを設定しておく
 */
function onBlurNone() {
}

/**
 * プロパティ入力個所でのENTERキー押下でプロパティ更新(色設定プロパティ)
 * @param  :e オブジェクト エラーオブジェクト
 * @return :
 */
function onKeyUpEnterColorProperty(e){
  if(!m_browserType.isIE){
    var numKeyCode = e.keyCode;
    var strId      = e.target.id;
  }else{
    var numKeyCode = event.keyCode
    var strId      = event.srcElement.id;
  }

  if(numKeyCode == KEYCODE.ENTER){
    onChangeColorProperty(strId, getDocumentElementById(strId).value);
  }

}

/**
 *
 */
function getPropertyField(propertyId, elementId) {
  if(elementId) {
    if(m_selection.current.front != elementId) {
      return null;
    }
  }
  return getPropertyEditElement(propertyId);
}

/**
 *
 */
function setPropertyField(propertyId, value, elementId) {
  var ele = getPropertyField(propertyId, elementId);
  if(ele) {
    ele.value = value;
  }
}

/**
 *
 */
function checkPropertyField(propertyId, value, elementId) {
  var ele = getPropertyField(propertyId, elementId);
  if(ele) {
    ele.checked = value;
  }
}

/**
 * カスタマイズ時、設定された値がoriginalvalueと異なる場合、カスタマイズにチェックを入れる
 * @param  :objDS    オブジェクト参照 データセットオブジェクト
 *          objValue 文字型           表示のoriginalvalue
 * @return :
 */
function customizedVisibilityChecker(objDS, objValue, elementId){
  if(m_monitorEditStatus == 2 && objDS.getCustomizableItems().visibility){
    var tmpOrgValue = objDS.getCustomProperty('visibility', 'originalvalue');
    // @visible if(tmpOrgValue == '') tmpOrgValue = 'visible';
    if(objValue != tmpOrgValue){
      checkPropertyField('customize-visibility', true, elementId);
      objDS.setProperty('customize-visibility', 'enabled');
    }else{
      checkPropertyField('customize-visibility', false, elementId);
      objDS.setProperty('customize-visibility', 'disabled');
    }
  }
}

/**
 * カスタマイズ時、設定された値がoriginalvalueと異なる場合、カスタマイズにチェックを入れる
 * @param  :objDS   オブジェクト DataSet
 *          topVal  文字型       topの設定値
 *          leftVal 文字列       leftの設定値
 * @return :
 */
function customizedMobilityChecker(objDS, topVal, leftVal, elementId){
  if(m_monitorEditStatus == 2 && objDS.getCustomizableItems().mobility){
    if(topVal != objDS.getCustomProperty('top', 'originalvalue') || leftVal != objDS.getCustomProperty('left', 'originalvalue')){
      checkPropertyField('customize-mobility', true, elementId);
      objDS.setProperty('customize-mobility', 'enabled');
    }else{
      checkPropertyField('customize-mobility', false, elementId);
      objDS.setProperty('customize-mobility', 'disabled');
    }
  }
}

/**
 * カスタマイズ時、設定された値がoriginalvalueと異なる場合、カスタマイズにチェックを入れる
 * @param  :objDS       オブジェクト DataSet
 *          objValue    文字型       初期値の設定値
 *          strPropName 文字型       初期値設定のプロパティ名称(value,selvalue)
 * @return :
 */
function customizedDefaultValueChecker(objDS, objValue, strPropName, elementId){
  if(m_monitorEditStatus == 2 && objDS.getCustomizableItems().defaultvalue){
    if(objValue != objDS.getCustomProperty(strPropName, 'originalvalue')){
      //getDocumentElementById('fld_customize-defaultvalue').checked = true;
      checkPropertyField('customize-defaultvalue', true, elementId);
      objDS.setProperty('customize-defaultvalue', 'enabled');
    }else{
      //getDocumentElementById('fld_customize-defaultvalue').checked = false;
      checkPropertyField('customize-defaultvalue', false, elementId);
      objDS.setProperty('customize-defaultvalue', 'disabled');
    }
  }
}

/**
 * カスタマイズ時、設定された値がoriginalvalueと異なる場合、カスタマイズにチェックを入れる
 * @param  :objDS    オブジェクト DataSet
 *          objValue 文字型       列数の設定値
 * @return :
 */
function customizedMaxlinesChecker(objDS, objValue, elementId){
  if(m_monitorEditStatus == 2 && objDS.getCustomizableItems().maxlines){
    if(objValue != objDS.getCustomProperty('maxlines', 'originalvalue')){
      //getDocumentElementById('fld_customize-maxlines').checked = true;
      checkPropertyField('customize-maxlines', true, elementId);
      objDS.setProperty('customize-maxlines', 'enabled');
    }else{
      //getDocumentElementById('fld_customize-maxlines').checked = false;
      checkPropertyField('customize-maxlines', false, elementId);
      objDS.setProperty('customize-maxlines', 'disabled');
    }
  }
}

/** */
var m_imageFileBuffer = new Object();

/**
 * イメージのバッファ
 * @param  :imageFilename パス
 * @return :Image
 */
function addImageFileBuffer(imageFilename){
  if(m_imageFileBuffer[imageFilename]) {
    return m_imageFileBuffer[imageFilename];
  }
  var image = new Image();
  image.src = imageFilename;
  m_imageFileBuffer[imageFilename] = image;
  return image;
}

/**
 * インクルードファイル編集ダイアログを開く
 * @param  :arg ダイアログに渡すオブジェクト
 * @return :開いたwindowオブジェクト
 */
function openJsfileDialog(arg){
  return openDialog(DIALOG_LISTITEM, '', arg, '500', '316');
}

/**
 * メタ情報編集ダイアログを開く
 * @param  :arg ダイアログに渡すオブジェクト
 * @return :開いたwindowオブジェクト
 */
function openMetaDialog(arg){
  return openDialog(DIALOG_LISTITEM, '', arg, '500', '364');
}

/**
 * パラメータ編集ダイアログを開く
 * @param  :arg ダイアログに渡すオブジェクト
 * @return :開いたwindowオブジェクト
 */
function openParameterDialog(arg){
  return openDialog(DIALOG_LISTITEM, '', arg, '500', '340');
}

/**
 * オプション編集ダイアログを開く
 * @param  :arg ダイアログに渡すオブジェクト
 * @return :開いたwindowオブジェクト
 */
function openOptionDialog(arg){
  return openDialog(DIALOG_LISTITEM, '', arg, '500', '340');
}

/**
 * 色編集ダイアログを開く
 * @param  :arg ダイアログに渡すオブジェクト
 * @return :開いたwindowオブジェクト
 */
function openColorDialog(arg){
  return openDialog(DIALOG_COLOR, '', arg, '420', '470');
}

/**
 * 項目タイプ変更ダイアログを開く
 * @param  :arg ダイアログに渡すオブジェクト
 * @return :開いたwindowオブジェクト
 */
function openTypeChangeDialog(arg){
  return openDialog(DIALOG_TYPECHANGE, DIALOGNAME_TYPECHANGE, arg, '550', '144');
}

/**
 * イベント編集ダイアログを開く
 * @param  :arg ダイアログに渡すオブジェクト
 * @return :開いたwindowオブジェクト
 */
function openEventDialog(arg){
  var strUrl = DIALOG_EVENT;
  if(m_threadId != ''){
    strUrl = DIALOG_EVENT + '&THREADID=' + m_threadId;
  }
  return openDialog(strUrl, '', arg, '600', '420');
}

/**
 * ファイル名/URL編集ダイアログを開く
 * @param  :arg ダイアログに渡すオブジェクト
 * @return :開いたwindowオブジェクト
 */
function openLongStringDialog(arg){
  return openDialog(DIALOG_LONGPROPERTY, '', arg, '650', '144');
}

/**
 * バージョンダイアログを開く
 * @param  :arg ダイアログに渡すオブジェクト
 * @return :開いたwindowオブジェクト
 */
function openVersionDialog(arg){
  return openDialog(DIALOG_VERSION, DIALOGNAME_VERSION, arg, '550', '200');
}

/**
 * 画像ファイル一覧ダイアログを開く
 * @param  :arg ダイアログに渡すオブジェクト
 * @return :開いたwindowオブジェクト
 */
function openImageListDialog(arg){
  var url = 'appcontroller?JSPID=' + JSPID_IMAGELIST;
  url += '&PROCESSID=';
  url += '&PROCESSMODE=1';
  url += '&DISPLANGID=' + DISPLANGID;
  url += '&THREADID=' + getSessionData('THREADID');
  url += '&LISTMODE=' + m_imageListListmode;
  return openDialog(url, DIALOGNAME_IMAGELIST, arg, {width:600,height:500,scrollbars:'yes',resizable:'yes'});
}

/**
 * フレームテンプレートを開く
 * @param  :arg ダイアログに渡すオブジェクト
 * @return :開いたwindowオブジェクト
 */
function openFrameTemplateDialog(arg){
  return openDialog(DIALOG_FRAMETEMPLATE, DIALOGNAME_FRAMETEMPLATE, arg, 600, 500);
}

/**
 * try&catchでハンドリングしたエラーの情報をステータスバーに書き込む
 * @param  :e         オブジェクト エラーオブジェクト
 *          arrString 配列         エラー時に作成されるのメッセージ群
 * @return :
 */
function printHandlingError(e, arrString){
  var strMessage = '';
  for(var i=0; i<arrString.length; i++){
    strMessage += arrString[i] + '/';
  }

  alert(strMessage);
  if(e) {
    throw(e);
  }
}


/**
 * タイプ日本語名取得用オブジェクト実装クラス
 * @param  :
 * @return :文字型 タイプ日本語名
 */
var m_namesForTypeNames = new Object();
function TypeNames() {

  TypeNames.prototype.getTypeName = function(_typeId) {
    var typeid = _typeId.toLowerCase();
    if(!m_namesForTypeNames[typeid]) {
      m_namesForTypeNames[typeid] = getLiteral('pageitemtype.' + typeid);
    }
    return m_namesForTypeNames[typeid];
  }
}

/**
 * 属性設定時の存在チェック
 * @param  :id 画面項目ID
 * @return :
 */
function isPropertyOwnerExists(id){
  
  for(var i=0; i < m_addElementArray.length; i++) {
    if(m_addElementArray[i] == id) {
      return true;
    }
  }
  alert(getMessage('A0003', new Array(id)));
  return false;
}

