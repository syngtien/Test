function doLogin() {
  if (getFieldById("SAVEPASS")) {
    saveCookie(getFieldById("SAVEPASS").value, getFieldValue("COMPANYID"), getFieldValue("USERID"), getFieldValue("PASSWORD"), getFieldValue("NARROWBAND"));
  }
  doSubmitProcess(document.forms[0], 'SysLoginP', 'SysFrame', '', '', '', 'SysLogin', '', 'MESSAGE=');
}
function saveCookie(savePass, companyId, userId, password, narrowband) {
  if (savePass == "1") {
    putCookie("COMPANYID", companyId);
    putCookie("USERID", userId);
    putCookie("PASSWORD", password);
    putCookie("NARROWBAND", narrowband);
  } else {
    removeCookie("COMPANYID");
    removeCookie("USERID");
    removeCookie("PASSWORD");
    removeCookie("NARROWBAND");
  }
}
function restoreCookie() {
  var key = "COMPANYID";
  if (getFieldById(key)) {
    if (getCookie(key).length > 0) {
      getFieldById(key).value=getCookie(key);
    }
  }
  key = "USERID";
  if (getFieldById(key)) {
    if (getCookie(key).length > 0) {
      getFieldById(key).value=getCookie(key);
    }
  }
  key = "PASSWORD";
  if (getFieldById(key)) {
    if (getCookie(key).length > 0) {
      getFieldById(key).value=getCookie(key);
      if (getFieldById("SAVEPASS_check")) {
        getFieldById("SAVEPASS_check").checked = true;
      }
      if (getFieldById("SAVEPASS")) {
        getFieldById("SAVEPASS").value = "1";
      }
    }

    if (getCookie(key).length ==0) {
      if (getCookie("USERID").length > 0) {
        getFieldById(key).value=getCookie(key);
        if (getFieldById("SAVEPASS_check")) {
          getFieldById("SAVEPASS_check").checked = true;
        }
        if (getFieldById("SAVEPASS")) {
          getFieldById("SAVEPASS").value = "1";
        }
      }
    }
  }

  key = "NARROWBAND";
  if (getFieldById(key)) {
    if (getCookie(key).length > 0) {
      narrowband = getCookie(key);
      getFieldById(key).value = narrowband;
      if (getFieldById("NARROWBAND_check") && (narrowband == "1")) {
        getFieldById("NARROWBAND_check").checked = true;
      }
      if (getFieldById("NARROWBAND")) {
        getFieldById("NARROWBAND").value = narrowband;
      }
    }
  }
}
