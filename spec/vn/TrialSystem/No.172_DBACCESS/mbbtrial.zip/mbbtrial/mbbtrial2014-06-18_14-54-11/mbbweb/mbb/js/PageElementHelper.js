// XMLHTTPオブジェクトを生成して返す
function _createXMLHttp() {
  var xmlhttp;
  try {
    xmlhttp = new ActiveXObject('Msxml2.XMLHTTP');
  } catch (e) {
    try {
      xmlhttp = new ActiveXObject('Microsoft.XMLHTTP');
    } catch (E) {
      xmlhttp = false;
    }
  }
  if (!xmlhttp && typeof XMLHttpRequest!='undefined') {
    xmlhttp = new XMLHttpRequest();
  }
  return xmlhttp;
}

// targetで指定されたオブジェクト（画面HTMLNode）をclassNameを実行した結果のHTMLで置換する
function replacePageElement(target, className, params) {
  var xmlhttp = _createXMLHttp();
  xmlhttp.open('POST', 'appcontroller', true);
  xmlhttp.setRequestHeader('Content-Type' , 'application/x-www-form-urlencoded');
  var param = '';
  if (arguments.length > 2) {
    param = '&' + params;
  }
  var postdata = 'PROCESSID=&PAGEID=&JSPID=jsp/PageElement&CLASSNAME=' + className + param;
  xmlhttp.onreadystatechange = function() 
  {
    if (xmlhttp.readyState == 4) {
      if (xmlhttp.status == 200) {
        var html = xmlhttp.responseText;
        target.parentNode.innerHTML = html;
      }
    }
  }
  xmlhttp.send(encodeURI(postdata));
}

// targetで指定されたSELECTオブジェクトのoptionsをclassNameを実行した結果のoptionsで置換する
// classNameが返すXMLは、<option value="値1">テキスト1</option><option value="値2">テキスト2</option>...
// のoptionを使用します。外側にselect等の他のタグが含まれる場合は無視されoption部分のみ参照されます。
function replaceSelectOptions(target, className, params) {
  var xmlhttp = _createXMLHttp();
  xmlhttp.open('POST', 'appcontroller', true);
  xmlhttp.setRequestHeader('Content-Type' , 'application/x-www-form-urlencoded');
  var param = '';
  if (arguments.length > 2) {
    param = '&' + params;
  }
  var postdata = 'PROCESSID=&PAGEID=&JSPID=jsp/PageElementHelper&CLASSNAME=' + className + param;
  xmlhttp.onreadystatechange = function() 
  {
    if (xmlhttp.readyState == 4) {
      if (xmlhttp.status == 200) {
        var xmldoc = xmlhttp.responseXML;
        var options = xmldoc.getElementsByTagName('option');
        target.length = options.length;
        for(var i = 0; i < options.length; ++i) {
          target.options[i].value = options[i].getAttribute('value');
          if (options[i].firstChild) {
            target.options[i].text = options[i].firstChild.nodeValue;
          } else {
            target.options[i].text = '';
          }
          if (options[i].getAttribute('selected')) {
            target.selectedIndex = i;
          }
        }
      }
    }
  }
  xmlhttp.send(encodeURI(postdata));
}

// targetsで指定されたオブジェクト群のvalueをclassNameを実行した結果をセット(or選択)する
// targetsは、document.getElementsByTagName('SELECT')のように複数エレメントを指定
// classNameクラスの実行結果は、ID1=値1;ID2=値2;... のように複数指定可能
function replaceElementsValue(targets, className, params) {
  var xmlhttp = _createXMLHttp();
  xmlhttp.open('POST', 'appcontroller', true);
  xmlhttp.setRequestHeader('Content-Type' , 'application/x-www-form-urlencoded');
  var param = '';
  if (arguments.length > 2) {
    param = '&' + params;
  }
  var postdata = 'PROCESSID=&PAGEID=&JSPID=jsp/PageElement&CLASSNAME=' + className + '&' + param;
  xmlhttp.onreadystatechange = function() 
  {
    if (xmlhttp.readyState == 4) {
      if (xmlhttp.status == 200) {
        var text = xmlhttp.responseText;
        var items = text.split(';');
        for (var i = 0; i < targets.length; i++) {
          if (targets[i].tagName == 'SELECT') {
            setSelectValue(targets[i], getItemValue(items, targets[i].id));
          } else if (targets[i].type == 'text') {
            targets[i].value = getItemValue(items, targets[i].id);
          }
        }
      }
    }
  }
  xmlhttp.send(encodeURI(postdata));
}

// 項目IDより、項目のバリューを取得する
function getItemValue(items, itemId) {
  for (var i = 0; i < items.length; i++) {
    var keyValue = items[i].split('=');
    if (keyValue[0] == itemId) {
      return keyValue[1];
    }
  }
  return '';
}

// SELECTオブジェクトの選択値を設定する
function setSelectValue(selectObject, value) {
  for (var i = 0; i < selectObject.options.length; i++) {
    if (selectObject.options[i].value == value) {
      selectObject.options[i].selected = true;
      break;
    }
  }
}

function setErrorStyle(target) {
  if (target.tagName=='SELECT')target=target.parentNode;
  target.style.borderColor='#ff0000';
  target.style.borderWidth='2px';
  target.style.borderStyle='solid';
}

function setErrorMessage(target, messageid, params) {
  setErrorStyle(target);
  var xmlhttp = _createXMLHttp();
  xmlhttp.open('POST', 'appcontroller', true);
  xmlhttp.setRequestHeader('Content-Type' , 'application/x-www-form-urlencoded');
  var param = '&FIELDID=' + target.name + '&VALUE=' + encodeURI(getFieldValue(target.id));
  if (arguments.length > 2) {
    param = '&' + params;
  }
  var postdata = 'PROCESSID=&PAGEID=&JSPID=jsp/PageElementMessage&MESSAGEID=' + messageid + param;
  xmlhttp.onreadystatechange = function() 
  {
    if (xmlhttp.readyState == 4) {
      if (xmlhttp.status == 200) {
        var html = xmlhttp.responseText;
        alert(html);
      }
    }
  }
  xmlhttp.send(encodeURI(postdata));
}

