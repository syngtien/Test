function putCookie(key, value) {
  cookie = key + "=" + encodeURI(value) + "; expires=Tue, 31-Dec-2999 23:59:59; ";
  document.cookie = cookie;
}
function removeCookie(key) {
  cookie = key + "=x; expires=Tue, 1-Jan-1980 00:00:00; ";
  document.cookie = cookie;
}
function getCookie(key) {
  cookies = document.cookie.split(";");
  for (i = 0; i < cookies.length; i++) {
    if (cookies[i].substring(0,1) == " ") {
      cookies[i] = cookies[i].substring(1);
    }
    if (cookies[i].substring(0, key.length + 1) == key + "=") {
      return decodeURI(cookies[i].substring(key.length + 1));
    }
  }
  return "";
}
