/*
  dragtable v1.0
  June 26, 2008
  Dan Vanderkam, http://danvk.org/dragtable/
                 http://code.google.com/p/dragtable/

  Instructions:
    - Download this file
    - Add <script src="dragtable.js"></script> to your HTML.
    - Add class="draggable" to any table you might like to reorder.
    - Drag the headers around to reorder them.

  This is code was based on:
    - Stuart Langridge's SortTable (kryogenix.org/code/browser/sorttable)
    - Mike Hall's draggable class (http://www.brainjar.com/dhtml/drag/)
    - A discussion of permuting table columns on comp.lang.javascript

  Licensed under the MIT license.
 */

resizetable = {

  dragObj: null,
  startPos: null,
  startWidth: 0,
  getParentNode: function(elt, nodeName) {
    while(elt!=null){
      if(elt.nodeName==nodeName){
        return elt;
      }
      elt=elt.parentNode;
    }
    return null;
  },
  dragStart: function(event, id) {
    var el;
    var x, y;

    var browser = dragtable.browser;
    if (browser.isIE)
      resizetable.dragObj = window.event.srcElement;
    else
      resizetable.dragObj = event.target;
    var pos = dragtable.eventPosition(event);
    if (browser.isIE) {
      document.attachEvent("onmousemove", resizetable.dragMove);
      document.attachEvent("onmouseup",   resizetable.dragEnd);
      window.event.cancelBubble = true;
      window.event.returnValue = false;
    } else {
      document.addEventListener("mousemove", resizetable.dragMove, true);
      document.addEventListener("mouseup",   resizetable.dragEnd, true);
      event.preventDefault();
    }
    resizetable.startPos = dragtable.eventPosition(event);
    resizetable.startWidth = resizetable.getParentNode(resizetable.dragObj,'TH').width;
  },
  dragMove: function(event) {
    if (resizetable.startPos==null){
      return;
    }
    if (resizetable.dragObj){
      var pos = dragtable.eventPosition(event);
      var w = resizetable.startWidth;
      var lastwidth = 0;
      if (lastwidth == 0) {
        var table = resizetable.getParentNode(resizetable.getParentNode(resizetable.dragObj,'TH'), 'TABLE');
        lastwidth = table.width;
        var ths = table.getElementsByTagName('TH');
        for(var i = 0; i < ths.length - 1; ++i){
          lastwidth = lastwidth - ths[i].width;
        }
        if(w == '100%'){
          w = lastwidth;
        }
      }
      if (lastwidth <= 10) {
        lastwidth = 10;
      }
      w = w - (resizetable.startPos.x - pos.x);
      if (w >= 0 && w <= 1600) {
        var th = resizetable.getParentNode(resizetable.dragObj,'TH');
        if(th){
          var table = resizetable.getParentNode(th, 'TABLE');
          if(table) {
            var ths = table.getElementsByTagName('TH');
            var idx = -1;
            for(var i=0;i<ths.length;++i){
              if(ths[i]==th){
                idx = i;
                break;
              }
            }
            if(idx == ths.length - 1) {
              return;
            } else {
              th.width=w;
            }
            ths[ths.length-1].width=lastwidth;
            if(idx != -1) {
              var trs = table.getElementsByTagName('TR');
              for(var i=0;i<trs.length;++i){
                if(trs[i].childNodes.lenth>0){
                  trs[i].childNodes[idx].width=th.width;
                  trs[i].childNodes[trs[i].childNodes.length-1].width='100%';
                }
              }
            }
          }
        }
      }
      //window.status=resizetable.startWidth + '->' + w;
    }
  },
  dragEnd: function(event) {
    //alert(resizetable.dragObj.parentNode.parentNode.parentNode.parentNode.parentNode.parentNode.parentNode.outerHTML);
    var browser = dragtable.browser;
    if (browser.isIE) {
      window.event.cancelBubble = true;
      window.event.returnValue = false;
    } else {
      event.preventDefault();
      alert('hoge');
    }
    resizetable.startPos=null;
    resizetable.dragObj=null;
  }
}

// Here's the notice from Mike Hall's draggable script:
//*****************************************************************************
// Do not remove this notice.
//
// Copyright 2001 by Mike Hall.
// See http://www.brainjar.com for terms of use.
//*****************************************************************************
dragtable = {
  // How far should the mouse move before it's considered a drag, not a click?
  dragRadius2: 100,
  setMinDragDistance: function(x) {
    dragtable.dragRadius2 = x * x;
  },

  // Determine browser and version.
  // TODO: eliminate browser sniffing except where it's really necessary.
  Browser: function() {
    var ua, s, i;

    this.isIE    = false;
    this.isNS    = false;
    this.version = null;
    ua = navigator.userAgent;

    s = "MSIE";
    if ((i = ua.indexOf(s)) >= 0) {
      this.isIE = true;
      this.version = parseFloat(ua.substr(i + s.length));
      return;
    }

    s = "Netscape6/";
    if ((i = ua.indexOf(s)) >= 0) {
      this.isNS = true;
      this.version = parseFloat(ua.substr(i + s.length));
      return;
    }

    // Treat any other "Gecko" browser as NS 6.1.
    s = "Gecko";
    if ((i = ua.indexOf(s)) >= 0) {
      this.isNS = true;
      this.version = 6.1;
      return;
    }
  },
  browser: null,

  // Detect all draggable tables and attach handlers to their headers.
  init: function() {
    // Don't initialize twice
    if (arguments.callee.done) return;
    arguments.callee.done = true;
    if (_dgtimer) clearInterval(_dgtimer);
    if (!document.createElement || !document.getElementsByTagName) return;

    dragtable.dragObj.zIndex = 0;
    dragtable.browser = new dragtable.Browser();
    forEach(document.getElementsByTagName('table'), function(table) {
      if (table.className.search(/\bdraggable\b/) != -1) {
        dragtable.makeDraggable(table);
      }
    });
    dragLoadFinish = true;
  },

  // The thead business is taken straight from sorttable.
  makeDraggable: function(table) {
    if (table.getElementsByTagName('thead').length == 0) {
      if (table.getElementsByTagName('tr').length == 0) {
        return;
      }
      the = document.createElement('thead');
      the.appendChild(table.rows[0]);
      table.insertBefore(the,table.firstChild);
    }

    // Safari doesn't support table.tHead, sigh
    if (table.tHead == null) {
      table.tHead = table.getElementsByTagName('thead')[0];
    }
    table.tHead.style.cursor='pointer';

    var headers = table.tHead.rows[0].cells;
    for (var i = 0; i < headers.length; i++) {
      headers[i].onmousedown = dragtable.dragStart;
      headers[i].onselectstart = function(){return false;};
      headers[i]._ind = i;
    }

    //get pageid:<!-- PageId: SysApplicationLD_JA -->
    var pid = '';
    var objpid = document.getElementsByTagName('!');
    if(objpid && objpid.length > 1) {
      var pos = objpid[1].innerHTML.indexOf('PageId:');
      if(pos > 0) {
        var poslast = objpid[1].innerHTML.lastIndexOf('_');
        pid = objpid[1].innerHTML.substring(pos + 8, poslast);
      }
    }
    pid += '-' + headers.length;
    table.cookieid = pid;

    var odiv = document.createElement("span");
    odiv.innerHTML = '*';
    odiv.title = 'テーブルのレイアウトをリセットします。';
    odiv.onclick = function(){
      d_putCookie(pid, '');
      d_putCookie(pid+'_H', '');
      // reset table conlumn width if suppot resize.js
      if (typeof resetTableWidth == 'function') resetTableWidth();
      if (dragtable.browser.isIE) {
        window.event.cancelBubble = true;
        window.event.returnValue = false;
      } else {
        event.preventDefault();
      }
      alert('画面は次回の表示にテーブルが元のレイアウトに戻ります。');
    };

    var tchild = table.tHead.rows[0].cells[0].getElementsByTagName('div');
    if(tchild.length > 0) {
      tchild[0].appendChild(odiv);
      tchild[0].style.position = "relative";
    }
    else {
      table.tHead.rows[0].cells[0].appendChild(odiv);
      table.tHead.rows[0].cells[0].style.position = "relative";
    }
    odiv.style.position = "absolute";
    odiv.style.left = "0px";
    odiv.style.top = "0px";
    odiv.style.width = '3px';
    odiv.style.height = '3px';
    odiv.style.cursor = 'pointer';
    odiv.style.fontSize = '7';
    odiv.style.color = '#CCC';

    headers = table.tHead.rows[0].cells;
    for (var i = 1; i < headers.length; i++) {
      var odiv = document.createElement("span");
      odiv.innerHTML = 'X';
      odiv.title = '列を隠します。';
      odiv._ind = headers[i]._ind;
      odiv.onclick = function(){
        if (dragtable.browser.isIE) {
          window.event.cancelBubble = true;
          window.event.returnValue = false;
        } else {
          event.preventDefault();
        }
        dragtable.hideColumn(table, this._ind);

        //save to cookie
        var tpos = '';
        var headers = table.tHead.rows[0].cells;
        for (var i = 0; i < headers.length; i++) {
          if(headers[i].style.display == 'none') {
            tpos += headers[i]._ind + ',';
          }
        }
        d_putCookie(pid+'_H', tpos);
      };
      var tchild = headers[i].getElementsByTagName('div');
      if(tchild.length > 0) {
        tchild[0].appendChild(odiv);
        tchild[0].style.position = "relative";
      }
      else {
        headers[i].appendChild(odiv);
        headers[i].style.position = "relative";
      }
      odiv.style.position = "absolute";
      odiv.style.left = "0px";
      odiv.style.top = "0px";
      odiv.style.width = '3px';
      odiv.style.height = '3px';
      odiv.style.cursor = 'pointer';
      odiv.style.fontSize = '7';
      odiv.style.color = '#CCC';
    }

    var tpos = d_getCookie(pid);
    var tposarr = tpos.split(',');
    if(tposarr.length == headers.length + 1) {
      for (var i = 0; i < headers.length; i++) {
        if(headers[i]._ind != tposarr[i]) {

          for (var j = 0; j < headers.length; j++) {
            if(headers[j]._ind == tposarr[i]) {
              dragtable.moveColumn(table, j, i);
              headers = table.tHead.rows[0].cells;
              break;
            }
          }

        }
      }
    }

    tpos = d_getCookie(pid+'_H');
    tposarr = tpos.split(',');
    for (var i = 0; i < tposarr.length; i++) {
      if(tposarr[i] != '') {
        dragtable.hideColumn(table, tposarr[i]);
      }
    }

    var rresize = document.getElementsByTagName('span');
    for (var i = 0; i < rresize.length; i++) {
      if (rresize[i].className=='rresize'){
        var text = resizetable.getParentNode(rresize[i],'TH').innerText;
        text=text.replace(/\r\n/,'');
        text=text.replace(/ /,'');
        if(text.length>0){
          rresize[i].onmousedown = resizetable.dragStart;
        }else{
          rresize[i].style.display='none';
        }
      }
    }

  },

  // Global object to hold drag information.
  dragObj: new Object(),

  // Climb up the DOM until there's a tag that matches.
  findUp: function(elt, tag) {
    do {
      if (elt.nodeName && elt.nodeName.search(tag) != -1)
        return elt;
    } while (elt = elt.parentNode);
    return null;
  },

  findTable: function(elt) {
    do {
      if (elt.nodeName && elt.nodeName.search('TABLE') != -1 && elt.tHead)
        return elt;
    } while (elt = elt.parentNode);
    return null;
  },
  
  // clone an element, copying its style and class.
  fullCopy: function(elt, deep) {
    var new_elt = elt.cloneNode(deep);
    new_elt.className = elt.className;
//    forEach(elt.style, function(k) { new_elt.style[k] = elt.style[k]; });
    // suppot IE : copy all style
    copyComputedStyle(elt, new_elt);
    return new_elt;
  },

  eventPosition: function(event) {
    var x, y;
    if (dragtable.browser.isIE) {
      x = window.event.clientX + document.documentElement.scrollLeft
        + document.body.scrollLeft;
      y = window.event.clientY + document.documentElement.scrollTop
        + document.body.scrollTop;
      return {x: x, y: y};
    }
    return {x: event.pageX, y: event.pageY};
  },

 // Determine the position of this element on the page. Many thanks to Magnus
 // Kristiansen for help making this work with "position: fixed" elements.
 absolutePosition: function(elt) {
   var ex = 0, ey = 0;
   do {
     var curStyle = dragtable.browser.isIE ? elt.currentStyle
                                           : window.getComputedStyle(elt, '');
     var supportFixed = !(dragtable.browser.isIE &&
                          dragtable.browser.version < 7);
     if (supportFixed && curStyle.position == 'fixed') {
       // Get the fixed el's offset
       ex += parseInt(curStyle.left, 10);
       ey += parseInt(curStyle.top, 10);
       // Compensate for scrolling
       ex += document.body.scrollLeft;
       ey += document.body.scrollTop;
       // End the loop
       break;
     } else {
       ex += elt.offsetLeft;
       ey += elt.offsetTop;
     }
   } while (elt = elt.offsetParent);
   return {x: ex, y: ey};
 },

  // MouseDown handler -- sets up the appropriate mousemove/mouseup handlers
  // and fills in the global dragtable.dragObj object.
  dragStart: function(event, id) {
    var el;
    var x, y;
    var dragObj = dragtable.dragObj;

    var browser = dragtable.browser;
    if (browser.isIE)
      dragObj.origNode = window.event.srcElement;
    else
      dragObj.origNode = event.target;
    var pos = dragtable.eventPosition(event);

    // Drag the entire table cell, not just the element that was clicked.
    dragObj.origNode = dragtable.findUp(dragObj.origNode, /T[DH]/);

    // Since a column header can't be dragged directly, duplicate its contents
    // in a div and drag that instead.
    // TODO: I can assume a tHead...
    var table = dragtable.findTable(dragObj.origNode);
    dragObj.table = table;
    dragObj.startCol = dragtable.findColumn(table, pos.x);
    if (dragObj.startCol == -1) return;

    var new_elt = dragtable.fullCopy(table, false);
    new_elt.style.margin = '0';

    // Copy the entire column
    var copySectionColumn = function(sec, col) {
      var new_sec = dragtable.fullCopy(sec, false);
      forEach(sec.rows, function(row) {
        var cell = row.cells[col];
        var new_tr = dragtable.fullCopy(row, false);
        if (row.offsetHeight) new_tr.style.height = row.offsetHeight + "px";
        var new_td = dragtable.fullCopy(cell, true);
        if (cell.offsetWidth) new_td.style.width = cell.offsetWidth + "px";
        new_tr.appendChild(new_td);
        new_sec.appendChild(new_tr);
      });
      return new_sec;
    };

    // First the heading
    if (table.tHead) {
      new_elt.appendChild(copySectionColumn(table.tHead, dragObj.startCol));
    }
    forEach(table.tBodies, function(tb) {
      new_elt.appendChild(copySectionColumn(tb, dragObj.startCol));
    });
    if (table.tFoot) {
      new_elt.appendChild(copySectionColumn(table.tFoot, dragObj.startCol));
    }

    var obj_pos = dragtable.absolutePosition(dragObj.origNode);
    new_elt.style.position = "absolute";
    new_elt.style.left = obj_pos.x + "px";
    new_elt.style.top = obj_pos.y + "px";
    new_elt.style.width = dragObj.origNode.offsetWidth;
    new_elt.style.height = dragObj.origNode.offsetHeight;

    // Hold off adding the element until this is clearly a drag.
    dragObj.addedNode = false;
    dragObj.tableContainer = dragObj.table.parentNode || document.body;
    dragObj.elNode = new_elt;

    // Save starting positions of cursor and element.
    dragObj.cursorStartX = pos.x;
    dragObj.cursorStartY = pos.y;
    dragObj.elStartLeft  = parseInt(dragObj.elNode.style.left, 10);
    dragObj.elStartTop   = parseInt(dragObj.elNode.style.top,  10);

    if (isNaN(dragObj.elStartLeft)) dragObj.elStartLeft = 0;
    if (isNaN(dragObj.elStartTop))  dragObj.elStartTop  = 0;

    // Update element's z-index.
    dragObj.elNode.style.zIndex = ++dragObj.zIndex;

    dragObj.elNode.style.filter = 'alpha(opacity=50)';

    // Capture mousemove and mouseup events on the page.
    if (browser.isIE) {
      document.attachEvent("onmousemove", dragtable.dragMove);
      document.attachEvent("onmouseup",   dragtable.dragEnd);
      window.event.cancelBubble = true;
      window.event.returnValue = false;
    } else {
      document.addEventListener("mousemove", dragtable.dragMove, true);
      document.addEventListener("mouseup",   dragtable.dragEnd, true);
      event.preventDefault();
    }
  },

  // Move the floating column header with the mouse
  // TODO: Reorder columns as the mouse moves for a more interactive feel.
  dragMove: function(event) {
    var x, y;
    var dragObj = dragtable.dragObj;

    // Get cursor position with respect to the page.
    var pos = dragtable.eventPosition(event);

    var dx = dragObj.cursorStartX - pos.x;
    var dy = dragObj.cursorStartY - pos.y;
    if (!dragObj.addedNode && dx * dx + dy * dy > dragtable.dragRadius2) {
      dragObj.tableContainer.insertBefore(dragObj.elNode, dragObj.table);
      dragObj.addedNode = true;
    }

    // Move drag element by the same amount the cursor has moved.
    var style = dragObj.elNode.style;
    style.left = (dragObj.elStartLeft + pos.x - dragObj.cursorStartX) + "px";
    style.top  = (dragObj.elStartTop  + pos.y - dragObj.cursorStartY) + "px";

    if (dragtable.browser.isIE) {
      window.event.cancelBubble = true;
      window.event.returnValue = false;
    } else {
      event.preventDefault();
    }
  },

  // Stop capturing mousemove and mouseup events.
  // Determine which (if any) column we're over and shuffle the table.
  dragEnd: function(event) {
    if (dragtable.browser.isIE) {
      document.detachEvent("onmousemove", dragtable.dragMove);
      document.detachEvent("onmouseup", dragtable.dragEnd);
    } else {
      document.removeEventListener("mousemove", dragtable.dragMove, true);
      document.removeEventListener("mouseup", dragtable.dragEnd, true);
    }
    
    // If the floating header wasn't added, the mouse didn't move far enough.
    var dragObj = dragtable.dragObj;
    if (!dragObj.addedNode) {
      return;
    }
    dragObj.tableContainer.removeChild(dragObj.elNode);

    // Determine whether the drag ended over the table, and over which column.
    var pos = dragtable.eventPosition(event);
    var table_pos = dragtable.absolutePosition(dragObj.table);
    if (pos.y < table_pos.y ||
        pos.y > table_pos.y + dragObj.table.offsetHeight) {
      return;
    }
    var targetCol = dragtable.findColumn(dragObj.table, pos.x);
    if (targetCol != -1 && targetCol != dragObj.startCol) {
      dragtable.moveColumn(dragObj.table, dragObj.startCol, targetCol);

      //save to cookie
      if(dragObj.table.cookieid) {
        var tpos = '';
        var headers = dragObj.table.tHead.rows[0].cells;
        for (var i = 0; i < headers.length; i++) {
          tpos += headers[i]._ind + ',';
        }
        d_putCookie(dragObj.table.cookieid, tpos);
      }

    }
    
    // re-resize table conlumn width if suppot resize.js
    if (typeof reResize == 'function') reResize();
  },

  // Which column does the x value fall inside of? x should include scrollLeft.
  findColumn: function(table, x) {
    table = dragtable.findTable(table);
    var header = table.tHead.rows[0].cells;
    for (var i = 0; i < header.length; i++) {
      //var left = header[i].offsetLeft;
      var pos = dragtable.absolutePosition(header[i]);
      //if (left <= x && x <= left + header[i].offsetWidth) {
      if (pos.x <= x && x <= pos.x + header[i].offsetWidth) {
        return i;
      }
    }
    return -1;
  },

  // Move a column of table from start index to finish index.
  // Based on the "Swapping table columns" discussion on comp.lang.javascript.
  // Assumes there are columns at sIdx and fIdx
  moveColumn: function(table, sIdx, fIdx) {
    table = dragtable.findTable(table);
    var row, cA;
    var i=table.rows.length;
    while (i--){
      row = table.rows[i];
      var x = row.removeChild(row.cells[sIdx]);
      if (fIdx < row.cells.length) {
        row.insertBefore(x, row.cells[fIdx]);
      } else {
        row.appendChild(x);
      }
    }

    // For whatever reason, sorttable tracks column indices this way.
    // Without a manual update, clicking one column will sort on another.
    var headrow = table.tHead.rows[0].cells;
    for (var i=0; i<headrow.length; i++) {
      headrow[i].sorttable_columnindex = i;
    }
  },

  // Remove a column of table from start index.
  hideColumn: function(table, sIdx) {
    table = dragtable.findTable(table);
    var row, cA;
    var w = 0;
    var ind = -1;
    var headers = table.tHead.rows[0].cells;
    for (var i = 0; i < headers.length; i++) {
      if(headers[i]._ind == sIdx) {
        w = headers[i].width;
        ind = i;
        break;
      }
    }
    var i=table.rows.length;
    while (ind>=0 && i--){
      row = table.rows[i];
      row.cells[ind].style.display = 'none';
    }
//    table.width -= w;

    // For whatever reason, sorttable tracks column indices this way.
    // Without a manual update, clicking one column will sort on another.
    var headrow = table.tHead.rows[0].cells;
    for (var i=0; i<headrow.length; i++) {
      headrow[i].sorttable_columnindex = i;
    }
  }
}

/* ******************************************************************
   Supporting functions: bundled here to avoid depending on a library
   ****************************************************************** */

// Dean Edwards/Matthias Miller/John Resig
// has a hook for dragtable.init already been added? (see below)
var dgListenOnLoad = false;
var dragLoadFinish = false;

/* for Mozilla/Opera9 */
if (document.addEventListener) {
  dgListenOnLoad = true;
  document.addEventListener("DOMContentLoaded", dragtable.init, false);
}

/* for Internet Explorer */
/*@cc_on @*/
/*@if (@_win32)
  dgListenOnLoad = true;
  document.write("<script id=__dt_onload defer src=javascript:void(0)><\/script>");
  var script = document.getElementById("__dt_onload");
  script.onreadystatechange = function() {
    if (this.readyState == "complete") {
      dragtable.init(); // call the onload handler
    }
  };
/*@end @*/

/* for Safari */
if (/WebKit/i.test(navigator.userAgent)) { // sniff
  dgListenOnLoad = true;
  var _dgtimer = setInterval(function() {
    if (/loaded|complete/.test(document.readyState)) {
      dragtable.init(); // call the onload handler
    }
  }, 10);
}

/* for other browsers */
/* Avoid this unless it's absolutely necessary (it breaks sorttable) */
if (!dgListenOnLoad) {
  window.onload = dragtable.init;
}

// Dean's forEach: http://dean.edwards.name/base/forEach.js
/*
  forEach, version 1.0
  Copyright 2006, Dean Edwards
  License: http://www.opensource.org/licenses/mit-license.php
*/

// array-like enumeration
if (!Array.forEach) { // mozilla already supports this
  Array.forEach = function(array, block, context) {
    for (var i = 0; i < array.length; i++) {
      block.call(context, array[i], i, array);
    }
  };
}

// generic enumeration
Function.prototype.forEach = function(object, block, context) {
  for (var key in object) {
    if (typeof this.prototype[key] == "undefined") {
      block.call(context, object[key], key, object);
    }
  }
};

// character enumeration
String.forEach = function(string, block, context) {
  Array.forEach(string.split(""), function(chr, index) {
    block.call(context, chr, index, string);
  });
};

// globally resolve forEach enumeration
var forEach = function(object, block, context) {
  if (object) {
    var resolve = Object; // default
    if (object instanceof Function) {
      // functions have a "length" property
      resolve = Function;
    } else if (object.forEach instanceof Function) {
      // the object implements a custom forEach method so use that
      object.forEach(block, context);
      return;
    } else if (typeof object == "string") {
      // the object is a string
      resolve = String;
    } else if (typeof object.length == "number") {
      // the object is array-like
      resolve = Array;
    }
    resolve.forEach(object, block, context);
  }
};

function d_putCookie(key, value) {
  cookie = key + "=" + escape(value) + "; expires=Tue, 31-Dec-2999 23:59:59; ";
  document.cookie = cookie;
}
function d_getCookie(key) {
  cookies = document.cookie.split(";");
  for (i = 0; i < cookies.length; i++) {
    if (cookies[i].substring(0,1) == " ") {
      cookies[i] = cookies[i].substring(1);
    }
    if (cookies[i].substring(0, key.length + 1) == key + "=") {
      return unescape(cookies[i].substring(key.length + 1));
    }
  }
  return "";
}

////////////  suppot IE : copy all style
var realStyle = function(_elem, _style) {
    var computedStyle;
    if ( typeof _elem.currentStyle != 'undefined' ) {
    	computedStyle = _elem.currentStyle;
    } else {
    	computedStyle = document.defaultView.getComputedStyle(_elem, null);
    }

    return _style ? computedStyle[_style] : computedStyle;
};

var copyComputedStyle = function(src, dest) {
    var s = realStyle(src);
    for ( var i in s ) {
    	// Do not use `hasOwnProperty`, nothing will get copied
    	if ( typeof i == "string" && i != "cssText" && !/\d/.test(i) ) {
    		// The try is for setter only properties
    		try {
    			dest.style[i] = s[i];
    			// `fontSize` comes before `font` If `font` is empty, `fontSize` gets
    			// overwritten.  So make sure to reset this property. (hackyhackhack)
    			// Other properties may need similar treatment
    			if ( i == "font" ) {
    				dest.style.fontSize = s.fontSize;
    			}
    		} catch (e) {}
    	}
    }
};




/*
  SortTable
  version 2
  7th April 2007
  Stuart Langridge, http://www.kryogenix.org/code/browser/sorttable/
  
  Instructions:
  Download this file
  Add <script src="sorttable.js"></script> to your HTML
  Add class="sortable" to any table you'd like to make sortable
  Click on the headers to sort
  
  Thanks to many, many people for contributions and suggestions.
  Licenced as X11: http://www.kryogenix.org/code/browser/licence.html
  This basically means: do what you want with it.
*/

 
var stIsIE = /*@cc_on!@*/false;
var _up = '';
var _down = '';

sorttable = {
  init: function() {
    // quit if this function has already been called
    if (arguments.callee.done) return;
    // flag this function so we don't do the same thing twice
    arguments.callee.done = true;
    // kill the timer
    if (_timer) clearInterval(_timer);
    
    if (!document.createElement || !document.getElementsByTagName) return;
    
    sorttable.DATE_RE = /^(\d\d?)[\/\.-](\d\d?)[\/\.-]((\d\d)?\d\d)$/;
    
    forEach(document.getElementsByTagName('table'), function(table) {
      if (table.className.search(/\bsortable\b/) != -1) {
        sorttable.makeSortable(table);
      }
    });
    
  },
  
  makeSortable: function(table) {
    if (table.getElementsByTagName('thead').length == 0) {
      if (table.getElementsByTagName('tr').length == 0) {
        return;
      }
      // table doesn't have a tHead. Since it should have, create one and
      // put the first table row in it.
      the = document.createElement('thead');
      the.appendChild(table.rows[0]);
      table.insertBefore(the,table.firstChild);
    }
    // Safari doesn't support table.tHead, sigh
    if (table.tHead == null) table.tHead = table.getElementsByTagName('thead')[0];
    
    if (table.tHead.rows.length != 1) return; // can't cope with two header rows
    
    table.tHead.style.cursor='pointer';
    
    // Sorttable v1 put rows with a class of "sortbottom" at the bottom (as
    // "total" rows, for example). This is B&R, since what you're supposed
    // to do is put them in a tfoot. So, if there are sortbottom rows,
    // for backwards compatibility, move them to tfoot (creating it if needed).
    sortbottomrows = [];
    for (var i=0; i<table.rows.length; i++) {
      if (table.rows[i].className.search(/\bsortbottom\b/) != -1) {
        sortbottomrows[sortbottomrows.length] = table.rows[i];
      }
    }
    if (sortbottomrows) {
      if (table.tFoot == null) {
        // table doesn't have a tfoot. Create one.
        tfo = document.createElement('tfoot');
        table.appendChild(tfo);
      }
      for (var i=0; i<sortbottomrows.length; i++) {
        tfo.appendChild(sortbottomrows[i]);
      }
      delete sortbottomrows;
    }
    
    // work through each column and calculate its type
    headrow = table.tHead.rows[0].cells;
    for (var i=0; i<headrow.length; i++) {
      // manually override the type with a sorttable_type attribute
      if (!headrow[i].className.match(/\bsorttable_nosort\b/)) { // skip this col
        mtch = headrow[i].className.match(/\bsorttable_([a-z0-9]+)\b/);
        if (mtch) { override = mtch[1]; }
	      if (mtch && typeof sorttable["sort_"+override] == 'function') {
	        headrow[i].sorttable_sortfunction = sorttable["sort_"+override];
	      } else {
	        headrow[i].sorttable_sortfunction = sorttable.guessType(table,i);
	      }
	      // make it clickable to sort
	      headrow[i].sorttable_columnindex = i;
	      headrow[i].sorttable_tbody = table.tBodies[0];
	      dean_addEvent(headrow[i],"mousedown", function(e) {
	      
	      if(e.srcElement.className=='rresize'&&e.srcElement.tagName=='SPAN'){
	        return;
	      }

          if (this.className.search(/\bsorttable_sorted\b/) != -1) {
            // if we're already sorted by this column, just 
            // reverse the table, which is quicker
            sorttable.reverse(this.sorttable_tbody);
            this.className = this.className.replace('sorttable_sorted',
                                                    'sorttable_sorted_reverse');
            this.removeChild(document.getElementById('sorttable_sortfwdind'));
            sortrevind = document.createElement('span');
            sortrevind.id = "sorttable_sortrevind";
            sortrevind.style.display='none';
            sortrevind.innerHTML = stIsIE ? '&nbsp'+_up : '&nbsp;&#x25B4;';
            this.appendChild(sortrevind);
//            var childs = sortrevind.parentNode.childNodes[0].getElementsByTagName('TD');
//            for(var j = 0; j < childs.length; ++j) {
//              if(childs[j].className=='sort_guide'){
//                childs[j].innerText=_up;
//              }
//            }
            
            sorttable.reColor(this.sorttable_tbody);
            
            return;
          }
          if (this.className.search(/\bsorttable_sorted_reverse\b/) != -1) {
            // if we're already sorted by this column in reverse, just 
            // re-reverse the table, which is quicker
            sorttable.reverse(this.sorttable_tbody);
            this.className = this.className.replace('sorttable_sorted_reverse',
                                                    'sorttable_sorted');
            this.removeChild(document.getElementById('sorttable_sortrevind'));
            sortfwdind = document.createElement('span');
            sortfwdind.id = "sorttable_sortfwdind";
            sortfwdind.style.display='none';
            sortfwdind.innerHTML = stIsIE ? '&nbsp'+_down : '&nbsp;&#x25BE;';
            this.appendChild(sortfwdind);
//            var childs = sortfwdind.parentNode.childNodes[0].getElementsByTagName('TD');
//            for(var j = 0; j < childs.length; ++j) {
//              if(childs[j].className=='sort_guide'){
//                childs[j].innerText=_down;
//              }
//            }
            
            sorttable.reColor(this.sorttable_tbody);
            
            return;
          }
          
          // remove sorttable_sorted classes
          theadrow = this.parentNode;
          forEach(theadrow.childNodes, function(cell) {
            if (cell.nodeType == 1) { // an element
              cell.className = cell.className.replace('sorttable_sorted_reverse','');
              cell.className = cell.className.replace('sorttable_sorted','');
            }
          });
          sortfwdind = document.getElementById('sorttable_sortfwdind');
          if (sortfwdind) { sortfwdind.parentNode.removeChild(sortfwdind); }
          sortrevind = document.getElementById('sorttable_sortrevind');
          if (sortrevind) { sortrevind.parentNode.removeChild(sortrevind); }
          
          this.className += ' sorttable_sorted';
          sortfwdind = document.createElement('span');
          sortfwdind.id = "sorttable_sortfwdind";
          sortfwdind.innerHTML = stIsIE ? '&nbsp'+_down : '&nbsp;&#x25BE;';
          sortfwdind.style.display='none';
          this.appendChild(sortfwdind);
//          var childs = sortfwdind.parentNode.childNodes[0].getElementsByTagName('TD');
//          for(var j = 0; j < childs.length; ++j) {
//            if(childs[j].className=='sort_guide'){
//              childs[j].innerText=_down;
//            }
//          }

	        // build an array to sort. This is a Schwartzian transform thing,
	        // i.e., we "decorate" each row with the actual sort key,
	        // sort based on the sort keys, and then put the rows back in order
	        // which is a lot faster because you only do getInnerText once per row
	        row_array = [];
	        col = this.sorttable_columnindex;
	        rows = this.sorttable_tbody.rows;
	        for (var j=0; j<rows.length; j++) {
	          row_array[row_array.length] = [sorttable.getInnerText(rows[j].cells[col]), rows[j]];
	        }
	        /* If you want a stable sort, uncomment the following line */
	        //sorttable.shaker_sort(row_array, this.sorttable_sortfunction);
	        /* and comment out this one */
	        row_array.sort(this.sorttable_sortfunction);
	        
	        tb = this.sorttable_tbody;
	        for (var j=0; j<row_array.length; j++) {
	          tb.appendChild(row_array[j][1]);
	        }
	        
	        delete row_array;
	        
	        sorttable.reColor(this.sorttable_tbody);
	      });
	    }
    }
  },
  
  guessType: function(table, column) {
    // guess the type of a column based on its first non-blank row
    sortfn = sorttable.sort_alpha;
    var className = "";
    for (var i=0; i<table.tBodies[0].rows.length; i++) {
      var text = sorttable.getInnerText(table.tBodies[0].rows[i].cells[column]);
      if (text != '') {
        if (text.match(/^-?[\d,.]+%?$/)) {
          return sorttable.sort_numeric;
        }
        // check for a date: dd/mm/yyyy or dd/mm/yy 
        // can have / or . or - as separator
        // can be mm/dd as well
        possdate = text.match(sorttable.DATE_RE)
        if (possdate) {
          // looks like a date
          first = parseInt(possdate[1]);
          second = parseInt(possdate[2]);
          if (first > 12) {
            // definitely dd/mm
            return sorttable.sort_ddmm;
          } else if (second > 12) {
            return sorttable.sort_mmdd;
          } else {
            // looks like a date, but we can't tell which, so assume
            // that it's dd/mm (English imperialism!) and keep looking
            sortfn = sorttable.sort_ddmm;
          }
        }
      }
    }
    return sortfn;
  },
  
  getInnerText: function(node) {
    // gets the text we want to use for sorting for a cell.
    // strips leading and trailing whitespace.
    // this is *not* a generic getInnerText function; it's special to sorttable.
    // for example, you can override the cell text with a customkey attribute.
    // it also gets .value for <input> fields.
    
    hasInputs = (typeof node.getElementsByTagName == 'function') &&
                 node.getElementsByTagName('input').length;
    
    if (node.getAttribute("sorttable_customkey") != null) {
      return node.getAttribute("sorttable_customkey");
    }
    else if (typeof node.textContent != 'undefined' && !hasInputs) {
      return node.textContent.replace(/^\s+|\s+$/g, '');
    }
    else if (typeof node.innerText != 'undefined' && !hasInputs) {
      return node.innerText.replace(/^\s+|\s+$/g, '');
    }
    else if (typeof node.text != 'undefined' && !hasInputs) {
      return node.text.replace(/^\s+|\s+$/g, '');
    }
    else {
      switch (node.nodeType) {
        case 3:
          if (node.nodeName.toLowerCase() == 'input') {
            return node.value.replace(/^\s+|\s+$/g, '');
          }
        case 4:
          return node.nodeValue.replace(/^\s+|\s+$/g, '');
          break;
        case 1:
        case 11:
          var innerText = '';
          for (var i = 0; i < node.childNodes.length; i++) {
            innerText += sorttable.getInnerText(node.childNodes[i]);
          }
          return innerText.replace(/^\s+|\s+$/g, '');
          break;
        default:
          return '';
      }
    }
  },
  
  reverse: function(tbody) {
    // reverse the rows in a tbody
    newrows = [];
    for (var i=0; i<tbody.rows.length; i++) {
      newrows[newrows.length] = tbody.rows[i];
    }
    for (var i=newrows.length-1; i>=0; i--) {
       tbody.appendChild(newrows[i]);
    }
    delete newrows;
  },
  
  /* sort functions
     each sort function takes two parameters, a and b
     you are comparing a[0] and b[0] */
  sort_numeric: function(a,b) {
    aa = parseFloat(a[0].replace(/[^0-9.-]/g,''));
    if (isNaN(aa)) aa = 0;
    bb = parseFloat(b[0].replace(/[^0-9.-]/g,'')); 
    if (isNaN(bb)) bb = 0;
    return aa-bb;
  },
  sort_alpha: function(a,b) {
    if (a[0]==b[0]) return 0;
    if (a[0]<b[0]) return -1;
    return 1;
  },
  sort_ddmm: function(a,b) {
    mtch = a[0].match(sorttable.DATE_RE);
    y = mtch[3]; m = mtch[2]; d = mtch[1];
    if (m.length == 1) m = '0'+m;
    if (d.length == 1) d = '0'+d;
    dt1 = y+m+d;
    mtch = b[0].match(sorttable.DATE_RE);
    y = mtch[3]; m = mtch[2]; d = mtch[1];
    if (m.length == 1) m = '0'+m;
    if (d.length == 1) d = '0'+d;
    dt2 = y+m+d;
    if (dt1==dt2) return 0;
    if (dt1<dt2) return -1;
    return 1;
  },
  sort_mmdd: function(a,b) {
    mtch = a[0].match(sorttable.DATE_RE);
    y = mtch[3]; d = mtch[2]; m = mtch[1];
    if (m.length == 1) m = '0'+m;
    if (d.length == 1) d = '0'+d;
    dt1 = y+m+d;
    mtch = b[0].match(sorttable.DATE_RE);
    y = mtch[3]; d = mtch[2]; m = mtch[1];
    if (m.length == 1) m = '0'+m;
    if (d.length == 1) d = '0'+d;
    dt2 = y+m+d;
    if (dt1==dt2) return 0;
    if (dt1<dt2) return -1;
    return 1;
  },
  
  shaker_sort: function(list, comp_func) {
    // A stable sort function to allow multi-level sorting of data
    // see: http://en.wikipedia.org/wiki/Cocktail_sort
    // thanks to Joseph Nahmias
    var b = 0;
    var t = list.length - 1;
    var swap = true;

    while(swap) {
        swap = false;
        for(var i = b; i < t; ++i) {
            if ( comp_func(list[i], list[i+1]) > 0 ) {
                var q = list[i]; list[i] = list[i+1]; list[i+1] = q;
                swap = true;
            }
        } // for
        t--;

        if (!swap) break;

        for(var i = t; i > b; --i) {
            if ( comp_func(list[i], list[i-1]) < 0 ) {
                var q = list[i]; list[i] = list[i-1]; list[i-1] = q;
                swap = true;
            }
        } // for
        b++;

    } // while(swap)
  },
  
  reColor: function(tbody) {
	  var className = "";
	  for (var row=0; row<tbody.rows.length; row++) {
		  for (var column=0; column<tbody.rows[row].cells.length; column++) {
			  className = tbody.rows[row].cells[column].className;
		      className = className.replace('line-even', '').replace('line-odd', '');
			  if (row % 2 == 1) {
		        className += "line-even";
		      } else {
		        className += "line-odd";
		      }
			  tbody.rows[row].cells[column].className = className;
		  }
	  	}
  	}
}

/* ******************************************************************
   Supporting functions: bundled here to avoid depending on a library
   ****************************************************************** */

// Dean Edwards/Matthias Miller/John Resig

/* for Mozilla/Opera9 */
if (document.addEventListener) {
    document.addEventListener("DOMContentLoaded", sorttable.init, false);
}

/* for Internet Explorer */
/*@cc_on @*/
/*@if (@_win32)
    document.write("<script id=__ie_onload defer src=javascript:void(0)><\/script>");
    var script = document.getElementById("__ie_onload");
    script.onreadystatechange = function() {
        if (this.readyState == "complete") {
            sorttable.init(); // call the onload handler
        }
    };
/*@end @*/

/* for Safari */
if (/WebKit/i.test(navigator.userAgent)) { // sniff
    var _timer = setInterval(function() {
        if (/loaded|complete/.test(document.readyState)) {
            sorttable.init(); // call the onload handler
        }
    }, 10);
}

/* for other browsers */
window.onload = sorttable.init;

// written by Dean Edwards, 2005
// with input from Tino Zijdel, Matthias Miller, Diego Perini

// http://dean.edwards.name/weblog/2005/10/add-event/

function dean_addEvent(element, type, handler) {
	if (element.addEventListener) {
		element.addEventListener(type, handler, false);
	} else {
		// assign each event handler a unique ID
		if (!handler.$$guid) handler.$$guid = dean_addEvent.guid++;
		// create a hash table of event types for the element
		if (!element.events) element.events = {};
		// create a hash table of event handlers for each element/event pair
		var handlers = element.events[type];
		if (!handlers) {
			handlers = element.events[type] = {};
			// store the existing event handler (if there is one)
			if (element["on" + type]) {
				handlers[0] = element["on" + type];
			}
		}
		// store the event handler in the hash table
		handlers[handler.$$guid] = handler;
		// assign a global event handler to do all the work
		element["on" + type] = handleEvent;
	}
};
// a counter used to create unique IDs
dean_addEvent.guid = 1;

function removeEvent(element, type, handler) {
	if (element.removeEventListener) {
		element.removeEventListener(type, handler, false);
	} else {
		// delete the event handler from the hash table
		if (element.events && element.events[type]) {
			delete element.events[type][handler.$$guid];
		}
	}
};

function handleEvent(event) {
	var returnValue = true;
	// grab the event object (IE uses a global event object)
	event = event || fixEvent(((this.ownerDocument || this.document || this).parentWindow || window).event);
	// get a reference to the hash table of event handlers
	var handlers = this.events[event.type];
	// execute each event handler
	for (var i in handlers) {
		this.$$handleEvent = handlers[i];
		if (this.$$handleEvent(event) === false) {
			returnValue = false;
		}
	}
	return returnValue;
};

function fixEvent(event) {
	// add W3C standard event methods
	event.preventDefault = fixEvent.preventDefault;
	event.stopPropagation = fixEvent.stopPropagation;
	return event;
};
fixEvent.preventDefault = function() {
	this.returnValue = false;
};
fixEvent.stopPropagation = function() {
  this.cancelBubble = true;
}

// Dean's forEach: http://dean.edwards.name/base/forEach.js
/*
	forEach, version 1.0
	Copyright 2006, Dean Edwards
	License: http://www.opensource.org/licenses/mit-license.php
*/

// array-like enumeration
if (!Array.forEach) { // mozilla already supports this
	Array.forEach = function(array, block, context) {
		for (var i = 0; i < array.length; i++) {
			block.call(context, array[i], i, array);
		}
	};
}

// generic enumeration
Function.prototype.forEach = function(object, block, context) {
	for (var key in object) {
		if (typeof this.prototype[key] == "undefined") {
			block.call(context, object[key], key, object);
		}
	}
};

// character enumeration
String.forEach = function(string, block, context) {
	Array.forEach(string.split(""), function(chr, index) {
		block.call(context, chr, index, string);
	});
};

// globally resolve forEach enumeration
var forEach = function(object, block, context) {
	if (object) {
		var resolve = Object; // default
		if (object instanceof Function) {
			// functions have a "length" property
			resolve = Function;
		} else if (object.forEach instanceof Function) {
			// the object implements a custom forEach method so use that
			object.forEach(block, context);
			return;
		} else if (typeof object == "string") {
			// the object is a string
			resolve = String;
		} else if (typeof object.length == "number") {
			// the object is array-like
			resolve = Array;
		}
		resolve.forEach(object, block, context);
	}
};




// Resizable Table Columns.
//  version: 1.0
//
// (c) 2006, bz
//
// 25.12.2006:  first working prototype
// 26.12.2006:  now works in IE as well but not in Opera (Opera is @#$%!)
// 27.12.2006:  changed initialization, now just make class='resizable' in table and load script
//
var isResize = false;
function preventEvent(e) {
	var ev = e || window.event;
	if (ev.preventDefault) ev.preventDefault();
	else {
		window.event.cancelBubble = true;
		ev.returnValue = false;
	}
	if (ev.stopPropagation)
		ev.stopPropagation();
	return false;
}

function getStyle(x, styleProp) {
	if (x.currentStyle)
		var y = x.currentStyle[styleProp];
	else if (window.getComputedStyle)
		var y = document.defaultView.getComputedStyle(x,null).getPropertyValue(styleProp);
	return y;
}

function getWidth(x) {
	if (x.currentStyle)
		// in IE
		var y = x.clientWidth - parseInt(x.currentStyle["paddingLeft"]) - parseInt(x.currentStyle["paddingRight"]);
		// for IE5: var y = x.offsetWidth;
	else if (window.getComputedStyle)
		// in Gecko
		var y = document.defaultView.getComputedStyle(x,null).getPropertyValue("width");
	return y || 0;
}

function setCookie(key, value) {
	  cookie = key + "=" + escape(value) + "; expires=Tue, 31-Dec-2999 23:59:59; ";
	  document.cookie = cookie;
	}

function getCookie(key) {
  cookies = document.cookie.split(";");
  for (i = 0; i < cookies.length; i++) {
    if (cookies[i].substring(0,1) == " ") {
      cookies[i] = cookies[i].substring(1);
    }
    if (cookies[i].substring(0, key.length + 1) == key + "=") {
      return unescape(cookies[i].substring(key.length + 1));
    }
  }
  return "";
}
	
// main class prototype
function ColumnResize(table) {
	if (table.tagName != 'TABLE') return;
	
	this.id = table.id;
	
//	table.removeAttribute('width');
	table.width = '';
	tableParentIndx = table.parentNode.cellIndex + table.parentNode.colSpan - 1;
	tableParent = table.parentNode.parentNode.parentNode.parentNode;
	
	cookieid = '';
    var objpid = document.getElementsByTagName('!');
    if(objpid && objpid.length > 1) {
      var pos = objpid[1].innerHTML.indexOf('PageId:');
      if(pos > 0) {
        var poslast = objpid[1].innerHTML.lastIndexOf('_');
        cookieid = objpid[1].innerHTML.substring(pos + 8, poslast);
      }
    }
    cookieid += '-' + this.id + '-resize';
    
    this.removeChildWidth = function(eleChild, cokiesw) {
		if (eleChild.tagName.toLowerCase()=='table') {
			var divs = eleChild.getElementsByTagName('div');
			if (cokiesw && divs[0]) {
				divs[0].style.width = cokiesw + "px";
			}
			
			colgroup = eleChild.getElementsByTagName('colgroup');
			if (colgroup && colgroup[0]) {
				eleChild.removeChild(colgroup[0]);
			}
		}
		return true;
	}

	this.setChildWidthStyle = function(child, w) {
		if (child.tagName.toLowerCase()=='table') {
			divs = child.getElementsByTagName('div');
			if (divs && divs[0]) {
				divs[0].style.width = w + 'px';
			}
		}
		return true;
	}

	this.addWidthStyle = function(child, w) {
		if (child.tagName.toLowerCase()=='table') {
			var divs = child.getElementsByTagName('div');
			if (divs && typeof divs[0] == 'object') {
				divs[0].style.width = parseInt(divs[0].style.width.replace('px')) + w + 'px';
			}
		}
		return true;
	}
	
	this.clearCookies = function() {
		setCookie(cookieid, '');
		setCookie(cookieid + 'F', '');
		return true;
	}
	
	this.reResize = function() {
		dragColumns = table.tHead.rows[0].cells;
		
		var colWidth = '';
		var separator = '';
		for (var i=0; i<dragColumns.length; i++) {
			colWidth += separator + parseInt( getWidth(dragColumns[i]) );
			separator = '+';
		}
		
		var tblColWidth = '';
		tblColWidth += tableParent.firstChild.children[tableParentIndx].width;
		tblColWidth += '+';
		tblColWidth += tableParent.width;
			
		setCookie(cookieid, colWidth);
		setCookie(cookieid + 'F', tblColWidth);
//		console.log('setCookie = ' + colWidth);
//		console.log('setCookieF = ' + tblColWidth);
		return true;
	}

	// ============================================================
	// private data
	var self = this;
	
	if (table.getElementsByTagName('thead').length == 0) {
	      the = document.createElement('thead');
	      the.appendChild(table.rows[0]);
	      table.insertBefore(the,table.firstChild);
	}

	var dragColumns  = table.tHead.rows[0].cells; // first row columns, used for changing of width
//	var dragColumns  = table.rows[0].cells; // first row columns, used for changing of width
	if (!dragColumns) return; // return if no table exists or no one row exists

	for (var colNo=0; colNo<dragColumns.length; colNo++) {
		for (var rowNo=0; rowNo<table.tBodies[0].rows.length; rowNo++) {
			var eleChild = table.tBodies[0].rows[rowNo].cells[colNo].childNodes;
			
			self.removeChildWidth(eleChild[0], null);
		}
		if (dragColumns[colNo].childNodes[0]) {
			self.removeChildWidth(dragColumns[colNo].childNodes[0], dragColumns[colNo].width);
		}
	}
	
	// restore from cokies
	var cokies = getCookie(cookieid);
//	console.log('getCookie = ' + cokies);
	if (cokies != "") {
		var colWidth = cokies.split('+');
		if (colWidth.length > 0) {
			for (var colNo = 0; colNo < colWidth.length; colNo++) {
				if (dragColumns[colNo]) {
					for (var rowNo=0; rowNo<table.tBodies[0].rows.length; rowNo++) {
						var eleChild = table.tBodies[0].rows[rowNo].cells[colNo].childNodes;
						
						self.removeChildWidth(eleChild[0], colWidth[colNo]);
					}
					
					var headRow = dragColumns[colNo];
					headRow.style.width = colWidth[colNo] + 'px';
					self.removeChildWidth(headRow.childNodes[0], colWidth[colNo]);
				}
			}
		}
	}
	var tblCokies = getCookie(cookieid + 'F');
//	console.log('getCookieF = ' + tblCokies);
	if (tblCokies != "") {
		tableParent.width = tblCokies;
	}
	
	
	var tableParentIndx; // current dragging column
	var dragColumnNo; // current dragging column
	var cookieid;
	var dragX;        // last event X mouse coordinate
	var tableParent;

	var saveOnmouseup;   // save document onmouseup event handler
	var saveOnmousemove; // save document onmousemove event handler
	var saveBodyCursor;  // save body cursor property

	
	// ============================================================
	// methods

	// ============================================================
	// do changes columns widths
	// returns true if success and false otherwise
	this.changeColumnWidth = function(no, w) {
//		console.log("w= " + w);
		if (!dragColumns) return false;
		if (no < 0) return false;
		if (dragColumns.length < no) return false;
		if (parseInt(dragColumns[no].style.width.replace('px')) <= -w) return false;
		
		var tableParentCol1 = tableParent.firstChild.children[tableParentIndx];
		var tblWidth = tableParent.width;
		if(!tblWidth){
			tblWidth = tableParent.clientWidth;
		}
		tableParent.width = parseInt(tblWidth) + w;
//		tableParent.width = parseInt(tableParent.width) + w;
//		console.log("tableParent.width= " + tableParent.width);
		
		var changeWidth = parseInt(dragColumns[no].style.width.replace('px')) + w;
		dragColumns[no].style.width = changeWidth +'px';
		
		for (var rowNo=0; rowNo<table.tBodies[0].rows.length; rowNo++) {
			table.tBodies[0].rows[rowNo].cells[no].style.width = changeWidth +'px';
			
			var eleChild = table.tBodies[0].rows[rowNo].cells[no].childNodes;
			if (eleChild) self.addWidthStyle(eleChild[0], w);
		}
		self.addWidthStyle(dragColumns[no].childNodes[0], w);
		
		return true;
	}

	// ============================================================
	// do drag column width
	this.columnDrag = function(e) {
		var e = e || window.event;
		var X = e.clientX || e.pageX;
		if (!self.changeColumnWidth(dragColumnNo, X-dragX)) {
			// stop drag!
			self.stopColumnDrag(e);
		}

		dragX = X;
		// prevent other event handling
		preventEvent(e);
		return false;
	}

	// ============================================================
	// stops column dragging
	this.stopColumnDrag = function(e) {
		var e = e || window.event;
		if (!dragColumns) return;

		// restore handlers & cursor
		document.onmouseup  = saveOnmouseup;
		document.onmousemove = saveOnmousemove;
		document.body.style.cursor = saveBodyCursor;

		// remember columns widths in cookies for server side
		var colWidth = '';
		var separator = '';
		for (var i=0; i<dragColumns.length; i++) {
			colWidth += separator + parseInt( getWidth(dragColumns[i]) );
			separator = '+';
		}
		
		var tblColWidth = tableParent.width;
			
		setCookie(cookieid, colWidth);
		setCookie(cookieid + 'F', tblColWidth);
//		console.log('setCookie = ' + colWidth);
//		console.log('setCookieF = ' + tblColWidth);
		
		preventEvent(e);
		
		isResize = false;
	}

	// ============================================================
	// init data and start dragging
	this.startColumnDrag = function(e) {
		isresize = true;
		
		var e = e || window.event;

		// remember dragging object
		dragColumnNo = (e.target || e.srcElement).parentNode.cellIndex;
		dragX = e.clientX || e.pageX;

		// set up current columns widths in their particular attributes
		// do it in two steps to avoid jumps on page!
		var colWidth = new Array();
		for (var i=0; i<dragColumns.length; i++)
			colWidth[i] = parseInt( getWidth(dragColumns[i]) );
		for (var i=0; i<dragColumns.length; i++) {
			dragColumns[i].width = ""; // for sure
			dragColumns[i].style.width = colWidth[i] + "px";
		}

		saveOnmouseup       = document.onmouseup;
		document.onmouseup  = self.stopColumnDrag;

		saveBodyCursor             = document.body.style.cursor;
		document.body.style.cursor = 'w-resize';

		// fire!
		saveOnmousemove      = document.onmousemove;
		document.onmousemove = self.columnDrag;

		preventEvent(e);
	}
	
	// prepare table header to be draggable
	// it runs during class creation
	for (var i=0; i<dragColumns.length; i++) {
		dragColumns[i].style.position = "relative";
		var dragPoint = document.createElement('div');
		dragPoint.style.position = 'absolute';
		dragPoint.style.height = '20px';
		dragPoint.style.width = '2px';
		dragPoint.style.marginLeft = '0px';
		dragPoint.style.left = '100%';
		dragPoint.style.top = '0px';
		dragPoint.style.backgroundColor = '#000000';
		dragPoint.style.cursor = 'w-resize';
		dragPoint.style.zIndex = '10';
		dragPoint.style.display = 'block';
		dragPoint.style.className = 'rresize';
		dragPoint.onmousedown = this.startColumnDrag;
		dragColumns[i].appendChild(dragPoint);
	}
}

// select all tables and make resizable those that have 'resizable' class
var resizableTables = new Array();
function ResizableColumns() {
	// quit if this function has already been called
	if (arguments.callee.done) return;
    arguments.callee.done = true;
    
	if (_dgtimer) clearInterval(_dgtimer);
	if (_onDragCheckTimer) clearInterval(_onDragCheckTimer);
	
	var tables = document.getElementsByTagName('table');
	for (var i=0; tables.item(i); i++) {
		if (tables[i].className.match(/resizable/)) {
			// make table resizable
			resizableTables[resizableTables.length] = new ColumnResize(tables[i]);
			
		}
	}
}

var resetTableWidth = function() {
	if (typeof( resizableTables ) != "[object]") {
		for(var i = 0; i < resizableTables.length; i++) {
			resizableTables[i].clearCookies();
		}
	}
}

var reResize = function() {
	if (typeof( resizableTables ) != "[object]") {
		for(var i = 0; i < resizableTables.length; i++) {
			resizableTables[i].reResize();
		}
	}
}

var _onDragCheckTimer;

// init tables

if (document.addEventListener) {
	if (typeof dragLoadFinish == 'undefined') {
		document.addEventListener("onload", ResizableColumns, false);
	} else {
		_onDragCheckTimer = setInterval(function() {
	        if (dragLoadFinish) {
	        	ResizableColumns();
	        }
	    }, 10);
	}
}
else if (window.attachEvent) {
	if (typeof dragLoadFinish == 'undefined') {
		window.attachEvent("onload", ResizableColumns);
	} else {
		_onDragCheckTimer = setInterval(function() {
	        if (dragLoadFinish) {
	        	ResizableColumns();
	        }
	    }, 10);
	}
}

window.onload = ResizableColumns;

/* for Safari */
if (/WebKit/i.test(navigator.userAgent)) { // sniff
	if (typeof dragLoadFinish == 'undefined') {
		 var _dgtimer = setInterval(function() {
		        if (/loaded|complete/.test(document.readyState)) {
		        	ResizableColumns(); // call the onload handler
		        }
		    }, 10);
	} else {
		_onDragCheckTimer = setInterval(function() {
	        if (dragLoadFinish) {
	        	 var _dgtimer = setInterval(function() {
	        	        if (/loaded|complete/.test(document.readyState)) {
	        	        	ResizableColumns();
	        	        }
        	    }, 10);
	        }
	    }, 10);
	}
}

//document.body.onload = ResizableColumns;

//============================================================
//
// Usage. In your html code just include the follow:
//
//============================================================
// <table id='objectId'>
// ...
// </table>
// < script >
// var xxx = new ColumnDrag( 'objectId' );
// < / script >
//============================================================
//
// NB! spaces was used to prevent browser interpret it!
//
//============================================================

