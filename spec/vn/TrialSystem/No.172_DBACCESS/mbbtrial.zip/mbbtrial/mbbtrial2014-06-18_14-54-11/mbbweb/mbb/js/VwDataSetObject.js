/**
 * VwDataSetObject
 * 属性値セット
 */
LAST_MODIFIED('2004.10.26', '1.0.25');

/*
 * DataSet構造
 * DataSet.プロパティ文字列(小文字).value
 *                                       .customized
 *                                       .customizable
 *                                       .originalvalue
 */

/////////
///class

/**
 * 画面に配置したエレメントのデータを保持するオブジェクト
 * @param  :strId   文字型 編集画面上でのみ使用する仮ID
 *          strType 文字型 項目TYPE
 *          strName 文字型 項目ID
 * @return :
 */
function DataSet(strId, strType, strName){

  // プロパティの形式
  function Property(_value) {
    this.value = _value;
  }
  
  // タイプは大文字か小文字に統一
  strType = toTypeCase(strType);

  this.id   = new Property(strId);
  this.type = new Property(strType);
  if(strName != undefined) {
    this.name = new Property(strName);
  }
  
  //***:public method
  DataSet.prototype.isType               = fnIsType;               // 該当するタイプか調べる
  DataSet.prototype.getProperty          = fnGetProperty;          // プロパティを読み出す
  DataSet.prototype.setProperty          = fnSetProperty;          // プロパティに書き込み
  DataSet.prototype.getCustomProperty    = fnGetCustomProperty;    // カスタムプロパティの読み出し
  DataSet.prototype.setCustomProperty    = fnSetCustomProperty;    // カスタムプロパティの書き込み
  DataSet.prototype.getExtraProperty     = fnGetExtraProperty;     // DataSetの属性を読み出す
  DataSet.prototype.setExtraProperty     = fnSetExtraProperty;     // DataSetの属性に書き込み
  DataSet.prototype.getDefaultPropName   = fnGetDefaultPropName;   // 各項目TYPE毎の「初期値」プロパティ文字列
  DataSet.prototype.getItemCustomizable  = fnGetItemCustomizable;  // カスタマイズの可・不可を取得
  DataSet.prototype.getCustomizableItems = fnGetCustomizableItems; // 各カスタマイズ項目毎の可・不可を取得
  DataSet.prototype.getCustomizedProp    = fnGetCustomizedProp;    // カスタマイズされているかどうかを取得(プロパティ単位)
  DataSet.prototype.getCustomized        = fnGetCustomized;        // カスタマイズされているかどうかを取得
  DataSet.prototype.toString             = _toString;              // オブジェクトの文字列

  /**
   * 該当するタイプか調べる
   */
  function fnIsType(typeId){
    return (this.type.value == typeId);
  }
  
  /**
   * DataSetのプロパティを読み出す
   * @param  :_propertyId 文字型 プロパティ文字列
   * @return :プロパティ値
   */
  function fnGetProperty(_propertyId){

    var property = this[_propertyId];
    var val;
    
    //初期化されていないプロパティ時
    if(isArrayValue(_propertyId)){
      val = new Array();
      if(property) {
        var ref = property.value;
        if(ref) {
          for(var j in ref){
            val[j] = ref[j];
          }
        }
      }
      return val;
    } else {
      val = ''
      if(property && property.value != undefined) {
        val = property.value;
      }
    }
    
    return val;

  }

  /**
   * DataSetのプロパティを書き込む
   * @param  :_propertyId 文字型 プロパティ文字列
   *          setValue           設定するプロパティ値
   * @return :
   */
  function fnSetProperty(_propertyId, setValue){
    //初期化されていないプロパティ時
    if(!this[_propertyId]){
      this[_propertyId] = new Property('');
    }

    var id = this.id.value;
    if(isArrayValue(_propertyId)){

      if(setValue.toString() != this[_propertyId].value.toString()) {
        _defaultDataSetEventHandler.propertyChanged(this.id, _propertyId);
      }
      var val = new Array();
      var ref = this[_propertyId].value;
      for(var j in setValue){
        val[j] = setValue[j];
      }      
      this[_propertyId].value = val;

    }else{
      switch(typeof(setValue)) {
      case 'string':
        break;
      case 'number':
        setValue = setValue.toString();
        break;
      case 'undefined':
        setValue = '';
        break;
      case 'object':
        if(setValue == null) {
          setValue = '';
        }
        setValue = setValue.toString();
        break;
      }
      //if(setValue == null || setValue == 'undefined'){
      //  setValue = '';
      //}

      if((!this[_propertyId].value && setValue != '') ||
        (this[_propertyId].value && this[_propertyId].value != setValue)) {
        // プロパティ値が変更されたことを通知
        _defaultDataSetEventHandler.propertyChanged(this.id, _propertyId);
      }

      this[_propertyId].value = setValue;

    }
  }

  /**
   * 指定カスタムプロパティの読み出し
   * @param  :_propertyId
   *          strCustomProperty(customized, customizable, originalvalue)
   * @return :
   */
  function fnGetCustomProperty(_propertyId, strCustomProperty){
    //初期化されていないプロパティ時
    if(!this[_propertyId]){
      this[_propertyId] = new Object();
    }

    if(!this[_propertyId][strCustomProperty]){
      return '';
    }

    return this[_propertyId][strCustomProperty];

  }

  /**
   * 指定カスタムプロパティの書き込み
   * @param  :_propertyId
   *          strCustomProperty(customized, customizable, originalvalue)
   *          strValue
   * @return :
   */
  function fnSetCustomProperty(_propertyId, strCustomProperty, strValue){
    //初期化されていないプロパティ時
    if(!this[_propertyId]){
      this[_propertyId] = new Object();
    }

    if(!strValue){
      strValue = '';
    }

    this[_propertyId][strCustomProperty] = strValue;

  }
  
  // Viewの属性でないDataSetの属性
  var EXTRAPROPERTIESID = 'extra properties';
  /**
   * Viewの属性でないDataSetの属性
   */
  function fnSetExtraProperty(propertyid, value) {
    if(!this[EXTRAPROPERTIESID]) {
      this[EXTRAPROPERTIESID] = {};
    }
    this[EXTRAPROPERTIESID][propertyid] = value;
  }

  /**
   * Viewの属性でないDataSetの属性
   */
  function fnGetExtraProperty(propertyid) {
    if(this[EXTRAPROPERTIESID]) {
      if(this[EXTRAPROPERTIESID][propertyid] != undefined) {
        return this[EXTRAPROPERTIESID][propertyid];
      }
    }
    return '';
  }
    
  /**
   * 「初期値」カスタマイズの属性名称取得
   * @param  :
   * @return :
   */
  function fnGetDefaultPropName(){
    return 'fieldvalue';
  }

  /**
   * 項目のカスタマイズ可・不可を取得
   * @param  :
   * @return :ブール true 可 , false 不可
   */
  function fnGetItemCustomizable(){
    //カスタマイズプロパティ決め打ち(left,visibility,value)
    //カスタマイズの可不可を取得getDefaultPropName
    if(this.getCustomProperty('left', 'customizable') == true) return true;
    if(this.getCustomProperty('visibility', 'customizable') == true) return true;
    if(this.getCustomProperty(this.getDefaultPropName(), 'customizable') == true) return true;
    if(this.getCustomProperty('maxlines', 'customizable') == true) return true;
    return false;
  }

  /**
   * 項目のプロパティ単位のカスタマイズ可・不可を取得
   * @param  :
   * @return :オブジェクト   構造 object.mobility(true/false)
   *                                    .visibility(true/false)
   *                                    .defaultvalue(true/false)
   *                                    .maxlines(true/false)
   */
  function fnGetCustomizableItems(){
    var rtnObj = new Object();
    if(this.getCustomProperty('left', 'customizable') == true){
      rtnObj.mobility = true;
    }else{
      rtnObj.mobility = false;
    }
    if(this.getCustomProperty('visibility', 'customizable') == true){
      rtnObj.visibility = true;
    }else{
      rtnObj.visibility = false;
    }
    if(this.getCustomProperty(this.getDefaultPropName(), 'customizable') == true){
      rtnObj.defaultvalue = true;
    }else{
      rtnObj.defaultvalue = false;
    }
    if(this.getCustomProperty('maxlines', 'customizable') == true){
      rtnObj.maxlines = useMaxLines(this.getProperty('tablemode'));
    }else{
      rtnObj.maxlines = false;
    }
    return rtnObj;
  }

  /**
   * カスタマイズされているかどうかを取得(プロパティ単位)
   * @param  :
   * @return :rtnObj オブジェクト true(カスタマイズ済)/false(未カスタマイズ)
   *                              rtnObj.mobility
   *                                    .visibility
   *                                    .defaultvalue
   *                                    .maxlines
   */
  function fnGetCustomizedProp(){
    var rtnObj = new Object();
    //移動
    if(this.getProperty('left') != this.getCustomProperty('left', 'originalvalue') || 
       this.getProperty('top') != this.getCustomProperty('top', 'originalvalue')
    ){
      rtnObj.mobility = true;
    }else{
      rtnObj.mobility = false;
    }
    //表示
    var tmpCurVisibility = this.getProperty('visibility');
    // @visible if(tmpCurVisibility == '') tmpCurVisibility = 'visible';
    var tmpOrgVisibility = this.getCustomProperty('visibility', 'originalvalue');
    // @visible if(tmpOrgVisibility == '') tmpOrgVisibility = 'visible';
    if(tmpCurVisibility != tmpOrgVisibility){
      rtnObj.visibility = true;
    }else{
      rtnObj.visibility = false;
    }
    //初期値
    if(this.getProperty(this.getDefaultPropName()) != this.getCustomProperty(this.getDefaultPropName(), 'originalvalue')){
      rtnObj.defaultvalue = true;
    }else{
      rtnObj.defaultvalue = false;
    }
    //行数
    if(useMaxLines(this.getProperty('tablemode'))){
      if(this.getProperty('maxlines') != this.getCustomProperty('maxlines', 'originalvalue')){
        rtnObj.maxlines = true;
      }else{
        rtnObj.maxlines = false;
      }
    }else{
      rtnObj.maxlines = false;
    }
    return rtnObj;
  }

  /**
   * カスタマイズされているかどうかを取得
   * @param  :
   * @return :true(カスタマイズ済)/false(未カスタマイズ)
   */
  function fnGetCustomized(){
    //プロパティ単位でチェック
    var tmpPropCustomized = this.getCustomizedProp();
    if(tmpPropCustomized.mobility){
      return true;
    }
    if(tmpPropCustomized.visibility){
      return true;
    }
    if(tmpPropCustomized.defaultvalue){
      return true;
    }
    if(tmpPropCustomized.maxlines){
      return true;
    }
    return false;
  }

  function _toString() {
    return inspectObject(this, 'value');
  }
}

/**
 * プロパティ変更時のイベントハンドラ
 */
function DataSetEventHandler() {
  DataSetEventHandler.prototype.propertyChanged = _propertyChanged;
  function _propertyChanged(elementId, propertyId) {
  }
}

/**
 * プロパティ変更時のイベントハンドラ実装
 */
var _defaultDataSetEventHandler = new DataSetEventHandler();

/**
 * プロパティ変更時のイベントハンドラ取得
 */
function getDefaultDataSetEventHandler() {
  return _defaultDataSetEventHandler;
}

