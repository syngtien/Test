/**
 * ヘルプ画面呼び出し用ライブラリ
 * ヘルプ画面を呼び出すページはこのjsファイルをインクルードすること。
 * このファイルの前にcommonutil.js, common.jsをインクルードすること
 */

/** 呼び元画面のIDのセット先テキストボックスのID */
var idfield = "";

/** 呼び元画面の2つ目のIDのセット先テキストボックスのID */
var idfieldSecond = "";

/** 呼び元画面のIDテキストボックスのID配列 */
var idfields = "";

/** 呼び元画面の名称のセット先テキストボックスのID */
var namefield = "";

/** 呼び元画面の2つ目の名称のセット先テキストボックスのID */
var namefieldSecond = "";

/** 呼び元画面の名称テキストボックスのID配列 */
var namefields = "";

/** セットする名称のプロパティID */
var namepropaty = "";

/** セットする2つ目の名称のプロパティID */
var namepropatySecond = "";

/** セットする値をシングルクォートで囲む */
var valueShouldBeQuoted = false;

/* */
var QUOTEDOPTION = '#QUOTED';

/*
function lock(){
  locked = true;
}

function unlock(){
  locked = false;
}*/

/**
 * IDのセット先テキストボックスのIDを返す
 */
function getIdFieldId(){
  return idfield;
}

/**
 * 2つ目のIDのセット先テキストボックスのIDを返す
 */
function getIdFieldIdSecond(){
  return idfieldSecond;
}

/**
 * IDテキストボックスのID配列を返す
 */
function getIdFieldIds(){
  return idfields;
}

/**
 * 名称のセット先テキストボックスのIDを返す
 */
function getNameFieldId(){
  return namefield;
}

/**
 * 2つ目の名称のセット先テキストボックスのIDを返す
 */
function getNameFieldIdSecond(){
  return namefieldSecond;
}

/**
 * 名称テキストボックスのID配列を返す
 */
function getNameFieldIds(){
  return namefields;
}

/**
 * セットする名称のプロパティIDを返す
 */
function getNamePropertyId(){
  return namepropaty;
}

/**
 * セットする名称のプロパティIDを返す
 */
function getNamePropertyIdSecond(){
  return namepropatySecond;
}

/**
 * applicationIdからアクセスするURLを取得する
 */
function getURL(applicationId) {
  var urlstr="";
  urlstr="./appcontroller?APPLICATIONID=" + applicationId;
  try {
    var menuItemKey=document.forms[0].elements['_MENUITEMKEY'];
    if(!isEmpty(menuItemKey)){
      urlstr=urlstr+'&_MENUITEMKEY='+menuItemKey.value;
    }
  } catch(e) {
    alert(e);
  }
  return urlstr;
}
/*
 * 指定されたヘルプ画面を開く.
 * @param applicationId    アプリケーションID
 * @param idFieldId        IDテキストボックスのID
 * @param nameFieldId      名称テキストボックスのID
 * @param namePropertyId   名称プロパティID 
 * @param date             適用日
 * @param optionParameters 追加のパラメータ  
 *                           &パラメータ名=値&パラメータ名=値･･･で指定する
 * @param windowOptions    画面追加変更パラメータ 
 *                           パラメータ名=値,パラメータ名=値･･･で指定する
 */
function openHelp(applicationId, idFieldId, nameFieldId, namePropertyId,
      date, optionParameters, windowOptions) {
//  alert("enter");

//  if (locked){
//    return;
//  }
  valueShouldBeQuoted = false;

  var debug = true;
  var winoptions = "";

  var urlstr=getURL(applicationId);

  if (!isEmpty(date)){
    urlstr += "&DATE=" + date;
  }
  //if (debug){
//    alert(urlstr);
  //}
  //入力されていたらくっつける
  //最初の文字が&でなかったらくっつける
  
  if (!isEmpty(optionParameters)){
    var parmstr = "";
    if(optionParameters.charAt(0)=='&'){
      optionParameters = optionParameters.substring(1, optionParameters.length);
    }
    var paramarray = optionParameters.split('&');
    for(var i=0; i<paramarray.length; i++){
      var aParam = paramarray[i];
      if(aParam==QUOTEDOPTION){
        valueShouldBeQuoted = true;
      }else{
        parmstr += '&' + aParam;  
      }
    }
    //alert(parmstr);
    urlstr += parmstr;
  }
  //alert(urlstr);

  //if (debug){
//    urlstr = "./" + applicationId + ".html";
  //}

  if (isEmpty(idFieldId)){
    idfield = "";
  }else{
    idfield = idFieldId;
  }
        
  if (isEmpty(nameFieldId)){
    namefield = "";
  }else{
    namefield = nameFieldId;
  }

  if (isEmpty(namePropertyId)){
    namepropaty = "";
  }else{
    namepropaty = namePropertyId;
  }

  idfieldSecond = "";
  namefieldSecond = "";
  namepropatySecond = "";
  idfields = "";
  namefields = "";

  //alert(idfield);
//  alert(windowOptions);
//  alert(window.name);

  //複数ブラウザで同時に同じヘルプを開くことを可能とするため、名前なしとする
  var win = openWindow(urlstr, windowOptions, "");
  
  //lock();

}

/*
 * 指定されたヘルプ画面を開く.
 * @param applicationId    アプリケーションID
 * @param idFieldId        1つ目のIDテキストボックスのID
 * @param idFieldIdSecond  2つ目のIDテキストボックスのID

 * @param nameFieldId        1つ目の名称テキストボックスのID
 * @param nameFieldIdSecond  2つ目の名称テキストボックスのID
 * @param namePropertyId         1つ目の名称プロパティID 
 * @param namePropertyIdSecond   2つ目の名称プロパティID 
 * @param date             適用日
 * @param optionParameters 追加のパラメータ  
 *                           &パラメータ名=値&パラメータ名=値･･･で指定する
 * @param windowOptions    画面追加変更パラメータ 
 *                           パラメータ名=値,パラメータ名=値･･･で指定する
 */
function openHelpTwoIds(applicationId, idFieldId, idFieldIdSecond,
      nameFieldId, nameFieldIdSecond, namePropertyId, namePropertyIdSecond,
      date, optionParameters, windowOptions) {
//  alert("enter");

//  if (locked){
//    return;
//  }

  valueShouldBeQuoted = false;
  var debug = true;
  var winoptions = "";

  var urlstr=getURL(applicationId);
  
  if (!isEmpty(date)){
    urlstr += "&DATE=" + date;
  }
  //if (debug){
//    alert(urlstr);
  //}
  //入力されていたらくっつける
  //最初の文字が&でなかったらくっつける
  if (!isEmpty(optionParameters)){
    var parmstr = "";
    if(optionParameters.charAt(0)=='&'){
      optionParameters = optionParameters.substring(1, optionParameters.length);
    }
    var paramarray = optionParameters.split('&');
    for(var i=0; i<paramarray.length; i++){
      var aParam = paramarray[i];
      if(aParam==QUOTEDOPTION){
        valueShouldBeQuoted = true;
      }else{
        parmstr += '&' + aParam;  
      }
    }
    //alert(parmstr);
    urlstr += parmstr;
  }
  //alert(urlstr);

  //if (debug){
//    urlstr = "./" + applicationId + ".html";
  //}

  if (isEmpty(idFieldId)){
    idfield = "";
  }else{
    idfield = idFieldId;
  }

  if (isEmpty(idFieldIdSecond)){
    idfieldSecond = "";
  }else{
    idfieldSecond = idFieldIdSecond;
  }

  if (isEmpty(nameFieldId)){
    namefield = "";
  }else{
    namefield = nameFieldId;
  }

  if (isEmpty(nameFieldIdSecond)){
    namefieldSecond = "";
  }else{
    namefieldSecond = nameFieldIdSecond;
  }

  if (isEmpty(namePropertyId)){
    namepropaty = "";
  }else{
    namepropaty = namePropertyId;
  }
//  alert(namepropaty);

  if (isEmpty(namePropertyIdSecond)){
    namepropatySecond = "";
  }else{
    namepropatySecond = namePropertyIdSecond;
  }

  idfields = "";
  namefields = "";

//  alert(namepropatySecond);

  //alert(idfield);
//  alert(windowOptions);

  //複数ブラウザで同時に同じヘルプを開くことを可能とするため、名前なしとする
  var win = openWindow(urlstr, windowOptions, "");  

}

/*
 * 指定されたヘルプ画面を開く.
 * @param applicationId    アプリケーションID
 * @param idFieldIds        IDテキストボックスのID配列
 *            引数の指定は以下のように行う。
 *            new Array(propertyId, propertyId, ･･･ , valueId, valueId･･･)
 *            配列の前半に設定先プロパティIDを入れる。
 *            後半に設定元となるヘルプ画面上のプロパティIDを入れる。
 *            プロパティIDと値プロパティIDの個数は同じになっていることを前提とする。
 * @param nameFieldIds       名称テキストボックスのID配列
 *            引数はidFieldIdsと同様に、
 *            配列の前半に設定先名称プロパティIDを入れる。
 *            後半に設定元となるヘルプ画面上の名称プロパティIDを入れる。
 * @param date             適用日
 * @param optionParameters 追加のパラメータ  
 *                           &パラメータ名=値&パラメータ名=値･･･で指定する
 * @param windowOptions    画面追加変更パラメータ 
 *                           パラメータ名=値,パラメータ名=値･･･で指定する
 */
function openHelpMultiIds(applicationId, idFieldIds, nameFieldIds,
      date, optionParameters, windowOptions) {
  valueShouldBeQuoted = false;
  var debug = true;
  var winoptions = "";

  var urlstr=getURL(applicationId);
  
  if (!isEmpty(date)){
    urlstr += "&DATE=" + date;
  }

  // 入力されていたらくっつける
  // 最初の文字が&でなかったらくっつける
  if (!isEmpty(optionParameters)){
    var parmstr = "";
    if(optionParameters.charAt(0)=='&'){
      optionParameters = optionParameters.substring(1, optionParameters.length);
    }
    var paramarray = optionParameters.split('&');
    for(var i=0; i<paramarray.length; i++){
      var aParam = paramarray[i];
      if(aParam==QUOTEDOPTION){
        valueShouldBeQuoted = true;
      }else{
        parmstr += '&' + aParam;  
      }
    }
    //alert(parmstr);
    urlstr += parmstr;
  }
  //alert(urlstr);

  if (isEmpty(idFieldIds)) {
    idfields = "";
  } else {
    idfields = idFieldIds;
  }

  if (isEmpty(nameFieldIds)) {
    namefields = "";
  } else {
    namefields = nameFieldIds;
  }

  //複数ブラウザで同時に同じヘルプを開くことを可能とするため、名前なしとする
  var win = openWindow(urlstr, windowOptions, "");  
}

/*
 * エレメントに値を設定する.
 * @param _id    エレメントのID
 * @param _value      設定する値
 */
function setValueById(_id, _value) {
	var element = document.getElementById(_id);
	if (!element) {
		return;
	}
	//alert(element.nodeName);

	//判断は簡略化している
	var browsertype = -1;
  var uName = navigator.userAgent;
	if (uName.indexOf("Safari") > -1) {
		browsertype = 6;
	} else if (uName.indexOf("MSIE") > -1) {
		browsertype = 1;
  } else if (uName.indexOf("Opera") > -1) {
		browsertype = 5;
	} else if (uName.indexOf("Mozilla") > -1) {
		browsertype = 2;
  } else if (uName.indexOf("Netscape") > -1) {
		browsertype = 3;
  }

  if(valueShouldBeQuoted) {
    if(element.nodeName == 'SPAN'){
			if(browsertype==1){
				element.innerText = '\'' + escapeJavaScript(_value) + '\'';
				if(element.onchange)element.onchange();
			}else if(browsertype==2 || browsertype==3){
				//本当はhtml escapeをしないといけない
				element.innerHTML = '\'' + escapeJavaScript(_value) + '\'';
				if(element.onchange)element.onchange();
			}
		} else {
			element.value = '\'' + escapeJavaScript(_value) + '\'';
			if(element.onchange)element.onchange();
		}
  } else {
		if(element.nodeName == 'SPAN'){
//alert('browsertype=' +browsertype);
			if(browsertype==1){
				element.innerText = _value;
				if(element.onchange)element.onchange();
			}else if(browsertype==2 || browsertype==3){
				//本当はhtml escapeをしないといけない
				element.innerHTML = _value;
				if(element.onchange)element.onchange();
			}
		} else {
			element.value = _value;
			if(element.onchange)element.onchange();
		}
	}
  }

/**
 * 特殊文字をJavaScript用にエスケープする
 * @param value
 * @return String
 */
function escapeJavaScript(value){
  if(!value) {
    return '';
  }
  var sb = '';
  for(var i = 0; i < value.length; i++) {
    var c = value.charAt(i);
    switch(c){
    case  '\\':
      sb += '\\\\';
      break;
    case '\'':
      sb += '\\\'';
      break;
    default:
      sb += c;
    }
  }
  return sb;
}
