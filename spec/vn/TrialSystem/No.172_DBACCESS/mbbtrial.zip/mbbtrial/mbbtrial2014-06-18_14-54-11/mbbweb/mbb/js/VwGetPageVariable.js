/**
 * VwGetPageVariable
 * ページ読み込み
 */
LAST_MODIFIED('2004.10.26', '1.0.25');

/**
 *  編集画面読込時の画面定義オブジェクト構築処理
 */
function getPageVariable(){
  //validateHeightByRows(_defaultPageDefinition);
  
  var oldstatus = window.status;
  var progressBar = new WindowStatusProgressBar(_defaultPageDefinition.pageItemCount * 7);

  
    /* 画面項目の階層 */
    var root = new HierarchyPageItem(0, '', '', _defaultPageDefinition, progressBar);

    _defaultPageDefinition.pageItemCount = 0;
    
    // 配下オブジェクトを再起生成しないためのフラグをリセット
    for(var i in _defaultPageDefinition.pageItems) {
      _defaultPageDefinition.pageItemCount++;
      var pageItem = _defaultPageDefinition.pageItems[i];
      if(pageItem.addedToHierarchy) {
        pageItem.addedToHierarchy = false;
      }
    }

    /* ページの定義 */
    var pageOriginal = getLoadPageDefinition(deepCopy(_defaultPageDefinition), root , progressBar);

    /* ページの定義 */
    var pageCustom = getLoadPageDefinition(makeCustomized(_defaultPageDefinition), root, progressBar);

    progressBar.release();

    pageCustom.showErrors();

    // 使用しているフォントをリストに追加
    /*
    for(var i in pageOriginal.pageItems) {
      if(pageOriginal.pageItems[i].properties['fontfamily']) {
        var fontname = pageOriginal.pageItems[i].properties['fontfamily'].value;
        if(!m_fontDefineArray[fontname]) {
          m_fontDefineArray[fontname] = '(' + fontname + ')';
        }
      }
    }
    */
    
    var marged = margeOriginalValue(pageCustom, pageOriginal);

    window.status = oldstatus;
    
    return marged;

    /**
     * カスタムにオリジナルのpage情報をマージ
     * @param  _custom,_original
     * @return マージされたオブジェクト
     */
    function margeOriginalValue(_custom,_original){
      for(var pageItemId in _original.pageItems) {
        var pageItem = _original.pageItems[pageItemId];
        for(var propertyId in pageItem.properties) {
          var property = pageItem.properties[propertyId];
          if(property.values) {
            _custom.pageItems[pageItemId].properties[propertyId].originalValues = property.values;
          } else {
            _custom.pageItems[pageItemId].properties[propertyId].originalValue = property.value;
          }
        }
      }
      return _custom;
    }

    /**
     * オブジェクトのディープコピー（参照先オブジェクトもコピー）を作成
     * @param  _original：コピー元オブジェクト
     * @return コピーされたオブジェクト
     */
    function deepCopy(_original){
      if(typeof(_original) == 'object'){
        var dupe = new Array();
        for(var i in _original){
            dupe[i] = deepCopy(_original[i]);
        }
        return dupe;
      }else{
        return _original;
      }
    }

    /**
     * カスタムページを作成
     * @param  _original：コピー元オブジェクト
     * @return コピーされたオブジェクト
     */
    function makeCustomized(_original){
      var custom = deepCopy(_original);
      for(var pageItemId in custom.pageItems) {
        for(var propertyId in custom.pageItems[pageItemId].properties) {
          var property = custom.pageItems[pageItemId].properties[propertyId];
          if(property.customizable) {
            if(typeof(property.customizedLoadValue) != 'undefined') {
              property.value = property.customizedLoadValue;
              property.loadValue = property.customizedLoadValue;
              property.customized = true;
            } else {
              property.customized = false;
            }
          }
        }
      }
      return custom;
    }
} 

/**
 * ページの定義を読み込む
 * @return 画面定義オブジェクト
 */
function getLoadPageDefinition(_page, _root, progressBar) {

    /* ページの定義 */
    var page = _page;
    
    // editStatusが存在するかどうかを目安にする。
    if(!page.editStatus) {
      // スクリプトが存在しなかった場合、<input>から読み込み
      page = new LoadPageDefinition('PAGEDATA');
    }

    if(!page.errors) {
      page.errors = new Array();
    }
    
    /* 画面項目の階層 */
    var root = _root;
    
    /* 編集画面上の絶対位置とのオフセット */
    var offsetTop = 0;
    
    /* 編集画面上の絶対位置とのオフセット */
    var offsetLeft = 0;

    /* rowをtopに変換する際の行のpxサイズ */
    var ROWSIZE = DISPLAYROWHEIGHT;

    // 階層順にソート
    var newPageItems = new Object();
    addChildPageItemReference(root, page.pageItems, newPageItems);
    page.pageItems = newPageItems;
    function addChildPageItemReference(_rt, _oldPageItems, _newPageItems) {
      for(var i in _rt.children) {
        if(_oldPageItems[i]) {
          _newPageItems[i] = _oldPageItems[i];
        }
        addChildPageItemReference(_rt.children[i], _oldPageItems, _newPageItems);
      }
    }
    
    var pageItemCount = 0;
    // type変換 form→frame
    for(var i in page.pageItems) {
      pageItemCount++;
      if(page.pageItems[i].pageItemTypeId == 'form') {
        if(page.pageItems[i].properties['method'] &&
           page.pageItems[i].properties['method'].loadValue.toLowerCase() == 'frame' ) {
          page.pageItems[i].pageItemTypeId = 'frame';
        }
      }
    }
    
    // デフォルトpageClass
    if(!page.pageClass) {
      page.pageClass = '0'; // 通常のページ
    }
    
    // 属性変換
    for(var i in root.children) {
      progressBar.update();

      var pageItem = page.pageItems[i];
      if(pageItem.pageItemTypeId == 'form') {
        pageItem.level = root.children[i].level;
        if(pageItem.properties.top) {
            offsetTop = pageItem.properties.top.value * ROWSIZE;
        }
        page.addProperty(pageItem, 'top', offsetTop);
        page.addProperty(pageItem, 'left', offsetLeft);
        convertLoadValueToValue(pageItem);
        validateOffset(root.children[i], offsetTop, offsetLeft, progressBar);
        makePropertyArray(pageItem, 'jsfilename');
        makePropertyArray(pageItem, 'meta');

        defaultFormPageItemId = i;

      } else if(pageItem.pageItemTypeId == 'frame') {
        //
        pageItem.level = root.children[i].level;
        validateFrame(root.children[i]);
        makePropertyArray(pageItem, 'jsfilename');
        makePropertyArray(pageItem, 'meta');
        
        // 
        page.pageClass = '1'; // フレームのページ
        page.topPageItemId = i;
      } else {
        // form以外が 最上位階層にある
        //addError('E0004', new Array(i, pageItem.pageItemTypeId));
        //delete root.children[i];
        //delete pageItem;
      }
    }

    // formの高さが600pxより小さくしない。
    var lastForm = null;
    var rowsToAdd = 600 / DISPLAYROWHEIGHT;
    for(var i in root.children) {
        if(page.pageItems[i].pageItemTypeId == 'form') {
          lastForm = page.pageItems[i];
          rowsToAdd -= parseInt(lastForm.properties['rows'].value);
        }
    }
    if(lastForm && 0 < rowsToAdd) {
      lastForm.properties['rows'].value = parseInt(lastForm.properties['rows'].value) + rowsToAdd;
    }
    if(lastForm && lastForm.properties['rows'].value < lastForm.properties['rows'].loadValue) {
      lastForm.properties['rows'].value = lastForm.properties['rows'].loadValue;
    }
   
    page.errPageItemId = new Object();
    var samples = new PageItemTypePropertySamples();
    for(var i in page.pageItems) {
        progressBar.update();
      
        // 変換するtag#を取得しておく
        var tags = getTags(page.pageItems[i]);
        
        // 不要な属性を削除
        if(page.pageItems[i].parentPageItemTypeId &&
           page.pageItems[i].parentPageItemTypeId == 'table') {
            samples.diet('cell', page.pageItems[i].properties);
        } else {
          if(samples.isValidType(page.pageItems[i].pageItemTypeId)) {
            samples.diet(page.pageItems[i].pageItemTypeId, page.pageItems[i].properties);
          } else {
            addError('E0008', new Array(page.pageItems[i].pageItemTypeId));
            page.errPageItemId[i] = page.pageItems[i];
          }
        }
        
        // 一時使用したtableのセル情報を削除
        if(page.pageItems[i].pageItemTypeId == 'table') {
            delete page.pageItems[i].panel;
        }

        // %tag%を変換
        for(var tag in tags) {
            convertTag(page.pageItems[i], tag, tags[tag]);
        }

        // 属性変換前の値を削除
        for(var propertyId in page.pageItems[i].properties) {
            if(page.pageItems[i].properties[propertyId].loadValue) {
                delete page.pageItems[i].properties[propertyId].loadValue;
            }
        }
    }
    
    // エラーチェック
    for(var i in page.pageItems) {
        progressBar.update();
      
      if(!page.pageItems[i].level) {
        addError('E0003', new Array(i, page.pageItems[i].pageItemTypeId));
        if(defaultFormPageItemId != '') {
          page.pageItems[i].parentPageItemId = ELEMENTID_FIRSTFORM;
        } else {
          page.errPageItemId[i] = page.pageItems[i];
        }
      }
    }

    for(var i in page.errPageItemId) {
      delete page.pageItems[i];
    }
    
    // bgcolorの設定（旧Viewツール対応）
    /* label,stringの表示の背景が透明になったらコメントをはずす. 保存時specified-bgcolorも保存するように変更
    for(var i in page.pageItems) {
      if(page.pageItems[i].pageItemTypeId == 'label') {

        if(page.pageItems[i].properties['bgcolor']) {
          var property = page.pageItems[i].properties['bgcolor'];
          if(!property.specified && property.value != '') {
            if(property.value == getParentBgColor(page.pageItems[i].parentPageItemId)) {
              property.value = '';
            }
          }
        }
      }
    }
    */
    
    return page;
    //

    function getParentBgColor(_id) {
      if(page.pageItems[_id]) {
        if(page.pageItems[_id].properties['bgcolor']) {
          var property = page.pageItems[_id].properties['bgcolor'];
          if(property.value != '') {
            return property.value;
          }
        }
        return getParentBgColor(page.pageItems[_id].parentPageItemId);
      }
      return '';
    }
    
    function addError(_id, _prms) {

      var index = page.errors.length;
      page.errors[index] = new Object();
      page.errors[index].id = _id;
      page.errors[index].msg = getMessage(_id, _prms);
    }
    
    /* %tag#%変換 */
    function convertTag(_pageItem, _tagId, _tagName) {
        var property;
        for(var i in _pageItem.properties) {
            property = _pageItem.properties[i];
            if(property.value) {
              property.value = tagReplace(property.value,  _tagId, _tagName);
            } else if(property.values) {
              for(var val in property.values) {
                property.values[val] = tagReplace(property.values[val],  _tagId, _tagName);
              }
            }
        }
        for(var i in _pageItem.literalProperties) {
            property = _pageItem.literalProperties[i];
            for(var lang in property) {
              if(property.langIds[lang].value) {
                property.langIds[lang].value = tagReplace(property.langIds[lang].value,  _tagId, _tagName);
              } else if(property.langIds[lang].values) {
                for(var val in property.langIds[lang].values) {
                  property.langIds[lang].values[val] = tagReplace(property.langIds[lang].values[val],  _tagId, _tagName);
                }
              }
            }
        }
        if(_pageItem.frames) {
          for(var i in _pageItem.frames) {
            var frame = _pageItem.frames[i];
            for(var frameProperty in frame) {
              if(frameProperty != 'pageItem') {
                frame[frameProperty] = tagReplace(frame[frameProperty],  _tagId, _tagName);
              }
            }
          }
        }
        
        function tagReplace(_str, _tagId, _tagName) {
            return stringReplace(_str, '%' + _tagId + '%', '<%' + _tagName + '%>');
        }
    }

    /*
     *
     */
    function stringReplace(str, strbef, straft) {
        var ret = '';
        var left;
        var right = str;
        var idx;
        
        while(0 < right.length){
            
            idx = right.indexOf(strbef);
            if(idx < 0){
                break;
            }
            left = right.substring(0, idx);
            right = right.substring(idx + strbef.length, right.length);
                        
            ret = ret + left + straft;
        }
        ret = ret + right;
        
        return ret;
    }
    
    /* %tag#%配列取得 */
    function getTags(_pageItem) {
        var tags = new Object();
        for(var i = 0; _pageItem.properties[PROPERTYIDPREFIX_TAG + i]; i++) {
            tags[PROPERTYIDPREFIX_TAG + i] = _pageItem.properties[PROPERTYIDPREFIX_TAG + i].value;
        }
        for(var i = 0; _pageItem.properties[PROPERTYIDPREFIX_TAGCUSTOM + i]; i++) {
            tags[PROPERTYIDPREFIX_TAGCUSTOM + i] = _pageItem.properties[PROPERTYIDPREFIX_TAGCUSTOM + i].value;
        }
        return tags;
    } 

    /*
     *
     */
    function convertLoadValueToValue(_pageItem, _propertyId) {
      var property = null;

      if(_propertyId) {
        convertLoadValueToValueByPropertyId(_pageItem, _propertyId);
      } else {
        for(var p in m_propertyConversion) {
          convertLoadValueToValueByPropertyId(_pageItem, p);
        }
      }
      
      function convertLoadValueToValueByPropertyId(_pageItem, _propertyId) {
        var viewp = convertToViewPropertyId(_propertyId, _pageItem.pageItemTypeId);
        if(_pageItem.properties[viewp]) {
          convertByProperty(_pageItem.properties[viewp], _propertyId);
        }
        
        if(_pageItem.literalProperties[viewp]) {
          for(var langId in _pageItem.literalProperties[viewp]) {
            convertByProperty(_pageItem.literalProperties[viewp][langId], _propertyId);
          }
        }
      }

      function convertByProperty(_property, _propertyId) {
        if(_property.loadValue) {
          _property.value = convertToViewEditorPropertyValue(_property.loadValue, _propertyId);
        }
      }
    }

    /* frame配下の属性変換 */
    function validateFrame(_node) {
      
      var pageItem = page.pageItems[_node.self];
      var direction = 'rows';
      var childdirection = '';
      
      // direction チェック
      if(pageItem.properties['direction']) {
        direction = pageItem.properties['direction'].value;
        if(direction == 'cols') {
          childdirection = 'rows';
        } else {
          childdirection = 'cols';
        }
      } else {
        // directionがないのでエラー
        pageItem.properties['direction'] = new Object();
        pageItem.properties['direction'].value = direction;
        addError('E0005', new Array('direction', 'フレーム', _node.self));
      }

      // colsrows チェック
      if(pageItem.properties['colsrows']) {

      } else {
        // colsrowsがないのでエラー
        pageItem.properties['colsrows'] = new Object();
        pageItem.properties['colsrows'].value = '*,*';
        addError('E0005', new Array('colsrows', 'フレーム', _node.self));
      }

      for(var i in _node.children) {
        var childPageItem = page.pageItems[i];
        childPageItem.level = _node.children[i].level;
        
        // direction の設定
        if(childPageItem.properties['direction']) {
          if(childdirection != '' && childdirection != childPageItem.properties['direction'].value) {
            // directionが違っているので訂正した
            addError('E0015', new Array(i, 'フレーム', 'direction'));
          }
        } else {
          // directionがないのでエラー
          childPageItem.properties['direction'] = new Object();
          addError('E0005', new Array('direction', 'フレーム', i));
        }
        childPageItem.properties['direction'].value = childdirection;
        
        validateFrame(_node.children[i]);
      }
      makeFrames(pageItem, page.pageItems);
    }
    
    /* framesに配下フレームの情報をまとめる */
    function makeFrames(_pageItem, _pageItems) {
      _pageItem.frames = new Array();
      var colsrows = null;
      if(_pageItem.properties['colsrows']) {
        colsrows = _pageItem.properties['colsrows'].loadValue.split(',');
      } else {
        colsrows = new Array('*', '*');
      }
      
      for(var i = 0; i < colsrows.length; i++) {
        _pageItem.frames[i] = new Object();
        _pageItem.frames[i].frameflag =      getValueForIndex(_pageItem, 'frameflag', i, '0');
        _pageItem.frames[i].framename =      getValueForIndex(_pageItem, 'framename', i, '');
        _pageItem.frames[i].framesrc =       getValueForIndex(_pageItem, 'framesrc', i, '');
        _pageItem.frames[i].frameresize =    getValueForIndex(_pageItem, 'frameresize', i, '');
        _pageItem.frames[i].framescrolling = getValueForIndex(_pageItem, 'framescrolling', i, 'auto');
        if(_pageItem.frames[i].frameflag == '1') {
          for(var id in _pageItems) {
            if(_pageItems[id].properties['name'] &&
               _pageItems[id].properties['name'].value == _pageItem.frames[i].framename) {
              _pageItem.frames[i].pageItem = _pageItems[id];
              break;
            }
          }
        }
      }

      function getValueForIndex(_pageItem, _propertyId, index, defaultValue) {
        if(_pageItem.properties[_propertyId + '-' + index]) {
          return _pageItem.properties[_propertyId + '-' + index].value;
        } else {
          return defaultValue;
        }
      }
    }
        
    /* form,panel配下の属性変換 */
    function validateOffset(_node, _offsetTop, _offsetLeft, progressBar) {
        var rows = 1;
        var offsetTop = 0;
        var offsetLeft = 0;
        var currentRow = 0;
        var currentRows = 1;
        
        for(var id in _node.children) {
          progressBar.update();

            if(page.pageItems[id].pageItemTypeId == 'empty') {
              if(page.pageItems[id].properties.row) {
                if(rows <= parseInt(page.pageItems[id].properties.row.value)) {
                  rows = parseInt(page.pageItems[id].properties.row.value) + 1;
                }
              }
                delete page.pageItems[id];
                continue;
            }
            var pageItem = page.pageItems[id];
            pageItem.level = _node.children[id].level;
            offsetTop = 0;
            offsetLeft = 0;
            if(pageItem.properties.row) {
                if(isNaN(pageItem.properties.row.loadValue)) {
                  addError('E0007', new Array(id, 'row', pageItem.properties.row.loadValue, 
                                                        pageItem.pageItemTypeId));
                } else if(0 > parseInt(pageItem.properties.row.loadValue)) {
                  addError('E0007', new Array(id, 'row', pageItem.properties.row.loadValue, 
                                                        pageItem.pageItemTypeId));
                  offsetTop = 0;
                  currentRow = 0;
                } else {
                  offsetTop = pageItem.properties.row.value * ROWSIZE;
                  currentRow = parseInt(pageItem.properties.row.loadValue);
                }
                delete pageItem.properties.row.value;
            }
            if(pageItem.properties.left) {
                if(isNaN(pageItem.properties.left.loadValue)) {
                  addError('E0007', new Array(id, 'left', pageItem.properties.left.loadValue, 
                                                         pageItem.pageItemTypeId));
                } else if(0 > parseInt(pageItem.properties.left.loadValue)) {
                  addError('E0007', new Array(id, 'left', pageItem.properties.left.loadValue, 
                                                         pageItem.pageItemTypeId));
                  offsetLeft = 0;
                } else {
                  offsetLeft = pageItem.properties.left.value * 1;
                }
            } else {
                //addError('E0005', new Array('left', i));
            }
            page.addProperty(pageItem, 'top', _offsetTop + offsetTop);
            page.addProperty(pageItem, 'left', _offsetLeft + offsetLeft);
            
            convertLoadValueToValue(pageItem);
            
            if(pageItem.pageItemTypeId == 'table') {
                if(pageItem.properties.groupid) {
                    page.addProperty(pageItem, 'name', pageItem.properties.groupid.loadValue);
                }
                //convertLoadValueToValue(pageItem, 'borderstyle');
                validateCellOffset(_node.children[id], _offsetTop + offsetTop, _offsetLeft + offsetLeft, progressBar);
            }
            
            if(pageItem.pageItemTypeId == 'panel') {
                pageItem.parentPageItemTypeId = page.pageItems[pageItem.pageItemId].pageItemTypeId;
                validateOffset(_node.children[id], _offsetTop + offsetTop, _offsetLeft + offsetLeft, progressBar);


                if(pageItem.properties.rows &&
                   !pageItem.properties.height) {

                    page.addProperty(pageItem, 'height', 
                      pageItem.properties.rows.loadValue * ROWSIZE);
                }
                
            }
            if(pageItem.pageItemTypeId == 'list' ||
               pageItem.pageItemTypeId == 'combo' ||
               pageItem.pageItemTypeId == 'radio') {
                makePropertyArray(pageItem, 'cell');
            }
            if(pageItem.pageItemTypeId == 'radio') {
                makePropertyArray(pageItem, 'accesskey', 'acckey');
            }
            if(pageItem.pageItemTypeId == 'applet' ||
               pageItem.pageItemTypeId == 'embed' ||
               pageItem.pageItemTypeId == 'object') {
                makePropertyArray(pageItem, 'params');
                makePropertyArray(pageItem, 'otherparams');
            }
            if(pageItem.pageItemTypeId == 'object') {
                makePropertyArray(pageItem, 'embedparams');
                makePropertyArray(pageItem, 'embedotherparams');
            }
            //samples.diet(pageItem.pageItemTypeId, pageItem.properties);
            
            currentRows = 1;
            if(pageItem.properties.rows) {
                currentRows = parseInt(pageItem.properties.rows.value);
            }
            
            if(rows <= currentRow + currentRows) {
              rows = currentRow + currentRows;
            }
        } //for(var id in _node.children) {
        
        page.addProperty(page.pageItems[_node.self], 'rows', rows);
    }

    /* table配下の属性変換 */
    function validateCellOffset(_node, _offsetTop, _offsetLeft, progressBar) {
        var maxrows = 1;
        var maxcols = 1;
        var rows = new Array();
        var row = 0;
        var flgModeSimple = false;
        var table = page.pageItems[_node.self];
        if(table.properties.mode &&
           table.properties.mode.value == 'MODE_SIMPLE' &&
           table.properties.maxrows) {
            flgModeSimple = true;
            maxrows = table.properties.maxrows.value * 1;
        } else {
          if(table.properties.titlerows) {
            maxrows = Number(table.properties.titlerows.value) + 1;
          }
        }
        if(table.properties.maxcols) {
            maxcols = table.properties.maxcols.value * 1;
        }
        table.panel = new Array();
        table.panel.maxrows = maxrows;
        table.panel.maxcols = maxcols;
        var offsetTop = 0;
        var widths = {};
        for(var i = 1; i <= maxrows; i++) {
            if(!flgModeSimple) {
              if(i == maxrows) {
                row = 0;
              } else {
                row = i;
              }
            } else {
              row = i;
            }
            rows[row] = 1;
            table.panel[row] = new Array();
            var offsetLeft = 0;
            for(var j = 1; j <= maxcols; j++) {
              progressBar.update();
              
                var id = getPageItemCellInTable(_node, row, j);
                if(id == '') {
                    addError('E0006', new Array(_node.self,row, j));
                    //continue;

                    if(i == 1) {
                      widths[j] = 20;
                    }
                    // 画面表示できるように、ダミー作成
                    id = getCellId(_node.self, i, j);
                    page.addPageItem(id, 'panel', _node.self);
                    var pageItem = page.pageItems[id];
                    page.addProperty(pageItem, 'row', i);
                    page.addProperty(pageItem, 'col', j);
                    page.addProperty(pageItem, 'width', widths[j]);
                    page.addProperty(pageItem, 'height', DISPLAYROWHEIGHT);
                    pageItem.addedToHierarchy = false;
                    _node.children[id] = new Object();
                    _node.children[id].children = new Object();
                    _node.children[id].self = id;
                } else {
                  var pageItem = page.pageItems[id];
                  if(pageItem.properties.width) {
                    if(i == 1) {
                      widths[j] = Number(pageItem.properties.width.value);
                    }
                  } else {
                      addError('E0005', new Array('width', id, pageItem.pageItemTypeId));
                      offsetLeft = offsetLeft + ROWSIZE;
                  }
                }
                pageItem.level = _node.level + 1;
                table.panel[row][j] = pageItem;
                pageItem.parentPageItemTypeId = table.pageItemTypeId;
                
                page.addProperty(pageItem, 'top', _offsetTop + offsetTop);
                page.addProperty(pageItem, 'left', _offsetLeft + offsetLeft);

                convertLoadValueToValue(pageItem);
                
                if(pageItem.pageItemTypeId == 'panel') {
                    validateOffset(_node.children[id], _offsetTop + offsetTop, _offsetLeft + offsetLeft, progressBar);
                }

                //if(pageItem.properties.width) {
                //    offsetLeft = offsetLeft + pageItem.properties.width.value * 1;
                //} else {
                //    addError('E0005', new Array('width', id, pageItem.pageItemTypeId));
                //    offsetLeft = offsetLeft + ROWSIZE;
                //}
                offsetLeft += widths[j];

                if(pageItem.properties.rows &&
                   !pageItem.properties.height) {

                    page.addProperty(pageItem, 'height', 
                      pageItem.properties.rows.loadValue * ROWSIZE);
                }
            }
            if(table.panel[row][1] &&
               table.panel[row][1].properties.rows) {

              var pageItem = table.panel[row][1];
              if(pageItem.properties.rows.loadValue) {
                offsetTop += pageItem.properties.rows.loadValue * ROWSIZE;
                rows[i] = parseInt(pageItem.properties.rows.loadValue);
              } else {
                offsetTop += ROWSIZE;
                rows[i] = ROWSIZE;
              }

            } else {

                addError('E0009', new Array(_node.self,row, 1));
                offsetTop = offsetTop + ROWSIZE;
            }
             
        }
        
        if(flgModeSimple) {
          rows[0] = 0;
          for(var i = 1; i <= maxrows; i++) {
            rows[0] += rows[i];
          }
        }
        page.addProperty(table, 'rows', rows[0]);

        function getPageItemCellInTable(_node, _row, _col) {
            var returnPageItemId = '';
            for(var i in _node.children) {
                if(page.pageItems[i]) {
                  if(page.pageItems[i].pageItemTypeId != 'panel') {
                     alert('tableの配下に不正なタイプ(' + page.pageItems[i].pageItemTypeId + ')がありました。');
                     delete page.pageItems[i];
                     delete _node.children[i];
                     continue;
                  }
                  if(page.pageItems[i].properties.row &&
                     page.pageItems[i].properties.row.loadValue * 1 == _row &&
                     page.pageItems[i].properties.col &&
                     page.pageItems[i].properties.col.loadValue * 1 == _col ) {
                    if(returnPageItemId != '') {
                      alert('tableの配下のパネル(row=' + page.pageItems[i].properties.row.loadValue
                                             + ',col=' + page.pageItems[i].properties.col.loadValue
                                             + ')が重複しています。');
                    }
                    returnPageItemId = i;
                  }
                }
            }
            return returnPageItemId;
        }
    }
    
    /* 配列属性の設定（jsfilename-#,cell-# 等） */ 
    function makePropertyArray(_pageItem, _propertyId, _replacePropertyId) {
        if(!_replacePropertyId) _replacePropertyId = _propertyId;
        _pageItem.properties[_replacePropertyId] = new Object();
        _pageItem.properties[_replacePropertyId].values = new Array();
        
        for(var index = 0; _pageItem.properties[_propertyId + '-' + index]; index++) {
            _pageItem.properties[_replacePropertyId].values[index] = _pageItem.properties[_propertyId + '-' + index].value;
            delete _pageItem.properties[_propertyId + '-' + index];
        }
    }    
}

/** 
 *  画面項目の階層構造を構築する
 */
function HierarchyPageItem(_level, _parentPageItemId, _pageItemId, _pageDefinition, progressBar) {
    /* 階層のレベル */ 
    this.level  = _level;

    /* 上位画面項目ID */
    this.parent = _parentPageItemId;

    /* 自分自身の画面項目ID */
    this.self   = _pageItemId;

    /* 下位画面項目 */
    this.children = new Object;

    // 配下オブジェクトを再起生成
    for(var i in _pageDefinition.pageItems) {
      var pageItem = _pageDefinition.pageItems[i];
      if(pageItem.parentPageItemId == _pageItemId) {
        if(pageItem.addedToHierarchy) {
          var msg = getMessage('E0014', new Array(i, pageItem.pageItemTypeId, pageItem.parentPageItemId));
          alert(msg);
          break;
        } else {
          pageItem.addedToHierarchy = true;
          this.children[i] = new HierarchyPageItem(this.level + 1, _pageItemId, i, _pageDefinition, progressBar);
        }
      }
    }
    
    progressBar.update();
    
    /* このオブジェクトの文字列表現 */
    HierarchyPageItem.prototype.toString = function() {
        return this.self
    }
    
    /* 下位階層から該当する画面項目IDを取得 */
    HierarchyPageItem.prototype.find = function(_id) {
        for(var i in this.children) {
            if(i == _id) {
                return this.children[i];
            } else {
                var findChild = this.children[i].find(_id);
                if(findChild != null) {
                    return findChild;
                }
            }   
        }
        return null;
    }
}

/**
 * 読み込んだ画面の定義を保持するオブジェクト
 */
function LoadPageDefinition(_formName) {

    // オブジェクトの数
    this.pageItemCount = 0;
    
    /* エラー追加メソッド */
    LoadPageDefinition.prototype.addError = function(_id,_prm) {
      _addError(this,_id,_prm);
    }

    /* 画面項目追加メソッド */
    LoadPageDefinition.prototype.addPageItem = _addPageItem;

    /* 属性追加メソッド */
    LoadPageDefinition.prototype.addProperty = _addProperty;

    /* Name属性追加メソッド*/
    LoadPageDefinition.prototype.addNameProperty = _addNameProperty;

    this.errors = new Array();
    

    /* 名前取得  */
    LoadPageDefinition.prototype.getPageName = function(langid) {
      try {
        return this.pageName[langid].value;
      } catch(e) {
      }
      return '';
    }
    
    /* 関数定義  */
    LoadPageDefinition.prototype.showErrors = function() {
      var msg = '';
      for(var i in this.errors) {
        msg += this.errors[i].msg + '\n'; 
      }
      if(msg != '') {
        alertMore(msg);
      }
    }
    
    if(!_formName || _formName == '') {
      this.pageId             = '';
      this.packageId          = '';
      //2003/08/18 timestampValue追加(更新チェック用)
      this.timestampValue     = '';
      this.fieldIdSource      = '';
      this.fieldIdSourceClass = '';
      //this.editStatus         = ''; //チェックに使用するので追加しない
      this.pageName  = new Object();
      this.pageItems = new Object();
      this.fields    = new Object();
      this.language  = new Object();
      this.session   = new Object();
      return;
    }
    
    /* 各値を_formNameフォーム内のエレメントから取得 */
    this.pageId             = getValueByName('PAGE.PAGEID');
    this.packageId          = getValueByName('PAGE.PACKAGEID');
    this.timestampValue     = getValueByName('PAGE.TIMESTAMPVALUE');
    this.fieldIdSource      = getValueByName('STATEGROUP.FIELDIDSOURCE');
    this.fieldIdSourceClass = getValueByName('STATEGROUP.FIELDIDSOURCECLASS');
    this.editStatus         = getValueByName('STATEGROUP.EDITSTATE');
    this.pageName  = getPageNames();
    this.pageItems = getPageItems();
    this.fields    = getFields();
    this.language  = getLanguage();
    this.session   =  new Object();
    
    var dispLangId = '';
    for(var i in this.language) {
        dispLangId = i;
        break;
    }
        
    /* 属性追加メソッド */
    function _addError(page,_id, _prms) {

      var index = page.errors.length;
      page.errors[index] = new Object();
      page.errors[index].id = _id;
      page.errors[index].msg = getMessage(_id, _prms);
    }
    
    /* 画面項目メソッド */
    function _addPageItem(_pageItemId, _pageItemTypeId, _parentPageItemId) {
        var newPageItem = new Object();
        newPageItem.pageItemId = _pageItemId
        newPageItem.pageItemTypeId = _pageItemTypeId;
        newPageItem.parentPageItemId = _parentPageItemId;
        newPageItem.properties = new Object();
        newPageItem.literalProperties = new Object();
        this.pageItems[_pageItemId] = newPageItem;
        this.pageItemCount++;
        return newPageItem;
    }

    /* 属性追加メソッド */
    function _addProperty(_pageItem, _propertyId, _value, _loadValue) {
        if(!_pageItem.properties[_propertyId]) {
            _pageItem.properties[_propertyId] = new Object();
        }
        _pageItem.properties[_propertyId].value = _value;
        if(_loadValue) {
            _pageItem.properties[_propertyId].loadValue = _loadValue;
        }
    }

    /* Name属性追加メソッド*/
    function _addNameProperty(_pageItem, _propertyId, _dispLangId, _value, _loadValue) {

        if(!_pageItem.properties[_propertyId]) {
            _pageItem.properties[_propertyId] = new Object();
        }
        _pageItem.properties[_propertyId].value = _value;
        if(_loadValue) {
            _pageItem.properties[_propertyId].loadValue = _loadValue;
        }

/*
        if(!_pageItem.literalProperties[_propertyId]) {
            _pageItem.literalProperties[_propertyId] = new Object();
        }
        
        if(!_pageItem.literalProperties[_propertyId].language) {
            _pageItem.literalProperties[_propertyId].language = new Object();
        }
        _pageItem.literalProperties[_propertyId].langIds[_dispLangId] = new Object();
        _pageItem.literalProperties[_propertyId].langIds[_dispLangId].value = _value;
*/
    }
    
    /* 画面項目の定義取得 */
    function getPageItems() {
        var pageItems = new Object();
        var pageItemIds = getValuesByName('PAGELAYOUT.PAGEITEMID');
        var pageItemTypes = getValuesByName('PAGELAYOUT.PAGEITEMTYPEID');
        var parentPageItemIds = getValuesByName('PAGELAYOUT.PARENTPAGEITEMID');
        for(var i in pageItemIds) {
            pageItems[pageItemIds[i]] = new Object();
            pageItems[pageItemIds[i]].pageItemId = pageItemIds[i];
            pageItems[pageItemIds[i]].pageItemTypeId = convertViewDataClassIdToPageItemTypeId(getStringValue(pageItemTypes, i));
            pageItems[pageItemIds[i]].parentPageItemId = getStringValue(parentPageItemIds, i);
            pageItems[pageItemIds[i]].properties = new Object();
            pageItems[pageItemIds[i]].literalProperties = new Object();
        }
        initProperties(pageItems);
        initNameProperties(pageItems);
        return pageItems;
    }

    /* ViewDataClassId を PageItemTypeId に変換 （旧Viewツール対応）*/
    function convertViewDataClassIdToPageItemTypeId(_viewDataClassId) {
        var typePos = _viewDataClassId.lastIndexOf('@');
        if(-1 < typePos) {
            return _viewDataClassId.substring(typePos + 1, _viewDataClassId.length).toLowerCase();
        } else {
            return _viewDataClassId;
        }
    }
    
    /* Propertiesの定義取得 */
    function initProperties(pageItems) {
        var pageItemIds = getValuesByName('PAGEITEMPROPERTY.PAGEITEMID');
        var propertyIds = getValuesByName('PAGEITEMPROPERTY.PROPERTYID');
        var values      = getValuesByName('PAGEITEMPROPERTY.VALUE');
        for(var i in pageItemIds) {
            if(pageItems[pageItemIds[i]]) {
                _addProperty(pageItems[pageItemIds[i]], 
                             getStringValue(propertyIds, i), 
                             getStringValue(values, i), 
                             getStringValue(values, i));
            }
        }
    }

    /* NamePropertiesの定義取得 */
    function initNameProperties(pageItems) {
        var pageItemIds = getValuesByName('PAGEITEMLITERALPROPERTY.PAGEITEMID');
        var propertyIds = getValuesByName('PAGEITEMLITERALPROPERTY.PROPERTYID');
        var dispLangIds = getValuesByName('PAGEITEMLITERALPROPERTY.DISPLANGID');
        var values      = getValuesByName('PAGEITEMLITERALPROPERTY.VALUE');
        var defaultDispLangId = 'JA';
        if(dispLangIds[0]) {
            defaultDispLangId = dispLangIds[0];
        }
        for(var i in pageItemIds) {
            if(defaultDispLangId != dispLangIds[i]) {
                continue;
            }
            if(pageItems[pageItemIds[i]]) {
                _addNameProperty(pageItems[pageItemIds[i]], 
                                 getStringValue(propertyIds, i), 
                                 getStringValue(dispLangIds, i), 
                                 getStringValue(values, i), 
                                 getStringValue(values, i));
            }
        }
    }

    /* 項目定義のフィールド一覧を取得 */
    function getPageNames() {
        var pageNames = new Object();
        var dispLangIds = getValuesByName('PAGENAME.DISPLANGID');
        var nameValues = getValuesByName('PAGENAME.NAMEVALUE');
        for(var i in dispLangIds) {
            pageNames[dispLangIds[i]] = getStringValue(nameValues, i);
        }
        return pageNames;
    }

    /* 項目定義のフィールド一覧を取得 */
    function getFields() {
        var fields = new Object();
        var fieldIds = getValuesByName('FIELDITEM.FIELDID');
        var fieldNames = getValuesByName('FIELDITEM.OFFICIALNAME');
        
        for(var i in fieldIds) {
            fields[fieldIds[i]] = getStringValue(fieldNames, i);
        }
        return fields;
    }

    /* 言語の一覧を取得 */
    function getLanguage() {
        var language = new Object();
        var langIds = getValuesByName('LANGUAGE.LANGID');
        var officialNames = getValuesByName('LANGUAGE.OFFICIALNAME');
        for(var i in langIds) {
            language[langIds[i]] = getStringValue(officialNames, i);
        }
        return language;
    }

    /* エレメントの名前により値を取得する */
    function getValueByName(elementName) {
        var vals = getValuesByName(elementName);
        if(vals.length == 0) {
            return '';
        } 
        return vals[0];
    }

    /* エレメントの名前により値の配列を取得する */
    function getValuesByName(elementName) {
        var values = new Array();
        //values.elementName = elementName;
        var el = window.document.forms[_formName][elementName];
        if(el) {
            if(el.length){
                for(var i = 0; i < el.length; i++) {
                    values[i] = el[i].value;
                }
            }else{
                values[0] = el.value;
            }
        }
        return values;
    }

    /* エレメントの名前により値の配列を取得する */
    function getStringValue(object, property) {
        if(object[property]) {
            return '' + object[property];
        } else {
            return '';
        }
    }
}


/** 
 *  画面項目タイプ別のプロパティ
 */
var pageItemTypePropertySamples = new PageItemTypePropertySamples();

function PageItemTypePropertySamples() {
    
    PageItemTypePropertySamples.prototype.isValidType = function(_pageItemTypeId) {
      
      if(isValidItemType(_pageItemTypeId)) {
        return true;
      }
      if(_pageItemTypeId == 'frame') {
        return true;
      }
      return false;
    }
    
    PageItemTypePropertySamples.prototype.diet = function(_pageItemTypeId,_properties) {
      if(!this.isValidType(_pageItemTypeId)) {
        return;
      }
      
      for(var i in _properties) {
        if(!isValidViewProperty(_pageItemTypeId, i)) {
          delete _properties[i];
        }
      }
    }
}

// サーバ出力用スクリプト

/**
 * 読み込みデータを保持するオブジェクト
 */
var _defaultPageDefinition = new LoadPageDefinition();

/**
 * 単一のデータ読み込み用
 * @param  :string _name  データの名前
 *          string _value データの値
 */
function addData(_name, _value) {

  if(_name == 'PAGE.PAGEID') {

    _defaultPageDefinition.pageId = _value;

  } else if(_name == 'PAGE.PACKAGEID') {

    _defaultPageDefinition.packageId = _value;

  } else if(_name == 'PAGE.LANGID') {

    _defaultPageDefinition.langId = _value;

  } else if(_name == 'PAGE.TIMESTAMPVALUE') {

    _defaultPageDefinition.timestampValue = _value;

  } else if(_name == 'STATEGROUP.FIELDIDSOURCE') {

    _defaultPageDefinition.fieldIdSource = _value;

  } else if(_name == 'STATEGROUP.FIELDIDSOURCECLASS') {

    _defaultPageDefinition.fieldIdSourceClass = _value;

  } else if(_name == 'STATEGROUP.EDITSTATE') {

    _defaultPageDefinition.editStatus = _value;

  } else {

    if(!_defaultPageDefinition.undefinedName) {
      _defaultPageDefinition.undefinedName = new Object();
    }

    _defaultPageDefinition.undefinedName[_name] = _value;

  }
}

/**
 * ページ名称読み込み用
 * @param  :string _dispLangId 言語ID
 *          string _propertyId プロパティID
 *          string _nameValue  ページ名称
 *
 * 2003/03/27 2個目の引数に_propertyIdを追加
 *            page.pageNameの構造を変更
 */
function addPageNameData(_dispLangId, _propertyId, _nameValue) {
  
//  _defaultPageDefinition.pageName[_dispLangId] = _nameValue;
  _defaultPageDefinition.pageName[_dispLangId]            = new Object();
  _defaultPageDefinition.pageName[_dispLangId].value      = _nameValue;
  _defaultPageDefinition.pageName[_dispLangId].propertyId = _propertyId;

}

/**
 * 言語マスタのデータ読み込み用
 * @param  :string _langId       言語ID
 *          string _officialName 言語名称
 */
function addLanguageData(_langId, _officialName) {

  _defaultPageDefinition.language[_langId] = _officialName;

}

/**
 * 画面項目のデータ読み込み用
 * @param  :string _pageItemId       画面項目ID
 *          string _pageItemTypeId   画面項目タイプID
 *          string _parentPageItemId 親画面項目ID
 */
function addPageItemData(_pageItemId, _pageItemTypeId, _parentPageItemId) {

  var type = convertViewDataClassIdToPageItemTypeId(_pageItemTypeId);

  _defaultPageDefinition.addPageItem(_pageItemId, type, ltrim(_parentPageItemId));

  
  /* ViewDataClassId を PageItemTypeId に変換 （旧Viewツール対応）*/
  function convertViewDataClassIdToPageItemTypeId(_viewDataClassId) {
      var typePos = _viewDataClassId.lastIndexOf('@');
      if(-1 < typePos) {
          return _viewDataClassId.substring(typePos + 1, _viewDataClassId.length).toLowerCase();
      } else {
          return _viewDataClassId;
      }
  }

  function ltrim(_str) {
    var ret = _str;
    while(0 < ret.length) {
      if(ret.charAt(0) == ' ') {
        ret = ret.substring(1);
      } else {
        break;
      }
    }
    return ret;
  }    
}

/**
 * 画面項目属性のデータ読み込み用
 * @param  :string _pageItemId 画面項目ID
 *          string _propertyId プロパティID
 *          string _value      値
 */
function addPageItemPropertyData(_pageItemId, _propertyId, _value, _enable) {

  if(_defaultPageDefinition.pageItems[_pageItemId]) {
    // （正常）pageItemId が存在

    // プロパティが存在しないとき作成
    if(!_defaultPageDefinition.pageItems[_pageItemId].properties[_propertyId]) {
      _defaultPageDefinition.pageItems[_pageItemId].properties[_propertyId] = new Object;
    }

    // 値を設定するプロパティの参照
    var property = _defaultPageDefinition.pageItems[_pageItemId].properties[_propertyId];
    
    // 設定値
    var value = '';
    if(_value != ' ') {
      value = _value;
    }
    
    // 値を設定
    if(!property.specified) {
      property.value = value;
      property.loadValue = value;
    }

    // @2004.06.17
/*    if(_propertyId == 'height') {
      var rowsproperty = _defaultPageDefinition.pageItems[_pageItemId].properties['rows'];
      if(!rowsproperty) {
        var intvalue = parseInt(value);
        //if(intvalue >= 40) {
          _defaultPageDefinition.pageItems[_pageItemId].properties['rows'] = rowsproperty = {};
          rowsproperty.value = '' + parseInt(intvalue / 20);
          rowsproperty.loadValue = rowsproperty.value;
        //}
      }
    }
*/
    // customize-xxxxの場合の処理
    setEnableForCustomizeProperty(_defaultPageDefinition.pageItems[_pageItemId], _propertyId, value);

    // specified-xxxxの場合の処理
    setSpecifiedValue(_defaultPageDefinition.pageItems[_pageItemId], _propertyId, value);

  } else {
    // （異常）pageItemId が存在しない。エラーデータとして登録
    _defaultPageDefinition.addError('E0010', new Array(_pageItemId, _propertyId, _value));
  }
}

/**
 * 画面項目文字属性のデータ読み込み用
 * @param  :string _pageItemId 画面項目ID
 *          string _propertyId プロパティID
 *          string _langId     言語ID
 *          string _value      値
 */
function addPageItemLiteralPropertyData(_pageItemId, _propertyId, _langId, _value) {
  addPageItemPropertyData(_pageItemId, _propertyId, _value);
  return;
}

var m_getPageVarAddFieldDataIndex = 0;
/**
 * 項目定義のデータ読み込み用
 * @param  :string _fieldId      フィールドID
 *          string _officialName フィールド名称
 */
function addFieldData(_fieldId, _officialName) {

//  _defaultPageDefinition.fields[_fieldId] = _officialName;
  _defaultPageDefinition.fields[m_getPageVarAddFieldDataIndex] = _fieldId + '::' + _officialName;
  m_getPageVarAddFieldDataIndex++;

}

/**
 * セッションデータ読み込み用
 * @param  :string _key   キー
 *          string _value 設定値
 */
function addSessionData(_key, _value) {

  _defaultPageDefinition.session[_key] = _value;

}

/**
 * セッションデータ取り出し用
 * @param  :string _key   キー
 * @return :設定値
 */
function getSessionData(_key) {
  if(_defaultPageDefinition.session[_key]) {
    return _defaultPageDefinition.session[_key];
  } else {
    return '';
  }
}

/**
 * 画面項目属性のデータ読み込み用
 * @param  :string _pageItemId 画面項目ID
 *          string _propertyId プロパティID
 *          string _value      値
 */
function addCustomPageItemPropertyData(_pageItemId, _propertyId, _value) {

  if(_defaultPageDefinition.pageItems[_pageItemId]) {
    // （正常）pageItemId が存在

    var pageItem = _defaultPageDefinition.pageItems[_pageItemId];

    // 設定値
    var value = '';
    if(_value != ' ') {
      value = _value;
    }
    
    // プロパティが存在しないとき作成しない
    if(!pageItem.properties[_propertyId]) {

      // カスタムタグは元のになくてもよい
      if(0 == _propertyId.indexOf(PROPERTYIDPREFIX_TAGCUSTOM)) {
        pageItem.properties[_propertyId] = new Object();
        pageItem.properties[_propertyId].value = value;
        return;
      } else {
        _defaultPageDefinition.addError('E0012', new Array(_pageItemId, _propertyId, _value, pageItem.pageItemTypeId));
        return;
      }
    }

    // 値を設定するプロパティの参照
    var property = pageItem.properties[_propertyId];
    
    // 値を設定
    if(property.customizable) {
      property.customizedLoadValue = value;
    } else {
      _defaultPageDefinition.addError('E0013', new Array(_pageItemId, _propertyId, _value, pageItem.pageItemTypeId));
      
    }

  } else {
    // （異常）pageItemId が存在しない。エラーデータとして登録
    _defaultPageDefinition.addError('E0011', new Array(_pageItemId, _propertyId, _value));

  }
}

/**
 * 画面項目文字属性のデータ読み込み用
 * @param  :string _pageItemId 画面項目ID
 *          string _propertyId プロパティID
 *          string _langId     言語ID
 *          string _value      値
 */
function addCustomPageItemLiteralPropertyData(_pageItemId, _propertyId, _langId, _value) {

  addCustomPageItemPropertyData(_pageItemId, _propertyId, _value);
  return;

}


/**
 * カスタマイズ可能設定
 * @param  :object _pageItem 画面項目
 *          string _propertyId プロパティID
 *          string _value      値
 */
function setEnableForCustomizeProperty(_pageItem, _propertyId, _value) {
  // 対象は customize-xxx だけ

  if(0 != _propertyId.indexOf('customize-')) {
    return;
  }

  // 対象は 値がenabledのものだけ
  if(_value != 'enabled') {
    return;
  }

  // タイプを取得
  var typeId = toTypeCase(_pageItem.pageItemTypeId);
  var customizeinfo = getCustomizeInfo(typeId);
  
  // この項目タイプで設定可能かチェック
  var exists = false;
  for(var i in customizeinfo.customProperties) {
    if(customizeinfo.customProperties[i] == _propertyId) {
      exists = true;
      break;
    }
  }
  if(!exists) {
    return;
  }

  // 各カスタマイズプロパティに対応するプロパティをカスタマイズ可能に設定する 
  
  if(_propertyId == 'customize-mobility') {
    makeEnabled(_pageItem, 'row');
    makeEnabled(_pageItem, 'left');
  }

  if(_propertyId == 'customize-visibility') {
    makeEnabled(_pageItem, 'visibility');
  }

  if(_propertyId == 'customize-defaultvalue') {
    var propid = convertToViewPropertyId('fieldvalue', typeId);
    makeEnabled(_pageItem, propid);
  }

  //2003/04/07 customize-maxlines追加
  if(_propertyId == 'customize-maxlines') {
    makeEnabled(_pageItem, 'maxlines');
  }

  function makeEnabled(_pageItem, _propertyId) {
    if(!_pageItem.properties[_propertyId]) {
      _pageItem.properties[_propertyId] = new Object();
      _pageItem.properties[_propertyId].value = '';
      _pageItem.properties[_propertyId].loadValue = '';
    }
    _pageItem.properties[_propertyId].customizable = true;
  }

}

/**
 * ツールでの設定と保存値の異なる属性値の設定
 * @param  :object _pageItem 画面項目
 *          string _propertyId プロパティID
 *          string _value      値
 */
function setSpecifiedValue(_pageItem, _propertyId, _value) {
  // 対象は specified-xxx だけ

  if(0 != _propertyId.indexOf('specified-')) {
    return;
  }

  // 対象の propertyId
  var propertyId = _propertyId.substring(10);
  
  var value = '';
  // ''は 'empty'で保存されている
  if(_value != 'empty') {
    value = _value;
  }
  
  // 
  if(!_pageItem.properties[propertyId]) {
    _pageItem.properties[propertyId] = new Object();
  }
  _pageItem.properties[propertyId].value = value;
  _pageItem.properties[propertyId].specified = true;

}

function validateHeightByRows(page) {
  if(DISPLAYROWHEIGHT == 20) return;
  for(var i in page.pageItems) {
    var pageItem = page.pageItems[i];
    if(pageItem.pageItemTypeId == 'form' ||
       pageItem.pageItemTypeId == 'panel' ||
       pageItem.pageItemTypeId == 'table') {

      var val = DISPLAYROWHEIGHT;
      var innerrows = pageItem.properties['innerrows'];
      if(innerrows && innerrows.loadValue) {
        val = innerrows.loadValue * DISPLAYROWHEIGHT;
      } else {
        var rows = pageItem.properties['rows'];
        if(rows && rows.loadValue) {
          val = rows.loadValue * DISPLAYROWHEIGHT;
        } else {
          var height = pageItem.properties['height'];
          if(height && height.loadValue) {
            // innerrowsが存在しないバージョンでは必ず 行の高さは20
            val = parseInt(height.loadValue / 20) * DISPLAYROWHEIGHT;
          }
        }
      }
      var height = pageItem.properties['height'];
      if(!height) {
        pageItem.properties['height'] = {};
      }
      pageItem.properties['height'].value = val;
    }
  }
}

