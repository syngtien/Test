/**
 *  共通JavaScript
 */
 
	var NODATASENDOPTION = "#NODATASEND";
	var ONSUBMITOPTION = "#ONSUBMIT";
	var noConfirm = false;
	var locked = false;
	var locktimeout = 1000;
	var winHeight_ = 540;
	var winWidth_ = 840;
	var confirmDialogMessage = "\nStill continue to process even if alert came out?";
	var confirm1Message = "Is it OK to register?";
	var confirm2Message = "Is it OK to modify?";
	var confirm3Message = "Is it OK  to delete?";

/**
 * PDFを表示するウィンドウを開く.
 * @param processId     プロセスID
 * @param processMode   プロセスモード
 * @param pageId        ページID
 * @param optionParams  クエリーストリング形式のパラメータたち
 *                       パラメータ名=値&パラメータ名=値&パラメータ名=値･･･と指定すること
 * @param  windowOptions   オープンするWindowの追加設定。
 *                         "name=value,name=value･･･"で指定すること。
 * @param  windowname  作成するWindowオブジェクトの名前。デフォルトは"newwin"
 * @return オープンしたWindowオブジェクトの参照
 */
function openReport(processId, processMode, pageId, optionParams, windowOptions){
	/*var str = "";
	for(var i=0;i<document.forms[0].elements.length;i++){
		var obj = document.forms[0].elements[i];
		if(obj.length){
			for(var j=0;j<obj.length;j++){
				str+=";"+obj[j].name+"="+obj[j].value;
			}
		}else{
			str+=";"+obj.name+"="+obj.value;
		}
	}
	alert(str);
	*/
	var winoptions = "";
	
	var urlstr="";
	urlstr="./appcontroller?PROCESSID="+processId+"&PROCESSMODE="+processMode
					+"&PAGEID="+pageId
					+"&JSPID=jsp/PDFView&ERRORPAGEID=CmErrorD&ERRORJSPID=jsp/AppView";

	//入力されていたらくっつける
	//最初の文字が&でなかったらくっつける
	if (!isEmpty(optionParams)){
		//alert(optionParams.charAt(0));
		if(optionParams.charAt(0)=='&'){
			urlstr += optionParams;
		}else{
			urlstr += '&'+optionParams;
		}
	}
	//alert(urlstr);
	
	var win = openWindow(urlstr, windowOptions, "");
	return win;
}
/**
 * 指定されたURLについて新規にウィンドウを開く.
 * @param  urlstr  新規にWindowをオープンするページのURL（必須）
 * @param  windowOptions   オープンするWindowの追加設定。
 *                         "name=value,name=value･･･"で指定すること。
 * @param  windowname  作成するWindowオブジェクトの名前。デフォルトは"newwin"
 * @return オープンしたWindowオブジェクトの参照
 */
function openWindow(urlstr, windowOptions, windowname) {
	//ユーザ指定の画面設定があれば、上書きする

	var option = "";
	var winname = "";
	var i=0;
	if (!isEmpty(windowname)){
		winname = windowname;
//	}else{
//		winname = "newwin";
	}
	var defaultoptionsname = new Array("status","scrollbars",
			"resizable","copyhistory",
			"width","height",
			"screenX","screenY",
			"left","top");
	var defaultoptionsvalue=new Array("yes","yes",
			"yes","yes",
			winWidth_,winHeight_,
			"","",
			"","");

	var strval = "";
	var paraname = "";
	var paravalue = "";
	var j=0;
	var addpara = "";
	var existdefault = false;

	if (!isEmpty(windowOptions)){
//alert(windowOptions);
		var r = windowOptions.split(",");
		for(i=0; i<r.length; i++){
			//パラメータ名と値に分離する
			strval = trim(r[i]);
//			alert(strval);
			paraname = getFrontString(strval,"=");
//alert(paraname);
			paravalue = getBackString(strval,"=");
//alert(paravalue);
			existdefault = false;
			if (paraname == "left" || paraname == "screenX"){
				defaultoptionsvalue[6] = paravalue;
				defaultoptionsvalue[8] = paravalue;
				existdefault = true;
			}else if(paraname == "top" || paraname == "screenY"){
				defaultoptionsvalue[7] = paravalue;
				defaultoptionsvalue[9] = paravalue;
				existdefault = true;
			}else{
				//デフォルトパラメータが存在すればその値を書きかえる。
				for(j=0;j<defaultoptionsname.length;j++){
					if(defaultoptionsname[j] == paraname){
						defaultoptionsvalue[j] = paravalue;
						existdefault = true;
						break;
					}
				}
			}
			//無ければ、追加する
			if (!existdefault){
				addpara += ("," + strval);
			}
		}
	}

	//デフォルトで画面の中心に出るようにする
	var def_x=0;
	var def_y=0;
	def_x = parseInt((window.screen.width - parseInt(defaultoptionsvalue[4]))/2);
	def_y = parseInt((window.screen.height - parseInt(defaultoptionsvalue[5]))/2);
	if (def_y > 20) {
	  def_y -= 20;
	}
	if (defaultoptionsvalue[6] == "" || defaultoptionsvalue[8] == "") {
		defaultoptionsvalue[6] = def_x;
		defaultoptionsvalue[8] = def_x;
	}
	if (defaultoptionsvalue[7] == "" || defaultoptionsvalue[9] == "") {
		defaultoptionsvalue[7] = def_y;
		defaultoptionsvalue[9] = def_y;
	}

	//パラメータ文字列を生成する
	option += (defaultoptionsname[0] + "=" + defaultoptionsvalue[0]);
	for(j=1;j<defaultoptionsname.length;j++){
		option += ("," + defaultoptionsname[j] 
							+ "=" + defaultoptionsvalue[j]);
	}

	if (!isBlank(addpara)){
		option += addpara;
	}
	
	// _MENUITEMKEYがあれば追加する
	try {
		var menuItemKey=document.forms[0].elements['_MENUITEMKEY'];
		if(!isEmpty(menuItemKey)){
			urlstr=urlstr+'&_MENUITEMKEY='+menuItemKey.value;
		}
	} catch(e) {
		alert(e);
	}


	//option = "toolbar=no,location=no,directories=no";
	//option = option + ",status=yes,menubar=no,scrollbars=yes,resizable=yes";
	//option = option + ",copyhistory=yes,width=800,height=600";
	//option = option + ",screenX=100,screenY=50,left=100,top=50";
	//alert(option);
	var path = "";
	var paramstr = "";
	//パラメータをエンコードする
	if(urlstr.indexOf('?')!=-1){
		path = urlstr.substring(0,urlstr.indexOf('?'))
		paramstr = urlstr.substring(urlstr.indexOf('?')+1, urlstr.length);
		if(paramstr.length>0){
//debugger			
			var paramsary = paramstr.split('&');
			paramstr = "";
			var key = "";
			var val = "";
			if(paramsary[0].indexOf('=')!=-1){
				key=getFrontString(paramsary[0],"=");
				val = getBackString(paramsary[0],"=");
				paramstr = key+"="+encodeUrl(unescape(val));
			}else{
				paramstr = paramsary[0];
			}
			for(i=1; i<paramsary.length; i++){
				if(paramsary[i].indexOf('=')!=-1){
					key = getFrontString(paramsary[i],"=");
					val = getBackString(paramsary[i],"=");
					paramstr += "&"+key+"="+encodeUrl(unescape(val));
				}else{
					paramstr += "&"+paramsary[i];
				}
			}
		}
		urlstr = path+"?"+paramstr;
	}
		
	if(document.forms[0]){
		if(document.forms[0].elements["THREADID"]){

			var threadId = "";
			threadId = document.forms[0].elements["THREADID"].value;
			var threadIdstr = "";
			if(urlstr.indexOf('appcontroller?')!=-1){
				path = urlstr.substring(0, urlstr.indexOf('appcontroller?')+'appcontroller?'.length)
				paramstr = urlstr.substring(urlstr.indexOf('appcontroller?')+'appcontroller?'.length, urlstr.length);

				if (paramstr==""){
					urlstr = path + "THREADID=" + threadId;
				}else{
					urlstr = path + "THREADID=" + threadId + "&" + paramstr;
				}
			}else if(urlstr.charAt(0)=='?'){
				if(urlstr.charAt(0)=='?' && urlstr.length>1){
					paramstr = urlstr.substring(1, urlstr.length);
					urlstr = '?' + "THREADID=" + threadId + "&" + paramstr;
				} else {
					urlstr = "?THREADID="+threadId;
				}
			}
		}
	}

	//alert(urlstr);
	var win = window.open(urlstr, winname, option);

	try{
		win.focus();
	}catch(e){}
	return win;
}

/**
 * 指定されたドキュメントに属する指定されたIDのエレメントオブジェクトを返す。
 * これはクロスブラウザ用である。Netscapeでdocument.allは使用不可能であるため、
 * この関数を使用する。
 * @param    id         参照を得たいエレメントのID
 * @param    document   参照を得たいエレメントが属するDocumentオブジェクト
 * @return   エレメントオブジェクト
 */
function getFieldByIdWithDocument(id, doc){
	if (doc.getElementById) {
		return doc.getElementById(id);
	} else if (doc.all) {
		return doc.all.item(id);
	}
	return null;
}

/**
 * このファイルをインクルードしているwindowのドキュメントオブジェクトに属する
 * 指定されたIDのエレメントオブジェクトを返す。
 * これはクロスブラウザ用である。Netscapeでdocument.allは使用不可能であるため、
 * この関数を使用する。
 * @param    id         参照を得たいエレメントのID
 * @param    document   参照を得たいエレメントが属するDocumentオブジェクト
 * @return   エレメントオブジェクト
 */
function getFieldById(id){
	if (window.document.getElementById) {
		return window.document.getElementById(id);
	} else if (window.document.all) {
		return window.document.all.item(id);
	}
	return null;
}

/**
 *  指定された設定値でinputタグを生成して、指定されたフォームに
 * 子エレメントとしてくっつける。
 * @param form    作成したエレメントをくっつける先のフォーム
 * @param type    作成するインプットエレメントのタイプ（hidden,button,textなど)
 * @param id      作成するインプットエレメントのid属性 
 * @param name    作成するインプットエレメントのname属性
 * @param value   作成するインプットエレメントのvalue属性
 * @return        作成されたインプットエレメント
 */
function addInputField(form, type, id, name, value) {
	if (document.getElementById) {
		var input = document.createElement('input');
		if (document.all) {
			input.id = id;
			input.type = type;
			input.name = name;
			input.value = value;
		} else {
			input.setAttribute('id',id);
			input.setAttribute('type', type);
			input.setAttribute('name', name);
			input.setAttribute('value', value);
		}
		form.appendChild(input);
		return input;
	}
	return null;
}

/**
 * 正しい日付の形式(年月日）であるかを判定する.
 * @param field
 */
/*
function checkDate(field, label){
	if (field == null)
		return false;
	field.value = trim(field.value);
	var str = field.value;
	if (!isDate(str)){
		alert(label + " is not a corect date.");
		return false;
	}
	return true;
}
*/

/**
 * 正しい年月であるか判定する
 * @param field
 */
/*
function checkYYYYMM(field, label){
	if (field == null)
		return false;
	field.value = trim(field.value);
	var str = field.value;
	if (!isYYYYMM(str)){
		alert(label + " is not a corect date.");
		return false;
	}
	return true;
	
}
*/
/**
 * 正しい数値であるかを判定する.
 * @param field
 */
function checkNumber(field, label){
	if (field == null)
		return false;
	field.value = trim(field.value);
	var str = field.value;

	
	if(!isNumber(str)){
		if(!isEmpty(label))
			alert(label + " is not a corect number data.");
		else
			alert("It is not a corect number data.");

		field.focus();
		return false;
	}
	return true;
}

/**
 * 必須チェック.
 * @param field
 */
/*
function checkMandatory(field, label){
	if (field == null)
		return false;
	field.value = trim(field.value);

	var str = field.value;

	if(!isBlank(str)){
		alert("Please enter a value at " + label + ".");
		return false;
	}
	return true;
}
*/

/**
 * 実行
 * 引数はdoApplication()を参照せよ
 */
function doSubmit(formobj, applicationId, optionParams){

	doApplication(formobj, applicationId, "3", optionParams);

}

/**
 * 確認
 * 引数はdoApplication()を参照せよ
 */
/*
function doConfirm(frmobj, applicationId){

	doApplication(formobj, applicationId, "2", optionParams);

}
*/

/**
 * 初期化
 * 引数はdoApplication()を参照せよ
 */
function doInitialize(formobj, applicationId, optionParams){

	doApplication(formobj, applicationId, "1", optionParams);

}

/**
 * 引数を使用してinputタグ文字列を生成して返す。
 * @param type
 * @param id
 * @param name
 * @param value
 */
function makeInputTagString(type, id, name, value){
	var str = "";
	str += '<input type="'+type+'"';
	if(id != ""){
		str += ' id="'+ id + '"';
	}
	str += ' name="'+ name + '"';
	str += ' value="'+ value + '"';
	str += '>\n';
	return  str;
	
}
/**
 * アプリケーションIDを指定してAppContorllerにsubmitする。
 * @param formobj          submitするFormオブジェクトの参照
 * @param applicationId    アプリケーションID
 * @param processMode      プロセスモード 1 or 2 or 3
 * @param optionParams     追加パラメータ。
 */

function doApplication(formobj, applicationId, processMode, optionParams){
	if(locked){
		return;
	}

	var bNodadatasend = false;
	var bOnSubmit = false;
	var paramarray = new Array();
	//alert(optionParams);
	if(!isEmpty(optionParams)){
		//データを送信しない指示が無いか見る
		if(optionParams.charAt(0) == '&'){
			optionParams = optionParams.substring(1, optionParams.length);
		}
		paramarray = optionParams.split('&');
		for(var i=0; i<paramarray.length; i++){
			var aParam = paramarray[i];
			if(aParam==NODATASENDOPTION){
				bNodadatasend = true;
			}else if(aParam==ONSUBMITOPTION){
				bOnSubmit = true;
			}
		}
	}
	
	if(bNodadatasend){
		//alert("nodatasend");
		//フォームのデータを消去し、指定されたパラメータのみ送信する
		var str = "";
		str += makeInputTagString("hidden", "", "APPLICATIONID", applicationId);
		str += makeInputTagString("hidden", "", "PROCESSMODE", processMode);
		//スレッドID
		var threadId = "";
		if(formobj.elements['THREADID']){
			threadId = formobj.elements['THREADID'].value;
		}
		str += makeInputTagString("hidden", "", "THREADID", threadId);

		for(var i=0; i<paramarray.length; i++){
			//パラメータ名と値に分離する
			var strval = paramarray[i];
			if(strval == NODATASENDOPTION || strval == ONSUBMITOPTION){
				continue;
			}
			var paraname = getFrontString(strval,"=");
			var paravalue = getBackString(strval,"=");
			str += makeInputTagString("hidden", "", paraname, unescape(paravalue));
		}
		//alert(str);

		//フォームが複数あると1部分だけ消えて見えるから、全部非表示にしておく
		document.body.style.visibility = 'hidden';

		formobj.innerHTML = str;
	}else{
		//alert("datasend");
		if(formobj.APPLICATIONID){
//			alert("1");
			formobj.APPLICATIONID.value = applicationId;
		}else{
//			alert("2");
			//エレメントが無かったら作成してフォームにappendする
			addInputField(formobj, "hidden", "APPLICATIONID", "APPLICATIONID", applicationId);
		}

		if(formobj.PROCESSMODE){
			formobj.PROCESSMODE.value = processMode;
		}else{
			addInputField(formobj, "hidden", "PROCESSMODE", "PROCESSMODE", processMode);
		}

		//オプションのパラメータをhiddenで追加する。
		//複数同じパラメータ名がある場合は最後のみ有効となる
		appendParams(formobj, optionParams);
	}

	var jspidstr  = "";
	if(formobj.JSPID){
		jspidstr = formobj.JSPID.value;
	}

	if(!bOnSubmit){
		if((formobj.target=='_self' || formobj.target=='') 
							&& (jspidstr == "jsp/AppView" || jspidstr == "" || jspidstr == "jsp/SVFView")){
			doFormLock();
		}
		try{
			formobj.submit();
		}catch(e){
			if(e.number==-2147024891){
				alert("Becase file's path is not valid filepath, the processing is broken.");
			}else{
				alert(e.description);
			}
		}
	}

}

/**
 *  formobjにクエリーストリング形式で指定されたパラメータたちを
 *  hiddenフィールドとして追加する。
 *  @param formobj フォーム
 *  @param optionParams  クエリーストリング形式のパラメータたち
 *                       パラメータ名=値&パラメータ名=値&パラメータ名=値･･･と指定すること
 */
function appendParams(formobj, optionParams){
	//オプションのパラメータをhiddenで追加する。
	//複数同じパラメータ名がある場合は最後のみ有効となる
	var	strval = "";
	var paraname = "";
	var paravalue = "";
	
	if (!isEmpty(optionParams)){
//			alert(optionParams.charAt(0));
		if(optionParams.charAt(0) == '&'){
			optionParams = optionParams.substring(1, optionParams.length);
		}
//alert(optionParams);
		var r = optionParams.split("&");
		for(i=0; i<r.length; i++){
			//パラメータ名と値に分離する
			strval = r[i];
			
			if(strval==ONSUBMITOPTION || strval==NODATASENDOPTION){
				continue;
			}
			
//alert(strval);
			paraname = getFrontString(strval,"=");
			var append=false;
			if(paraname.substring(0,1)=='+'){
				append=true;
				paraname=paraname.substring(1,paraname.length);
			}
//alert(paraname);
			paravalue = getBackString(strval,"=");
//alert(paravalue);
			//パラメータ名の大小は使う側で気をつけて一致させること
			//paraname = paraname.toUpperCase();
			if(formobj.elements[paraname]&&!append){
//alert("exists");
				formobj.elements[paraname].value = unescape(paravalue);
			}else{
//alert("nothing");
				addInputField(formobj, "hidden", paraname, paraname, unescape(paravalue));
			}
//alert(formobj.elements[paraname].value);
		}
	}

}

/**
 *  formobjにクエリーストリング形式で指定されたパラメータたちを
 *  hiddenフィールドとして追加する。
 *  @param formobj フォーム
 *  @param optionParams  クエリーストリング形式のパラメータたち
 *                       パラメータ名=値&パラメータ名=値&パラメータ名=値･･･と指定すること
 */
function appendParamsSeparateJSP(formobj, optionParams){
	//オプションのパラメータをhiddenで追加する。
	//複数同じパラメータ名がある場合は最後のみ有効となる
	var	strval = "";
	var paraname = "";
	var paravalue = "";
	var compvalue = "";
	var optParam = "";

	//オプションパラメータをhiddenフィールドに追加
	appendParams(formobj, optionParams);

	if (!isEmpty(optionParams)) {
//			alert(optionParams.charAt(0));
		if (optionParams.charAt(0) == '&') {
			optionParams = optionParams.substring(1, optionParams.length);
		}
		var r = optionParams.split("&");
		for (i = 0; i < r.length; i++) {
			//パラメータ名と値に分離する
			strval = r[i];
			
			if (strval == ONSUBMITOPTION || strval == NODATASENDOPTION) {
				continue;
			}
			compvalue = strval.substring(0, 6);
			compvalue2 = strval.substring(0, 21);
			compvalue3 = strval.substring(0, 15);
			if (compvalue == "JSPID=" || compvalue2 == "FORCENEXTPROCESSMODE=" || compvalue3 == "FORCEPRINTMODE=") {
				paraname = getFrontString(strval,"=");
				paravalue = getBackString(strval,"=");
				//パラメータ名の大小は使う側で気をつけて一致させること
				if (formobj.elements[paraname]) {
					formobj.elements[paraname].value = paravalue;
				} else {
					addInputField(formobj, "hidden", paraname, paraname, paravalue);
				}
			}
			else {
				if (!isEmpty(optParam)) {
					optParam += "&";
				}
				optParam += strval;
			}
		}
		if (!isEmpty(optParam)) {
			paraname = "OPTIONPARAMS";
			//パラメータ名の大小は使う側で気をつけて一致させること
			if (formobj.elements[paraname]) {
				formobj.elements[paraname].value = optParam;
			} else {
				addInputField(formobj, "hidden", paraname, paraname, optParam);
			}
		}
	}
}

/**
 * 実行（プロセスID指定）
 * 引数の説明はdoProcessを参照せよ。
 */
function doSubmitProcess(formobj, processId, pageId,
						nextProcessId, nextProcessMode,
						confirmtype, errorPageId, target, optionParams){
	doProcess(formobj, processId, "3", pageId,
						nextProcessId, nextProcessMode,
						confirmtype, errorPageId, target, optionParams)

}

/**
 * Web/Client帳票印刷用実行（プロセスID指定）
 * 引数の説明はdoSvfProcessを参照せよ。
 * JSP以外のoptionParametersをNextProcessに渡す
 */
function doSvfSubmitProcess(formobj, processId, pageId,
						nextProcessId, nextProcessMode,
						confirmtype, errorPageId, target, optionParams){

	doSvfProcess(formobj, processId, "3", pageId,
						nextProcessId, nextProcessMode,
						confirmtype, errorPageId, target, optionParams)

}

/**
 * 確認（プロセスID指定）
 * 引数の説明はdoProcessを参照せよ。
 */
function doConfirmProcess(formobj, processId, pageId, 
						nextProcessId, nextProcessMode,
						confirmtype, errorPageId, target, optionParams){

	doProcess(formobj, processId, "2", pageId,
						nextProcessId, nextProcessMode,
						confirmtype, errorPageId, target, optionParams)
}

/**
 * 初期化（プロセスID指定）
 * 引数の説明はdoProcessを参照せよ。この関数に確認メッセージの種類は無い。
 */
function doInitializeProcess(formobj, processId, pageId,
						nextProcessId, nextProcessMode,
						errorPageId, target, optionParams){
	doProcess(formobj, processId, "1", pageId,
						nextProcessId, nextProcessMode,
						"", errorPageId, target, optionParams)
}

/**
 * ロック状態にリンクをクリックして中断されるのを防止するためのダミー関数
 */
function doProcessLocked() {
  return false;
}
/**
 * ロック状態にリンクをクリックして中断されるのを防止するためのダミー関数
 */
function doProcessAbort() {
  alert('処理が途中で中断されたため継続できません。メニューから再度実行してください。');
  return false;
}
/**
 * 中断された場合のロック状態をタイムアウトで解除する
 */
function doProcessTimeout() {
  if(document.readyState=='loading'){
    // 読み込み中の場合は、再度タイムアウトを設定
    setTimeout('doProcessTimeout()',locktimeout);
    return;
  }
  locked = false;
  // カーソル形状をデフォルトにする
  document.body.style.cursor='';
  var _elements = document.getElementsByTagName('A');
  for(var i=0,_len=_elements.length;i<_len;++i){
    var obj = _elements[i];
    obj.onclick=doProcessAbort;
    obj.style.cursor='';
  }
  _elements = document.getElementsByTagName('INPUT');
  for(var i=0,_len=_elements.length;i<_len;++i){
    var obj = _elements[i];
    obj.onclick=doProcessAbort;
    obj.style.cursor='';
  }
}
/**
 * submit中にリンクをクリックしてロック状態のままsubmitを中断するのを防止する関数
 */
function doFormLock() {
  locked = true;
  document.body.style.cursor='progress';
  var _elements = document.getElementsByTagName('A');
  for(var i=0,_len=_elements.length;i<_len;++i){
    var obj = _elements[i];
    obj.onclick=doProcessLocked;
    obj.style.cursor='progress';
  }
  _elements = document.getElementsByTagName('INPUT');
  for(var i=0,_len=_elements.length;i<_len;++i){
    var obj = _elements[i];
    obj.onclick=doProcessLocked;
    obj.style.cursor='progress';
  }
  setTimeout('doProcessTimeout()',locktimeout);
}

/**
 * 指定されたプロセスID、プロセスモードを指定されたFormオブジェクトにセットして、
 * submitする。確認メッセージの種類が指定されている場合、その種類に該当する
 * メッセージを表示して処理をキャンセルすることができる。
 *
 * @param formobj             submitするフォームオブジェクトの参照（必須）
 * @param processId           プロセスID（必須）
 * @param processMode         プロセスモード（必須）
 * @param pageId              ページID（必須)
 * @param nextProcessId       次のプロセスID
 * @param nextProcessMode     次のプロセスモード
 * @param confirmtype         確認メッセージの種類
 * @param errorPageId         エラーページID
 * @param target              target(フレーム指定）
 *  @param optionParams  クエリーストリング形式のパラメータたち
 *                       パラメータ名=値&パラメータ名=値&パラメータ名=値･･･と指定すること
 */
function doProcess(formobj, processId, processMode, pageId,
						nextProcessId, nextProcessMode,
						confirmtype, errorPageId, target, optionParams){
	if(locked){
		return;
	}

	var messagestr = "";

	if (!isEmpty(confirmtype)){
		//確認のタイプによりメッセージを変える
		if(confirmtype == "1")
			messagestr = confirm1Message;
		else if(confirmtype == "2")
			messagestr = confirm2Message;
		else if(confirmtype == "3")
			messagestr = confirm3Message;
		else if(confirmtype == "9")
			messagestr = "";
		else
			messagestr = confirmtype;
	}

	if (!isBlank(messagestr) && !noConfirm){
		if(!confirm(messagestr)){
			return false;
		}
	}

	if(parent&&parent.header&&(errorPageId==null||errorPageId=='')){
		// HTMLをフレームヘッダのsavebodyに保存して、エラー時に復元できるようにする
		var savebody = parent.header.document.getElementById('savebody');
		if(!savebody){
			savebody = parent.header.document.createElement('input');
			if (document.all) {
				savebody.id = 'savebody';
				savebody.name = 'savebody';
				savebody.type = 'hidden';
			} else {
				savebody.setAttribute('id', 'savebody');
				savebody.setAttribute('name', 'savebody');
				savebody.setAttribute('type', 'hidden');
			}
			parent.header.document.forms[0].appendChild(savebody);
		}
		if(savebody){
			var err = document.getElementById('_error_dialog');
			if(err){
				document.body.removeChild(err);
			}
			try {
				_resetError();
			} catch(e) {}
			savebody.value=document.body.innerHTML;
		}
	}

	var bNodadatasend = false;
	var bOnsubmit = false;
	var paramarray = new Array();
	//alert(optionParams);
	if(!isEmpty(optionParams)){
		//データを送信しない指示が無いか見る
		if(optionParams.charAt(0) == '&'){
			optionParams = optionParams.substring(1, optionParams.length);
		}
		paramarray = optionParams.split('&');
		for(var i=0; i<paramarray.length; i++){
			var aParam = paramarray[i];
			if(aParam==NODATASENDOPTION){
				bNodadatasend = true;
			}else if(aParam==ONSUBMITOPTION){
				bOnsubmit = true;
			}
		}
	}

	if(bNodadatasend){
		var str = '';
		str += makeInputTagString('hidden', '', 'PROCESSID', processId);
		str += makeInputTagString('hidden', '', 'PROCESSMODE', processMode);
		str += makeInputTagString('hidden', '', 'PAGEID', pageId);
		//スレッドID
		str += getHiddenAutoParamsHTML(formobj, 'THREADID');
		str += getHiddenAutoParamsHTML(formobj, '_MENUITEMKEY');
		str += getHiddenAutoParamsHTML(formobj, '_APPLICATIONID');
		str += getHiddenAutoParamsHTML(formobj, '_FROMPROCESSID');
		str += getHiddenAutoParamsHTML(formobj, '_FROMPROCESSMODE');
		str += getHiddenAutoParamsHTML(formobj, '_FROMPAGEID');
		str += getHiddenAutoParamsHTML(formobj, '_FROMSKIPPAGE');

		//ネクストプロセスID
		if (!isEmpty(nextProcessId)){
			str += makeInputTagString('hidden', '', 'NEXTPROCESSID', nextProcessId);
		}

		//ネクストプロセスモード
		if (!isEmpty(nextProcessMode)){
			str += makeInputTagString('hidden', '', 'NEXTPROCESSMODE', nextProcessMode);
		}

		//エラーページID
		if (!isEmpty(errorPageId)){
		 str += makeInputTagString('hidden', '', 'ERRORPAGEID', errorPageId);
		}
		
		// _SKIPPAGEの設定
		if(pageId == getThisValue(formobj.elements['_FROMPAGEID'])) {
			// nodatasendでページIDが同じ場合は、_SKIPPAGEを設定する
			str += makeInputTagString('hidden', '', '_SKIPPAGE', getThisValue(formobj.elements['_FROMSKIPPAGE']));
		}
		
		for(var i=0; i<paramarray.length; i++){
			//パラメータ名と値に分離する
			var strval = paramarray[i];
			if(strval == NODATASENDOPTION || strval == ONSUBMITOPTION){
				continue;
			}
			var paraname = getFrontString(strval, "=");
			var paravalue = getBackString(strval, "=");
			str += makeInputTagString("hidden", "", paraname, unescape(paravalue));
		}
		//alert(str);
		
		//フォームが複数あると1部分だけ消えて見えるから、全部非表示にしておく
		//document.body.style.visibility='hidden';
		//
		//formobj.innerHTML = str;
		
		//新しいフォームを作成して、そこから実行する
		var newformobj = document.createElement('form');
		newformobj.action=formobj.action;
		newformobj.method=formobj.method;
		newformobj.target=formobj.target;
		newformobj.onsubmit=function(){alert('submit')};
		newformobj.style.visibility='hidden';
		newformobj.innerHTML = str;
		document.body.appendChild(newformobj);
		formobj = newformobj;
		
	}else{
		//alert("datasend");
		//プロセスID
		if(formobj.PROCESSID){
			formobj.PROCESSID.value = processId;
		}else{
			addInputField(formobj, "hidden", "PROCESSID", "PROCESSID", processId);
		}

		//ページID
		if(formobj.PAGEID){
			formobj.PAGEID.value = pageId;
		}else{
			addInputField(formobj, "hidden", "PAGEID", "PAGEID", pageId);
		}

		//プロセスモード
		if(formobj.PROCESSMODE){
		  formobj.PROCESSMODE.value = processMode;
		}else{
			addInputField(formobj, "hidden", "PROCESSMODE", "PROCESSMODE", processMode);
		}

		//ネクストプロセスID
		if (isEmpty(nextProcessId)){
		  nextProcessId = "";
		}
		if(formobj.NEXTPROCESSID){
			formobj.NEXTPROCESSID.value = nextProcessId;
		}else{
			addInputField(formobj, "hidden", "NEXTPROCESSID", "NEXTPROCESSID", nextProcessId);
		}

		//ネクストプロセスモード
		if (isEmpty(nextProcessMode)){
			nextProcessMode = "";
		}
		if(formobj.NEXTPROCESSMODE){
			formobj.NEXTPROCESSMODE.value = nextProcessMode;
		}else{
			addInputField(formobj, "hidden", "NEXTPROCESSMODE", "NEXTPROCESSMODE", nextProcessMode);
		}

		//エラーページID
		if (isEmpty(errorPageId)){
			errorPageId = "";
		}
		if(formobj.ERRORPAGEID){
			formobj.ERRORPAGEID.value = errorPageId;
		}else{
			addInputField(formobj, "hidden", "ERRORPAGEID", "ERRORPAGEID", errorPageId);
		}

		//JSPIDの初期化
		if(formobj.JSPID){
			formobj.JSPID.value = "";
		}else{
			addInputField(formobj, "hidden", "JSPID", "JSPID", "");
		}

		// _SKIPPAGEの設定
		if(!compareProcessId(processId, getThisValue(formobj.elements['_FROMPROCESSID'])) && pageId == getThisValue(formobj.elements['_FROMPAGEID'])) {
			// プロセスが異なりページIDが同じ場合は、_SKIPPAGEを設定する
			var skippage = getThisValue(formobj.elements['_FROMSKIPPAGE']);
			if(formobj._SKIPPAGE){
				formobj._SKIPPAGE.value = skippage;
			}else{
				addInputField(formobj, 'hidden', '_SKIPPAGE', '_SKIPPAGE', skippage);
			}
		}
		
		//オプションのパラメータをhiddenで追加する。
		//複数同じパラメータ名がある場合は最後のみ有効となる
		appendParams(formobj, optionParams);	 
	}
							
	if (!isEmpty(target)){
		formobj.target = target;
	}else{
		formobj.target = '_self';
	}

	var jspidstr  = "";
	if(formobj.JSPID){
		jspidstr = formobj.JSPID.value;
	}

	if(!bOnsubmit){
		if((formobj.target=='_self' || formobj.target=='') 
								&& (jspidstr == "jsp/AppView" || jspidstr == "" || jspidstr == "jsp/SVFView")){
			doFormLock();
		}
		try{
			formobj.submit();
		}catch(e){
			if(e.number==-2147024891){
				alert("Becase file's path is not valid filepath, the processing is broken.");
			}else{
				alert(e.description);
			}
		}
	}
}

function getHiddenAutoParamsHTML(formobj, id) {
	if(formobj.elements[id]){
		return makeInputTagString('hidden', '', id, formobj.elements[id].value);
	} else {
		return '';
	}
}

function compareProcessId(proc1, proc2) {
  var p1 = proc1;
  var p2 = proc2;
  if (p1 == null) p1 = '';
  if (p2 == null) p2 = '';
  if (p1.indexOf('&') != -1) p1 = p1.substring(0, p1.indexOf('&'));
  if (p2.indexOf('&') != -1) p2 = p2.substring(0, p2.indexOf('&'));
  if (p1.indexOf('!') == p1.length - 1) p1 = p1.substring(0, p1.length - 1);
  if (p2.indexOf('!') == p2.length - 1) p2 = p2.substring(0, p2.length - 1);
  if (p1.indexOf('+') == 0) p1 = p1.substring(1);
  if (p2.indexOf('+') == 0) p2 = p2.substring(1);
  return p1 == p2;
}

/**
 * 指定されたプロセスID、プロセスモードを指定されたFormオブジェクトにセットして、
 * submitする。確認メッセージの種類が指定されている場合、その種類に該当する
 * メッセージを表示して処理をキャンセルすることができる。
 * JSP以外のoptionParametersをNextProcessに渡す
 *
 * @param formobj             submitするフォームオブジェクトの参照（必須）
 * @param processId           プロセスID（必須）
 * @param processMode         プロセスモード（必須）
 * @param pageId              ページID（必須)
 * @param nextProcessId       次のプロセスID
 * @param nextProcessMode     次のプロセスモード
 * @param confirmtype         確認メッセージの種類
 * @param errorPageId         エラーページID
 * @param target              target(フレーム指定）
 * @param optionParams  クエリーストリング形式のパラメータたち
 *                       パラメータ名=値&パラメータ名=値&パラメータ名=値･･･と指定すること
 */
function doSvfProcess(formobj, processId, processMode, pageId,
						nextProcessId, nextProcessMode,
						confirmtype, errorPageId, target, optionParams){
	if(locked){
		return;
	}

	var messagestr = "";

	if (!isEmpty(confirmtype)){
		//確認のタイプによりメッセージを変える
		if(confirmtype == "1")
			messagestr = confirm1Message;
		else if(confirmtype == "2")
			messagestr = confirm2Message;
		else if(confirmtype == "3")
			messagestr = confirm3Message;
		else
			messagestr = confirmtype;
	}

	if (!isBlank(messagestr) && !noConfirm){
		if(!confirm(messagestr)){
			return false;
		}
	}

	var bNodadatasend = false;
	var bOnsubmit = false;
	var paramarray = new Array();
	//alert(optionParams);
	if(!isEmpty(optionParams)){
		//データを送信しない指示が無いか見る
		if(optionParams.charAt(0) == '&'){
			optionParams = optionParams.substring(1, optionParams.length);
		}
		paramarray = optionParams.split('&');
		for(var i=0; i<paramarray.length; i++){
			var aParam = paramarray[i];
			if(aParam==NODATASENDOPTION){
				bNodadatasend = true;
			}else if(aParam==ONSUBMITOPTION){
				bOnsubmit = true;
			}
		}
	}

	if(bNodadatasend){
		//alert("nodatasend");
		var str = "";
		str += makeInputTagString("hidden", "", "PROCESSID", processId);
		str += makeInputTagString("hidden", "", "PROCESSMODE", processMode);
		str += makeInputTagString("hidden", "", "PAGEID", pageId);
		//スレッドID
		var threadId = "";
		if(formobj.elements['THREADID']){
			threadId = formobj.elements['THREADID'].value;
		}
		str += makeInputTagString("hidden", "", "THREADID", threadId);

		//ネクストプロセスID
		if (!isEmpty(nextProcessId)){
			str += makeInputTagString("hidden", "", "NEXTPROCESSID", nextProcessId);
		}

		//ネクストプロセスモード
		if (!isEmpty(nextProcessMode)){
			str += makeInputTagString("hidden", "", "NEXTPROCESSMODE", nextProcessMode);
		}

		//エラーページID
		if (!isEmpty(errorPageId)){
		 str += makeInputTagString("hidden", "", "ERRORPAGEID", errorPageId);
		}
		
		for(var i=0; i<paramarray.length; i++){
			//パラメータ名と値に分離する
			var strval = paramarray[i];
			if(strval == NODATASENDOPTION || strval == ONSUBMITOPTION){
				continue;
			}
			var paraname = getFrontString(strval, "=");
			var paravalue = getBackString(strval, "=");
			str += makeInputTagString("hidden", "", paraname, unescape(paravalue));
		}
		//alert(str);
		
		//フォームが複数あると1部分だけ消えて見えるから、全部非表示にしておく
		document.body.style.visibility='hidden';
		
		formobj.innerHTML = str;

	}else{
		//alert("datasend");
		//プロセスID
		if(formobj.PROCESSID){
			formobj.PROCESSID.value = processId;
		}else{
			addInputField(formobj, "hidden", "PROCESSID", "PROCESSID", processId);
		}

		//ページID
		if(formobj.PAGEID){
			formobj.PAGEID.value = pageId;
		}else{
			addInputField(formobj, "hidden", "PAGEID", "PAGEID", pageId);
		}

		//プロセスモード
		if(formobj.PROCESSMODE){
		  formobj.PROCESSMODE.value = processMode;
		}else{
			addInputField(formobj, "hidden", "PROCESSMODE", "PROCESSMODE", processMode);
		}

		//ネクストプロセスID
		if (isEmpty(nextProcessId)){
		  nextProcessId = "";
		}
		if(formobj.NEXTPROCESSID){
			formobj.NEXTPROCESSID.value = nextProcessId;
		}else{
			addInputField(formobj, "hidden", "NEXTPROCESSID", "NEXTPROCESSID", nextProcessId);
		}

		//ネクストプロセスモード
		if (isEmpty(nextProcessMode)){
			nextProcessMode = "";
		}
		if(formobj.NEXTPROCESSMODE){
			formobj.NEXTPROCESSMODE.value = nextProcessMode;
		}else{
			addInputField(formobj, "hidden", "NEXTPROCESSMODE", "NEXTPROCESSMODE", nextProcessMode);
		}

		//エラーページID
		if (isEmpty(errorPageId)){
			errorPageId = "";
		}
		if(formobj.ERRORPAGEID){
			formobj.ERRORPAGEID.value = errorPageId;
		}else{
			addInputField(formobj, "hidden", "ERRORPAGEID", "ERRORPAGEID", errorPageId);
		}

		//JSPIDの初期化
		if(formobj.JSPID){
			formobj.JSPID.value = "";
		}else{
			addInputField(formobj, "hidden", "JSPID", "JSPID", "");
		}

		//オプションパラメータのうち、Formオブジェクトにセットするオブジェクトを初期化する
		clearOptionParameterObject(formobj);

		//オプションのパラメータをhiddenで追加する。
		//複数同じパラメータ名がある場合は最後のみ有効となる
		//JSPIDが指定されている場合は、JSPID以外のoptionParameterをそのままNextProcessに渡す
		appendParamsSeparateJSP(formobj, optionParams);	
	}
							
	if (!isEmpty(target)){
		formobj.target = target;
	}else{
		formobj.target = '_self';
	}

	var jspidstr  = "";
	if(formobj.JSPID){
		jspidstr = formobj.JSPID.value;
	}

	if(!bOnsubmit){
		if((formobj.target=='_self' || formobj.target=='') 
								&& (jspidstr == "jsp/AppView" || jspidstr == "" || jspidstr == "jsp/SVFView")){
			doFormLock();
		}
		try{
			formobj.submit();
		}catch(e){
			if(e.number==-2147024891){
				alert("Becase file's path is not valid filepath, the processing is broken.");
			}else{
				alert(e.description);
			}
		}
	}
}

function doBack(formobj,optionParams){
	var paramarray = new Array();
	var optstr = '';
	if(!isEmpty(optionParams)){
		//データを送信しない指示が無いか見る
		if(optionParams.charAt(0) == '&'){
			optionParams = optionParams.substring(1, optionParams.length);
		}
		paramarray = optionParams.split('&');
		for(var i=0; i<paramarray.length; i++){
			//パラメータ名と値に分離する
			var strval = paramarray[i];
			var paraname = getFrontString(strval, "=");
			var paravalue = getBackString(strval, "=");
			optstr += '&' + unescape(paraname) + '=' + unescape(paravalue);
		}
	}
	var processMode = getLastValue(formobj._FROMPROCESSMODE);
	var processId = getLastValue(formobj._FROMPROCESSID);
	var pageId = getLastValue(formobj._FROMPAGEID);
	var _skipPage = getLastValue(formobj._FROMSKIPPAGE);
	if (pageId != null) {
		var backparam = '&_FROMPAGEID=' + formobj._FROMPAGEID.value
			 + '&_FROMPROCESSID=' + formobj._FROMPROCESSID.value
			 + '&_FROMPROCESSMODE=' + formobj._FROMPROCESSMODE.value
			 + '&_FROMSKIPPAGE=' + formobj._FROMSKIPPAGE.value
			 + '&_BACKPAGE=1';
		if (_skipPage != null && _skipPage != '') {
			backparam = backparam + '&_SKIPPAGE=' + _skipPage;
		}
		if (optstr != '') {
			backparam = backparam + optstr;
		}
		if (processMode == '1') {
			doInitializeProcess(formobj, processId, pageId, '', '', pageId, '', '#NODATASEND' + backparam);
		} else if (processMode == '2') {
			doConfirmProcess(formobj, processId, pageId, '', '', '', pageId, '', '#NODATASEND' + backparam);
		} else if (processMode == '3') {
			doSubmitProcess(formobj, processId, pageId, '', '', '', pageId, '', '#NODATASEND' + backparam);
		}
	}
}

function doSubmitBack(formobj, processId, confirmtype){
	var lastPageId = getLastValue(formobj._FROMPAGEID);
	var lastProcessId = getLastValue(formobj._FROMPROCESSID);
	var lastProcessMode = getLastValue(formobj._FROMPROCESSMODE);
	var thisPageId = getThisValue(formobj._FROMPAGEID);
	var _skipPage = getLastValue(formobj._FROMSKIPPAGE);
	if (lastPageId != null) {
		var backparam = '_BACKPAGE=1';
		if (_skipPage != null && _skipPage != '') {
			backparam = backparam + '&_SKIPPAGE=' + _skipPage;
		}
		lastProcessId = '!' + lastProcessId;
		lastProcessId = lastProcessId + '&' + backparam + '&_FROMPAGEID=' + formobj._FROMPAGEID.value + '&_FROMPROCESSID=' + formobj._FROMPROCESSID.value + '&_FROMPROCESSMODE=' + formobj._FROMPROCESSMODE.value + '&_FROMSKIPPAGE=' + formobj._FROMSKIPPAGE.value;
		doSubmitProcess(formobj, processId, lastPageId, lastProcessId, lastProcessMode, confirmtype, thisPageId, '', backparam);
	} else {
		doSubmitProcess(formobj, processId, thisPageId, '', '', confirmtype, thisPageId, '', '');
	}
}

function getThisValue(obj) {
	if(obj) {
		var value = obj.value;
		if(!value){
			return null;
		}
		var i = value.indexOf(",");
		if (i == -1) {
			return value;
		}
		return value.substring(0, i);
	} else {
		return null;
	}
}

function getLastValue(obj) {
	if(obj) {
		var value = obj.value;
		if(!value){
			return null;
		}
		var i = value.indexOf(",");
		if (i == -1) {
			return null;
		}
		var j = value.indexOf(",", i + 1);
		if (j == -1) {
			return value.substring(i + 1);
		} else {
			return value.substring(i + 1, j);
		}
	} else {
		return null;
	}
}

function getBackValue(obj) {
	if(obj) {
		var value = obj.value;
		if(!value){
			return "";
		}
		var i = value.indexOf(",");
		if (i == -1) {
			return "";
		}
		return value.substring(i + 1);
	} else {
		return "";
	}
}

/**
 * オプションパラメータのうち、Formオブジェクトにセットするオブジェクトを初期化する
 * @param formobj フォーム
 */
function clearOptionParameterObject(formobj){
	//TARGETMODEの初期化
	if(formobj.TARGETMODE){
		formobj.TARGETMODE.value = "";
	}else{
		addInputField(formobj, "hidden", "TARGETMODE", "TARGETMODE", "");
	}

	//FORCENEXTPROCESSMODEの初期化
	if(formobj.FORCENEXTPROCESSMODE){
		formobj.FORCENEXTPROCESSMODE.value = "";
	}else{
		addInputField(formobj, "hidden", "FORCENEXTPROCESSMODE", "FORCENEXTPROCESSMODE", "");
	}

	//FORCEPRINTMODEの初期化
	if(formobj.FORCEPRINTMODE){
		formobj.FORCEPRINTMODE.value = "";
	}else{
		addInputField(formobj, "hidden", "FORCEPRINTMODE", "FORCEPRINTMODE", "");
	}
}

/**
 * formObjが持つfieldnameというnameのすべてのCheckboxに対し、
 * checkedを行う
 * @param formobj フォーム
 * @param fieldname Checkboxのname
 * @param checked trueならばチェックする、falseならばチェックをはずす
 */
function checkAllCheckbox(formobj, fieldname, checked){

	var obj = null;
//	if(isEmpty(fieldname){
//		return;
//	}
	//勝手についてる
	var strfieldname = fieldname + "_check";
	
	if(formobj.elements[strfieldname]){
		//alert("exist");
		obj = formobj.elements[strfieldname];
//alert(obj.length);
		if(obj.length){
			//alert("multi");
			for(var i=0;i<obj.length;i++){
				if(!obj[i].disabled){
					obj[i].checked = checked;
					//hiddenの値を変更する
					obj[i].onclick();
				}
			}
		}else{
			if(obj!=null&&!obj.disabled){
				obj.checked = checked;
				//hiddenの値を変更する
				obj.onclick();
			}
		}
	}
}

function closeWindow(){
	try{
		(window.open('','_top').opener=top).close();
	}catch(e){
		window.close();
	}
}

/**
 * チェックされた行があるか調べる
 * 
 * @param name チェックボックスの項目名。デフォルトは'LINE.CHECK'
 * @param msgNoCheck チェックがなかったときのメッセージ。'' を指定するとメッセージを表示しない。
 * @param msgNoLine 行がなかったときのメッセージ。デフォルトはmsgNoCheckと同じ
 * @return boolean true:ある false:ない
 */
function lineChecked(name, msgNoCheck, msgNoLine) {
	if(!name) {
		name = 'LINE.CHECK';
	}

	var checked = false;
	for(var e,i = 1; e = document.getElementById(name + '_' + i + '_check'); i++) {
		if(e.checked) {
			return true;
		}
	}

	if((typeof msgNoCheck) == 'string' && msgNoCheck == '') {
		return false;
	}

	if(!msgNoCheck) {
		msgNoCheck = 'It is not checked.';
	}

	if(i == 1) {
		if(!msgNoLine) {
			msgNoLine = msgNoCheck;
		}
		alert(msgNoLine);
		return false;
	}

	alert(msgNoCheck);
	return false;
}


/**
 * ページ移動ボタンの実行
 * @param skipPage 読み飛ばすページ数
 **/
function doPageSubmit(skipPage) {
	var frm = document.forms[0];
	var submit = false;
	if(frm._SKIPPAGE){;
	  frm._SKIPPAGE.value=skipPage;
	}else{;
	  addInputField(frm,'hidden','_SKIPPAGE','_SKIPPAGE',skipPage);
	}
	for(var i = 0; i < frm.elements.length; i++) {
	  if (frm.elements[i].type == 'submit') {
	    submit = true;
	    frm.elements[i].click();
	    break;
	  }
	}
	if (!submit) {
	  frm.submit();
	}
}

/**
 * ページ移動ボタンの無効化
 * ※抽出条件を変更した場合、ページ移動が正しく機能しないため、抽出条件のonchangeより呼び出す
 **/
function doPageCancel() {
	var prevbtn = document.getElementById('PREVBTN');
	var nextbtn = document.getElementById('NEXTBTN');
	if(prevbtn)prevbtn.disabled=true;
	if(nextbtn)nextbtn.disabled=true;
	var prevbtn2 = document.getElementById('PREVBTN2');
	var nextbtn2 = document.getElementById('NEXTBTN2');
	if(prevbtn2)prevbtn2.disabled=true;
	if(nextbtn2)nextbtn2.disabled=true;
}


/**
 * ヘルプ（マスタヘルプ）を呼び出すショートカット（隣のボタンを押す）
 */
function doHelpButton(src) {
  var elements = src.parentNode.parentNode.childNodes;
  if (elements) {
    var i = 0;
    for(;i<elements.length;++i){
      if(src.parentNode==elements[i]) {
        break;
      }
    }
    for(;i<elements.length;++i){
      var e = elements[i];
      if (e.tagName == 'TD') {
        e = e.firstChild;
      }
      if (e == null) {
        break;
      }
      if(e.tagName=='INPUT'&&e.type=='button') {
        e.click();
        break;
      }
    }
  }
}

var _disableHelpFocus = false;

function doDisableHelpFocus() {
  var e = document.getElementsByTagName('INPUT');
  if(e) {
    for(var i=0,_len=e.length;i<_len;++i){
      if(e[i].type=='button'&&e[i].value=='?'){
        e[i].tabIndex=-1;
        e[i].onfocus=new Function("this.blur();");
      }
    }
  }
  _disableHelpFocus=true;
}

/*capで指定したキャプションが含まれるボタンを探して返す*/
function findButton(cap) {
  var inputs=document.getElementsByTagName('INPUT');
  if(inputs){
    for(var i=0,n=inputs.length;i<n;++i){
      var input=inputs[i];
      if ((input.type=='button'||input.type=='submit')
        &&input.value
        &&input.currentStyle['visibility']!='hidden'
        &&input.currentStyle['display']!='none'
        &&!input.disabled
      ) {
        var caption = input.value.replace(/ /g,'');
        if(caption.match(cap)) {
          return input;
        }
      }
    }
  }
  return null;
}

function getScreenTop(elem) {
  var html = document.documentElement;  
  var rect = elem.getBoundingClientRect();  
  var top = rect.top - html.clientTop;  
  return top;
} 
function getScreenLeft(elem) {
  var html = document.documentElement;  
  var rect = elem.getBoundingClientRect();  
  var left = rect.left - html.clientLeft;  
  return left;
} 
function getElementLeft(elem) {  
  try {
    var html = document.documentElement;  
    var body = document.body;  
    var scrollLeft = (body.scrollLeft || html.scrollLeft);  
    var sleft = getScreenLeft(elem);  
    return sleft + scrollLeft;  
  }catch(e){
    return -1;
  }
}
function compareLeftPos(left1,left2){
  if(Math.abs(left2-left1)<5){
    return true;
  }
  return false;
}
function getAboveElement(elem) {
  var top = getScreenTop(elem);
  var left = getElementLeft(elem);
  var inputs=document.getElementsByTagName('INPUT');
  if(inputs){
    var last=null;
    var laste=null;
    for(var i=0,n=inputs.length;i<n;++i){
      var input=inputs[i];
      if ((input.type=='text'||input.type=='file'||input.type=='password')
        &&input.currentStyle['visibility']!='hidden'
        &&input.currentStyle['display']!='none'
        &&!input.disabled
        &&!input.readOnly
      ) {
        if(compareLeftPos(getElementLeft(input),left)){
          if(input==elem){
            // 自分が見つかった場合
            if(laste!=null&&last!=null&&getScreenTop(laste)>getScreenTop(last)+10 || last==null){
              return laste;
            }
            return last;
          }else{
            last=input; // 自分と同じ左位置の最後にチェックした項目
          }
        }else{
          if(getScreenTop(input)<top-10){
            laste=input; // 自分よりも上で最後にチェックした項目
          }
        }
      }
    }
  }
  return null;
}
function getBelowElement(elem) {
  var top = getScreenTop(elem);
  var left = getElementLeft(elem);
  var inputs=document.getElementsByTagName('INPUT');
  var laste=null;
  if(inputs){
    var me=false;
    for(var i=0,n=inputs.length;i<n;++i){
      var input=inputs[i];
      if ((input.type=='text'||input.type=='file'||input.type=='password')
        &&input.currentStyle['visibility']!='hidden'
        &&input.currentStyle['display']!='none'
        &&!input.disabled
        &&!input.readOnly
      ) {
        var itop=getScreenTop(input);
        if(itop + 10 < top)continue;
        if(compareLeftPos(getElementLeft(input),left)){
          // 左位置が一致
          if(input==elem){
            me=true;
          } else if(me){
            if(laste!=null&&getScreenTop(laste)<itop+10&&getScreenTop(laste)<getScreenTop(input)){
              return laste;
            }
            return input;
          }
        }else{
          if(me&&laste==null&&getScreenTop(input)>top+10){
            laste=input;
          }
        }
      }
    }
  }
  return laste;
}

function doKeyDown(evt) {
  var button;
  if(document.all) evt = event;
  if(document.body && document.body.onhelp==null) document.body.onhelp=function(){return false;};
  if(!_disableHelpFocus){doDisableHelpFocus()};
  var key = evt.keyCode;
  if (key == 112) { /* F1 */
    doHelpButton(evt.srcElement);
    return false;
  }
  if (key == 114) { /* F3 */
    return false;
  }
  if (key == 115) { /* F4 */
    button = findButton('新規|New');
    if(button){doButtonClick(button);event.keyCode = 0;return false;}
  }
  if (key == 116) { /* F5 */
    button = findButton('確認|Check');
    if(button){doButtonClick(button);event.keyCode = 0;return false;}
  }
  if (key == 117) { /* F6 */
    button = findButton('^登録|^Apply|^Regist');
    if(button){doButtonClick(button);event.keyCode = 0;return false;}
    button = findButton('更新|Save|Update');
    if(button){doButtonClick(button);event.keyCode = 0;return false;}
  }
  if (key == 118) { /* F7 */
    button = findButton('連続登|Repeat Apply|Repeat Regist');
    if(button){doButtonClick(button);event.keyCode = 0;return false;}
    button = findButton('^申請|^Application');
    if(button){doButtonClick(button);event.keyCode = 0;return false;}
  }
  if (key == 119) { /* F8 */
    button = findButton('一覧|List');
    if(button){doButtonClick(button);event.keyCode = 0;return false;}
    button = findButton('戻る|Return');
    if(button){doButtonClick(button);event.keyCode = 0;return false;}
  }
//  if (key == 120) { /* F9 */
//    button = findButton('新規');
//    if(button)doButtonClick(button);
//    event.keyCode = 0;
//    return false;
//  }
//  if (key == 121) { /* F10 */
//    button = findButton('一覧');
//    if(button)doButtonClick(button);
//    else {
//      button = findButton('戻る');
//      if(button)doButtonClick(button);
//    }
//    event.keyCode = 0;
//    return false;
//  }
  if (key == 122) { /* F11 */
    // メニューのopen/close
    var links = parent.header.document.getElementsByTagName('A');
    if(links&&links.length>0) {
      links[0].click();
    }
    return false;
  }
  if (key == 8) { /* BS */
//    event.keyCode = 0; // BSによるhistory.back()を無効にする
//    return false;
  }
  if (key == 78 && evt.ctrlKey) {
    // Ctrl+Nが押された
    // 新規ボタンを検索してclickする
    button = findButton('新規|New');
    if(button)doButtonClick(button);
    return false;
  }
  if (key == 83 && evt.ctrlKey) {
    // Ctrl+Sが押された
    // 登録ボタンを検索してclickする
    button = findButton('登録|Apply|Regist');
    if(button)doButtonClick(button);
    return false;
  }
  if (key == 33) {
    // PageUpが押された
    button = document.getElementById('PREVBTN');
    if(button&&!button.disabled)doButtonClick(button);
    return false;
  }
  if (key == 34) {
    // PageDownが押された
    button = document.getElementById('NEXTBTN');
    if(button&&!button.disabled)doButtonClick(button);
    return false;
  }
  if (key == 38) {
    // ↑が押された
    var elm=evt.srcElement;
    if(elm&&elm.tagName=='INPUT'&&!elm.disabled&&!elm.readOnly) {
      var isearchbox = document.getElementById('_isearchbox');
      if(!isearchbox){
        isearchbox = document.getElementById('_isearchboxid_'+elm.id);
      }
      if(!isearchbox||isearchbox.style.display=='none'){
        var item=getAboveElement(evt.srcElement);
        if(item != null){
          item.focus();
          try {
            if(item.createTextRange){
              var range = item.createTextRange();
              range.moveStart("character",item.value.length);
              range.moveEnd("character",item.value.length);
              range.select();
            }else if(item.setSelectionRange){
              item.setSelectionRange(item.value.length,item.value.length);
            }
          }catch(e){}
          return false;
        }
      }
    }
  }
  if (key == 40) {
    // ↓が押された
    var elm=evt.srcElement;
    if(elm&&elm.tagName=='INPUT'&&!elm.disabled&&!elm.readOnly) {
      var isearchbox = document.getElementById('_isearchbox');
      if(!isearchbox){
        isearchbox = document.getElementById('_isearchboxid_'+elm.id);
      }
      if(!isearchbox||isearchbox.style.display=='none'){
        var item=getBelowElement(evt.srcElement);
        if(item != null){
          item.focus();
          try {
            if(item.createTextRange){
              var range = item.createTextRange();
              range.moveStart("character",item.value.length);
              range.moveEnd("character",item.value.length);
              range.select();
            }else if(item.setSelectionRange){
              item.setSelectionRange(item.value.length,item.value.length);
            }
          }catch(e){}
          return false;
        }
      }
    }
  }
//  if (key == 81 && evt.ctrlKey) {
//    // Ctrl+Qが押された
//    window.open('jsp/SQLLog.jsp', '');
//    event.keyCode = 0;
//    return false;
//  }
//  alert(key);
  return true;
}

/*ファクションキーバー表示（画面表示の最初に呼ばれる）*/
function doDisplayFunctionGuide() {
  if(document.getElementById('_functionGuide')) {
    return true;
  }
  var span = document.createElement('SPAN');
  var inputs = document.getElementsByTagName('INPUT');
  var ent = '';
  var f1 = '';
  var f2 = '';
  var f3 = '';
  var f4 = '';
  var f5 = '';
  var f6 = '';
  var f7 = '';
  var f8 = '';
  var f9 = '';
  var f10 = '';
  var submit = false;
  for(var i=0,n=inputs.length; i < n; ++i) {
    var input = inputs[i];
    if((input.type=='button'||input.type=='submit')
        &&input.value
        &&input.currentStyle['visibility']!='hidden'
        &&input.currentStyle['display']!='none'
        &&!input.disabled
    ) {
      var caption = input.value.replace(/ /g,'');
      if(caption == '?') {
        //f1 = 'F1:帮助'+'&nbsp;&nbsp;';
      } else if(caption.match(/新規|New/)) {
        f4='F4:'+caption+'&nbsp;&nbsp;';
        if(input.type=='submit') submit=true;
      } else if(caption.match(/確認|Check/)) {
        f5='F5:'+caption+'&nbsp;&nbsp;';
        if(input.type=='submit') submit=true;
      } else if(caption.match(/^登録|^Reqist|^Apply|更新|Save|Update/)) {
        f6='F6:'+caption+'&nbsp;&nbsp;';
        if(input.type=='submit') submit=true;
      } else if(caption.match(/連続登|Repeat Apply|Repeat Regist|^申請|^Application/)) {
        f7='F7:'+caption+'&nbsp;&nbsp;';
        if(input.type=='submit') submit=true;
      } else if(caption.match(/一覧|List|戻る|Return/)) {
        f8='F8:'+caption+'&nbsp;&nbsp;';
        if(input.type=='submit') submit=true;
      }
      if(!submit&&ent==''&&input.type=='submit') {
        ent='Ent:'+caption+'&nbsp;&nbsp;';
      }
    }
  }
  var f=f1+f2+f3+f4+f5+f6+f7+f8+f9+f10;
  if(f!='') {
   span.innerHTML=f+ent;
   span.style.position='absolute';
   span.style.left='0';
   span.style.top='0';
   span.style.width='100%';
   span.style.textAlign='right';
   span.style.color='#aaaaaa';
   span.style.fontSize='8pt';
   span.id='_functionGuide';
   document.forms[0].insertBefore(span,null);
  }
}
/* 画面はロードされたとき実行（OnLoadイベントは使われる可能性があるので、setTimeoutで実現） */
function commonOnLoad() {
  if(document.readyState=='complete') {
    try {
      if(document.forms[0]) doDisplayFunctionGuide();
    } catch(e) {
      setTimeout('commonOnLoad()', 300);
    }
  } else {
    setTimeout('commonOnLoad()', 300);
  }
}
setTimeout('commonOnLoad()', 300);


var _buttonclick = null;
var _button;
var _button_bgcolor = null;
var _button_color = null;
function doButtonClick(button) {
  _button = button;
  try {
    _button.focus();
  } catch(e){}
  try {
    _button_bgcolor = _button.style.backgroundColor;
    _button_color = _button.style.color;
    _button.style.backgroundColor='#000000';
    _button.style.color='#ffffff';
    _buttonclick = setInterval("doButtonClickInterval()", 1000);
    _button.click();
  } catch(e){}
}

function doButtonClickInterval() {
  try {
    _button.style.backgroundColor = _button_bgcolor;
    _button.style.color = _button_color;
    clearInterval(_buttonclick);
  } catch(e){}
}

function doDblClick(evt) {
  if (document.all) evt = event;
  if (!parent || !parent.header) {
    return;
  }
  if(evt.srcElement&&(evt.srcElement.tagName=='SELECT'||evt.srcElement.tagName=='INPUT'||evt.srcElement.tagName=='SPAN')){
    //alert(evt.srcElement.tagName);
    return;
  }
  var links = parent.header.document.getElementsByTagName('A');
  if(links&&links.length>0&&links[0].parentNode.style.display=='') {
    links[0].click();
  }
}

document.onkeydown=doKeyDown;
document.ondblclick=doDblClick;
if(!document.all)document.captureEvents(Event.KEYDOWN);
if(!document.all)document.captureEvents(Event.DBLCLICK);
