/*
 * VwTypeSelect
 * 項目タイプ表示（選択系）
 */
LAST_MODIFIED('2005.02.08', '1.0.33');

/*
 * 使用するタイプを登録する
 */
registerViewObject(TYPE.COMBO,  ViewObjectCombo);
registerViewObject(TYPE.LIST,   ViewObjectList);
registerViewObject(TYPE.RADIO,  ViewObjectRadio);
registerViewObject(TYPE.CHECK,  ViewObjectCheck);

/**
 * ComboタイプのtypeObject実装クラス
 * @param  :
 * @return :作成したHTML文字列
 */
function ViewObjectCombo(){

  ViewObjectCombo.prototype.setDefaultProperty  = fnSetDefaultProperty_common;
  ViewObjectCombo.prototype.getPropertiesHtml   = fnGetPropertiesHtml;

  function fnGetPropertiesHtml(objDs){

    var strComboId = objDs.getProperty('id');
    var strBgcolor = tagFree(getBgcolorType(objDs, 0), 'white');
    var strCursor  = getCursorType(objDs);
    var strFontSize = '';
    if(objDs.getProperty('fontsize').length != 0){
      strFontSize = 'font-size :' + objDs.getProperty('fontsize') + 'pt;';
    }
    var strValue = '&nbsp;';
    
    var strHTML = '<table cellspacing="0" cellpadding="0" id="' + strComboId + 
    '" class="vw-combo ' + getTextElementClassProperty(objDs) +
    '" style="width:' + objDs.getProperty('width') + 
    'px;' + cancelStyle() + '"><tr><td id="' + strComboId 
    + '_SETWIDTH" align="right" style="width:100%; height:0px; ' +
    'cursor:' + strCursor + 
    '; "><table cellspacing="0" cellpadding="0" width="100%"><tr><td id="' + strComboId
    + '_SETSIZE" class="vw-combo ' + getTextElementClassProperty(objDs) + 
    '" style="background-color:' + strBgcolor + 
    ';color:' +  objDs.getProperty('fontcolor') +
    ';white-space:nowrap; overflow:hidden; border:none;margin:0px;padding:0px;' + strFontSize +
    '">' + strValue +
    '</td><td id="' + strComboId + '_SETBG" style="background-color:' + strBgcolor + 
    ';font-size:1pt;">&nbsp;</td><td id="' + strComboId + 
    '_SETHEIGHT" valign="center" align="center" style="width:14px; height:' + objDs.getProperty('height') + 
    'px; background-color:' + pref.view.get('popupbuttoncolor') + '; border:2px outset white;"><img src="' + IMAGEURL_COMBO + 
    '"></td></tr></table></td></tr></table>';
    log.debug('combo:\n'+strHTML);
    return strHTML;
  }

  this.setter = new Setter();
  function Setter() {
    Setter.prototype.width = _width;
    Setter.prototype.height = _height;
    Setter.prototype.fontsize = _fontsize;
    Setter.prototype.backgroundcolor = _backgroundcolor;
    Setter.prototype.fontcolor = _fontcolor;

    function _width(newValue, elementId, dataset, cellElementId, cellDataset) {
      var modified = '';
      var val = '';
      if(newValue != '') {
        if(newValue < 1) {
          newValue = 1;
          modified = 'modified';
        }
        val = parseInt(newValue) - 4;
        if(val < 20) val = 20;
      }
      getDocumentElementById(elementId).style.width = newValue;
      return flags(newValue, 'resized', modified, 'border');
    }
    
    function _height(newValue, elementId, dataset, cellElementId, cellDataset) {
      var modified = '';
      var val = '';
      if(newValue != '') {
        if(newValue < 1) {
          newValue = 1;
          modified = 'modified';
        } else if(newValue < 5) {
          val = 1;
        } else {
          val = parseInt(newValue) - 4;
        }
      }
      getDocumentElementById(elementId + '_SETHEIGHT').style.height = val;
      return flags(newValue, 'resized', modified);
    }
    
    function _fontsize(newValue, elementId, dataset, cellElementId, cellDataset) {
      var val = '';
      if(newValue != '') {
        val = newValue + 'pt';
      }
      getDocumentElementById(elementId + '_SETSIZE').style.fontSize = val;
      return flags(newValue, 'resized');
    }

    // 背景色
    function _backgroundcolor(newValue, elementId, dataset, cellElementId, cellDataset) {
      if(dataset.getProperty('visibility') != 'hidden'){
        if(newValue == '') {
          getDocumentElementById(elementId + '_SETSIZE').style.backgroundColor = '';
          getDocumentElementById(elementId + '_SETBG').style.backgroundColor = '';
        } else {
          setElementStyleBackgroundColor(getDocumentElementById(elementId + '_SETSIZE'), newValue, 'white');
          setElementStyleBackgroundColor(getDocumentElementById(elementId + '_SETBG'), newValue, 'white');
        }
      }
      return flags(newValue);
    }

    // 色
    function _fontcolor(newValue, elementId, dataset, cellElementId, cellDataset) {
      if(dataset.getProperty('visibility') != 'hidden'){
        getDocumentElementById(elementId + '_SETSIZE').style.color = newValue;
      }
      return flags(newValue);
    }
  }
}

/**
 * ListタイプのtypeObject実装クラス
 * @param  :
 * @return :作成したHTML文字列
 */
function ViewObjectList(){

  ViewObjectList.prototype.setDefaultProperty  = fnSetDefaultProperty_common;
  ViewObjectList.prototype.getPropertiesHtml   = fnGetPropertiesHtml;

  function fnGetPropertiesHtml(objDs){

    var strBgcolor = getBgcolorType(objDs, 0);
    var strCursor  = getCursorType(objDs);
    var strHTML = '';
    
    var strFontSize = '';
    var strFontHeight = '10';
    if(objDs.getProperty('fontsize').length != 0){
      strFontSize = 'font-size :' +objDs.getProperty('fontsize')  + 'pt;';
    }
    var strWidth = objDs.getProperty('width');
    var strSize = objDs.getProperty('listsize');
    var strClass = getTextElementClassProperty(objDs);
    var strValue = '';
    var optionList = objDs.getProperty('option');
    if(optionList && optionList.length && optionList.length > 0) {
      for(var i = 0; i < strSize; i++) {
        if(i < optionList.length) {
          if(i > 0) {
            strValue += '<br>\n';
          }
          var separatePos = optionList[i].indexOf('::');
          if(separatePos > 0) {
            strValue += '<span style="padding-left:2px;white-space:nowrap;overflow:hidden;width:' + strWidth + ';">' 
            + htmlEscape(optionList[i].substring(0,separatePos)) + '</span>';
          }
        } else {
          strValue += '<span style="white-space:nowrap;overflow:hidden;width:' + strWidth + ';">&nbsp;</span>';
        }
      }
    } else {
      for(var i = 0; i < strSize; i++) {
        strValue += '<span style="white-space:nowrap;overflow:hidden;width:' + strWidth + ';">&nbsp;</span>';
      }
    }

    strHTML += '<div id="' + objDs.getProperty('id') +
      '" class="vw-list ' + strClass +
      '" style="width:' + objDs.getProperty('width') +
      'px; height:' + objDs.getProperty('height') +
      'px; ' + strFontSize +
      'color:' + objDs.getProperty('fontcolor') +
      '; font-family:' + objDs.getProperty('fontfamily')+
      '; background-color:' + strBgcolor +
      '; cursor:' + strCursor + ';overflow:hidden;' + cancelStyle() + '">' + strValue +
      '</div>';

    return strHTML;
  }

  /** 
   * 表示更新メソッド群 
   */
  this.setter = new Setter();

  function Setter() {
    Setter.prototype.selectmode = _selectmode;
    Setter.prototype.listsize = _listsize;
    Setter.prototype.fieldvalue = _fieldvalue;
    Setter.prototype.option = _option;
 
     // 選択項目
    function _option(newValue, elementId, dataset, cellElementId, cellDataset) {
      dataset.setProperty('option', newValue);
      return flags(newValue, 'repaint', 'updated');
    }    

    // 値
    function _fieldvalue(newValue, elementId, dataset, cellElementId, cellDataset) {

      //カスタマイズ時：カスタマイズ自動チェック
      customizedDefaultValueChecker(dataset, newValue, 'fieldvalue', elementId);

      return flags(newValue);
    }
    
    // サイズ
    function _listsize(newValue, elementId, dataset, cellElementId, cellDataset) {
      if(newValue.length == 0 || newValue < 2){
        if(dataset.getProperty('selectmode')) {
          newValue = 1;
        } else {
          newValue = 2;
        }
      }
      getDocumentElementById(elementId).rows = newValue;
      return flags(newValue, 'repaint', 'modified');
    }
    
    // 複数選択
    function _selectmode(newValue, elementId, dataset, cellElementId, cellDataset) {
      var updates = null;
      if(newValue){
        newValue = 'multiple';
      }else{
        newValue = '';
        
        var siz = dataset.getProperty('listsize');
        if(!siz || siz < 2) {
          updates = createOtherUpdates('listsize', 2, updates);
        }

      }
      dataset.setProperty('selectmode', newValue);
      return flags(newValue, 'resized', 'updated', updates);
    }
  }
}

/**
 * RadioタイプのtypeObject実装クラス
 * @param  :
 * @return :作成したHTML文字列
 */
function ViewObjectRadio(){

  ViewObjectRadio.prototype.setDefaultProperty  = fnSetDefaultProperty_common;
  ViewObjectRadio.prototype.getPropertiesHtml   = fnGetPropertiesHtml;

  function fnGetPropertiesHtml(objDs){
/*
    var option = objDs.getProperty('option');
    var id = objDs.getProperty('id');
    var optionrows = objDs.getProperty('optionrows');
    var optioncols = objDs.getProperty('optioncols');
        
    return getRadioHtml(objDs, id, option, optionrows, optioncols);
*/
    var id = objDs.getProperty('id');
    var option = objDs.getProperty('option');
    var optioncols = Number(objDs.getProperty('optioncols'));
    var optionrows = 1;
    var texts = [];
    var fill = 0;
    if(option.length < optioncols) {
      fill = optioncols - option.length;
    }

    if(option.length > 0) {
      for(var i = 0; i < option.length; i++) {
        if(option[i].indexOf('<$') != -1) {
          texts[texts.length] = '***';
          while(0 < fill--) {
            texts[texts.length] = '***';
          }
        } else {
          texts[texts.length] = option[i].substring(0, option[i].indexOf('::'));
        }
      }
    } else {
      texts[texts.length] = ' ';
    }

    var bgcolorr = objDs.getProperty('backgroundcolorr');
    var bgcolort = objDs.getProperty('backgroundcolort');

    var setWidth = '';
    if(objDs.getProperty('width') != ''){
      var setWidth = ' width:' + objDs.getProperty('width') + 'px;';
    }

    var setHeight = '';
    if(objDs.getProperty('height') != ''){
      var setHeight = ' height:' + objDs.getProperty('height') + 'px;';
    }

    //背景色取得
    var strBgcolor = getBgcolorType(objDs, 0);
    //カーソルタイプ取得
    var strCursor  = getCursorType(objDs);

    var strHTML = '';
    strHTML += '<table cellpadding="0" cellspacing="0" id="' + id +
    '" class="vw-radio ' + getTextElementClassProperty(objDs) +
    '" style="cursor:' + strCursor + '; ' + setWidth + setHeight +
    ' background-color:' + strBgcolor + ';';
    if(objDs.getProperty('fontfamily').length != 0){
      strHTML += ' font-family:' + objDs.getProperty('fontfamily') + ';';
    }
    if(objDs.getProperty('fontstyle').length != 0){
      strHTML += ' font-style:' + objDs.getProperty('fontstyle') + ';';
    }
    if(objDs.getProperty('fontweight').length != 0){
      strHTML += ' font-weight:' + objDs.getProperty('fontweight') + ';';
    }
    if(objDs.getProperty('fontsize').length != 0){
      strHTML += ' font-size:' + objDs.getProperty('fontsize') + 'pt; ';
    }
    strHTML += 'color:' + objDs.getProperty('fontcolor') +
    ';' + cancelStyle() + '">';

    for(var i = 0; i < texts.length; i++) {
      var input = '<input type="radio" name="' + id + '" id="' + id + '.radio' + i 
        + '" style="width:14px;background-color:' + bgcolorr + '">';

      if(i % optioncols == 0) {
        strHTML += '<tr>';
      }

      strHTML += '<td width="14">' + input +
        '</td><td align="left"><span id="' + id + '.text' + i + 
        '" style="padding-left:1px;background-color:' + bgcolort + '">' +
        htmlEscape(texts[i]) + '</span></td>';

      if((i+1) % optioncols == 0) {
        strHTML += '</tr>';
      }
    }
    
    if(texts.length % optioncols > 0) {
      for(var i = (texts.length % optioncols); i < optioncols; i++) {
        strHTML += '<td width="14"></td><td align="left"></td>';
        if(i + 1 == optioncols) {
          strHTML += '</tr>';
        }
      }
    }

    strHTML += '</table>';
    return strHTML;
  }

  /** 
   * 表示更新メソッド群 
   */
  this.setter = new Setter();

  function Setter() {
    Setter.prototype.fontcolor = _fontcolor;
    Setter.prototype.fontsize = _fontsize;
    Setter.prototype.optioncols = _optioncols;
    Setter.prototype.optionrows = _optionrows;
    Setter.prototype.option = _option;
    Setter.prototype.backgroundcolorr = _backgroundcolorr;
    Setter.prototype.backgroundcolort = _backgroundcolort;
    
    function _fontcolor(newValue, elementId, dataset, cellElementId, cellDataset) {
      //setElementStyleFontColor(getDocumentElementById(elementId).childNodes.item(0), newValue);
      setElementStyleFontColor(getDocumentElementById(elementId), newValue);
      return flags(newValue);
    }
    
    function _fontsize(newValue, elementId, dataset, cellElementId, cellDataset) {
      if(newValue == '') {
        //getDocumentElementById(elementId).childNodes.item(0).style.fontSize = newValue;
        getDocumentElementById(elementId).style.fontSize = newValue;
      } else {
        //getDocumentElementById(elementId).childNodes.item(0).style.fontSize = newValue + 'pt';
        getDocumentElementById(elementId).style.fontSize = newValue + 'pt';
      }
      return flags(newValue, 'resized');
    }

    // 列数
    function _optioncols(newValue, elementId, dataset, cellElementId, cellDataset) {
      log.debug('_optioncols:' + newValue);

      //var id           = dataset.getProperty('id');
      var modified = 'modified';
      var option   = dataset.getProperty('option');
      var oldValue = dataset.getProperty('optioncols');
      
      if(!newValue || Number(newValue) <= 0) {
        newValue = 1;
        modified = 'modified';
      }

      if(hasListTag(option)) {
      
      } else if(option.length == 0){
        newValue = 1;
        modified = 'modified';
      } else if(Number(newValue) > option.length) {
        newValue = option.length;
        modified = 'modified';
      }
      
      var updated = '';
      var repaint = '';
      if(Number(oldValue) == Number(newValue)) {
        updated = 'updated';
      } else {
        repaint = 'repaint';
      }

      log.debug('flags:' + newValue + ',' + updated + ',' + modified + ',' + repaint);
      return flags(newValue, updated, modified, repaint);
    }

    // 行数
    function _optionrows(newValue, elementId, dataset, cellElementId, cellDataset) {
/*
      if(!dataset.getProperty('option') || dataset.getProperty('option').length == 0){
        newValue = 1;
        return flags(newValue, 'resized', 'modified');
      }
      dataset.setProperty('optionrows', newValue);
      radioRewrite(dataset, 'optionrows');
*/
      return flags(newValue, 'updated');
    }

    // 選択項目
    function _option(newValue, elementId, dataset, cellElementId, cellDataset) {
      log.debug('_option');
      
      var optioncols = dataset.getProperty('optioncols');
      var updates = null;
      var modified = '';
      
      if(hasListTag(newValue)) {
      
      } else if(newValue.length == 0){
        if(Number(optioncols) != 1) {
          updates = createOtherUpdates('optioncols', 1, updates);
        }
      } else if(Number(optioncols) > newValue.length) {
        updates = createOtherUpdates('optioncols', newValue.length, updates);
      }

      return flags(newValue, 'repaint', updates);
    }

    // ラジオボタンの背景色
    function _backgroundcolorr(newValue, elementId, dataset, cellElementId, cellDataset) {
      if(dataset.getProperty('visibility') != 'hidden'){
        for(var i = 0;; i++) {
          var element = getDocumentElementById(elementId + '.radio' + i);
          if(!element) break;
          setElementStyleBackgroundColor(element, newValue);
        }
      }
      return flags(newValue);
    }

    // 文字の背景色
    function _backgroundcolort(newValue, elementId, dataset, cellElementId, cellDataset) {
      if(dataset.getProperty('visibility') != 'hidden'){
        for(var i = 0;; i++) {
          var element = getDocumentElementById(elementId + '.text' + i);
          if(!element) break;
          setElementStyleBackgroundColor(element, newValue);
        }
      }
      return flags(newValue);
    }

  }
}

/**
 * 実行時に展開するリストの指定があるか
 */
function hasListTag(options) {
  for(var i in options) {
    if(options[i].indexOf('<$') != -1) {
      return true;
    }
  }
  return false;
}

/**
 * ラジオボタンオブジェクトHTML生成
 */
function getRadioHtml(objDs, id, options, optionrows, optioncols){
  var radios = new Array();
  var radioIndex = 0;
  var col = 0;
  
  var bgcolorr = objDs.getProperty('backgroundcolorr');
  var bgcolort = objDs.getProperty('backgroundcolort');
  
  if(options.length > 0){
    //「選択肢」の数分RADIOを作成
    for(var i in options) {
      col += 1;
      radios[radioIndex] = new Object();
      radios[radioIndex].radio = '<input type="radio" name="' + id + '" id="' + id + '.radio' + radioIndex + '" style="width:14px;background-color:' + bgcolorr + '">';
      if(options[i].indexOf('<$') != -1) {
        radios[radioIndex].text  = '<$...$>';
      } else {
        radios[radioIndex].text  = options[i].substring(0, options[i].indexOf('::'));
      }
      
      if(!isNaN(optioncols) && parseInt(optioncols) <= col) {
          radios[radioIndex].br = true;
          col = 0;
      } else {
          radios[radioIndex].br = false;
      }
      radioIndex++;
    }
  }else{
    radios[radioIndex] = new Object();
    radios[radioIndex].radio = '<input type="radio" name="' + id + '" id="' + id + '.radio0" style="width:14px;background-color:' + bgcolorr + '">';
    radios[radioIndex].text  = '';
  }

  var radioIndex = 0;

  var setWidth = '';
  if(objDs.getProperty('width') != ''){
    var setWidth = ' width:' + objDs.getProperty('width') + 'px;';
  }

  var setHeight = '';
  if(objDs.getProperty('height') != ''){
    var setHeight = ' height:' + objDs.getProperty('height') + 'px;';
  }

  //背景色取得
  var strBgcolor = getBgcolorType(objDs, 0);
  //カーソルタイプ取得
  var strCursor  = getCursorType(objDs);

  var strHTML = '';
  strHTML += '<table cellpadding="0" cellspacing="0" id="' + id +
  '" class="vw-radio ' + getTextElementClassProperty(objDs) +
  '" style="cursor:' + strCursor + '; ' + setWidth + setHeight +
  ' background-color:' + strBgcolor + ';';
  if(objDs.getProperty('fontfamily').length != 0){
    strHTML += ' font-family:' + objDs.getProperty('fontfamily') + ';';
  }
  if(objDs.getProperty('fontstyle').length != 0){
    strHTML += ' font-style:' + objDs.getProperty('fontstyle') + ';';
  }
  if(objDs.getProperty('fontweight').length != 0){
    strHTML += ' font-weight:' + objDs.getProperty('fontweight') + ';';
  }
  if(objDs.getProperty('fontsize').length != 0){
    strHTML += ' font-size:' + objDs.getProperty('fontsize') + 'pt; ';
  }
  strHTML += 'color:' + objDs.getProperty('fontcolor') +
  ';' + cancelStyle() + '">';
  for(var row = 0; row < optionrows; row++) {
      strHTML += '<tr>';
      for(var col = 0; col < optioncols; col++) {
          if(radios[radioIndex]) {
            strHTML += '<td width="14">' +
              radios[radioIndex].radio +
              '</td><td align="left"><span id="' + id + '.text' + radioIndex + '" style="padding-left:1px;background-color:' + bgcolort + '">' +
              htmlEscape(radios[radioIndex].text) + '</span></td>';
            radioIndex++;
          }else{
            strHTML += '<td width="14"></td><td align="left"></td>';
            row = optionrows;
          }
      }
      strHTML += '</tr>';
  }

  strHTML += '</table>';
  return strHTML;

}

  
/**
 * プロパティ変更に伴うラジオボタンの再描画
 * @param  :dsObj       dataSetオブジェクト プロパティ変更を行うラジオボタンのdataSetオブジェクト
 *          strProperty 文字型              プロパティ文字列
 * @return :
 */
/*
function radioRewrite(dsObj, strProperty){
  var id           = dsObj.getProperty('id');
  var option       = dsObj.getProperty('option');
  var radioMaxCols = dsObj.getProperty('optioncols');
  var radioMaxRows = dsObj.getProperty('optionrows');
  
  if(!radioMaxCols) {
    radioMaxCols = 1;
  }

  if(hasListTag(option)) {
  
  } else if(option.length == 0){
    radioMaxCols = 1;
  } else {
  
  }
  
  if(option && 0 < option.length) {
    // optionrows , optioncols の再設定
    var maxcols = 1;
    var maxrows = 1;
    var colincrement = 0;
    var rowincrement = 0;
    if(radioMaxCols && !isNaN(radioMaxCols)) {
      maxcols = parseInt(radioMaxCols);
      if(option.length < maxcols) {
        maxcols = option.length;
      } else if(maxcols < 1) {
        maxcols = 1;
      }
    }

    if(radioMaxRows && !isNaN(radioMaxRows)) {
      maxrows = parseInt(radioMaxRows);
      if(option.length < maxrows) {
        maxrows = option.length;
      } else if(maxrows < 1) {
        maxrows = 1;
      }
    }

    if(strProperty == 'optioncols') {
      var smallest = parseInt((option.length - 1) / maxcols) + 1;
      var biggest  = option.length;
      if(1 < maxcols) {
        parseInt(option.length / (maxcols - 1)) - 1;
      }
      if(maxrows < smallest) {
        maxrows = smallest;
      } else if(biggest < maxrows) {
        maxrows = biggest;
      }
    } else {
      if(((maxrows - 1) * maxcols) < option.length &&
        option.length <= (maxrows * maxcols)) {
      } else {
        maxcols = 1;
        while((maxcols * maxrows) < option.length) {
          maxcols++;
        }
      }
      if(maxcols < smallest) {
        maxcols = smallest;
      } else if(biggest < maxcols) {
        maxcols = biggest;
      }
    }

    maxrows = 0;
    while((maxcols * maxrows) < option.length) {
      maxrows++;
    }
    var optionrows = maxrows.toString();
    var optioncols = maxcols.toString();
    
    dsObj.setProperty('optionrows', maxrows.toString());
    dsObj.setProperty('optioncols', maxcols.toString());

    var innerHTML = getRadioHtml(dsObj, id, option, optionrows, optioncols);

    getDocumentElementById(id + '_span').innerHTML = innerHTML;
  }else{
    //optionが無い時、「追加」時と同様のHTMLを作成する
    dsObj.setProperty('optionrows', '1');
    dsObj.setProperty('optioncols', '1');
    setOuterHTML(getDocumentElementById(id + '_span'), getElementHtml(getDataSet(id)));
  }

  // 属性欄の再表示
  setPropertyField('optioncols', dsObj.getProperty('optioncols'), id);
  setPropertyField('optionrows', dsObj.getProperty('optionrows'), id);
}
*/

/**
 * CheckタイプのtypeObject実装クラス
 * @param  :
 * @return :作成したHTML文字列
 */
function ViewObjectCheck(){

  ViewObjectCheck.prototype.setDefaultProperty  = fnSetDefaultProperty_common;
  ViewObjectCheck.prototype.getPropertiesHtml   = fnGetPropertiesHtml;

  function fnGetPropertiesHtml(objDs){

    var strCheckId = objDs.getProperty('id');
    var strBgcolor = getBgcolorType(objDs, 0);
    var strBgcolorT = objDs.getProperty('backgroundcolort');
    var strCursor  = getCursorType(objDs);
    var strClass = getTextElementClassProperty(objDs);
    var strStyle = '';
    if(objDs.getProperty('width') != ''){
      strStyle = 'width:' + objDs.getProperty('width') + 'px; ';
    }
    if(objDs.getProperty('height') != '' ) {
      strStyle += 'height:' + objDs.getProperty('height') + 'px; ';
    }
    if(objDs.getProperty('fontsize') != '' ) {
      strStyle += 'font-size:' + objDs.getProperty('fontsize') + 'pt; ';
    }
    strStyle +='font-family:' + objDs.getProperty('fontfamily') +
             '; font-weight:' + objDs.getProperty('fontweight') +
              '; font-style:' + objDs.getProperty('fontstyle') +
                   '; color:' + objDs.getProperty('fontcolor') +
        '; background-color:' + strBgcolor +
                  '; cursor:' + strCursor + 
                  '; ' + cancelStyle();
    var strHTML = '<table id="' + strCheckId +
      '" cellpadding="0" cellspacing="0" border="0" class="vw-check ' + strClass +
      '" style="' + strStyle +
      '"><tr><td width="14px">' +
      '<input id="' + strCheckId +'.check" type="checkbox"' + 
      ' style="width:14px; height:' + objDs.getProperty('heightc') + 
      'px; cursor:' + strCursor + ';" value="ON"></td><td>' +
      '<div id="' + strCheckId +'.text" style="cursor:' + strCursor + 
      '; height:' + objDs.getProperty('heightt') + 
      'px; background-color:' + strBgcolorT + ';padding-left:1px;">' +
      htmlEscape(objDs.getProperty('labeltext')) +
      '</div></td></tr></table>';
    return strHTML;
  }

  /** 
   * 表示更新メソッド群 
   */
  this.setter = new Setter();

  function Setter() {
    Setter.prototype.height = _height;
    Setter.prototype.heightc = _heightc;
    Setter.prototype.heightt = _heightt;
    Setter.prototype.labeltext = _labeltext;
    Setter.prototype.fieldvalue = _fieldvalue;
    Setter.prototype.backgroundcolort = _backgroundcolort;
    Setter.prototype.fontsize = _fontsize;
    
    function _height(newValue, elementId, dataset, cellElementId, cellDataset) {
      var modified = '';
      if(newValue != '' && newValue < 1) {
        newValue = 1;
        modified = 'modified';
      }
      var element = getDocumentElementById(elementId);
      element.style.height = newValue;
      var val = 1;
      if(newValue != '' && newValue > 2) {
        val = newValue - 2;
      }
      return flags(newValue, 'resized', modified);
    }
    
    function _heightc(newValue, elementId, dataset, cellElementId, cellDataset) {
      var modified = '';
      if(newValue != '' && newValue < 1) {
        newValue = 1;
        modified = 'modified';
      }
      var element = getDocumentElementById(elementId + '.check');
      element.style.height = newValue;
      var val = 1;
      return flags(newValue, 'resized', modified);
    }
    
    function _heightt(newValue, elementId, dataset, cellElementId, cellDataset) {
      var modified = '';
      if(newValue != '' && newValue < 1) {
        newValue = 1;
        modified = 'modified';
      }
      var element = getDocumentElementById(elementId + '.text');
      element.style.height = newValue;
      var val = 1;
      return flags(newValue, 'resized', modified);
    }
    
    // テキスト
    function _labeltext(newValue, elementId, dataset, cellElementId, cellDataset) {
      var element = getDocumentElementById(elementId + '.text');
      element.innerHTML = htmlEscape(newValue);
      return flags(newValue, 'resized', 'border');
    }
    
    // 値
    function _fieldvalue(newValue, elementId, dataset, cellElementId, cellDataset) {
      customizedDefaultValueChecker(dataset, newValue, 'fieldvalue', elementId);
      return flags(newValue);
    }

    // 文字の背景色
    function _backgroundcolort(newValue, elementId, dataset, cellElementId, cellDataset) {
      if(dataset.getProperty('visibility') != 'hidden'){
        var element = getDocumentElementById(elementId + '.text');
        setElementStyleBackgroundColor(element, newValue);
      }
      return flags(newValue);
    }

    // 文字のサイズ
    function _fontsize(newValue, elementId, dataset, cellElementId, cellDataset) {
      var val = '';
      if(newValue != '') {
        val = newValue + 'pt';
      }
      getDocumentElementById(elementId).style.fontSize = val;
      //return flags(newValue, 'resized');
      return flags(newValue, 'resized', 'border'); //checkbox,file用
    }
    
  }
}
