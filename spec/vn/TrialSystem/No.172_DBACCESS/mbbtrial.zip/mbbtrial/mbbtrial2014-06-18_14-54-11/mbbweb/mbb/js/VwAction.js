/**
 * VwAction
 * メニューコマンド実行
 */
LAST_MODIFIED('2005.02.18', '1.0.35');

/** エラーオブジェクト一覧画面オブジェクト */
var m_errorSearchDialogObject = new ErrorSearchDialogObject();

/**
 * ウィンドウオープン関数
 * @param  :strUrl    文字型 URL
 *          strName   文字型 ウィンドウ名
 *          strOption 文字型 オプション
 * @return :オープンしたウィンドウからの戻り値
 */
function openDialogList(strUrl, strName, strOption){
  strOption.status = 'yes';
  strOption.scrollbars = 'yes';
  strOption.resizable = 'yes';
  return openDialog(strUrl, strName, strOption);
}

/**
 * ダイアログオープン関数
 * @param  :strUrl       文字型 url
 *          strName      文字型 ウィンドウ名
 *          arg                 引数
 *          strDlgWidth  文字型 高さ
 *          strDlgHeight 文字型 幅
 *          strDlgTop    文字型 縦位置
 *          strDlgLeft   文字型 横位置
 * @return :
 */
function openDialog(strUrl, strName, arg, openParam, strDlgHeight, openerWin){
  if(!arg) {
    arg = {width:200,height:100};
  }
  if(strDlgHeight) {
    var opt = {width:openParam, height:strDlgHeight};
  } else if(openParam && openParam.width && openParam.height) {
    var opt = openParam;
  } else {
    var opt = arg;
  }
  
  if(!openerWin) {
    openerWin = window;
  }
  setDialogArguments(arg);
  return openerWin.open(strUrl, strName, makeDialogOptionString(opt));
}

function makeDialogOptionString(opt) {
  opt.left=parseInt((window.screen.width - parseInt(opt.width))/2);
  opt.top=parseInt(((window.screen.height*0.8) - parseInt(opt.height))/2);
  var strOpt = '';
  for(var p in opt) {
    if(strOpt) {
      strOpt += ', ';
    }
    strOpt += p + '=' + opt[p];
  }
  return strOpt;
}

/**
 * DialogArgument設定関数
 * @param  :arg Object パラメータ
 *          key String パラメータ取り出し用キー
 */
function setDialogArguments(arg, key){
  var keystr = 'default';
  if(!window.currentDialogArguments) {
    window.currentDialogArguments = new Object();
  }
  window.currentDialogArguments[keystr] = arg;
  if(key && key != '') {
    window.currentDialogArguments[key] = arg;
  }
}

/**
 * DialogArgument取得関数
 * @param  :key String パラメータ取り出し用キー
 * @return :パラメータから参照する情報
 */
function getDialogArguments(key){
  var keystr = 'default';
  if(window.currentDialogArguments) {
    if(key && key != '') {
      if(window.currentDialogArguments[key]) {
        return window.currentDialogArguments[key];
      } else {
        alert('No dialogArguments for "' + key + '".');
      }    
    }
    if(window.currentDialogArguments[keystr]) {
      return window.currentDialogArguments[keystr];
    } else {
      alert('No dialogArguments for "' + keystr + '".');
    }
  } else {
    alert('No dialogArguments.');
  }
  return null;
}

/**
 * 新規ボタン押下時の処理
 * @param  :
 * @return :
 */
function doCommandNew(){
  if(parseInt(m_monitorEditStatus) == 2) return;

  openOpenNewPageDialog();
}

/**
 * 新規作成処理
 * @param  :
 * @return :
 */
function openNewViewEditor(_pageClass){
  var jspid = JSPID_VIEWEDITOR;
  if(_pageClass && _pageClass == '1') {
    jspid = JSPID_VIEWEDITORFRAME;
  }
  
  //submit用FROMの中身クリア
  clearSubmitForm();

  //リクエストに固定項目設定
  var tmpFieldIdSource = '';
  var tmpFieldIdSourceClass = 0;
  //プロセスID選択時
  if(m_itemDefinitionObject.empty == false){
    tmpFieldIdSource = m_itemDefinitionObject.itemDefine;
    tmpFieldIdSourceClass = 1;
  }
  var strRequestHTML  = '';
  strRequestHTML += '<input type="hidden" name="PROCESSID" value="">';
  strRequestHTML += '<input type="hidden" name="PROCESSMODE" value="1">';
  strRequestHTML += '<input type="hidden" name="DISPLANGID" value="' + DISPLANGID + '">';
  strRequestHTML += '<input type="hidden" name="JSPID" value="' + jspid + '">';
  strRequestHTML += '<input type="hidden" name="ERRORJSPID" value="' + JSPID_ERROR + '">';
  //THREADID付加
  if(m_threadId != ''){
    strRequestHTML += '<input type="hidden" name="THREADID" value="' + m_threadId + '">';
  }
  strRequestHTML += '<input type="hidden" name="STATEGROUP.EDITSTATE" value="0">';
  strRequestHTML += '<input type="hidden" name="STATEGROUP.FIELDIDSOURCE" value="' + tmpFieldIdSource + '">';
  strRequestHTML += '<input type="hidden" name="STATEGROUP.FIELDIDSOURCECLASS" value="' + tmpFieldIdSourceClass + '">';

  appendSubmitForm(strRequestHTML);
  getDocumentElementById('NEWPAGE').submit();
}

/**
 * 読込ボタン押下時の処理
 * @param  :
 @return :
 */
function doCommandOpen(){
  openPageListDialog();
}

/**
 * 読込ダイアログからコールされる関数
 * @param  :objArg オブジェクト
 *          isOk   objArgの属性値 true/false
 *          value  objArgの属性値 ページID
 * @return :
 */
function doLoadSubmit(objArg){
  //戻り値判定
  if(!objArg.isOk) return;
  window.status = getMessage('S0001');

  //submit用FROMの中身クリア
  clearSubmitForm();
  //リクエストに固定項目設定
  if(m_monitorEditStatus != 2){

    var jspid = JSPID_VIEWEDITOR;
    if(objArg.pageClass && objArg.pageClass == '1') {
      jspid = JSPID_VIEWEDITORFRAME;
    }
    
    var strRequestHTML  = '';
    strRequestHTML += '<input type="hidden" name="PROCESSID" value="">';
    strRequestHTML += '<input type="hidden" name="PROCESSMODE" value="3">';
    strRequestHTML += '<input type="hidden" name="DISPLANGID" value="' + DISPLANGID + '">';
    strRequestHTML += '<input type="hidden" name="JSPID" value="' + jspid + '">';
    strRequestHTML += '<input type="hidden" name="ERRORJSPID" value="' + JSPID_ERROR + '">';
    strRequestHTML += '<input type="hidden" name="STATEGROUP.EDITSTATE" value="1">';
    strRequestHTML += '<input type="hidden" name="SELECTKEYS.PAGEID" value="' + objArg.value + '">';

    if(!m_itemDefinitionObject.empty) {
      strRequestHTML += '<input type="hidden" name="STATEGROUP.FIELDIDSOURCECLASS" value="1">';
      strRequestHTML += '<input type="hidden" name="STATEGROUP.FIELDIDSOURCE" value="' + m_itemDefinitionObject.itemDefine + '">';
    }else{
      strRequestHTML += '<input type="hidden" name="STATEGROUP.FIELDIDSOURCECLASS" value="">';
      strRequestHTML += '<input type="hidden" name="STATEGROUP.FIELDIDSOURCE" value="">';
    }

  }else{

    var strRequestHTML  = '';
    strRequestHTML += '<input type="hidden" name="PROCESSID" value="">';
    strRequestHTML += '<input type="hidden" name="PROCESSMODE" value="1">';
    strRequestHTML += '<input type="hidden" name="DISPLANGID" value="' + DISPLANGID + '">';
    strRequestHTML += '<input type="hidden" name="JSPID" value="' + JSPID_VIEWEDITORCUSTOMIZE + '">';
    strRequestHTML += '<input type="hidden" name="ERRORJSPID" value="' + JSPID_ERROR + '">';
    strRequestHTML += '<input type="hidden" name="STATEGROUP.EDITSTATE" value="2">';
    strRequestHTML += '<input type="hidden" name="SELECTKEYS.PAGEID" value="' + objArg.value + '">';
  }

  //THREADID付加
  if(m_threadId != ''){
    strRequestHTML += '<input type="hidden" name="THREADID" value="' + m_threadId + '">';
  }

  appendSubmitForm(strRequestHTML);
  getDocumentElementById('NEWPAGE').submit();
}

/**
 * 「保存中」ダイアログを表示しないで保存
 */
function doCommandSaveModal() {
  /*
  var saveObject = new SaveObject();
  var pageId = m_loadPageVariable.pageId;
  //言語IDをpageIdから取得
  var tmpPos = pageId.lastIndexOf('_');
  if(tmpPos >= 0) {
    saveObject.saveInfo.langId = pageId.substr(parseInt(tmpPos) + 1);
  } else {
    saveObject.saveInfo.langId = '';
  }
  //ページ情報セット
  saveObject.saveInfo.pageId    = pageId;
  saveObject.saveInfo.pageName  = m_loadPageVariable.getPageName(saveObject.saveInfo.langId);
  saveObject.saveInfo.packageId = m_loadPageVariable.packageId;
  saveObject.saveInfo.timestampValue = m_loadPageVariable.timestampValue;
 
  var rtn = saveObject.createEditPageHtml();
  if(rtn == -1){
    //ページ変数、データHTML作成失敗
  }else if(rtn == 0){
    // ユーザキャンセル
  }else{
    document.forms['PAGEDATA'].innerHTML = saveObject.innerHTML();
    document.forms['PAGEDATA'].submit();
    //log.debug(saveObject.innerHTML());
    //alert('ok');
  }
  */
}

/**
 * 「保存中」ダイアログを表示しないで保存
 */
function doCommandSaveAsModal() {
}

/**
 * 「保存」ボタン押下時の処理
 * @param  :
 * @return :
 */
function doCommandSave(){

  // 新規のとき
  if(m_monitorEditStatus == 0) {
    doCommandSaveAs();
    return;
  }
  window.saveObject = new SaveObject();
  window.saveObject.saveUpdate();
}

/**
 *「別名で保存」ボタン押下時の処理
 * @param  :
 * @return :
 */
function doCommandSaveAs(){
  //カスタマイズ時使用不可
  if(m_monitorEditStatus == 2) return;
  window.saveObject = new SaveObject();
  window.saveObject.saveNew();
}

/**
 * 保存情報
 */
function getSaveDialogInfo(){
  var saveInfo = new Object();
  saveInfo.pageId = '';
  saveInfo.pageName = '';
  saveInfo.packageId = '';
  saveInfo.langId = '';
  
  if(m_monitorEditStatus != 0) {
    //言語IDをpageIdから取得
    var spl = m_loadPageVariable.pageId.split('_');
    saveInfo.pageId = spl[0];
    if(1 < spl.length) {
      saveInfo.langId = spl[spl.length - 1];
    }
    //saveInfo.pageName  = m_loadPageVariable.pageName[saveInfo.langId].value;
    saveInfo.pageName  = m_loadPageVariable.getPageName(saveInfo.langId);
    saveInfo.packageId = m_loadPageVariable.packageId;
  }
  return saveInfo;
}

/**
 * 「保存」、「別名で保存」時に使用するデータを作成、保持するオブジェクトを生成する
 * @ param  :
 * @ return :
 */
function SaveObject() {
  // 保存値
  this.saveInfo = new Object();
  this.saveInfo.pageId    = '';
  this.saveInfo.pageName  = '';
  this.saveInfo.packageId = '';
  this.saveInfo.langId    = '';
  this.saveInfo.pageInfos = '';
  //2003/08/18 timestampValue追加(更新チェック用)
  this.saveInfo.timestampValue = '';

  // 重複チェック true:する false:しない
  this.uniqueCheckFlg = true;

  // 保存中メッセージウィンドウ
  this.savingMessage = null;

  // 新規保存
  SaveObject.prototype.saveNew = function() {
    if(this.savingMessage) {
      this.savingMessage.onblur = '';
      window.focus();
      this.savingMessage.close();
      this.savingMessage = null;
    }
    this.uniqueCheckFlg = true;
    this.saveInfo.isOk = false;
    //セッションからDISPLANGID取得
    this.saveInfo.dispLangId = getSessionData('DISPLANGID');

    openSaveAsDialog();
  }

  // 上書き保存
  SaveObject.prototype.saveUpdate = function() {
    if(this.savingMessage) {
      this.savingMessage.onblur = '';
      this.savingMessage.close();
      this.savingMessage = null;
    }
    this.uniqueCheckFlg = false;
    var rtn = new Object();
    rtn.pageId = m_loadPageVariable.pageId;
    //言語IDをpageIdから取得
    var tmpPos = rtn.pageId.lastIndexOf('_');
    if(tmpPos >= 0) {
      rtn.langId = rtn.pageId.substr(parseInt(tmpPos) + 1);
    } else {
      rtn.langId = '';
    }
    rtn.pageName  = m_loadPageVariable.getPageName(rtn.langId);
    rtn.packageId = m_loadPageVariable.packageId;
    //ページ情報セット
    this.saveInfo.pageId    = rtn.pageId;
    this.saveInfo.pageName  = rtn.pageName;
    this.saveInfo.packageId = rtn.packageId;
    this.saveInfo.langId    = rtn.langId;
    this.saveInfo.timestampValue    = m_loadPageVariable.timestampValue;

    this.savingMessage = openSavingDialog();
  }

  // submitする内容
  SaveObject.prototype.innerHTML = function() {
    if(m_monitorEditStatus == 2){
      var tmpProcessId = PROCESSID_CUSTOMPAGESAVE;
    }else{
      var tmpProcessId = PROCESSID_PAGESAVE;
    }

    var innerHtml = '';
    innerHtml += '<INPUT TYPE="hidden" NAME="PROCESSID" VALUE="' + tmpProcessId + '">\n';
    innerHtml += '<INPUT TYPE="hidden" NAME="JSPID" VALUE="' + JSPID_SAVECOMPLETE + '">\n';
    innerHtml += '<INPUT TYPE="hidden" NAME="ERRORJSPID" VALUE="' + JSPID_SAVECOMPLETE + '">\n';
    innerHtml += '<INPUT TYPE="hidden" NAME="PROCESSMODE" VALUE="3">\n';
    innerHtml += '<INPUT TYPE="hidden" NAME="DISPLANGID" VALUE="' + DISPLANGID + '">\n';
    if(m_threadId != ''){
      innerHtml += '<input type="hidden" name="THREADID" value="' + m_threadId + '">';
    }

    //プロセスID選択時、作成モード設定
    var tmpFieldIdSourceClass = 0;
    var tmpFieldIdSource = '';
    if(m_itemDefinitionObject.empty == false){
      tmpFieldIdSource = m_itemDefinitionObject.itemDefine;
      tmpFieldIdSourceClass = 1;
    }
    innerHtml += '<INPUT TYPE="hidden" NAME="STATEGROUP.FIELDIDSOURCE" VALUE="' + tmpFieldIdSource + '">\n';
    innerHtml += '<INPUT TYPE="hidden" NAME="STATEGROUP.FIELDIDSOURCECLASS" VALUE="' + tmpFieldIdSourceClass + '">\n';
    innerHtml += this.strSubmit;

    return innerHtml;
  }

  //「保存中」ウィンドウのinitで実行される関数
  SaveObject.prototype.createEditPageHtml = function() {
    //page変数作成
    var page  = createSaveData(this.saveInfo);

    //変換
    var submitHtml = setPageVariable(page, this.savingMessage, m_errorSearchDialogObject);
    
    if(!submitHtml.isOk){
      var errMessageArray = new Array('VwInit.js','init','保存に失敗しました。','setPageVariable()',submitHtml.message);
      printHandlingError(submitHtml.error, errMessageArray);
      return -1;
    }

    if(submitHtml.errorObject) {
      if(submitHtml.errorObject.isOpen && submitHtml.errorObject.activate) {
        submitHtml.errorObject.activate();
      } else {
        openErrorItemDialog(submitHtml.errorObject);
      }
    }

    if(submitHtml.html == ''){
      var parentid = getDataSet(submitHtml.id).getProperty('parenttableid');
      if(parentid != '') {
        m_selection.removeAll();
        m_selection.add(parentid);
      } else {
        m_selection.removeAll();
        m_selection.add(submitHtml.id);
      }
      ////log.debug('updating property area. [VwAction.js/SaveObject.createEditPageHtml]');
      m_selection.updatePropertyArea();

      return 0;
    }

    //正常変換後
    this.strSubmit = submitHtml.html;
    return 1;

  }

  // 保存完了時に呼ばれるメソッド
  SaveObject.prototype.complete = function(newTimestampValue) {

    if(m_monitorEditStatus != 2) {

      //画面のステータス設定(更新)
      m_monitorEditStatus = 1;
      m_monitorId         = this.saveInfo.pageId;
      m_moitorName        = this.saveInfo.pageName;
      m_monitorModeString = getLiteral('editormode.edit');

      m_loadPageVariable.pageId    = this.saveInfo.pageId;
      m_loadPageVariable.packageId = this.saveInfo.packageId;
      m_loadPageVariable.timestampValue = newTimestampValue;
      
      //読込時とは異なる言語IDで保存した時の対処
      try{
        m_loadPageVariable.pageName[this.saveInfo.langId].value = this.saveInfo.pageName;
      }catch(e){
        m_loadPageVariable.pageName[this.saveInfo.langId] = new Object();
        m_loadPageVariable.pageName[this.saveInfo.langId].value = this.saveInfo.pageName;
      }
      m_loadPageVariable.editStatus = '1';

    }

    //画面にステータス表示
    setPropertyMonitorStatus(m_monitorId, m_moitorName, m_monitorModeString);
  }
}

/**
 * 「保存」ダイアログから呼ばれる関数
 * @param  :rtn オブジェクト
 * @return :
 */
function pageInfoOk(rtn){
  if(rtn.isOk) {
    if(rtn.langId != '') {
      if(0 < rtn.pageId.indexOf('_' + rtn.langId) && rtn.pageId.length == rtn.pageId.indexOf('_' + rtn.langId) + rtn.langId.length + 1) {
        window.saveObject.saveInfo.pageId     = rtn.pageId;
      } else {
        rtn.pageId     = rtn.pageId + '_' + rtn.langId;
      }
    }
    //ページ情報セット
    window.saveObject.saveInfo.pageId    = rtn.pageId;
    window.saveObject.saveInfo.pageName  = rtn.pageName;
    window.saveObject.saveInfo.packageId = rtn.packageId;
    window.saveObject.saveInfo.langId    = rtn.langId;
    window.saveObject.saveInfo.timestampValue    = rtn.timestampValue;

    window.saveObject.savingMessage = openSavingDialog();
  }
}

/**
 *「プレビュー設定」の処理
 */
function doCommandPreviewSettings(){

  var objArg = new Object();
  if(m_loadPageVariable.pageId) {
    objArg.pageId = m_loadPageVariable.pageId;
  } else {
    objArg.pageId = '';
  }

  var ds = getDataSet(ELEMENTID_FIRSTFORM);
  var value = ds.getProperty(PREVIEWPROPERTYID);
  objArg.params = new HttpParameter(value);

  objArg.returnOk = onReturnOk;

  openPreviewSettingsDialog(objArg);
  
  function onReturnOk(rtn) {
    if(rtn.isOk) {

      if(rtn.params.get('PROCESSID') == '') {
        rtn.params.remove('PROCESSID');
        rtn.params.remove('PROCESSMODE');

      } else if(rtn.params.get('PROCESSMODE') == '') {
        rtn.params.remove('PROCESSMODE');
      }

      if(rtn.params.get('JSPID') == '') {
        rtn.params.remove('JSPID');
      }

      var newvalue = rtn.params.toString();
      if(newvalue != value) {
        ds.setProperty(PREVIEWPROPERTYID, newvalue);
        m_undoManager.notSaved();
      }
    }
  }
}

/**
 *「プレビュー」の処理
 * @param  :
 * @return :
 */
function doCommandPreview(){

  if(!m_undoManager.stateSaved()) {
    if(0 == confirm(getMessage('A0061'))) {
      return;
    }
  }

  var saveinfo = getSaveDialogInfo();
  if(saveinfo.pageId == '') {
    alert(getMessage('A0060'));
    return null;
  }

  var ds = getDataSet(ELEMENTID_FIRSTFORM);
  var setting = ds.getProperty(PREVIEWPROPERTYID);
  try {
    var params = new HttpParameter(setting);
  } catch(e) {
    var ret = confirm(getMessage('A0062', [e.message, setting]));
    if(!ret) {
      return null;
    }
    params = new HttpParameter();
  }

  if(params.get('PROCESSID') == '') {
    params.set('PROCESSID', PROCESSID_PREVIEW);
  }

  if(params.get('PROCESSMODE') == '') {
    params.set('PROCESSMODE', '1');
  }

  if(params.get('JSPID') == '') {
    params.set('JSPID', JSPID_PREVIEW);
  }

  if(params.get('PAGEID') == '') {
    params.set('PAGEID', saveinfo.pageId);
  }

  if(params.get('DISPLANGID') == '') {
    params.set('DISPLANGID', saveinfo.langId);
  }

  if(m_threadId != '') {
    params.set('THREADID', m_threadId);
  }

  params.url = './appcontroller';
  window.open(params.toString());

}

/**
 *「項目定義読込」ボタン押下時の処理
 * @param  :
 * @return :
 */
function doCommandLoadFields(){
  //カスタマイズ時使用不可
  if(m_monitorEditStatus == 2) return;

  openProcessList();
}

/**
 * 選択された項目定義ID、項目定義リストを取得し、変数に保存(プロセス一覧ダイアログからコール)
 * @param  :rtnObj           オブジェクト
 *          itemDefine       rtnObjの属性値       項目定義ID
 *          itemDefineList[] rtnObjの属性値(配列) 項目定義リスト
 * @return :
 * @note:
 */
function setItemDefine(rtnObj){
  m_itemDefinitionObject.empty = false;
  m_itemDefinitionObject.itemDefine = rtnObj.itemDefine;
  replaceItemDefinitionList(rtnObj.itemDefineList);
  
  // 項目名をツールチップに使用していた場合更新する
  if(getViewToolTipText.formats) {
    for(type in getViewToolTipText.formats) {
      if(getViewToolTipText.formats[type].indexOf('itemname') > 0) {
        for(var i=0; i<m_addElementArray.length; i++){
          updateViewToolTipAttribute(m_addElementArray[i]);
        }
        break;
      }
    }
  }
}

/**
 * m_itemDefinitionObject.itemDefineListを更新する
 */
function replaceItemDefinitionList(newList) {
  m_itemDefinitionObject.itemDefineList = new Array();
  m_itemDefinitionObject.itemDefineDict = new Object();
  for(var i = 0; i < newList.length; i++){
    fieldIdName = newList[i];
    m_itemDefinitionObject.itemDefineList[i] = fieldIdName;
    var pos = fieldIdName.indexOf('::');
    m_itemDefinitionObject.itemDefineDict[fieldIdName.substring(0, pos)] = fieldIdName.substring(pos + 2);
  }
}

/**
 *「追加」ボタン押下時の処理
 * @param  :
 * @return :
 */
function doCommandAdd(){
  if(m_monitorEditStatus == null || m_monitorEditStatus == 2) return;
  //追加ダイアログへのパラメータ作成(項目,TYPE)
  var paraObject = new Object();
  paraObject.fieldIds = new Array();
  //項目ID取得時：項目定義リストをセット、未取得時：空の配列をセット
  if(m_itemDefinitionObject.empty == false){
    for(var i=0; i < m_itemDefinitionObject.itemDefineList.length; i++){
      paraObject.fieldIds[i] = m_itemDefinitionObject.itemDefineList[i];
    }
    paraObject.itemDefineDict = m_itemDefinitionObject.itemDefineDict;
  }
  paraObject.pageItemTypeIds = new Array();
  for(var i in TYPE){
    var typeid = TYPE[i];
    var typetype = getPropertyInfoDef(typeid, 'type').convertiblePropertyId;
    if(typetype == 'type.node' || typetype == 'type.leaf'){
      paraObject.pageItemTypeIds[paraObject.pageItemTypeIds.length] = typeid;
    }
  }
  
  paraObject.typeNames = new TypeNames();
  paraObject.objectTypes = getTypeInfoDefs();
  paraObject.submitCreate = true;
  for(var i = 0; i < m_addElementArray.length; i++) {
    if(getDataSet(m_addElementArray[i])) {
      var dataset = getDataSet(m_addElementArray[i]);
      if(dataset.type) {
        switch(dataset.type.value) {
        case TYPE.BUTTON:
        case TYPE.SUBMIT:
        case TYPE.RESET:
          paraObject.submitCreate = false;
          break;
        }
        if(!paraObject.submitCreate) {
          break;
        }
      }
    }
  }

  paraObject.returnOk     = onReturnOk;
  paraObject.returnCancel = function(){};
  paraObject.isUnique     = checkUnique;

  openAddItemDialog(paraObject);
  
  function checkUnique(id){
    var checkId = id.toLowerCase();
    for(var i = 0; i < m_addElementArray.length; i++) {
      /* 2005.2.18
      var ds = getDataSet(m_addElementArray[i]);
      var pageItemId = ds.getExtraProperty('pageItemId');
      if(pageItemId) {
        if(checkId == pageItemId.toLowerCase()) {
          return false;
        }
        continue;
      }
      */
      if(checkId == m_addElementArray[i].toLowerCase()) {
        return false;
      }
    }
    return true;
  }
  
  /*
   *
   */
  function onReturnOk(rtn){

    document.body.style.cursor = 'wait';
    getDocumentElementById('FORMSCREEN').style.visibility = 'hidden';

    // window.status 表示用のカウント
    var statusMsg = getMessage('S0002');
    var count = 0;
    var maxcount = rtn.items.length + rtn.buttons.length;
    if(rtn.createTitles) {
      maxcount += rtn.items.length;
    }
    if(rtn.createList) {
      maxcount += 1;
    }
    
    var strCreateHtml = '';
    var workAddArray = [];

    var prefinit = pref.init.get(rtn.defaultItem.itemTypeId);
    var rows = Number(prefinit.get('rows'));
    if(!rows) {
      rows = 1;
      var height = Number(prefinit.get('height'));
      if(height) {
        rows = parseInt((height + (DISPLAYROWHEIGHT/2)) / DISPLAYROWHEIGHT);
      } else if(pref.init.itemrows && pref.init.itemrows.get){
        rows = Number(pref.init.itemrows.get(rtn.defaultItem.itemTypeId));
      }
    }
    if(rows <= 1) {
      rows = 1;
    }
      
    var position = {
      minTop        : 20,
      minLeft       : 40,
      maxTop        : Infinity,
      '':''
    };
    
    if(rtn.createList) {
      // 一覧形式
      position.minTop = pref.init.listtable.get('top');
      position.minLeft = pref.init.listtable.get('left');
      position.incrementTop = 0;
      position.incrementLeft = pref.init.listtable.get('cellwidth');
      position.offsetLeft = pref.init.listtable.get('hardpadding');
      if(rtn.createTitles) {
        position.feedTop = (rows + 2) * DISPLAYROWHEIGHT;
        position.offsetTop = DISPLAYROWHEIGHT;
      } else {
        position.feedTop = (rows + 1) * DISPLAYROWHEIGHT;
        position.offsetTop = 0;
      }
      var title = {
        offsetTop  : 0,
        offsetLeft : position.offsetLeft,
        width      : position.incrementLeft - (position.offsetLeft*2),
        align      : pref.init.listtable.get('titlealign'),
        colon      : '',
        '':''
      }
      position.width = title.width;
      position.height = rows * DISPLAYROWHEIGHT;

    } else {
      // 通常（一覧形式ではない）

      position.minTop = prefinit.get('top');
      if(position.minTop == '') {
        position.minTop = pref.init.component.get('top');
      }
      position.minLeft = prefinit.get('left');
      position.offsetTop = 0;
      position.offsetLeft = 0;
      if(rtn.defaultItem.itemTypeId == TYPE.TABLE ||
         rtn.defaultItem.itemTypeId == TYPE.PANEL) {
        // テーブル・パネル
        position.feedLeft = 0;
        if(rtn.createTitles) {
          position.offsetTop = DISPLAYROWHEIGHT;
        }
        position.incrementTop = (rows + 1) * DISPLAYROWHEIGHT;

      } else {
        // テーブル・パネル以外
        position.maxTop = getDataSet(ELEMENTID_FIRSTFORM).getProperty('pageheight');
        if(position.maxTop < 600) {
          position.maxTop = 600;
        }
        position.width = prefinit.get('width');
        if(rtn.createTitles) {
          position.offsetLeft = pref.init.titledtext.get('titlewidth')
                              + pref.init.titledtext.get('interval');
        }
        position.feedLeft = position.offsetLeft + position.width + 20;
        position.incrementTop = rows * DISPLAYROWHEIGHT;
        position.maxTop -= position.incrementTop;
      }
      position.incrementLeft = 0;

      var title = {
        offsetTop  : 0,
        offsetLeft : 0,
        width      : pref.init.titledtext.get('titlewidth'),
        align      : pref.init.titledtext.get('titlealign'),
        colon      : getLiteral('common.colon'),
        '':''
      }
    }

    // 一覧テーブル追加
    if(rtn.createList && 0 < rtn.items.length) {

      window.status = statusMsg + '(' + count + '/' + maxcount + ')';

      if(rtn.createTitles) {
        var titlerows = 1;
      } else {
        titlerows = '';
      }

      if(rtn.createCells) {
        var tablecols = rtn.items.length;
        var cellwidth = position.incrementLeft;
      } else {
        tablecols = 1;
        cellwidth = position.incrementLeft * rtn.items.length;
      }

      var elementId = setAddElement(rtn.tableName, TYPE.TABLE);
      dataSetObj = getDataSet(elementId);
      dataSetObj.setProperty('top', position.minTop);
      dataSetObj.setProperty('left', position.minLeft);
      dataSetObj.setProperty('tablemode', 'MODE_COPY');
      dataSetObj.setProperty('titlerows', titlerows);
      dataSetObj.setProperty('tablerows', '');
      dataSetObj.setProperty('tablecols', tablecols);
      dataSetObj.setProperty('maxlines', '');

      var row = 1;
      // タイトルのセル作成
      if(rtn.createTitles) {
        var cellProperties = {cellwidth:cellwidth, cellheight:DISPLAYROWHEIGHT};
        for(var col = 1; col <= tablecols; col++) {
          setAddCellElement(elementId, row, col, cellProperties);
        }
        row++;
      }

      // 項目のセル作成
      var cellProperties = {cellwidth:cellwidth, cellheight:position.height};
      for(var col = 1; col <= tablecols; col++) {
        setAddCellElement(elementId, row, col, cellProperties);
      }

      //作成したDataSetのHTML文字列作成
      strCreateHtml += getElementHtml(dataSetObj);

      //追加したエレメントのIDを保存
      workAddArray[workAddArray.length] = elementId;

      count++;
    }
//log.debug(new DescriptionObject(position,'position',3));
//log.debug(new DescriptionObject(title,'title',3));

    // 項目追加
    position.top = position.minTop;
    position.left = position.minLeft;
    for(var i = 0; i < rtn.items.length; i++) {
      var item = rtn.items[i];

      if(rtn.createTitles) {

        window.status = statusMsg + '(' + count + '/' + maxcount + ')';

        var elementId = setAddElement('', TYPE.STRING);
        var dataSetObj = getDataSet(elementId);
        dataSetObj.setProperty('top', position.top + title.offsetTop);
        dataSetObj.setProperty('left', position.left + title.offsetLeft);
        dataSetObj.setProperty('width', title.width);
        dataSetObj.setProperty('align', title.align);
        dataSetObj.setProperty('fieldvalue', item.title + title.colon);

        //作成したDataSetのHTML文字列作成
        strCreateHtml += getElementHtml(dataSetObj);
        
        //追加したエレメントのIDを保存
        workAddArray[workAddArray.length] = elementId;

        count++;

      }

      window.status = statusMsg + '(' + count + '/' + maxcount + ')';

      var elementId = setAddElement(item.itemId, rtn.defaultItem.itemTypeId, rtn.specifiedObjectId);
      var dataSetObj = getDataSet(elementId);
      dataSetObj.setProperty('top', position.top + position.offsetTop);
      dataSetObj.setProperty('left', position.left + position.offsetLeft);

      if(position.width) {
        if(rtn.defaultItem.itemTypeId == TYPE.TABLE) {
          setAddCellElement(elementId, 1, 1, {cellwidth:position.width, cellheight:position.height});
        } else {
          dataSetObj.setProperty('width', position.width);
        }
      }

      // 選択肢を設定する
      if(rtn.defaultItem.setOptionProperty) {
        
        var option = prefInitOptionDefault(item.itemId);
        dataSetObj.setProperty('option', option);

        if(rtn.defaultItem.itemTypeId == TYPE.RADIO) {
          dataSetObj.setProperty('optioncols', 2);
        }
      }

      //作成したDataSetのHTML文字列作成
      strCreateHtml += getElementHtml(dataSetObj);
      
      //追加したエレメントのIDを保存
      workAddArray[workAddArray.length] = elementId;

      count++;

      // 位置
      //
      position.top += position.incrementTop;
      position.left += position.incrementLeft;
      if(position.maxTop < position.top) {
        position.top = position.minTop;
        position.left += position.feedLeft;
      }
    }

    // ボタン
    if(rtn.createList) {
      position.top += position.feedTop;
      position.left = position.minLeft;
    }
    position.offsetTop = 0;
    position.offsetLeft = 0;
    position.incrementTop = 0;
    position.incrementLeft = 60;
    for(var i = 0; i < rtn.buttons.length; i++) {
      var item = rtn.buttons[i];

      window.status = statusMsg + '(' + count + '/' + maxcount + ')';

      var elementId = setAddElement('', item.itemTypeId);
      var dataSetObj = getDataSet(elementId);
      dataSetObj.setProperty('top', position.top + position.offsetTop);
      dataSetObj.setProperty('left', position.left + position.offsetLeft);
      dataSetObj.setProperty('labeltext', item.labelText);
      var fnc = item.functionName + '(document.forms[0], \'<%@PROCESSID%>\', \'<%@PAGEID%>\', \'\', \'\', \'\', \'<%@PAGEID%>\', \'\', \'\')'
      dataSetObj.setProperty('onclick', fnc);

      //作成したDataSetのHTML文字列作成
      strCreateHtml += getElementHtml(dataSetObj);
      
      //追加したエレメントのIDを保存
      workAddArray[workAddArray.length] = elementId;

      count++;

      // 位置
      //
      position.top += position.incrementTop;
      position.left += position.incrementLeft;
    }

    window.status = statusMsg + '(' + count + '/' + maxcount + ')';

    //作成したHTML文字列をインサート
    getDocumentElementById(ELEMENTID_FIRSTFORM).innerHTML += strCreateHtml;
    

    //追加したエレメントのzIndex設定
    //最大値取得は１回だけ
    var getZindexFlg = false;
    var zIdx = 0;
    var cmdSet = new UndoableCommandSet(getLiteral('menuitem.add'));
    var cmdSelUndo = new CommandSelect(true,true,'');
    var cmdSelRedo = new CommandSelect(false,true,'');
    cmdSet.add(cmdSelUndo);

    for(i=0; i < workAddArray.length; i++){
      //zIndexの割り当て
      if(rtn.defaultItem.itemTypeId == TYPE.TABLE ||
         rtn.defaultItem.itemTypeId == TYPE.PANEL) {
        if(!getZindexFlg){
          zIdx = getMaxzIndex(1) + 1;
          getZindexFlg = true;
        }else{
          zIdx = zIdx + 1;
        }
      }else{
        if(!getZindexFlg){
          zIdx = getMaxzIndex(0) + 1;
          getZindexFlg = true;
        }else{
          zIdx = zIdx + 1;
        }
      }
      try {
        getDocumentElementById(workAddArray[i] + '_span').style.zIndex = zIdx;
      }catch(e){}

      //undo&redo用
      var objParam = createAddUndoParam(workAddArray[i], '追加');
      var cmd = createActionCommand(objParam);
      cmdSet.add(cmd);
      
      cmdSelRedo.add(workAddArray[i]);
    }

    cmdSet.add(cmdSelRedo);
    m_undoManager.execute(cmdSet);

    cmdSelRedo.redo();
    
    getDocumentElementById('FORMSCREEN').style.visibility = 'visible';
    document.body.style.cursor = 'auto';
    
    itemFocusSetter(elementId);

    m_menuBar.enableSave();
    m_menuBar.enableMenuItem('EDIT', 'CUT');
    m_menuBar.enableMenuItem('EDIT', 'COPY');
    m_menuBar.enableMenuItem('EDIT', 'DELETE');

    //ステータスバークリア
    window.status = '';  
  }
}

/**
 * 指定されたノードにフォーカスを当て、ウィンドウのスクロールバーを初期化する
 * @param  :strId 文字型 指定オブジェクトID
 * @return :
 */
function itemFocusSetter(strId){
  try{
    getDocumentElementById(strId).focus();
    document.body.scrollLeft = 0;
    document.body.scrollTop  = 0;
  }catch(err){}
}

/** 
 * @「追加」ダイアログからの戻り値からDataSetを生成し、html文字列を生成
 * @param  :eleName 文字型 項目ID
 *          eleType 文字型 項目TYPE
 * @return :
 */
function setAddElement(eleName, eleType, specifiedPageItemId){
  //ID作成
  var workId = '';
  if(specifiedPageItemId) {
    workId = specifiedPageItemId;
  } else {
    workId = getNewId(eleType);
  }
  
  //DataSet作成
  var ds = createDataSet(workId, eleType, eleName);

/* 2005.2.18
  //ID作成
  var workId = getNewId(eleType);
  
  //DataSet作成
  var ds = createDataSet(workId, eleType, eleName);
  
  if(specifiedPageItemId) {
    ds.setExtraProperty('pageItemId', specifiedPageItemId);
  }
*/
  //追加したIDを保存
  m_addElementArray[m_addElementArray.length] = workId;

  //項目TYPE=TABLE追加時、TDに対応するPANELオブジェクト作成
  if(eleType == TYPE.TABLE){
    setAddCellElement(workId, 1,1);
  }

  //デフォルトのプロパティをセットしたHTML文字列を取得
  initDataSetByType(ds);
  if(typeof(eleName) == 'string' && eleName.length > 0) {
    ds.setProperty('name', eleName);
    setFieldValueByName(eleType, workId, eleName);
  }
  return workId;
}

/**
 *
 */
function setAddCellElement(tableId, cellrow, cellcol, properties){
  var cellid = getCellId(tableId, cellrow, cellcol);
  var origds = getDataSet(cellid);
  
  var cellds = createDataSet(cellid, TYPE.CELL);
  cellds.setProperty('cellrow', cellrow);
  cellds.setProperty('cellcol', cellcol);
  cellds.setProperty('parenttableid', tableId);
  cellds.setProperty('originalparentitemid', tableId);
  if(properties) {
    for(var p in properties) {
      cellds.setProperty(p, properties[p]);
    }
  }
  
  //追加したIDを保存
  if(!origds) {
    m_addElementArray[m_addElementArray.length] = cellid;
  }
}

/**
 * 追加するエレメントのIDを生成する
 * @param  :eleType 文字型 項目TYPE
 * @return :        文字型 生成したID
 */
getNewId.prefixes = {};
function getNewId(eleType){
  if(getNewId.prefixes[eleType]) {
    getNewId.prefixes[eleType]++;
  } else {

    //ID作成
    var tempMaxIndex = 0;

    //全ID検索対象配列作成
    var tmpAllIds = new Array();
    for(var i=0; i < m_addElementArray.length; i++){
      tmpAllIds[tmpAllIds.length] = m_addElementArray[i];
    }
    for(var i=0; i < m_deleteElementArray.length; i++){
      tmpAllIds[tmpAllIds.length] = m_deleteElementArray[i];
    }

    for(var i=1; i < tmpAllIds.length; i++){  //全ID検索
      if(tmpAllIds[i].match(eleType) != null){  //同タイプのIDを検索
        var tmpIndex = parseInt(tmpAllIds[i].replace(eleType, ''));
        if(!isNaN(tmpIndex) && tmpIndex > tempMaxIndex){  //検索したIDに付くインデックスの最大値を検索
          tempMaxIndex = tmpIndex;
        }
      }
    }
    getNewId.prefixes[eleType] = tempMaxIndex + 1
  }
  return eleType + getNewId.prefixes[eleType];
}

/**
 * 特殊属性(tag属性)の作成及びデータ保持オブジェクトへの設定
 * @param  :strType 文字型 項目TYPE
 *          strId   文字型 画面上のID
 *          strName 文字型 項目ID
 * @return :
 */
function setFieldValueByName(strType, elementId, name){
  var fieldvalue = '';
  if(typeof(name) == 'string' && name.length != 0){
    fieldvalue = '<%' + name.replace('.','/') + '%>';
    getDataSet(elementId).setProperty('fieldvalue', fieldvalue);

    if(strType == TYPE.STRING ||
       strType == TYPE.TEXT ||
       strType == TYPE.PASSWORD ||
       strType == TYPE.LABEL ||
       strType == TYPE.TEXTAREA) {
      if(getDocumentElementById(elementId)) {
        getDocumentElementById(elementId).value = fieldvalue;
      }
    }

/*
    // 選択肢を設定する
    if(strType == TYPE.RADIO ||
       strType == TYPE.COMBO ||
       strType == TYPE.LIST) {
      
      var option = prefInitOptionDefault(name);
      getDataSet(elementId).setProperty('option', option);
    }
    if(strType == TYPE.RADIO) {
      getDataSet(elementId).setProperty('optioncols', 2);
    }
 */
 
  }
}

/*
 * ●無効 ○有効
 */
function prefInitOptionDefault(name) {
  name = firstDotToSlash(name);
  //return ['::<$' + name + '$>'];
  return ['<$' + name + '.name.OFFICIALNAME$>::<$' + name + '$>'];
}

/*
 * ●無効[0] ○有効[1]
 */
function prefInitOptionDefault2(name) {
  name = firstDotToSlash(name);
  return ['<$' + name + '.name.OFFICIALNAME$>[<$' + name + '$>]::'];
}

/*
 * 一つ目の.をスラッシュにする
 */
function firstDotToSlash(name) {
  var pos = name.indexOf('.');
  if(pos > 0) {
    return name.substring(0, pos) + '/' + name.substring(pos + 1);
  } else {
    return name;
  }
}

/**
 * エラーオブジェクト一覧ダイアログ
 * @param  :
 * @return :
 */
function ErrorSearchDialogObject(){

  /** public property */
  this.dialogTitle = getLiteral('dialog.errorobject.title');

  this.isOpen     = false;            //ダイアログが開いているか
  this.autoClose  = false;             //選択後のダイアログクローズ
  this.autoUpdate = true;             //アクティブ時の自動更新
  this.width = 550;
  
  this.header = new Array();
  this.header[0] = new Object();
  this.header[0].width = 150;
  this.header[0].title = getLiteral('common.objectid');
  this.header[1] = new Object();
  this.header[1].width = 100;
  this.header[1].title = getLiteral('common.itemtype');
  this.header[2] = new Object();
  this.header[2].width = 300;
  this.header[2].title = getLiteral('dialog.errorobject.descriptiontitle');
  
  /** public method */
  ErrorSearchDialogObject.prototype.init        = fnInit; //初期化
  ErrorSearchDialogObject.prototype.getItemList = fnGetItemList; //最新リスト取得
  ErrorSearchDialogObject.prototype.returnOk    = fnReturnOk;    //ダイアログから呼ばれる関数
  ErrorSearchDialogObject.prototype.add         = fnAddErrorObject;    //項目追加

  /**
   * 初期化
   * @param  :
   * @return :
   */
  function fnInit(){
    //this.errorObjects.body = new Array();
    this.body = new Array();
  }

  /**
   * 項目追加
   * @param  :
   * @return :
   */
  function fnAddErrorObject(_objectId, _fieldId, _errorName){
    var obj = new Array();
    obj[0] = _objectId;
    obj[1] = _fieldId;
    obj[2] = _errorName;

    //this.errorObjects.body[this.errorObjects.body.length] = obj;
    this.body[this.body.length] = obj;
  }

  /**
   * 項目リスト取得
   * @param  :
   * @return :rtnArray 配列 項目リスト
   */
  function fnGetItemList(){
    //return this.errorObjects;
    return this;
  }

  /**
   * 項目検索ダイアログから呼ばれる関数
   * @param  :rtnId    文字型 オブジェクトID
   * @return :
   */
  function fnReturnOk(rtnId){

    var checkId = '';
    try{
      checkId = getDocumentElementById(rtnId).id;
    }catch(e){}
    if(checkId == '') return;

    //プロパティテーブル更新
    var parentId = getDataSet(rtnId).getProperty('parenttableid');
    m_selection.removeAll();
    if(parentId != '') {
      m_selection.add(parentId);
    } else {
      m_selection.add(rtnId);
    }
    ////log.debug('updating property area. [VwAction.js/ErrorSearchDialogObject.fnReturnOk]');
    m_selection.updatePropertyArea();
  }
}

/**
 *
 */
function initDataSetByType(dataset) {
  getViewObject(dataset.type.value).setDefaultProperty(dataset);
}
 

/** 検索ダイアログ管理オブジェクト */
var objSerchManager = null;

/**
 * 配置されている項目の検索ダイアログを開く
 * @param  :
 * @return :
 */
function doCommandFind(){
  if(!objSerchManager){
    objSerchManager = new SerchDlgStatusObject();
  }
  if(objSerchManager.isOpen && objSerchManager.activate){
    //ダイアログ活性化
    objSerchManager.activate();
  }else{
    //ダイアログオープン
    openSearchItemDialog(objSerchManager);
  }
}

/**
 * 検索ダイアログの状態を保持するオブジェクト実装クラス
 * @param  :
 * @return :
 */
function SerchDlgStatusObject(){

  /** public property */
  
  this.isOpen     = false;            //ダイアログが開いているか
  this.autoClose  = true;             //選択後のダイアログクローズ
  this.autoUpdate = false;            //アクティブ時の自動更新

  this.width = 650;
  this.header = new Array();
  this.header[0] = new Object();
  this.header[0].width = 150;
  this.header[0].title = getLiteral('common.objectid');
  this.header[1] = new Object();
  this.header[1].width = 100;
  this.header[1].title = getLiteral('common.itemtype');
  this.header[2] = new Object();
  this.header[2].width = 200;
  this.header[2].title = getLiteral('common.itemid');
  this.header[3] = new Object();
  this.header[3].width = 200;
  this.header[3].title = getLiteral('common.text');


  /** public method */
  SerchDlgStatusObject.prototype.getItemList = fnGetItemList; //最新リスト取得
  SerchDlgStatusObject.prototype.returnOk    = fnReturnOk;    //ダイアログから呼ばれる関数


  /**
   * 項目リスト取得
   * @param  :
   * @return :rtnArray 配列 項目リスト
   */
  function fnGetItemList(){
    var rtnArray = new Array();
    var tmpType  = new TypeNames();
    for(var i=0; i<m_addElementArray.length; i++){
      var objDS   = getDataSet(m_addElementArray[i]);
      var strType = objDS.getProperty('type');
      if(strType == TYPE.CELL) {
        continue;
      }
      var strName = '';
      if(getTypeInfoDef(strType).name){
        strName = objDS.getProperty('name');
      }
      var strText = '';
      switch(strType) {
      case TYPE.IFRAME:
        strText = objDS.getProperty('src');
        break;
      case TYPE.APPLET:
      case TYPE.IMAGE:
      case TYPE.EMBED:
      case TYPE.OBJECT:
        strText = objDS.getProperty('alt');
        break;
      case TYPE.FORM:
        strText = objDS.getProperty('pagetitle');
        break;
      case TYPE.TABLE:
        strText = objDS.getProperty('caption');
        break;
      case TYPE.STRING:
      case TYPE.HIDE:
      case TYPE.TEXTAREA:
      case TYPE.LABEL:
      case TYPE.TEXT:
        strText = objDS.getProperty('fieldvalue');
        break;
      case TYPE.CHECK:
      case TYPE.BUTTON:
      case TYPE.SUBMIT:
      case TYPE.RESET:
        strText = objDS.getProperty('labeltext');
        break;
      case TYPE.COMBO:
      case TYPE.LIST:
      case TYPE.RADIO:
        strText = objDS.getProperty('option');
        break;
      }

      var j = rtnArray.length;
      //セルとカスタマイズ時のカスタマイズ不可項目は除く
      if(m_monitorEditStatus != 2){
        if(strType != TYPE.CELL){
          //rtnArray[j]      = m_addElementArray[i];
          rtnArray[j] = new Array();
          rtnArray[j][0] = m_addElementArray[i];
          rtnArray[j][1] = tmpType.getTypeName(strType);
          rtnArray[j][2] = strName;
          rtnArray[j][3] = strText;
        }
      }else{
        if(strType != TYPE.CELL && objDS.getItemCustomizable()){
          //rtnArray[j]      = m_addElementArray[i];
          rtnArray[j] = new Array();
          rtnArray[j][0] = m_addElementArray[i];
          rtnArray[j][1] = tmpType.getTypeName(strType);
          rtnArray[j][2] = strName;
          rtnArray[j][3] = strText;
        }
      }
    }
    this.body = rtnArray;
    return this;
  }

  /**
   * 項目検索ダイアログから呼ばれる関数
   * @param  :rtnId    文字型 オブジェクトID
   * @return :
   */
  function fnReturnOk(rtnId, addMode){

    var checkId = '';
    try{
      checkId = getDocumentElementById(rtnId).id;
    }catch(e){}
    if(checkId == '') return;
    
    if(addMode) {
      if(m_selection.has(rtnId)) {
        m_selection.remove(rtnId);
      } else {
        m_selection.add(rtnId);
      }
    } else {
      m_selection.removeAll();
      m_selection.add(rtnId);
    }
    ////log.debug('updating property area. [VwAction.js/SerchDlgStatusObject.fnReturnOk]');
    m_selection.updatePropertyArea();
  }
}

/**
 * すべて選択
 */
function doCommandSelectAll() {
  var front = m_selection.front;
  
  // 進捗表示用
  var prog = new WindowStatusProgressRatio(m_addElementArray.length, getMessage('S0008'));

  for(var i=0; i<m_addElementArray.length; i++){
    prog.update();
    m_selection.add(m_addElementArray[i]);
  }
  prog.release();
  
  //log.debug('updating property area. [VwAction.js/doCommandSelectAll]');
  m_selection.updatePropertyArea();

  if(front == ELEMENTID_FIRSTFORM){
    if(m_selection.front != ELEMENTID_FIRSTFORM){
      m_menuBar.enableMenuItem('EDIT', 'CUT');
      m_menuBar.enableMenuItem('EDIT', 'COPY');
      m_menuBar.enableMenuItem('EDIT', 'DELETE');
    }
  }else{
    if(m_selection.front == ELEMENTID_FIRSTFORM){
      m_menuBar.disableMenuItem('EDIT', 'CUT');
      m_menuBar.disableMenuItem('EDIT', 'COPY');
      m_menuBar.disableMenuItem('EDIT', 'DELETE');
    }
  }
}

/**
 * 項目検索ダイアログを開く
 * @param  :arg ダイアログに渡すオブジェクト
 * @return :開いたwindowオブジェクト
 */
function openSearchItemDialog(arg){
  return openDialog(DIALOG_ITEMSEARCH, '', arg, arg.width + 40, '500');
}

/**
 * エラー項目一覧ダイアログを開く
 * @param  :arg ダイアログに渡すオブジェクト
 * @return :開いたwindowオブジェクト
 */
function openErrorItemDialog(arg){
  var path = location.pathname;
  path = path.substring(0, path.lastIndexOf('/') + 1) + DIALOG_ERROROBJECT;
  return openDialog(path, '', arg, arg.width + 40, '500');
}

/**
 * 項目検索ダイアログを開く
 * @param  :arg ダイアログに渡すオブジェクト
 * @return :開いたwindowオブジェクト
 */
function openAddItemDialog(arg){
  return openDialog(DIALOG_ADD, DIALOGNAME_ADD, arg, '510', '430');
}

/**
 * 新規ページを開く
 * @param  :arg ダイアログに渡すオブジェクト
 * @return :開いたwindowオブジェクト
 */
function openOpenNewPageDialog(arg){
  return openDialog(DIALOG_OPENNEWPAGE, DIALOGNAME_OPENNEWPAGE, arg, '300', '200');
}

/**
 * 新規ページを開く
 * @param  :arg ダイアログに渡すオブジェクト
 * @return :開いたwindowオブジェクト
 */
function openPreviewSettingsDialog(arg){
  var strQueryString = './appcontroller?PROCESSID=&JSPID='
    + JSPID_PREVIEWSETTINGS + '&PROCESSMODE=1&DISPLANGID=' + DISPLANGID;
  if(m_threadId != '') {
    strQueryString += '&THREADID=' + m_threadId;
  }

  return openDialog(strQueryString, DIALOGNAME_PREVIEWSETTINGS, arg, '550', '300');
}

/**
 * ページ選択ダイアログを開く
 */
function openPageListDialog(){
  /**/
  var strQueryString = '';
  if(m_monitorEditStatus != 2) {
    strQueryString += '?PROCESSID=' + PROCESSID_PAGESELECT;
  } else {
    strQueryString += '?PROCESSID=' + PROCESSID_CUSTOMPAGESELECT;
  }
  strQueryString += '&JSPID=' + JSPID_PAGELIST
                  + '&PROCESSMODE=1'
                  + '&ERRORJSPID=' + JSPID_ERROR
                  + '&DISPLANGID=' + DISPLANGID
                  + '&THREADID=' + m_threadId;
  //return openWindow('./appcontroller' + strQueryString , DIALOGNAME_PAGELIST , 'width=700,height=480,status=yes,center=yes,help=no,menubar=no,scrollbars=yes,toolbar=no,location=no,directories=no,top=200,left=200');
  return openDialogList('./appcontroller' + strQueryString , DIALOGNAME_PAGELIST, {width:700,height:480});
}

/**
 * 名前を付けて保存ダイアログを開く
 */
function openSaveAsDialog(){
  var strQueryString = '?PROCESSMODE=1&PROCESSID=' + PROCESSID_STORECHECK 
    + '&JSPID=' + JSPID_PAGESAVE 
    + '&ERRORJSPID=' + JSPID_PAGESAVE
    + '&DISPLANGID=' + DISPLANGID
    + '&THREADID=' + m_threadId;
  if(m_monitorEditStatus == 1) {
    var inf = getSaveDialogInfo();
    strQueryString += '&INPUT.PAGEID=' + URLEncode(inf.pageId);
    strQueryString += '&INPUT.OFFICIALNAME=' + URLEncode(inf.pageName);
    strQueryString += '&INPUT.PACKAGEID=' + URLEncode(inf.packageId);
    strQueryString += '&INPUT.LANGID=' + URLEncode(inf.langId);
  }
  //return openWindow('./appcontroller' + strQueryString , DIALOGNAME_PAGESAVE , 'width=540,height=240,status=yes,center=yes,help=no,menubar=no,scrollbars=yes,toolbar=no,location=no,directories=no,top=250,left=250');
  return openDialog('./appcontroller' + strQueryString , DIALOGNAME_PAGESAVE , {width:540,height:240});
}

/**
 * 保存中ダイアログを開く
 */
function openSavingDialog(){
  return openDialog(DIALOG_SAVING, DIALOGNAME_SAVING, null, 300,200);
}

/**
 * 項目定義一覧を開く
 */
function openProcessList(){

  var strQueryString = '?PROCESSID=' + PROCESSID_PROCESSSELECT 
    + '&JSPID=' + JSPID_PROCESSLIST 
    + '&PROCESSMODE=1&DISPLANGID=' + DISPLANGID;

  if(m_threadId != '') {
    strQueryString += '&THREADID=' + m_threadId;
  }
  //return openWindow('./appcontroller' + strQueryString , DIALOGNAME_PROCESSLIST , 'width=600,height=400,status=yes,center=yes,help=no,menubar=no,scrollbars=yes,toolbar=no,location=no,directories=no,top=200,left=200');
  return openDialogList('./appcontroller' + strQueryString , DIALOGNAME_PROCESSLIST, {width:650,height:400});
}
