/**
 * VwLiteralConfiguration_JA
 * 文字列定義（日本語）
 */
try {
LAST_MODIFIED('2005.11.30', '1.0.37');
}catch(e){}

// 言語ID
var DISPLANGID = 'JA';

/**
 * リテラル定義
 */
function LiteralNames() {

  // 共通
  this['common.close']             = '閉じる';
  this['common.ok']                = 'OK';
  this['common.cancel']            = 'キャンセル';
  this['common.add']               = '追加';
  this['common.replace']           = '置換';
  this['common.delete']            = '削除';
  this['common.list']              = '一覧';
  this['common.search']            = '検索';
  this['common.back']              = '戻る';
  this['common.selectall']         = 'すべて選択';
  this['common.unselectall']       = '選択をすべて解除';
  this['common.pageid']            = 'ページID';
  this['common.officialname']      = '正式名称';
  this['common.packageid']         = 'パッケージID';
  this['common.langid']            = '言語ID';
  this['common.language']          = '言語';
  this['common.processid']         = 'プロセスID';
  this['common.processmode']       = 'プロセスモード';
  this['processmode.1']            = '初期化';
  this['processmode.2']            = '確認';
  this['processmode.3']            = '実行';
  this['common.jspid']             = 'JSPID';
  this['common.fielddefinitionid'] = '項目定義ID';
  this['common.applicationid']     = 'アプリケーションID';
  this['common.parentclass']       = '合計区分';
  this['common.pageclass']         = 'ページの種類';
  this['pageclass.0']              = '通常';
  this['pageclass.1']              = 'フレーム';
  this['common.unspecified']       = '指定なし';
  this['common.all']               = 'すべて';
  this['common.objectid']          = 'オブジェクトID';
  this['common.itemtype']          = '項目タイプ';
  this['common.itemid']            = '項目ID';
  this['common.itemname']          = '項目名';
  this['common.fieldid']           = 'フィールドID';
  this['common.text']              = 'テキスト';
  this['common.id']                = 'ID';
  this['common.name']              = '名前';
  this['common.value']             = '値';
  this['common.returnvalue']       = '戻り値';
  this['matchingmethod.partialmatch']  = '部分一致';
  this['matchingmethod.fullmatch']     = '完全一致';
  this['matchingmethod.forwardmatch']  = '前方一致';
  this['matchingmethod.backwardmatch'] = '後方一致';
  this['common.colon']             = '：';
  this['common.title']             = 'タイトル';

  //メニュー menuitem.
  this['menuitem.file']        = 'ファイル';
  this['menuitem.edit']        = '編集';
  this['menuitem.help']        = 'ヘルプ';

  this['menuitem.new']         = '新規作成';
  this['menuitem.open']        = '開く';
  this['menuitem.save']        = '保存';
  this['menuitem.saveas']      = '別名で保存';
  this['menuitem.loadfields']  = '項目定義の読込';
  this['menuitem.preview']     = 'プレビュー'; 
  this['menuitem.pdfpreview']     = 'PDFプレビュー'; 
  this['menuitem.previewsettings']     = 'プレビュー設定';

  this['menuitem.undo']        = '元に戻す';
  this['menuitem.redo']        = 'やり直し';
  this['menuitem.cut']         = '切り取り';
  this['menuitem.copy']        = 'コピー';
  this['menuitem.paste']       = '貼り付け';
  this['menuitem.delete']      = '削除';
  this['menuitem.selectall']   = 'すべて選択';
  this['menuitem.add']         = '追加';
  this['menuitem.find']        = '検索';

  this['menuitem.versioninfo'] = 'バージョン情報';

  this['command.move']           = '移動';
  this['command.resize']         = 'サイズ変更';
  this['command.pageitemchange'] = '項目タイプ変更';

  //編集中情報 editor.xxxx
  this['editor.pageid']     = '画面ID';
  this['editor.pagename']   = '画面名称';
  this['editor.editormode'] = 'モード';
  //画面モード editmode.xxx
  this['editormode.new']        = '新規';
  this['editormode.edit']       = '編集';
  this['editormode.customize']  = 'カスタマイズ';

  // プロパティ編集欄
  this['propertyarea.caption'] = 'プロパティ';
  //FRAME propertygroup.
  this['propertygroup.page']      = 'ページ';
  this['propertygroup.division']  = '分割';
  this['propertygroup.frame']     = 'フレーム';
  this['propertygroup.frameset']  = 'フレームセット';

  //項目TYPE名 pageitemtype.xxx
  this['pageitemtype.form']       = 'フォーム';
  this['pageitemtype.frame']      = 'フレーム';
  this['pageitemtype.panel']      = 'パネル';
  this['pageitemtype.table']      = 'テーブル';
  this['pageitemtype.combo']      = 'コンボボックス';
  this['pageitemtype.list']       = 'リストボックス';
  this['pageitemtype.radio']      = 'ラジオボタン';
  this['pageitemtype.button']     = 'ボタン';
  this['pageitemtype.image']      = '画像';
  this['pageitemtype.file']       = 'ファイル';
  this['pageitemtype.hide']       = '隠しパラメータ';
  this['pageitemtype.check']      = 'チェックボックス';
  this['pageitemtype.label']      = '表示テキスト';
  this['pageitemtype.string']     = '文字列';
  this['pageitemtype.textarea']   = 'テキストエリア';
  this['pageitemtype.text']       = '入力テキスト';
  this['pageitemtype.password']   = 'パスワード';
  this['pageitemtype.applet']     = 'アプレット';
  this['pageitemtype.embed']      = 'プラグイン';
  this['pageitemtype.object']     = 'オブジェクト';
  this['pageitemtype.submit']     = '送信ボタン';
  this['pageitemtype.reset']      = 'リセットボタン';
  this['pageitemtype.titledtext'] = 'タイトル付き入力テキスト';
  this['pageitemtype.iframe']     = 'インラインフレーム';   // 2003.09.18
  this['pageitemtype.hr']         = '水平線';   // 2003.10.02

  //プロパティ項目名
  this['property.onclick']             = 'onClick';
  this['property.ondblclick']          = 'onDblClick';
  this['property.onmousedown']         = 'onMouseDown';
  this['property.onmouseup']           = 'onMouseUp';
  this['property.onmouseover']         = 'onMouseOver';
  this['property.onmouseout']          = 'onMouseOut';
  this['property.onmousemove']         = 'onMouseMove';
  this['property.onkeydown']           = 'onKeyDown';
  this['property.onkeyup']             = 'onKeyUp';
  this['property.onkeypress']          = 'onKeyPress';
  this['property.onfocus']             = 'onFocus';
  this['property.onblur']              = 'onBlur';
  this['property.onchange']            = 'onChange';
  this['property.onload']              = 'onLoad';
  this['property.onunload']            = 'onUnload';
  this['property.onsubmit']            = 'onSubmit';
  this['property.onreset']             = 'onReset';
  this['property.itemtype']            = '項目タイプ';
  this['property.itemid']              = '項目ID';
  this['property.itemname']            = '項目名';
  this['property.groupid']             = 'グループID';
  this['property.fieldid']             = 'フィールドID';
  this['property.top']                 = '縦位置(px)';
  this['property.left']                = '横位置(px)';
  this['property.visibility']          = '表示';
  this['property.customizable']        = 'カスタマイズ';
  this['property.customized']          = 'カスタマイズ';
  this['property.style']               = 'スタイル';
  this['property.width']               = '幅(px)';
  this['property.height']              = '高さ(px)';
  this['property.heightc']             = 'チェックボックスの高さ(px)';
  this['property.heightt']             = '文字の高さ(px)';
  this['property.backgroundcolorr']    = 'ラジオボタンの背景色';
  this['property.backgroundcolort']    = '文字の背景色';
  this['property.backgroundcolor']     = '背景色';
  this['property.backgroundimage']     = '背景画像';
  this['property.fontcolor']           = '文字の色';
  this['property.initialvalue']        = '初期値';

  this['property.value']               = '値';
  this['property.value0']              = '未選択値';

  this['property.tableclass']          = 'クラスID';
  this['property.tablerowclass']       = '行クラスID';
  this['property.tablecolclass']       = '列クラスID';
  this['property.text']                = 'テキスト';
  this['property.textid']              = 'テキストID';
  this['property.fontsize']            = 'フォントサイズ(pt)';
  this['property.fontfamily']          = 'フォント名';
  this['property.fontweight']          = '文字の太さ';
  this['property.fontstyle']           = 'フォントスタイル';
  this['property.align']               = '水平方向配置';
  this['property.target']              = 'ターゲット';
  this['property.pagetitle']           = 'ページタイトル';
  this['property.pagewidth']           = 'ページの幅(px)';
  this['property.pageheight']          = 'ページの高さ(px)';
  this['property.action']              = 'アクション';
  this['property.method']              = 'メソッド';
  this['property.jsfile']              = 'JavaScriptパス';
  this['property.meta']                = 'メタ情報';
  this['property.enctype']             = '送信形式';
  this['property.labeltext']           = 'ラベル';
  this['property.maxlength']           = '最大文字数';
  this['property.imagesrc']            = '画像ファイル';
  this['property.alt']                 = '代替テキスト';
  this['property.link']                = 'ハイパーリンク';
  this['property.selectmode']          = '複数行選択';
  this['property.listsize']            = '行数';
  this['property.tablemode']           = 'モード';
  this['property.tablecols']           = '列数';
  this['property.tablerows']           = '行数';
  this['property.maxlines']            = '行数';
  this['property.titlerows']           = '見出し行';
  this['property.titlerowvanishing']   = '見出し行の表示';
  this['property.titlecols']           = '見出し列';
  this['property.corner']              = '見出しコーナー';
  this['property.titlerowborderwidth'] = '見出し行の枠線の太さ(px)';
  this['property.titlerowborderstyle'] = '見出し行の枠線の線種';
  this['property.titlerowbordercolor'] = '見出し行の枠線の色';
  this['property.titlerowcolor']       = '見出し行の背景色';
  this['property.titlerowstyle']       = '見出し行のスタイル';
  this['property.titlecolborderwidth'] = '見出し列の枠線の太さ(px)';
  this['property.titlecolborderstyle'] = '見出し列の枠線の線種';
  this['property.titlecolbordercolor'] = '見出し列の枠線の色';
  this['property.titlecolcolor']       = '見出し列の背景色';
  this['property.titlecolstyle']       = '見出し列のスタイル';
  this['property.option']              = '選択肢';
  this['property.optioncols']          = '最大列数';
  this['property.optionrows']          = '最大行数';
  this['property.underline']           = '文字の下線';
  this['property.textdecoration']      = '文字の装飾';
  this['property.borderwidth']         = '枠線の太さ(px)';
  this['property.borderstyle']         = '枠線の線種';
  this['property.bordercolor']         = '枠線の色';
  this['property.caption']             = '表題';
  this['property.captionfontsize']     = '表題のフォントサイズ(pt)';
  this['property.captionfontcolor']    = '表題の文字の色';
  this['property.captionalign']        = '表題の配置';
  this['property.cellspacing']         = '各セル間の幅(px)';
  this['property.cellpadding']         = '各セルの余白(px)';
  this['property.tdborderwidth']       = '罫線の太さ(px)';
  this['property.tdborderstyle']       = '罫線の線種';
  this['property.tdbordercolor']       = '罫線の色';
  this['property.tdstyle']             = '罫線のスタイル';
  this['property.cellrow']             = 'セルの行';
  this['property.cellcol']             = 'セルの列';
  this['property.cellvisibility']      = 'セルの表示';
  this['property.cellwidth']           = 'セルの幅(px)';
  this['property.cellheight']          = 'セルの高さ(px)';
  this['property.cellbackgroundcolor'] = 'セルの背景色';
  this['property.cellbackgroundimage'] = 'セルの背景画像';
  this['property.cellbordercolor']     = 'セルの枠線の色';
  this['property.cellstyle']           = 'セルのスタイル';
  this['property.editmode']            = '編集不可';
  this['property.code']                = 'コード';
  this['property.codebase']            = 'コードベース';
  this['property.title']               = 'タイトル';
  this['property.classid']             = 'クラスID';
  this['property.archive']             = 'アーカイブ';
  this['property.src']                 = 'ソース';
  this['property.imagewidth']          = '画像の幅(px)';
  this['property.imageheight']         = '画像の高さ(px)';
  this['property.imageposition']       = '画像の位置';
  this['property.params']              = 'パラメータ';
  this['property.attributes']          = '追加属性';
  this['property.embedsrc']            = 'Embedソース';
  this['property.embedparams']         = 'Embedパラメータ';
  this['property.embedattributes']     = '追加Embed属性';
  this['property.tooltip']             = 'ツールチップ';
  this['property.accesskey']           = 'アクセスキー';
  this['property.textcolor']           = '文字色';
  this['property.linkcolor']           = 'リンク色';
  this['property.vlinkcolor']          = '既読リンク色';
  this['property.alinkcolor']          = '選択リンク色';
  this['property.textcols']            = '幅(文字数)';
  this['property.textrows']            = '高さ(文字数)';
  this['property.hrcolor']             = '色';
  this['property.shade']               = '影';
  this['property.thickness']           = '太さ(px)';
  this['property.tabindex']            = 'タブ順序';
  this['property.locationfixing']      = '配置方法';

  this['visibility.hidden']            = '非表示';
  this['fontweight.lighter']           = 'より細い';
  this['fontweight.normal']            = '普通';
  this['fontweight.bold']              = '太い';
  this['fontweight.bolder']            = 'より太い';
  this['fontstyle.italic']             = '斜体';
  this['align.left']                   = '左寄せ';
  this['align.center']                 = '中央揃え';
  this['align.right']                  = '右寄せ';
  this['captionalign.left']            = '表の左上';
  this['captionalign.top']             = '表の上';
  this['captionalign.right']           = '表の右上';
  this['captionalign.bottom']          = '表の下';
  this['imageposition.left']           = 'ラベルの左';
  this['imageposition.above']          = 'ラベルの上';
  this['imageposition.right']          = 'ラベルの右';
  this['imageposition.below']          = 'ラベルの下';
  this['textdecoration.underline']     = '下線';
  this['selectmode.multiple']          = '複数行選択';
  this['enctype.application/x-www-form-urlencoded'] = 'フォームエンコード';
  this['enctype.multipart/form-data']               = 'ファイル送信';
  this['tablemode.simple']             = 'シンプルモード';
  this['tablemode.copy']               = 'コピーモード';
  this['tablemode.line']               = 'ラインモード';
  this['corner.row']                   = '見出し行';
  this['corner.col']                   = '見出し列';
  this['titlerows.use']                = '見出し行追加';
  this['titlecols.use']                = '1列目を使用';
  this['titlerowvanishing.novanish']   = '常に表示する';
  this['titlerowvanishing.vanish']     = 'レコードがないときは表示しない';
  this['borderstyle.none']             = 'なし';
  this['borderstyle.dotted']           = '点線';
  this['borderstyle.dashed']           = '破線';
  this['borderstyle.solid']            = '実線';
  this['borderstyle.double']           = '二重線';
  this['borderstyle.groove']           = 'くぼみ';
  this['borderstyle.ridge']            = '浮き出し';
  this['borderstyle.inset']            = 'インセット';
  this['borderstyle.outset']           = 'アウトセット';
  this['editmode.readonly']            = '編集不可';
  this['common.editbutton']            = '編集';
  this['locationfixing.pageright']     = 'ページの右端にあわせる';

  this['customizable.visibility']      = '表示設定可';
  this['customizable.location']        = '移動設定可';
  this['customizable.initialvalue']    = '初期値設定可';
  this['customizable.maxlines']        = '行数設定可';
  this['customized.visibility']        = '表示';
  this['customized.location']          = '移動';
  this['customized.initialvalue']      = '初期値';
  this['customized.maxlines']          = '行数';

  this['shade.noshade']                = '影なし';

  // デフォルト値
  //追加ダイアログで追加される実行ボタン
  this['initialvalue.addsubmit.value'] = '実行';
  this['initialvalue.createexecutebutton.value'] = '実行';
  this['initialvalue.createconfirmbutton.value'] = '確認';
  this['initialvalue.createlistbutton.value']    = '検索';

  //SUBMIT
  this['initialvalue.submit.value'] = 'クエリ送信';

  //RESET
  this['initialvalue.reset.value'] = 'リセット';

  // 表示オブジェクト用
  //FILE
  this['element.file.browsebuttonlabel'] = '参照';

  // フレーム編集画面
  this['property.frameborderwidth'] = '境界線の幅(px)';
  this['property.framebordercolor'] = '境界線の色';
  this['property.direction']        = '分割開始方向';
  this['direction.rows']            = '行方向';
  this['direction.columns']         = '列方向';
  this['property.divisionlevel']    = '階層';
  this['divisions.nodivisions']     = '分割なし';
  this['divisions.unit']            = '分割';
  this['property.framename']        = 'フレーム名';
  this['property.framesrc']         = 'フレームソース';
  this['property.framescrolling']   = 'スクロール';
  this['property.framenoresize']    = 'サイズ固定';
  this['framescrolling.auto']       = '自動';
  this['framescrolling.yes']        = 'する';
  this['framescrolling.no']         = 'しない';
  this['framenoresize.noresize']    = '固定する';

  // 新規ダイアログdialog.pagenew.xxx
  this['dialog.pagenew.title']  = '新規作成';

  // フレームテンプレートダイアログ dialog.frametemplate.xxx
  this['dialog.frametemplate.title']        = 'テンプレートからフレームの新規作成';
  this['dialog.frametemplate.frame']        = 'フレーム';
  this['dialog.frametemplate.description']  = '説明';
  this['dialog.frametemplate.heighttop']          = '上の高さ';
  this['dialog.frametemplate.heightbottom']       = '下の高さ';
  this['dialog.frametemplate.heightlefttop']      = '左上の高さ';
  this['dialog.frametemplate.heightrighttop']     = '右上の高さ';
  this['dialog.frametemplate.heightrightbottom']  = '右下の高さ';
  this['dialog.frametemplate.widthleft']          = '左の幅';
  this['dialog.frametemplate.widthright']         = '右の幅';
  this['dialog.frametemplate.widthtopleft']       = '上左の幅';
  this['dialog.frametemplate.widthmiddleleft']    = '中左の幅';
  this['dialog.frametemplate.widthbottomleft']    = '下左の幅';
  this['dialog.frametemplate.widthbottomright']   = '下右の幅';
  this['dialog.frametemplate.dividehorizontally'] = '上下に2分割';
  this['dialog.frametemplate.dividevertically']   = '左右に2分割';
  this['dialog.frametemplate.divideverticallytohorizontally']   = '上下に分割し、それぞれを左右に分割';
  this['dialog.frametemplate.dividehorizontallytovertically']   = '左右に分割し、それぞれを上下に分割';
  this['dialog.frametemplate.divideverticallyandhorizontally']  = '縦横に4分割';

  // ページ一覧ダイアログ dialog.pagelist.xxx
  this['dialog.pagelist.title'] = 'ページ一覧';

  // 保存ダイアログ dialog.pagesave.xxx
  this['dialog.pagesave.title'] = 'ページの保存';

  // 保存中ダイアログ dialog.savemessage.xxx
  this['dialog.savemessage.title']          = 'ページの保存中';
  this['dialog.savemessage.verifying']      = '保存データ検証中...';
  this['dialog.savemessage.saving']         = '保存中...';
  this['dialog.savemessage.savingcomplete'] = '保存完了';
  this['dialog.savemessage.savingfailed']   = '保存エラー';
  this['dialog.savemessage.errors']         = 'エラーの内容：';

  //プロセス一覧ダイアログ dialog.processlist.xxx
  this['dialog.processlist.title']          = 'プロセス一覧';

  //項目IDの確認ダイアログ dialog.confirmfieldid.xxx
  this['dialog.confirmfieldid.title']       = '項目IDの確認';
  this['dialog.confirmfieldid.fieldidlist'] = '項目IDリスト';

  // 追加ダイアログ dialog.pageitemadd.xxx
  this['dialog.pageitemadd.title']              = '画面項目追加';
  this['dialog.pageitemadd.titletext']          = 'ラベルテキスト';
  this['dialog.pageitemadd.addsubmitbutton']    = '実行ボタンを追加する';
  this['dialog.pageitemadd.processdefinition']  = '項目定義';
  this['dialog.pageitemadd.userdefifnition']    = 'ユーザ定義';
  this['dialog.pageitemadd.specifyobjectid']    = 'オブジェクトIDを指定する';
  this['dialog.pageitemadd.createlist']         = '一覧形式のテーブルを作成する';
  this['dialog.pageitemadd.appendtitle']        = 'タイトルを付ける';
  this['dialog.pageitemadd.appendtitletoitem']  = '項目にタイトルを付ける';
  this['dialog.pageitemadd.createcells']        = '項目ごとにセルを生成する';
  this['dialog.pageitemadd.setoptionproperty']  = 'データ項目値を選択肢とする';
  this['dialog.pageitemadd.createbuttons']      = 'ボタンを追加する';

  // 検索ダイアログ
  this['dialog.find.title']                 = '項目検索';
  this['dialog.find.closewhenselected']     = '選択後ダイアログを閉じる';
  this['dialog.find.updatewhenactivated']   = 'ダイアログがアクティブになった時に項目リストを更新する';
  this['dialog.find.update']                = '更新';
  this['dialog.find.framename']             = 'フレーム名';
  this['dialog.find.frame']                 = 'フレーム';
  this['dialog.find.frameset']              = 'フレームセット';

  // エラーオブジェクト一覧ダイアログ dialog.errorobject.xxx
  this['dialog.errorobject.title']            = 'エラーオブジェクト一覧';
  this['dialog.errorobject.descriptiontitle'] = 'エラーの内容';
  this['dialog.errorobject.V0001'] = '項目IDが重複している';
  this['dialog.errorobject.V0002'] = '他のオブジェクトと重なっている';
  this['dialog.errorobject.V0003'] = '親の外に配置されている';
  this['dialog.errorobject.V0004'] = 'フォームの外に配置されている';
  this['dialog.errorobject.V0005'] = '親からはみだしている';
  this['dialog.errorobject.V0006'] = '設定された幅が小さい';
  this['dialog.errorobject.V0007'] = '幅が設定されていない';

  // バージョン情報ダイアログ dialog.versioninfo.title
  this['dialog.versioninfo.title']          = 'ViewEditorのバージョン情報';

  // 項目タイプ変更ダイアログ
  // dialog.pageitemchange.xxx
  this['dialog.pageitemchange.title']       = '項目タイプ変更';

  // プロパティ編集ダイアログ dialog.propertyedit.xxx
  this['dialog.propertyedit.title']         = 'プロパティ編集';
  this['dialog.propertyedit.propertyvalue'] = 'プロパティ値';

  // 画像一覧ダイアログ dialog.imagelist.xxx
  this['dialog.imagelist.title']         = '画像ファイル一覧';
  this['dialog.imagelist.listfile']      = 'リスト表示';
  this['dialog.imagelist.listpreview']   = 'プレビュー表示';
  this['dialog.imagelist.file']          = 'ファイル';
  this['dialog.imagelist.openuploader']  = '画像の追加...';

  // dialog.colorpicker.xxx
  this['dialog.colorpicker.title']          = '色の選択';
  this['dialog.colorpicker.basecolor']      = '基本色';
  this['dialog.colorpicker.usercolor']      = '作成した色';
  this['dialog.colorpicker.originalcolor']  = '元の色';
  this['dialog.colorpicker.addcolor']       = '色を追加する';
  this['dialog.colorpicker.red']            = '赤';
  this['dialog.colorpicker.green']          = '緑';
  this['dialog.colorpicker.blue']           = '青';
  this['dialog.colorpicker.color']          = '色';

  // イベント編集ダイアログ dialog.eventedit.xxx
  this['dialog.eventedit.title']                = 'イベント編集';
  this['dialog.eventedit.title_hyperlink']      = 'ハイパーリンク編集';
  this['dialog.eventedit.functionname']         = '関数名';
  this['dialog.eventedit.operationname']        = '';
  this['dialog.eventedit.editurl']              = 'URL';
  this['dialog.eventedit.editjs']               = 'JavaScript';
  this['dialog.eventedit.singlequotrequired']   = '文字列はシングルクォーテーションでくくってください';
  this['dialog.eventedit.userdefinition']       = 'ユーザ定義';
  this['dialog.eventedit.hyperlink']            = 'ハイパーリンク';

  // JSファイル編集ダイアログ dialog.jsfileedit.xxx
  this['dialog.jsfileedit.title']         = 'JavaScriptファイル インクルード';
  this['dialog.jsfileedit.listtitle']     = 'JavaScriptファイル';
  this['dialog.jsfileedit.jsfilepath']    = 'ファイルパス';

  // リスト項目編集ダイアログ dialog.listitemedit.xxx
  this['dialog.listitemedit.title']       = 'リスト項目編集';
  this['dialog.listitemedit.listtitle']   = 'リスト項目';
  this['dialog.listitemedit.text']        = 'テキスト';
  this['dialog.listitemedit.value']       = '値';

  // パラメータ編集ダイアログ dialog.parameteredit.xxx
  this['dialog.parameteredit.title']      = 'パラメータ編集';
  this['dialog.parameteredit.listtitle']  = 'パラメータ';
  this['dialog.parameteredit.name']       = '名前';
  this['dialog.parameteredit.value']      = '値';
  this['dialog.parameteredit.title_before'] = '';
  this['dialog.parameteredit.title_after']  = '編集';

  // メタ情報編集ダイアログ dialog.metaedit.xxx
  this['dialog.metaedit.title']      = 'メタ情報編集';
  this['dialog.metaedit.listtitle']  = 'メタ情報';
  this['dialog.metaedit.attrname']   = '属性';
  this['dialog.metaedit.attrval']    = '項目';
  this['dialog.metaedit.value']      = '値';
  this['dialog.metaedit.title_before'] = '';
  this['dialog.metaedit.title_after']  = '編集';

  // 画像アップロードダイアログ 
  this['dialog.imageupload.title']              = '画像のアップロード';
  this['dialog.imageupload.rename']             = '別名でアップロードする';
  this['dialog.imageupload.overwrite.caption']  = '同じ名前のファイルがあったら:';
  this['dialog.imageupload.overwrite.off']      = '上書きしない';
  this['dialog.imageupload.overwrite.on']       = '上書きする';
  this['dialog.imageupload.submit']             = '送信';
  this['dialog.imageupload.continue']           = '続ける';

  // 項目IDアレイ編集ダイアログ dialog.fieldidarrayedit.xxx
  this['dialog.fieldidarrayedit.title']      = '項目IDアレイ編集';
  this['dialog.fieldidarrayedit.listtitle']  = '項目IDと値の一覧';
  this['dialog.fieldidarrayedit.text']       = '項目ID';
  this['dialog.fieldidarrayedit.value']      = '値';

  // 配列引数編集ダイアログ dialog.arrayedit.xxx
  this['dialog.arrayargumentedit.title']        = '配列引数編集';
  this['dialog.arrayargumentedit.listtitle']    = 'の一覧';

  //caption.pageid
  // ヘルプ
  // help.applicationmaster.xxx
  this['help.applicationmaster.title']  = 'アプリケーションマスタヘルプ';

  // help.pagemaster.xxx
  this['help.pagemaster.title']         = 'ページマスタヘルプ';

  // help.processmaster.xxx
  this['help.processmaster.title']      = 'プロセスマスタヘルプ';

  // ソート項目編集 dialog.sortfieldedit.xxx
  this['dialog.sortfieldedit.title']      = 'ソート項目編集';

  // プレビュー設定ダイアログ dialog.previewsettings.xxx
  this['dialog.previewsettings.title']      = 'プレビュー設定';
  this['dialog.previewsettings.params']     = 'パラメータ';

  // 項目IDヘルプ
  this['help.fieldid.title']     = '項目IDヘルプ';

  // 戻り値ヘルプ
  this['help.returnvalue.title'] = '戻り値ヘルプ';
}

/**
 * メッセージ定義
 */
function Messages() {

  // 読込時エラーメッセージ
  this.E0001 = 'データの名前（$prm0）は定義されていません。';
  this.E0002 = '画面項目（$prm0）が見つかりません。';
  this.E0003 = '$prm0（$prm1）は階層の中に存在していません。';
  this.E0004 = 'form以外のオブジェクトが最上位階層に存在することはできません。';
  this.E0005 = '$prm1（$prm2）に、属性値（$prm0）が存在していません。';
  this.E0006 = 'table（pageItemId=$prm0）のセル（row=$prm1,col=$prm2）が見つかりません。';
  this.E0007 = '$prm0（$prm3）の属性値（$prm1=$prm2）は不正です。';
  this.E0008 = '未対応の画面項目タイプ $prm0 があります。（このオブジェクトは表示も保存もできません。）';
  this.E0009 = 'テーブル（pageItemId=$prm0）のセル（row=$prm1,col=$prm2）が存在しないため、正しく配置できません。';
  this.E0010 = '画面項目（$prm0）は定義されていないので、属性値（$prm1=$prm2）は設定できません。';
  this.E0011 = '画面項目（$prm0）は定義されていないので、属性値（$prm1=$prm2）のカスタマイズはできません。';
  this.E0012 = '$prm0（$prm3）に属性（$prm1）は定義されていないので、属性値（$prm1=$prm2）のカスタマイズはできません。';
  this.E0013 = '$prm0（$prm3）のカスタマイズ（$prm1=$prm2）は許可されていません。';
  this.E0014 = '$prm1（$prm0）の親オブジェクト（$prm2）に対する参照が、循環参照となっています。';
  this.E0015 = '$prm1（$prm0）の $prm2 属性値を訂正しました。';

  // 編集時alertメッセージ
  this.A0001 = '読込に失敗しました。';
  this.A0002 = 'データ読込に失敗しました。';
  this.A0003 = '画面項目（$prm0）が見つかりません。';

  // 追加ダイアログ 
  this.A0010 = '項目IDを設定してください。';
  this.A0011 = 'オブジェクトIDを入力してください。';
  this.A0012 = 'オブジェクトIDは20文字以内で入力してください。';
  this.A0013 = 'オブジェクトIDに不正な文字（$prm0）が使用されています。';
  this.A0014 = 'オブジェクトID（$prm0）はすでに使用されています。';

  // 保存時
  this.A0020 = '同一の画面IDがすでに存在します。上書きしますか？';
  this.A0021 = '保存が完了しました。';
  this.A0022 = '保存できませんでした。';
  this.A0023 = '保存できません。';

  // JSファイル編集ダイアログ 
  this.A0030 = 'ファイルパスを入力してください。';
  this.A0031 = '同一のファイルパスがすでに追加されています。';

  // 選択肢編集ダイアログ 
  this.A0040 = 'テキストを入力してください。';
  this.A0041 = '同一のテキストがすでに追加されています。';
  this.A0042 = '同一の値がすでに追加されています。';
  this.A0043 = '同一のアクセスキーがすでに追加されています。';
  this.A0044 = 'アクセスキーはラジオボタンでのみ有効です。'
  this.A0045 = '同一の$prm0がすでに追加されています。';

  // パラメータ編集ダイアログ 
  this.A0050 = '名前を入力してください。';
  this.A0051 = '同一の名前がすでに追加されています。';

  // プレビュー 
  this.A0060 = '保存するまでプレビューはできません。';
  this.A0061 = '現在保存されている内容をプレビューします。';
  this.A0062 = 'プレビューの設定で以下のエラーがありました.\n'
              + 'デフォルトのパラメータを使用してプレビューを実行しますか?'
              + '\n\nエラー : $prm0\n\n設定 : $prm1';
      
  // 画像アップロード
  this.A0070 = 'ファイル名を入力してください';
  this.A0071 = 'ファイル名に\'$prm0\' は使えません.($prm1)\n別名を指定してください.';
  this.A0072 = '別名を入力してください';
  this.A0073 = 'ファイル名に\'$prm0\' は使えません.($prm1)';
  this.A0074 = 'アップロードしようとしたファイルは<br> 存在しないか、空のファイルです.<br>';
  this.A0075 = '$prm0 はアップロードされました.<br>';
  this.A0076 = '<font color=red>アップロードできませんでした.</font><br>ファイル名：$prm0 <br>';
  this.A0077 = '<font color=red>アップロードできませんでした.</font><br>$prm0 は<br>同じ名前のファイルが存在します.<br>';
  this.A0078 = '<font color=red>サイズが大きすぎます.<br>(最大$prm0)</font><br>';
  this.A0079 = '<font color=red>画像ファイルではありません.</font><br>ファイル名：$prm0 <br>Content-Type:$prm1<br>';
  this.A0080 = '以下の拡張子以外は無効です.($prm0)\n別名を指定してください.\n\n$prm1';
  this.A0081 = '以下の拡張子以外は無効です.($prm0)\n\n$prm1';

  // 編集時confirmメッセージ
  this.C0001 = '選択された項目を削除してもよろしいですか？';
  this.C0002 = '編集内容をクリアします。\nよろしいでしょうか？';
  this.C0003 = '項目TYPEをSTRINGに変換します。\nよろしいでしょうか？';
  this.C0004 = '削除しようとしている項目はカスタマイズ可能に登録されています。\n削除してもよろしいでしょうか？';
  this.C0005 = 'ページを新規作成します。<br>\n現在の編集内容はクリアされます。';

  // 編集時statusメッセージ
  this.S0001 = '読込中。しばらくおまちください...';
  this.S0002 = '配置しています...';
  this.S0003 = '準備中...';
  this.S0005 = 'TABLE作成中...';
  this.S0006 = '現在のページに作成できる行数は$prm0以内です。';
  this.S0007 = '現在のページに作成できる列数は$prm0以内です。';
  this.S0008 = '処理中...';

  // コマンド実行中メッセージ
  this.S0010 = '切り取り中...';
  this.S0011 = 'コピー中...';
  this.S0012 = '貼り付け中...';
  this.S0013 = '削除中...';
  this.S0014 = '元に戻し中...';
  this.S0015 = '"$prm0" を元に戻し中...';
  this.S0016 = 'やり直し中...';
  this.S0017 = '"$prm0" をやり直し中...';

  this.S0020 = '$prm0の編集';

  // 保存時メッセージ
  this.V0001 = '項目IDの重複したオブジェクトがあります。このまま保存しますか？';
  this.V0001_1 = '項目ID:$prm0';
  this.V0001_2 = '$prm0 (項目タイプ:$prm1)';
  this.V0001_OV = '項目IDの重複したオブジェクトが $prm0項目あります。'
                  + '\n\n「キャンセル」すると一覧で詳細が確認できます。'
                  + '\n\nこのまま保存しますか？';

  this.V0002 = '重なっているオブジェクトがあります。\n実行時にエラーとなりますが、このまま保存しますか？';
  this.V0002_1 = '';
  this.V0002_2 = '$prm0 (項目タイプ:$prm1, 項目ID:$prm2)';
  this.V0002_OV = '重なっているオブジェクトが $prm0項目あります。'
                  + '\n\n「キャンセル」すると一覧で詳細が確認できます。'
                  + '\n\n実行時にエラーとなりますが、このまま保存しますか？';

  this.V0003 = '親オブジェクトの外に配置されたオブジェクトがあります。\n保存ができませんでした。';
  this.V0003_1 = '$prm0 (項目タイプ:$prm1, 項目ID:$prm2, 親オブジェクトID:$prm3)';
  this.V0003_OV = '親オブジェクトの外に配置されたオブジェクトが $prm0項目あります。'
                  + '\n保存ができませんでした。';

  this.V0004 = 'formの外に配置されたオブジェクトがあります。\nこのまま保存しますか？';
  this.V0004_1 = '$prm0 (項目タイプ:$prm1, 項目ID:$prm2)';
  this.V0004_OV = 'formの外に配置されたオブジェクトが $prm0項目あります。'
                  + '\n\n「キャンセル」すると一覧で詳細が確認できます。'
                  + '\n\nこのまま保存しますか？';

  this.V0005 = '親オブジェクトからはみ出たオブジェクトがあります。\n実行時にエラーとなりますが、このまま保存しますか？';
  this.V0005_1 = '$prm0 (項目タイプ:$prm1, 項目ID:$prm2, 親オブジェクトID:$prm3)';
  this.V0005_OV = '親オブジェクトからはみ出たオブジェクトが $prm0項目あります。'
                  + '\n\n「キャンセル」すると一覧で詳細が確認できます。'
                  + '\n\n実行時にエラーとなりますが、このまま保存しますか？';

  this.V0006 = '次のオブジェクトは幅に設定された値が小さすぎます。\n'
               + '幅を空欄にするか、推奨する値以上を設定してください。\n '
               + '実行時にレイアウトがくずれますが、このまま保存しますか？';
  this.V0006_1 = '$prm0 (項目タイプ:$prm1, 項目ID:$prm2) 現在の幅:$prm3 推奨する値:$prm4';
  this.V0006_OV = '幅に設定された値が小さすぎるオブジェクトが $prm0項目あります。'
                  + '\n幅を空欄にするか、大きめの値を設定してみてください。'
                  + '\n\n「キャンセル」すると一覧で詳細が確認できます。'
                  + '\n\n実行時にレイアウトがくずれますが、このまま保存しますか？';

  this.V0007 = '次のオブジェクトは幅が設定されていません。\n'
               + '実行時にレイアウトがくずれることがありますが、このまま保存しますか？';
  this.V0007_1 = '$prm0 (項目タイプ:$prm1, 項目ID:$prm2)';
  this.V0007_OV = '幅が設定されていないオブジェクトが $prm0項目あります。'
                  + '\n\n「キャンセル」すると一覧で詳細が確認できます。'
                  + '\n\n実行時にレイアウトがくずれることがありますが、このまま保存しますか？';

  // 設定エラー
  this.P0001 = '属性 $prm1 はチェックボックスとして表示できません。\n以下の設定が正しくありません。'
             + '\n\npref.xxx.$prm0.$prm1 = \'check\';';
  this.P0002 = '属性 $prm1 は選択肢として表示できません。\n以下の設定が正しくありません。'
             + '\n\npref.xxx.$prm0.$prm1 = \'select\';';
  this.P0003 = '属性編集タイプ $prm2 は未定義です。\n以下の設定が正しくありません。'
             + '\n\npref.xxx.$prm0.$prm1 = \'$prm2\';';
}

/**
 * 受け取ったキーに対応するリテラルを返す
 * @param  :_key string キー
 * @return :リテラル
 */
function getLiteral(_key){
  
  var literalNames = LiteralNames.instance;
  if(!literalNames) {
    literalNames = LiteralNames.instance = new LiteralNames();
  }
  
  if(literalNames[_key] != undefined){
    return literalNames[_key];
  } else {
    var splt = _key.split('.');
    return '!' + splt[splt.length - 1];
  }
}

/**
 * 追加する
 */
function setLiteral(_key, value){
  
  var literalNames = LiteralNames.instance;
  if(!literalNames) {
    literalNames = LiteralNames.instance = new LiteralNames();
  }
  literalNames[_key] = value;
}

/**
 * 受け取ったメッセージIDとパラメータによって作成したメッセージを返す
 * @param  :_id   文字型 メッセージID,
 *          _prms 配列   置き換える文字
 * @return :      文字型 メッセージ
 */
function getMessage(_id, _prms){
  
  var messages = Messages.instance;
  if(!messages) {
    messages = Messages.instance = new Messages();
  }

  var msg = '';
  if(messages[_id]){
    // idが存在
    
    if(_prms) {
      // prmが存在
      return replacePrms(messages[_id], _prms);
    } else {
      // prmなし
      return messages[_id];
    }

  }else{
    // idが存在しないとき、id (prm1, prm2, ...)と出力
    
    var retPrm = '';
    if(_prms) {
      for(var i in _prms) {
        retPrm += ', $prm' + i;
      }
    }
    if(retPrm != '') {
      // prmあり
      return replacePrms(_id + ' (' + retPrm.substring(2) + ')' , _prms);
    }
    // prmなし
    return _id;
  }

  // $prm#部分の置き換え
  function replacePrms(_msg, _prms) {
    var retMsg = _msg;
    for(var i in _prms) {
      if(-1 < retMsg.indexOf('$prm' + i)) {
        for(var chkMsg = '';chkMsg != retMsg;) {
          chkMsg = retMsg;
          retMsg = retMsg.replace('$prm' + i, _prms[i]);
        }
      }
    }
    return retMsg;
  }
}
