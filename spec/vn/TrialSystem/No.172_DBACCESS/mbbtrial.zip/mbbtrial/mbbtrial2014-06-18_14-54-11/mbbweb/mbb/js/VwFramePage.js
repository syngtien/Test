/**
 * VwFrame
 * フレーム編集
 */
LAST_MODIFIED('2005.01.06', '1.0.31');

// 編集画面上の最上位エレメント
var m_rootElement = null;

// フレームオブジェクトのルートオブジェクト
var m_rootFramePage = null;

/**
 * 新規フレームの初期化　onLoadで呼ばれる。
 */
function initFramePage() {
  
  // 新規作成時の初期値
  if(_defaultPageDefinition.editStatus && _defaultPageDefinition.editStatus == '0') {

    addFramePageItemDataByPreference('0001');

    // テンプレートから新規作成
    var win = openFrameTemplateDialog();

    // 編集画面初期化
    init();
    
    m_focusedPropId = '*';
    
    // ダイアログを手前に表示
    win.focus();

  } else {
  
    // 編集画面初期化
    init();

    m_focusedPropId = '*';
  }
}

/**
 * 初期設定に従って初期化する
 */
function addFramePageItemDataByPreference(id) {
  var preference = pref.init.frame;
  addPageItemData(id, 'form', '');
  addPageItemPropertyData(id, 'method',    'frame', '');
  addPageItemPropertyData(id, 'colsrows',  preference.get('colsrows'), '');
  addPageItemPropertyData(id, 'direction',  preference.get('direction'), '');
  addPageItemPropertyData(id, 'caption',  preference.get('caption'), '');
  addPageItemPropertyData(id, 'border',  preference.get('border'), '');
  addPageItemPropertyData(id, 'bordercolor',  preference.get('bordercolor'), '');
  addPageItemPropertyData(id, 'onload',  preference.get('onload'), '');
  addPageItemPropertyData(id, 'onunload',  preference.get('onunload'), '');
  addPageItemPropertyArrayData(id, 'jsfilename',  preference.get('jsfilename'));
  addPageItemPropertyArrayData(id, 'meta',  preference.get('meta'));

  function addPageItemPropertyArrayData(id, propertyid, arr) {
    if(arr && arr.length > 0) {
      for(var i = 0; i < arr.length; i++) {
        addPageItemPropertyData(id, propertyid + '-' + i,  arr[i], '');
      }
    }
  }
}

/**
 * ロードデータのpage変数から画面作成(initから実行される)
 * @param  :page オブジェクト getPageVariableの戻り値
 * @return :
 */
function loadFrameData(_page) {

  if(_page) {
    createFrameMain(_page, ELEMENTID_FIRSTFORM, pref.env.framedesignwidth, pref.env.framedesignheight);
  } else {
    createFrameMain(getPageVariable(), ELEMENTID_FIRSTFORM, pref.env.framedesignwidth, pref.env.framedesignheight);
  }
}

/**
 * 編集作業が開始できる状態にする
 */
function createFrameMain(_page, _id, _width, _height) {
  
  // 編集画面のエレメントを取得
  m_rootElement = getDocumentElementById(_id);

  // page変数
  m_loadPageVariable = _page;
  
  // width, heightのデフォルト値
  if(!_width) {
    _width = 800;
  }
  if(!_height) {
    _height = 600;
  }

  // フレームオブジェクト生成
  m_rootFramePage = new FramePage(null, _width ,_height, m_loadPageVariable.pageItems[m_loadPageVariable.topPageItemId]);

  // 編集画面に描画
  m_rootElement.style.border = 'none';
  m_rootElement.innerHTML = m_rootFramePage.getHtml();

  // 属性欄に描画
//  m_rootFramePage.drawPropertyEdit();
  drawFramePropertyEdit(m_rootFramePage, 'm_rootFramePage');

  // イベントハンドラ設定
  document.body.onmouseup    = framePageOnMouseUp;
  document.body.onmousemove  = framePageOnMouseMove;
  
}

/**
 * 現在のpage変数の状態を画面に書き直す
 * @param _refreshEdit boolean 属性欄を書き直すフラグ
 */
function refreshFrameMain(_refreshEdit, _defaultSelection) {

  m_rootFramePage = new FramePage(null,m_rootFramePage.width ,m_rootFramePage.height, m_loadPageVariable.pageItems[m_loadPageVariable.topPageItemId]);
  m_rootElement.innerHTML = m_rootFramePage.getHtml();
  
  if(m_operation.currentSelection) {

    // 書き直し前のelementを参照しているので、m_operation.currentSelectionを取得しなおし
    m_operation.currentSelection = m_rootFramePage.getObject(m_operation.currentSelection.id);
    
    if(!m_operation.currentSelection) {
      if(_defaultSelection) {
        m_operation.currentSelection = _defaultSelection;
      }
    }

    if(m_operation.currentSelection) {
      // 選択状態（のイメージ）にする
      m_operation.currentSelection.getFocus();
      if(_refreshEdit) {
        // 属性欄描画
        //m_operation.currentSelection.drawPropertyEdit();
        drawFramePropertyEdit(m_operation.currentSelection, 'm_operation.currentSelection');
      }
    } else {
      // 属性欄描画
      //m_rootFramePage.drawPropertyEdit();
      drawFramePropertyEdit(m_rootFramePage, 'm_rootFramePage');
    }
  }
}

/**
 * 属性欄描画
 * @param _obj      Object 属性欄表示対象オブジェクト(IE)
 *        _objName  String 属性欄表示対象オブジェクト変数名(NN)
 */
function drawFramePropertyEdit(_obj, _objName) {
  if(_obj) {
    _obj.drawPropertyEdit();
  }
}

/**
 * 属性欄描画 (NN対策用。 drawFramePropertyEditにバインドする)
 * @param _obj      Object 属性欄表示対象オブジェクト(IE)
 *        _objName  String 属性欄表示対象オブジェクト変数名(NN)
 */
function setTimeoutToDrawFramePropertyEdit(_obj, _objName) {
  if(_obj) {
    window.setTimeout(_objName + '.drawPropertyEdit();',0);
  }
}

// 属性設定用のダイアログが開かなくなるNNの不具合に対処する
if(m_browserType.isNN){
  drawFramePropertyEdit = setTimeoutToDrawFramePropertyEdit;
}

/**
 * フレームまたはフレームセットのオブジェクト.
 * @param _parent 親オブジェクト.
 *        _pageWidth 親の所有する境界の移動によって可変となる方向の幅.
 *        _parentFixedHeight _pageWidthでない方の方向の幅.
 *        _frameinfo フレームセットのときpageItem, フレームのとき pageItem.frames[#].
 */
function FramePage(_parent, _pageWidth, _parentFixedHeight, _obj, _frameindex) {
  // ページの最小の幅
  this.MINWIDTH = 4;

  // FramePageオブジェクトであることを示す
  this.isPage = true;

  // 親が保持するフレームの配列
  this.frames = null;

  // フレームのインデックス
  this.frameindex = '';
  
  // 対応するフレーム(自分)の情報
  this.frameinfo = null;

  // 対応するpageItem
  this.pageItem = null;

  // 引数_objの内容によって pageItemかframeinfoかを判定してセットする.
  if(_obj) {
    if(_obj[_frameindex]) {
      this.frames = _obj;
      if(this.frames[_frameindex]) {
        this.frameindex = _frameindex;
        this.frameinfo = this.frames[this.frameindex];
        if(this.frameinfo.pageItem) {
          this.pageItem = this.frameinfo.pageItem;
        }
      }
      
    } else {
      this.pageItem = _obj;
    }
  }

  // 子フレームの分割方向 rows:上下に分割 cols:左右に分割
  this.direction = 'rows';

  // 親
  this.parent = _parent;
  
  // クリック時の識別用ID
  this.id = '';
  
  // 階層のレベル 最上位=1
  this.level = 1;

  // 境界線の幅
  this.borderWidth = '';

  // 境界線の色
  this.borderColor = '';
  
  // プロパティ設定用
  this.property = new Object();
  
  if(_parent == null) {
    // 最上位である

    // 最上位のFramePageを設定
    this.root = this;

    this.id = 'root';

    if(this.pageItem) {
      this.direction = this.pageItem.properties['direction'].value;
    }

  } else {
    // 最上位ではない

    // 最上位のFramePageを設定
    this.root = this.parent.root;

    this.id = this.parent.mkId();

    this.level = _parent.level + 1;

    if(_parent.direction == 'rows') {
      this.direction = 'cols';
    }

    this.borderWidth = this.parent.borderWidth;
    this.borderColor = this.parent.borderColor;
  }
  
  // 親に対する縦位置
  this.top = 0;

  // 親に対する横位置
  this.left = 0;

  // 各フレームのページのふちどりの色
  //this.pageBorderColor = 'white';
  //if(!this.parent) {
    this.pageBorderColor = 'black';
  //}

  // 選択時にページの内部を表現する色
  this.selectedContentColor = '#a9b2ca';
  //this.selectedContentColor = '';

  // 選択時にページの内部を表現する背景画像
  //this.selectedContentBackground = getImageSrcUrl('images/VwSelection.gif');
  this.selectedContentBackground = '';

  if(this.direction == 'cols') {
    // 子を左右に分割する場合 = このオブジェクトは上下に分割されて作られている
    
    if(!this.parent) {
      var tmp = _parentFixedHeight;
      _parentFixedHeight = _pageWidth;
      _pageWidth = tmp;
    }
    
    // 表示用幅
    this.width   = _parentFixedHeight;

    // 表示用高さ
    this.height  = _pageWidth;
    
    // 子分割方向の幅
    this.totalWidth  = this.width;

    // 子分割方向でない方向の幅（子に共通の値）
    this.fixedHeight = this.height;

    // 子の位置offsetを計算する方向
    this.gainDirection = 'left';

  } else {
    // 子を上下に分割する場合 = このオブジェクトは左右に分割されて作られている
    
    // 表示用幅
    this.width   = _pageWidth;

    // 表示用高さ
    this.height  = _parentFixedHeight;

    // 子分割方向の幅
    this.totalWidth  = this.height;

    // 子分割方向でない方向の幅（子に共通の値）
    this.fixedHeight = this.width;

    // 子の位置offsetを計算する方向
    this.gainDirection = 'top';
  }


  // colsrowsに設定されている値
  if(this.parent) {
    if(this.parent.pageItem && this.parent.pageItem.properties['colsrows']) {
      var splt = this.parent.pageItem.properties['colsrows'].value.split(',');
      if(splt[this.frameindex]) {
        if(this.direction == 'cols') {
          if(splt[this.frameindex] != this.height) {
            this.property.height = splt[this.frameindex];
          }
        } else {
          if(splt[this.frameindex] != this.width) {
            this.property.width = splt[this.frameindex];
          }
        }
      }
    }
  }

  // 表示上のエレメント  
  this.baseElement = null;

  // 子フレームと境界線
  this.children = new Array();

  // colsrowsに対する表示の倍率 分子
  this.numerator = 1;

  // colsrowsに対する表示の倍率 分母
  this.denominator = 1;
  
  // 分割するメソッド
  FramePage.prototype.divide = FramePage_divide;

  // IDを取得するメソッド
  FramePage.prototype.mkId = FramePage_mkId;

  if(this.parent) {
    if(this.pageItem) {
      this.propertyEdit = m_propertyEdit['FRAMESET'];
      this.partitionPropertyEdit = m_propertyEdit['PARTITION'];
    } else {
      this.propertyEdit = m_propertyEdit['FRAME'];
      this.partitionPropertyEdit = m_propertyEdit['PARTITION'];
    }
    this.pagePropertyEdit = this.parent.pagePropertyEdit;
  } else {
//    this.propertyEdit = m_propertyEdit['ROOTFRAMESET'];
    this.propertyEdit = null;
    this.pagePropertyEdit = m_propertyEdit['PAGE'];
    this.partitionPropertyEdit = m_propertyEdit['PARTITION'];
  }
  
  if(this.pageItem) {
    // フレームセットの場合
    if(!this.parent) {
      // 最上位の場合

      // 境界線の太さを設定
      if(this.pageItem.properties['border']) {
        this.borderWidth = this.pageItem.properties['border'].value;
        this.borderWidth = this.pageItem.properties['border'].value;
        
        if(this.borderWidth != '' && !isNaN(this.borderWidth)) {
          this.borderWidth = parseInt(this.borderWidth);
        } else {
          this.borderWidth = '';
        }
        
      }

      // 境界線の色を設定
      if(this.pageItem.properties['bordercolor']) {
        this.borderColor = this.pageItem.properties['bordercolor'].value;
      }
    }

    this.borderStyle = 'solid';
    if(this.borderColor == '') {
      this.borderColor = 'silver';
    }
    if(this.borderWidth == '0') {
      this.borderWidth = 3;
      //this.borderColor = 'white';
      this.borderStyle = 'dotted';
    } else if(this.borderWidth == '') {
      this.borderWidth = 4;
    } else {
      if(parseInt(this.borderWidth) == 0) {
        this.borderWidth = 3;
        //this.borderColor = 'white';
        this.borderStyle = 'dotted';
      } else if(parseInt(this.borderWidth) < 3) {
        this.borderWidth = 3;
        //this.borderColor = 'white';
        this.borderStyle = 'dotted';
      }
    }

    // フレーム分割
    if(this.pageItem.properties['colsrows']) {
      this.divide(this.pageItem.properties['colsrows'].value);
    }
  }
  
  /**
   * 分割・フレーム・フレームセットのプロパティ部分描画
   */
  FramePage.prototype.drawPropertyEdit = function() {
    var frameElement = getDocumentElementById('fld_showPropertyTable_div_type');
    setCurrentPropertyTableOwner(null);
    if(!this.parent) {
      this.drawPagePropertyEdit();
    }
    if(this.propertyEdit) {
      frameElement.innerHTML =  this.partitionPropertyEdit.getHtml(this) + this.propertyEdit.getHtml(this);
    } else {
      frameElement.innerHTML =  this.partitionPropertyEdit.getHtml(this);
    }
    setCurrentPropertyTableOwner(this);
  }
   
  /**
   * 分割・フレーム・フレームセットのプロパティ部分描画
   */
  FramePage.prototype.drawPagePropertyEdit = function() {
    var pageElement = getDocumentElementById('fld_showPropertyTable_div');

    pageElement.innerHTML =  this.pagePropertyEdit.getHtml(this);
    setPagePropertyTableOwner(this);

  }
  
  /**
   * 属性値取得
   */
  FramePage.prototype.getValue = function(_id) {
    var ids = _id.split('.');
    if(ids[0] == 'page') {
      if(this.root.pageItem && this.root.pageItem.properties[ids[1]]) {
        if(ids[1] == 'jsfilename' || ids[1] == 'meta') {
          return this.root.pageItem.properties[ids[1]].values;
        }
        return this.root.pageItem.properties[ids[1]].value;
      }
    } else if(ids[0] == 'pageItem') {
      if(this.pageItem && this.pageItem.properties[ids[1]]) {
        return this.pageItem.properties[ids[1]].value;
      }
    } else if(ids[0] == 'frameinfo') {
      if(this.frameinfo && this.frameinfo[ids[1]]) {
        return this.frameinfo[ids[1]];
      }
    } else if(ids[0] == 'object') {
      if(this.property[ids[1]]) {
        return this.property[ids[1]];
      }
      if(this[ids[1]]) {
        //return '<' + this[ids[1]] + '>';
        return this[ids[1]];
      }
    } else if(ids[0] == 'divide') {
      /*
      var target = this;
      if(!isNaN(ids[1])) {
        for(var i = parseInt(ids[1]); i > 0; i--) {
          if(target.parent) {
            target = target.parent;
          }
        }
      }
      */
      var target = this.getTargetToDivide(ids[1]);
      
      if(target.pageItem && target.pageItem.properties['colsrows']) {
        var splt = target.pageItem.properties['colsrows'].value.split(',');
        //window.status = splt.length.toString();
        return splt.length.toString();
      }
    }
    return '';
  }

  /**
   * 属性値設定
   */
  FramePage.prototype.setValue = function(_id, _value) {
    var ids = _id.split('.');
    if(ids[0] == 'page') {
      if(this.root.pageItem) {
        if(!this.root.pageItem.properties[ids[1]]) {
          this.root.pageItem.properties[ids[1]] = new Object()
        }
        switch(ids[1]) {
        case 'jsfilename':
        case 'meta':
          this.root.pageItem.properties[ids[1]].values = new Array();
          for(var i in _value) {
            this.root.pageItem.properties[ids[1]].values[i] = _value[i];
          }
          break;
        case 'direction':
          if(this.root.pageItem.properties[ids[1]].value == _value) {
            return;
          }
          for(var i in m_loadPageVariable.pageItems) {
            if(m_loadPageVariable.pageItems[i].properties['direction']) {
              var property = m_loadPageVariable.pageItems[i].properties['direction'];
              if(property.value == 'cols') {
                property.value = 'rows';
              } else {
                property.value = 'cols';
              }
            }
          }
          break;
        default:
          this.root.pageItem.properties[ids[1]].value = _value;
        }
      }
    } else if(ids[0] == 'pageItem') {
      if(this.pageItem) {

        if(!this.pageItem.properties[ids[1]]) {
          this.pageItem.properties[ids[1]] = new Object()
        }
        this.pageItem.properties[ids[1]].value = _value;
        
        if(ids[1] == 'colsrows') {
          refreshFrameMain(true, this);
        }
      }
    } else if(ids[0] == 'frameinfo') {
      if(this.frameinfo) {
        this.frameinfo[ids[1]] = _value;
      }
    } else if(ids[0] == 'object') {
      if(this.property[ids[1]]) {
        this.property[ids[1]] = _value;
      }
      if(ids[1] == 'height' || ids[1] == 'width') {
        this.updateColsrowsByIndex(this.frameindex, _value);
      }
      
    } else if(ids[0] == 'divide') {
      /*
      var target = this;
      if(!isNaN(ids[1])) {
        for(var i = parseInt(ids[1]); i > 0; i--) {
          if(target.parent) {
            target = target.parent;
          }
        }
      }
      */
      var target = this.getTargetToDivide(ids[1]);
      var oldVal = this.getValue(_id);

      if(_value == '' || _value == '1') {
        delete target.pageItem;
        target.frameinfo.frameflag = '';
        target.frameinfo.framename = '';
        target.frameinfo.pageItem = null;
      
        refreshFrameMain(true, target);
      
      } else {
        if(oldVal == '' || oldVal == '1') {
          target.frameinfo.frameflag = '1';
          target.frameinfo.framesrc = '';
          target.frameinfo.framescrolling = '';
          target.frameinfo.frameresize = '';
          target.frameinfo.pageItem = target.createPageItem();
          target.frameinfo.framename = target.frameinfo.pageItem.properties['name'].value;
          target.pageItem = target.frameinfo.pageItem;
        }

        var colsrowssplit = target.getValue('pageItem.colsrows').split(',');
        var len = parseInt(_value);
        for(var i = 0; i < len; i++) {
          if(colsrowssplit[i]) {
          } else {
            colsrowssplit[i] = '*';
          }
        }
        var colsrows = '';
        for(var i = 0; i < len; i++) {
          if(i != 0) {
            colsrows += ',';
          }
          colsrows += colsrowssplit[i].toString();
          if(!target.pageItem.frames[i]) {
            target.pageItem.frames[i] = new Object();
          }
        }
        target.setValue('pageItem.colsrows', colsrows);
        //
      }

      // if(divide
    }

    refreshFrameMain();

    m_menuBar.enableSave();
    
    return '';
  }

  /**
   * 属性値設定
   */
  FramePage.prototype.getTargetToDivide = function(_lev) {
    var target = this;
    if(!isNaN(_lev)) {
      for(var i = parseInt(_lev); i > 0; i--) {
        if(target.parent) {
          target = target.parent;
        }
      }
    }
    return target;
  }
  
  /**
   * 
   */
  FramePage.prototype.updateColsrowsByIndex = function(_index, _value) {
    if(this.parent && 
       this.parent.pageItem &&
       this.parent.pageItem.properties['colsrows']) {
      
      var splt = this.parent.pageItem.properties['colsrows'].value.split(',');
      
      if(splt[_index]) {
        if(_value && (_value == '*' || (!isNaN(_value)))) { 
          splt[_index] = _value;
          var colsrows = '';
          for(var i in splt) {
            if(i != 0) {
              colsrows += ',';
            }
            colsrows += splt[i];
          }
          this.parent.pageItem.properties['colsrows'].value = colsrows;
          return true;
          
        } else {
          //alert('_value が不正です.');
          
        } //if(_value && (_value == '*' || (!isNaN(_value))) {
        
      } else {
        alert('colsrows に対して _index が大きすぎます.');
        
      } //if(splt[_index])...
    } else {
      alert('colsrows が見つかりません.');
      
    } // if(this.pare...
    return false;
  }

  /* pageItemを作成
   * @return pageItem
   */
  FramePage.prototype.createPageItem = function() {
    var pageItem = new Object();
    var pageItemId = '';
    var i = 0;
    for(var p in m_loadPageVariable.pageItems) {
      i++;
    }
    for(; i < 10000; i++) {
      if(i < 10) {
        pageItemId = '000' + i;
      } else if(i < 100) {
        pageItemId = '00' + i;
      } else if(i < 1000) {
        pageItemId = '0' + i;
      } else {
        pageItemId = i;
      }
      if(!m_loadPageVariable.pageItems[pageItemId]) {
        break;
      } else {
        pageItemId = '';
      }
    } 
    pageItem.pageItemId = pageItemId;
    pageItem.parentPageItemId = '';
    if(this.parent && this.parent.pageItem) {
      pageItem.parentPageItemId = this.parent.pageItem.pageItemId;
    }
    pageItem.pageItemTypeId = 'frame';
    pageItem.frames = new Array();
    pageItem.properties = new Object();
    pageItem.literalProperties = new Object();
    
    pageItem.properties['method'] = new Object();
    pageItem.properties['method'].value = 'FRAME';
    pageItem.properties['name'] = new Object();
    pageItem.properties['name'].value = 'frameset_' + pageItemId;

    pageItem.properties['direction'] = new Object();
    pageItem.properties['direction'].value = this.direction;
    
    m_loadPageVariable.pageItems[pageItemId] = pageItem;
    return pageItem;
  }
  
  /* pageItemにフレームセットを作成
   * @param  _id string 
   * @return FramePageまたはFrameBorder
   */
  FramePage.prototype.addFramesetToPageItem = function(_id) {
  }
  
  /* IDからオブジェクトを特定する
   * @param  _id string 
   * @return FramePageまたはFrameBorder
   */
  FramePage.prototype.getObject = function(_id) {
    if(_id == this.id) {
      return this;
    } else {
      for(var i in this.children) {
        var obj = this.children[i].getObject(_id);
        if(obj) {
          return obj;
        } 
      }
    }
    return null;
  }

  /* 選択されたときの表示
   *
   */
  FramePage.prototype.getFocus = function() {
    if(!this.baseElement) {
      this.baseElement = getDocumentElementById(this.id + '.BASE');
    }

    if(!this.baseElement) {
      // focusは設定できない
      return;
    }

    if(this.selectedContentColor != '') {
      this.baseElement.style.backgroundColor = this.selectedContentColor;
    }
    if(this.selectedContentBackground != '') {
      this.baseElement.style.backgroundImage = this.selectedContentBackground;
    }
    
  }

  /* 選択解除されたときの表示
   *
   */
  FramePage.prototype.loseFocus = function() {
    if(!this.baseElement) {
      this.baseElement = getDocumentElementById(this.id + '.BASE');
    }

    if(!this.baseElement) {
      // focusは解除できない
      return;
    }

    this.baseElement.style.backgroundColor = '';
    this.baseElement.style.backgroundImage = '';
  }
  
  /* IDを振る
   *
   */
  function FramePage_mkId() {
    var index = this.children.length + 1;
    if(this.parent == null) {
      return index.toString();
    }
    return this.id + '_' + index.toString();
  }
  
  /* フレーム分割
   * @param  _colsrows string カンマ区切りの各フレーム幅
   */
  function FramePage_divide(_colsrows) {

    var framecolsrows = new FrameColsrows(_colsrows, this.totalWidth, this.borderWidth, this.MINWIDTH);
    var colsrows = framecolsrows.displayString().split(',');
    for(var i in colsrows) {
      colsrows[i] = parseInt(colsrows[i]);
    }
    
    // オブジェクト作成
    this.children = new Array();
    var nextLoc = 0;
    var info = null;
    var i
    for(i = 0; i < colsrows.length - 1; i++) {
      info = null;
      if(this.pageItem) {
        if(this.pageItem.frames[i]) {
          info = this.pageItem.frames;
        }
      }
      this.children[(i * 2)] = new FramePage(this, colsrows[i], this.fixedHeight, info, i);
      this.children[(i * 2)][this.gainDirection] = nextLoc;
      nextLoc += colsrows[i];
      this.children[(i * 2 + 1)] = new FrameBorder(this, this.borderWidth, this.fixedHeight);
      this.children[(i * 2 + 1)][this.gainDirection] = nextLoc;
      nextLoc += this.borderWidth;
    }
    info = null;
    if(this.pageItem) {
      if(this.pageItem.frames[i]) {
        info = this.pageItem.frames;
      }
    }
    this.children[i * 2] = new FramePage(this, colsrows[i], this.fixedHeight, info, i);
    this.children[(i * 2)][this.gainDirection] = nextLoc;
  }

  /* 表示するためのHTML
   *
   */
  FramePage.prototype.getHtml = function() {
    var html = '';
    if(1 < this.children.length) {

      var span = new HtmlTag('span');
      span.id = this.id + '.BASE';
      span.style.top      = this.top + 'px';
      span.style.left     = this.left + 'px';
      span.style.width    = this.width + 'px';
      span.style.height   = this.height + 'px';
      span.style.position = 'absolute';
      for(var i in this.children) {
        span.innerHTML += this.children[i].getHtml();
      }
      html += span;
      
    } else {

      var table = new HtmlTag('table');
      table.id = this.id + '.BASE';
      table.cellspacing = '0';
      table.style.top      = this.top + 'px';
      table.style.left     = this.left + 'px';
      table.style.width    = this.width + 'px';
      table.style.height   = this.height + 'px';
      table.style.position = 'absolute';
      table.style.border   = '1px solid ' + this.pageBorderColor;
      table.style.cursor   = 'pointer';
      table.onmousedown = 'framePageMouseDown(\'' + this.id + '\', event);';
      table.ondblclick  = 'framePageDblClick(\'' + this.id + '\', event);';
      
      table.innerHTML = new HtmlTag('tr');
      table.innerHTML.innerHTML = new HtmlTag('td');
      table.innerHTML.innerHTML.id = this.id + '.TD';
      
      html += table;
      
    }
    this.baseElement = null;

    return html;
  }
}

/**
 * フレームの境界オブジェクト.
 * @param _parent 親オブジェクト.
 *        _pageWidth 親の所有する境界の幅によって可変となる方向の幅.
 *        _parentFixedHeight _pageWidthでない方の方向の幅.
 */
function FrameBorder(_parent,_pageWidth,_parentFixedHeight) {

  // フレームの境界オブジェクトであることを示す
  this.isBorder = true;

  // 親フレームセット
  this.parent = _parent;
  
  if(_parent) {
    this.level = _parent.level + 1;
    if(_parent.direction == 'cols') {
      this.direction = 'rows';
    } else {
      this.direction = 'cols';
    }
    this.id = this.parent.mkId();
  } else {
    this.level = 1;
    this.direction = 'cols';
    this.id = '';
  }
  
  // 縦位置
  this.top = 0;

  // 横位置
  this.left = 0;

  // 表示エレメント
  this.baseElement = null;

  if(this.direction == 'cols') {
    // 親はrows = 境界線は横位置

    this.width   = _parentFixedHeight;
    this.height  = _pageWidth;
    this.totalWidth  = this.width;
    this.fixedHeight = this.height;
    this.cursor = 'n-resize';

  } else {
    // 親はcols = 境界線は縦位置

    this.width   = _pageWidth;
    this.height  = _parentFixedHeight;
    this.totalWidth  = this.height;
    this.fixedHeight = this.width;
    this.cursor = 'e-resize';
  }

  /** 隣接するFrameを取得する
   * @param  num  number -1のとき前隣、1のとき後隣
   * @return FramPageオブジェクト
   */
  FrameBorder.prototype.getNeighborFramePage = function(num) {
    var ids = this.id.split('_');
    var id = '';
    if(!isNaN(ids[ids.length - 1])) {
      for(var i = 0; i < ids.length; i++) {
        if(i + 1  ==  ids.length) {
          id += (ids[i] + num).toString();
        } else {
          id += ids[i] + '_';
        }
      }
      return this.parent.children[parseInt(ids[ids.length - 1]) - 1 + num];
    }
    return null;
  }
  
  /** 境界線が移動できる範囲の最小値を返す
   * @return 境界線が移動できる範囲の最小値
   */
  FrameBorder.prototype.getMinToMove = function() {
    var neighbor = this.getNeighborFramePage(-1);
    if(neighbor) {
      if(this.direction == 'cols') {
        return neighbor.top + this.parent.MINWIDTH;
      } else {
        return neighbor.left + this.parent.MINWIDTH;
      }
    }
    return 0;
  }

  /** 境界線が移動できる範囲の最大値を返す
   * @return 境界線が移動できる範囲の最大値
   */
  FrameBorder.prototype.getMaxToMove = function() {
    var neighbor = this.getNeighborFramePage(1);
    if(neighbor) {
      if(this.direction == 'cols') {
        return neighbor.top + neighbor.height - this.parent.MINWIDTH - this.parent.borderWidth;
      } else {
        return neighbor.left + neighbor.width - this.parent.MINWIDTH - this.parent.borderWidth;
      }
    }
    return 0;
  }

  /** 移動が完了したときの処理
   * @param oldLocation number 移動前の位置
   *        newLocation number 移動後の位置
   */
  FrameBorder.prototype.updateLocation = function(oldLocation, newLocation) {
    window.status = '';

    var oldVal = this.parent.pageItem.properties['colsrows'].value;
    var newValueObj = new FrameColsrows(oldVal, this.parent.totalWidth, this.parent.borderWidth, this.parent.MINWIDTH);
    var ids = this.id.split('_');
    var index = parseInt(ids[ids.length - 1] / 2);
    var moveDistance = parseInt(newLocation - oldLocation);

    newValueObj.addByIndex(moveDistance, index - 1);
    newValueObj.addByIndex(0 - moveDistance, index);

    var newVal = newValueObj.getDisplayColsrows();
    this.parent.pageItem.properties['colsrows'].value = newVal;
    this.parent.divide(newVal);

    /* undo */
    if(oldVal != newVal) {
      var cmd = new FramePageUpdateValueCommand(this.parent, 'pageItem.colsrows', oldVal, newVal, true);
      m_undoManager.execute(cmd);
    }
  }
  
  /** 表示用HTML
   * @return HTML文字列
   */
  FrameBorder.prototype.getHtml = function() {
    var html = '';

    var table = new HtmlTag('table');
    table.id = this.id + '.BASE';
    table.cellspacing = '0';
    table.style.top      = this.top + 'px';
    table.style.left     = this.left + 'px';
    table.style.width    = this.width + 'px';
    table.style.height   = this.height + 'px';
    table.style.position = 'absolute';
    table.style.cursor   = this.cursor;
    table.style.border   = '1px solid ' + this.parent.borderColor;
    table.style.backgroundColor = this.parent.borderColor;
    table.onmousedown   = 'framePageMouseDown(\'' + this.id + '\', event);';
    table.oncontextmenu = 'framePageMouseDown(\'' + this.id + '\', event);';
    
    table.innerHTML = new HtmlTag('tr');
    table.innerHTML.innerHTML = new HtmlTag('td');
    table.innerHTML.innerHTML.id = this.id + '.TD';
    
    html += table;

    this.baseElement = null;
    return html;
  }

  /** idからオブジェクトを取得する
   * @param  _id string 取得したいオブジェクトのID
   * @return 取得したオブジェクト
   */
  FrameBorder.prototype.getObject = function(_id) {
    if(_id == this.id) {
      return this;
    }
    return null;
  }

  /** 選択時の表示
   *
   */
  FrameBorder.prototype.getFocus = function() {
    if(!this.baseElement) {
      this.baseElement = getDocumentElementById(this.id + '.BASE');
    }
    this.baseElement.style.border = '1px outset red';
  }

  /** 選択解除時の表示
   *
   */
  FrameBorder.prototype.loseFocus = function() {
    if(!this.baseElement) {
      this.baseElement = getDocumentElementById(this.id + '.BASE');
    }
    this.baseElement.style.border = '1px solid ' + this.parent.borderColor;
  }
}

/**
 * フレームの表示幅計算オブジェクト.
 * @param _colsrows         '100,*'等の文字列.
 *        _displayWidth     ページ全体の表示幅
 *        _borderWidth      境界線の幅
 *        _minContentWidth  1要素のページ幅の最小値
 */
function FrameColsrows(_colsrows, _displayWidth, _borderWidth, _minContentWidth) {
  
  // _colsrowsの配列表現
  this.elements = getElements(_colsrows, _borderWidth, _minContentWidth);

  // ページ全体の表示幅
  this.displayWidth = parseInt(_displayWidth);
  
  // 1要素のページ幅の最小値
  this.minContentWidth = parseInt(_minContentWidth);
  
  // 境界の幅
  this.borderWidth = parseInt(_borderWidth);
  
  // 要素合計の幅
  this.elementsTotalWidth = getTotal(this.elements);

  // 要素合計の最小幅
  this.minTotalWidth = getMinTotal(this.elements);

  // *
  this.existsAstarisk = false;
  for(var i in this.elements) {
    if(this.elements[i].isAstarisk) {
      this.existsAstarisk = true;
    }
  }
  
  // チェック
  if(this.displayWidth < this.minTotalWidth) {
    var msg = '';
    //msg += 'フレームセットの幅(' + this.displayWidth + ')が、';
    //msg += '必要な幅(' + this.minTotalWidth + ')に足りていません。\n';
    msg += '正しく表示できませんでした。（設定は有効です）';
    alert(msg);
    this.displayWidth = this.minTotalWidth;
  }

  if(this.displayWidth < this.elementsTotalWidth) {
    //数値を小さくする
    validateCorrective(this.elements, this.displayWidth);
  } else if(this.displayWidth > this.elementsTotalWidth) {
    if(this.existsAstarisk) {
      //数値はそのまま + アスタリスクの表示値計算
      validateAstariskCorrective(this.elements, this.displayWidth);
    } else {
      //数値を大きくする
      validateCorrective(this.elements, this.displayWidth);
    }
  } else {
    //そのまま
  }

  
  /*
   *
   */
  FrameColsrows.prototype.toString = function() {
    return _elementsToString(this.elements);
  }

  /*
   *
   */
  FrameColsrows.prototype.displayString = function() {
    return _elementsToString(this.elements, 'getDisplayValue');
  }

  /*
   *
   */
  FrameColsrows.prototype.addByIndex = function(_val, _index) {
    return _addByIndex(_val, _index, this.elements);
  }

  /*
   *
   */
  FrameColsrows.prototype.getDisplayColsrows = function() {
    return _elementsToString(this.elements, 'getDisplayColsrows');
  }

  return;

  /*
   * 値の足し算
   */
  function _addByIndex(_val, _index, arr) {
    if(arr[_index]) {
      var element = arr[_index];
      if(!element.isAstarisk) {
        element.fixed += parseInt(_val);
      }
    }
  }

  /*
   * 補正値計算
   */
  function validateCorrective(arr, displayWidth) {
    
    // 補正値設定
    var elementsTotalWidth = getTotal(arr);
    //alert('elementsTotalWidth:' + elementsTotalWidth + '\ndisplayWidth:' + displayWidth + '\narr[0].getTotal():' + arr[0].getTotal());
    for(var i in arr) {
      var correcttotal = parseInt(arr[i].getTotal() * displayWidth / elementsTotalWidth);
      
      var corrective   = correcttotal - arr[i].getTotal();
      arr[i].corrective = correcttotal - arr[i].fixed - arr[i].base;
      if(0 > arr[i].corrective + arr[i].fixed) {
        arr[i].corrective = 0 - arr[i].fixed;
      }
    }
    
    // 補正値誤差修正
    var displayTotal = getDisplayTotal(arr);
    var updating = true;
    while(updating) {
      updating = false;
      for(var i in arr) {
        if(arr[i].isAstarisk) {
          if(displayWidth < displayTotal){
            if(0 < arr[i].corrective + arr[i].fixed) {
              arr[i].corrective -= 1;
              displayTotal -= 1;
              updating = true;
            }
          }
          if(displayWidth > displayTotal){
            arr[i].corrective += 1;
            displayTotal += 1;
            updating = true;
          } 
        }
      }

      if(!updating) {
        for(var i in arr) {
          if(!arr[i].isAstarisk) {
            if(displayWidth < displayTotal){
              if(0 < arr[i].corrective + arr[i].fixed) {
                arr[i].corrective -= 1;
                displayTotal -= 1;
                updating = true;
              }
            }
            if(displayWidth > displayTotal){
              arr[i].corrective += 1;
              displayTotal += 1;
              updating = true;
            } 
          }
        }
      }
    }
  }
  
  /*
   * アスタリスクの表示値設定のための補正値計算
   */
  function validateAstariskCorrective(arr, displayWidth) {
    // アスタリスクの数
    var count = 0;
    for(var i in arr) {
      if(arr[i].isAstarisk) {
        count++;
      }
    }
    if(count == 0) {
      return;
    }
    
    // 補正値設定
    var correcttotal = displayWidth - getDisplayTotal(arr);
    for(var i in arr) {
      if(arr[i].isAstarisk) {
        arr[i].corrective = parseInt(correcttotal / count);
      }
    }
    
    // 補正値誤差修正
    correcttotal = displayWidth - getDisplayTotal(arr);

    var updating = true;
    while(updating) {
      updating = false;
      for(var i in arr) {
        if(0 < correcttotal) {
          arr[i].corrective += 1;
          correcttotal -= 1;
          updating = true;
        }
        if(0 > correcttotal) {
          arr[i].corrective -= 1;
          correcttotal += 1;
          updating = true;
        }
      }
    }
  }
  
  /*
   * 要素の幅合計
   */
  function getMinTotal(arr) {
    var total = 0;
    for(var i in arr) {
      total += arr[i].getMinTotal();
    }
    return total;
  }
  
  /*
   * 要素の幅合計
   */
  function getTotal(arr) {
    var total = 0;
    for(var i in arr) {
      total += arr[i].getTotal();
    }
    return total;
  }
  
  /*
   * 要素の幅合計
   */
  function getDisplayTotal(arr) {
    var total = 0;
    for(var i in arr) {
      total += arr[i].getDisplayTotal();
    }
    return total;
  }
  

  /*
   * this.elements の要素となるオブジェクト
   */
  function FrameColsrowsElement(_index, _value, _borderWidth, _base) {

    // 
    this.index = parseInt(_index);
    
    // 
    this.previousBorderWidth = 0;

    // 1要素のページ幅の最小値
    this.base = 4;
    if(_base && !isNaN(_base)) {
      this.base = parseInt(_base);
    }

    // 数値指定の this.base を引いた大きさ
    this.fixed = 0;
    
    // 表示のための補正値
    this.corrective = 0;
    
    // *
    this.isAstarisk = true;

    if(typeof(_value) == 'number') {
      this.fixed = parseInt(_value) - this.base;
      this.isAstarisk = false;
      
    } else if(typeof(_value) == 'string') {
      if(!isNaN(_value)) {
        this.fixed = parseInt(_value) - this.base;
        this.isAstarisk = false;
      }
    }
    if(this.fixed < 0) {
      this.fixed = 0;
    }

    if(0 < this.index) {
      this.previousBorderWidth = _borderWidth;
    }

    FrameColsrowsElement.prototype.getMinTotal = function() {
      return this.previousBorderWidth + this.base;
    }
    
    FrameColsrowsElement.prototype.getTotal = function() {
      return this.previousBorderWidth + this.base + this.fixed;
    }

    FrameColsrowsElement.prototype.getDisplayTotal = function() {
      return this.previousBorderWidth + this.base + this.fixed + this.corrective;
    }

    FrameColsrowsElement.prototype.getValue = function() {
      return this.base + this.fixed;
    }

    FrameColsrowsElement.prototype.getDisplayValue = function() {
      return this.base + this.fixed + this.corrective;
    }

    FrameColsrowsElement.prototype.toString = function() {
      if(this.isAstarisk) {
        return '*';
      }
      return this.getValue().toString();
    }

    FrameColsrowsElement.prototype.getDisplayColsrows = function() {
      if(this.isAstarisk) {
        return '*';
      }
      return this.getDisplayValue().toString();
    }
  }
  
  /* 文字列を配列に変換.要素の値は'*'か 1以上の整数
   *
   */
  function getElements(_colsrows, _borderWidth, _base) {
    var arr = new Array();
    if(_colsrows) {
      var splt = _colsrows.split(',');
      for(var i in splt) {
        arr[i] = new FrameColsrowsElement(i, splt[i], _borderWidth, _base);
      }
    }
    return arr;
  }

  /* 配列からカンマ区切り文字列作成
   * @param  _arr Array 配列
   * @return カンマ区切り文字列
   */
  function _elementsToString(_arr, methodName) {
    var str = '';
    for(var i = 0; i < _arr.length; i++) {
      if(i != 0) {
        str += ',';
      }
      if(!methodName) {
        str += _arr[i];
      } else {
        _arr[i].temporaryMethod = _arr[i][methodName];
        str += _arr[i].temporaryMethod();
      }
    }
    return str;
  }
}

/**
 * フレーム検索ダイアログを開く
 */ 
function doCommandFind_frame() {
  if(!objSerchManager) {
    objSerchManager = new SearchFrameObject();
  }
  
  if(objSerchManager.isOpen) {
    objSerchManager.activate();
  } else {
    openSearchItemDialog(objSerchManager);
  }
}

/**
 * フレーム検索ダイアログオブジェクト
 */ 
function SearchFrameObject() {
  this.isOpen = false;
  this.autoClose = false;
  this.autoUpdate = true;
  
  this.width = 400;
  this.header = new Array();
  this.header[0] = new Object();
  this.header[0].width = 100;
  this.header[0].title = getLiteral('common.objectid');
  this.header[1] = new Object();
  this.header[1].width = 100;
  this.header[1].title = getLiteral('common.itemtype');
  this.header[2] = new Object();
  this.header[2].width = 200;
  this.header[2].title = getLiteral('dialog.find.framename');
  this.ref = new Object();
  
  // 選択時
  SearchFrameObject.prototype.returnOk = function(_id) {
    framePageSelect(this.ref[_id]);
  }

  // 一覧取得  
  SearchFrameObject.prototype.getItemList = function() {
    
    this.arr = new Array();
    this.ref = new Object();
    makeListInfo(this, m_rootFramePage);
    this.body = this.arr;
    return this;
  }

  // 一覧取得のための関数
  function makeListInfo(arg, obj, indexinfo) {
    if(obj.isBorder) {
      return;
    }
    var newInfo = new Array('','','');
    arg.arr[arg.arr.length] = newInfo;
    if(obj.pageItem) {
      newInfo[0] = obj.pageItem.pageItemId;
      arg.ref[newInfo[0]] = obj;
      newInfo[1] = getLiteral('dialog.find.frameset');
      var childindexinfo = new Object();
      childindexinfo.objectId = obj.pageItem.pageItemId;
      childindexinfo.index = 1;
      if(indexinfo) {
        childindexinfo.parents = indexinfo.parents + ' - ' + childindexinfo.objectId;
      } else {
        childindexinfo.parents = childindexinfo.objectId;
      }
      //newInfo[2] = childindexinfo.parents;
      //newInfo[2] = obj.id;
      for(var i in obj.children) {
        makeListInfo(arg, obj.children[i], childindexinfo);
      }

    } else {
      newInfo[0] = indexinfo.objectId + '[' + indexinfo.index + ']';
      arg.ref[newInfo[0]] = obj;
      newInfo[1] = getLiteral('dialog.find.frame');
      newInfo[2] = obj.getValue('frameinfo.framename.edit');
      //newInfo[2] = indexinfo.parents + '[' + indexinfo.index + ']';
      //newInfo[2] = obj.id;
    }
    if(indexinfo) {
      indexinfo.index++;
    }
  }
}

// ユーザの作業状態をまとめたオブジェクト
var m_operation = new FrameOperation();
function FrameOperation() {

  // 現在選択されているフレーム or フレームセット
  this.currentSelection = null;

  // 選択されたフレームセット
  this.currentFrameset = null;

  // ドラッグ中の境界線
  this.currentBorder = null;

  // ドラッグ開始位置X
  this.dragStartX = -1;
  this.dragStartY = -1;

  // ドラッグ中
  this.dragging = false;

  // ドラッグ可能な範囲の最小値
  this.dragmin = 0;

  // ドラッグ可能な範囲の最大値
  this.dragmax = 0;
  
  // ダブルクリック時に発生するイベントの数
  if(m_browserType.isIE){
    this.MOUSEDOWNCOUNTLIMIT = 2;
  } else {
    this.MOUSEDOWNCOUNTLIMIT = 3;
  }

  // dblclick判定のためのカウント
  this.mousedownCount = 0;

  // 前回クリックされたID
  // 同じオブジェクトがクリックされた時に無視するために使用
  this.recentMousedownId = '';
  
  /**
   * 無視するイベントを判定する
   */
  FrameOperation.prototype.eventOrder = function(_eventType, _targetObject) {
    
    if(!_targetObject.isBorder) {
      // フレームがクリックされた場合

      if(_eventType == 'mousedown') {
        if(this.mousedownCount < this.MOUSEDOWNCOUNTLIMIT) {
          this.mousedownCount += 1;
        }
        
        if(this.recentMousedownId == _targetObject.id) {
          // 同じオブジェクトのクリックは無視
          return false;
        }

        this.recentMousedownId = _targetObject.id;

      } else if(_eventType == 'dblclick'){
        // this.currentFramesetを更新
        var current = this.currentFrameset;
        this.currentFrameset = _targetObject.parent;
        if(this.mousedownCount < this.MOUSEDOWNCOUNTLIMIT) {
          if(current && current.parent) {
            for(var tmpSelection = _targetObject; tmpSelection; tmpSelection = tmpSelection.parent) {
              if(tmpSelection == current) {
                this.currentFrameset = current.parent;
                break;
              }
            }
          }
        }
        this.mousedownCount = 0;
        this.recentMousedownId = '';
      } // _eventType

    } else {
      // 境界線がクリックされた場合

      this.recentMousedownId = '';
      if(_eventType == 'dblclick') {
        // ダブルクリックに対しては処理しない
        return false;
      }
    }
    return true;
  }
}

/**
 * IE と NN のeventの違いを吸収
 */
function validateCommonFramePageEvent(_event) {
  var cmnEvent = new Object();
  if(m_browserType.isIE){
    cmnEvent.type     = event.type;
//    cmnEvent.target   = event.srcElement;
    cmnEvent.clientX  = event.clientX;
    cmnEvent.clientY  = event.clientY;
    cmnEvent.keyCode  = event.keyCode;
//    cmnEvent.shiftKey = event.shiftKey;
//    cmnEvent.ctrlKey  = event.ctrlKey;
  } else {
    cmnEvent.type     = _event.type;
//    cmnEvent.target   = _event.target;
    cmnEvent.clientX  = _event.clientX;
    cmnEvent.clientY  = _event.clientY;
    cmnEvent.keyCode  = _event.keyCode;
//    cmnEvent.shiftKey = _event.shiftKey;
//    cmnEvent.ctrlKey  = _event.ctrlKey;

    cmnEvent.charCode = _event.charCode;
    if(0 < _event.charCode) {
      cmnEvent.hasCharCode = true;
    } else {
      cmnEvent.hasKeyCode = true;
    }
  }
  return cmnEvent;
}

/** 
 * イベントハンドラ：
 */
function framePageMouseDown(_id, _event) {
  var cmnEvent = validateCommonFramePageEvent(_event);
  m_menuBar.close();
  if(!m_rootFramePage) {
    return;
  }

  updatePropertyIfUncommited_frame();
  //if(uncommitedId == 'height' ||
  //   uncommitedId == 'width') {
  //  return;
  //}

  // クリックされたオブジェクト（フレーム or 境界線）
  var newSelection = m_rootFramePage.getObject(_id);

  // 発生したイベントを登録
  // もともと選択されたオブジェクトをクリックしたとき
  // または、ダブルクリックの2回目のクリックでは無視
  if(!m_operation.eventOrder(cmnEvent.type, newSelection)) {
    return;
  }
  
  if(newSelection.isBorder) {
    m_operation.currentBorder = newSelection;
    newSelection = null;
    
    m_operation.dragStartX = cmnEvent.clientX;
    m_operation.dragStartY = cmnEvent.clientY;

    m_operation.dragging = true;
    m_operation.dragmin = m_operation.currentBorder.getMinToMove();
    m_operation.dragmax = m_operation.currentBorder.getMaxToMove();
    drawDraggingRect(m_operation.currentBorder);

  } else {
    m_operation.currentBorder = null;
    
    framePageSelect(newSelection);  
  }
  
  return;
}

/** 
 * イベントハンドラ：
 */
function framePageDblClick(_id, _event) {
  var cmnEvent = validateCommonFramePageEvent(_event);
  
  if(!m_rootFramePage) {
    return;
  }

  // ダブルクリックされたオブジェクト
  var newSelection = m_rootFramePage.getObject(_id);

  // 発生したイベントを登録
  // もともと選択されたオブジェクトをクリックしたとき
  // または、ダブルクリックの2回目のクリックでは無視
  // 境界線のダブルクリックは無視
  if(!m_operation.eventOrder(cmnEvent.type, newSelection)) {
    return;
  }
  
  // フレームセットを選択
  framePageSelect(m_operation.currentFrameset);
  
  //debugger
}

/** 
 * ページ部分・枠部分選択時
 */
function framePageSelect(newSelection) {

  if(newSelection) {
    
    if(m_operation.currentSelection) {
      if(m_operation.currentSelection != newSelection) {
        m_operation.currentSelection.loseFocus();
      }
    }    
    m_operation.currentSelection = newSelection;
    m_operation.currentSelection.getFocus();

    updatePropertyIfUncommited_frame();
    //m_operation.currentSelection.drawPropertyEdit();
    drawFramePropertyEdit(m_operation.currentSelection, 'm_operation.currentSelection');
  }
}

/** 
 * 枠ドラッグ時：
 */
function drawDraggingRect(_selection) {
    var parent = getDocumentElementById(_selection.parent.id + '.BASE') ;
    if(parent) {

      var table = new HtmlTag('table');
      table.cellspacing = '0';
      table.id = 'DRAGGING';
      table.style.top      = _selection.top + 'px';
      table.style.left     = _selection.left + 'px';
      table.style.width    = _selection.width + 'px';
      table.style.height   = _selection.height + 'px';
      table.style.position = 'absolute';
      table.style.cursor   = _selection.cursor;
      table.style.border   = '1px dotted blue';
      
      table.innerHTML = new HtmlTag('tr');
      table.innerHTML.innerHTML = new HtmlTag('td');
      table.innerHTML.innerHTML.onmouseup = 'framePageOnMouseUp(event);';

      parent.innerHTML += table;
    }
}

/** 
 * イベントハンドラ：
 */
function framePageOnMouseDown(_event) {
  var cmnEvent = validateCommonFramePageEvent(_event);
}

/** 
 * イベントハンドラ：
 */
function framePageOnMouseMove(_event) {
  var cmnEvent = validateCommonFramePageEvent(_event);
  framePageMouseMove('', cmnEvent);
}

/** 
 * イベントハンドラ：
 */
function framePageOnMouseUp(_event) {
  var cmnEvent = validateCommonFramePageEvent(_event);
  framePageMouseUp('', cmnEvent);
}

/** 
 * イベントハンドラ：
 */
function framePageMouseMove(_id, cmnEvent) {
  if(!m_operation.dragging) {
    return ;
  }
  var rect = getDocumentElementById('DRAGGING') ;
  if(!rect) {
    return ;
  }
  
  var newValue = 0;
  if(m_operation.currentBorder.direction == 'cols') {
    newValue = m_operation.currentBorder.top + cmnEvent.clientY - m_operation.dragStartY;
    if(newValue < m_operation.dragmin) {
      newValue = m_operation.dragmin;
    } else if(m_operation.dragmax < newValue){
      newValue = m_operation.dragmax;
    }
    rect.style.top = newValue;
  } else {
    newValue = m_operation.currentBorder.left + cmnEvent.clientX - m_operation.dragStartX;
    if(newValue < m_operation.dragmin) {
      newValue = m_operation.dragmin;
    } else if(m_operation.dragmax < newValue){
      newValue = m_operation.dragmax;
    }
    rect.style.left = newValue;
  }
}

/** 
 * イベントハンドラ：
 */
function framePageMouseUp(_id, cmnEvent) {

  if(!m_operation.dragging) {
    return ;
  }
  m_operation.dragging = false;

  var rect = getDocumentElementById('DRAGGING') ;
  if(!rect) {
    return ;
  }

  if(m_operation.currentBorder.direction == 'cols') {
    newValue = m_operation.currentBorder.top + cmnEvent.clientY - m_operation.dragStartY;
    if(newValue < m_operation.dragmin) {
      newValue = m_operation.dragmin;
    } else if(m_operation.dragmax < newValue){
      newValue = m_operation.dragmax;
    }
    m_operation.currentBorder.updateLocation(m_operation.currentBorder.top, newValue);
  } else {
    newValue = m_operation.currentBorder.left + cmnEvent.clientX - m_operation.dragStartX;
    if(newValue < m_operation.dragmin) {
      newValue = m_operation.dragmin;
    } else if(m_operation.dragmax < newValue){
      newValue = m_operation.dragmax;
    }
    m_operation.currentBorder.updateLocation(m_operation.currentBorder.left, newValue);
  }
  m_menuBar.enableSave();

  rect.style.visibility = 'hidden';
  rect = null;

  m_rootElement.innerHTML = m_rootFramePage.getHtml();

  if(m_operation.currentSelection) {
    m_operation.currentSelection = m_rootFramePage.getObject(m_operation.currentSelection.id);
    if(m_operation.currentSelection) {
      updatePropertyIfUncommited_frame();
//      m_operation.currentSelection.drawPropertyEdit();
      drawFramePropertyEdit(m_operation.currentSelection, 'm_operation.currentSelection');
      m_operation.currentSelection.getFocus();
    }
  }
}

/**
 *
 */
var m_propertyEdit = new Object();

/**
 *  ページプロパティ用
 */
function FramePropertyPage() {
  this.propertyEdits = new Object();

  this.propertyEdits['caption']     = new FramePropertyEditText(getLiteral('property.pagetitle'),     'page.caption.edit');
  this.propertyEdits['border']      = new FramePropertyEditNumber(getLiteral('property.frameborderwidth'),       'page.border.edit' , 2);
  this.propertyEdits['bordercolor'] = new FramePropertyEditColor(getLiteral('property.framebordercolor'),         'page.bordercolor.edit');
  this.propertyEdits['onload']      = new FramePropertyEditEvent(getLiteral('property.onload'),             'page.onload.edit');
  this.propertyEdits['onunload']    = new FramePropertyEditEvent(getLiteral('property.onunload'),           'page.onunload.edit');
  this.propertyEdits['jsfilename']  = new FramePropertyEditInclude(getLiteral('property.jsfile'),     'page.jsfilename.edit');
  this.propertyEdits['meta']        = new FramePropertyEditMeta(getLiteral('property.meta'),     'page.meta.edit');
  
  FramePropertyPage.prototype.getHtml = function(obj) {
    return FrameProperty_getHtml(this.propertyEdits, obj, getLiteral('propertygroup.page'));  
  }
}
m_propertyEdit['PAGE'] = new FramePropertyPage();

/**
 *  分割プロパティ用
 */
function FramePropertyPartition() {
  this.propertyEdits = new Object();

  this.propertyEdits['direction']   = new FramePropertyEditComboDirection(getLiteral('property.direction'), 'page.direction.edit');
  
  FramePropertyPartition.prototype.getHtml = function(obj) {
    var pobjs = new Array();
    var pobj = obj;
    while(pobj.parent) {
      pobj = pobj.parent;
      pobjs[pobjs.length] = pobj;
    }
    var _propertyEdits = new Object();
    _propertyEdits['direction'] = this.propertyEdits['direction'];
    var level = 1;
    for(var i = pobjs.length; i > 0; i--) {
      _propertyEdits['divide.' + i] = new FramePropertyEditComboDivide(level , 'divide.' + i + '.edit');
      level++;
    }
    _propertyEdits['divide'] = new FramePropertyEditComboDivide(level, 'divide.edit');
    
    return FrameProperty_getHtml(_propertyEdits, obj, getLiteral('propertygroup.division'));  
  }
}
m_propertyEdit['PARTITION'] = new FramePropertyPartition();


/**
 *  最上位階層用
 */
function FramePropertyTopPage() {
  this.propertyEdits = new Object();

  FramePropertyTopPage.prototype.getHtml = function(obj) {
    return FrameProperty_getHtml(this.propertyEdits, obj, getLiteral('propertygroup.frameset'));  
  }
}
m_propertyEdit['ROOTFRAMESET'] = new FramePropertyTopPage();

/**
 *  フレームセット用
 */
function FramePropertyFramesetPage() {
  this.propertyEdits = new Object();

  this.propertyEdits['width']       = new FramePropertyEditFrameSize(getLiteral('property.width'),   'object.width.edit');
  this.propertyEdits['height']      = new FramePropertyEditFrameSize(getLiteral('property.height'), 'object.height.edit');
  
  FramePropertyFramesetPage.prototype.getHtml = function(obj) {
    this.propertyEdits['width'].hidden = (obj.parent.width == obj.width);
    this.propertyEdits['height'].hidden = (obj.parent.height == obj.height);
    return FrameProperty_getHtml(this.propertyEdits, obj, getLiteral('propertygroup.frameset'));  
  }
}
m_propertyEdit['FRAMESET'] = new FramePropertyFramesetPage();

/**
 *  フレーム用
 */
function FramePropertyFramePage() {
  this.propertyEdits = new Object();

  this.propertyEdits['width']       = new FramePropertyEditFrameSize(getLiteral('property.width'),      'object.width.edit');
  this.propertyEdits['height']      = new FramePropertyEditFrameSize(getLiteral('property.height'),    'object.height.edit');
  this.propertyEdits['framename']      = new FramePropertyEditText(getLiteral('property.framename'),   'frameinfo.framename.edit');
  this.propertyEdits['framesrc']       = new FramePropertyEditLongString(getLiteral('property.framesrc'), 'frameinfo.framesrc.edit');
  this.propertyEdits['framescrolling'] = new FramePropertyEditComboScrolling(getLiteral('property.framescrolling'),     'frameinfo.framescrolling.edit');
  this.propertyEdits['frameresize']    = new FramePropertyEditCheckResize(getLiteral('property.framenoresize'),     'frameinfo.frameresize.edit');
  
  FramePropertyFramePage.prototype.getHtml = function(obj) {
    this.propertyEdits['width'].hidden = (obj.parent.width == obj.width);
    this.propertyEdits['height'].hidden = (obj.parent.height == obj.height);
    return FrameProperty_getHtml(this.propertyEdits, obj, getLiteral('propertygroup.frame'));  
  }
}
m_propertyEdit['FRAME'] = new FramePropertyFramePage();

/**
 *  プロパティ編集欄の描画
 */
function FrameProperty_getHtml(propertyEdits, obj, title) {
  var html = '';

  // 属性欄タイトル
  if(title) {
    var table_title = new HtmlTag('table');
    table_title.style.fontSize = '8pt';
    table_title.innerHTML = new HtmlTag('tr');
    table_title.innerHTML.innerHTML = new HtmlTag('td');
    table_title.innerHTML.innerHTML.height = '22px';
    table_title.innerHTML.innerHTML.valign = 'bottom';
    table_title.innerHTML.innerHTML.innerHTML = '&lt;' + title + '&gt;';
    
    html += table_title;
  }

  // 属性欄
  var table = new HtmlTag('table');
  table.cellspacing = '0';
  table.cellpadding = '0';
  table.width       = '200px';
  table.border      = '1';
  table.style.tableLayout = 'fixed';
  table.style.fontSize = '9pt';

  // 各 tr 作成用
  var tr = new HtmlTag('tr');

  // 属性名 td
  var td_caption = new HtmlTag('td');
  td_caption.width = '100px';

  // 属性値 td
  var td_value = new HtmlTag('td');
  td_value.width = '100px';
  
  for(var i in propertyEdits) {
    if(!propertyEdits[i].hidden) {
      td_caption.innerHTML = propertyEdits[i].caption;
      td_value.innerHTML   = propertyEdits[i].getHtml(obj);
      table.innerHTML += tr.containing(td_caption + td_value);
    }
  }

  html += table;
  
  return html;  
}
  
/**
 *  テキストプロパティ編集のHTML
 */
function FramePropertyEditText(_caption, _id) {
  this.caption = _caption;
  this.id = _id;
  FramePropertyEditText.prototype.getHtml = function(obj) {
    var html = '';
    html += propertyEditTextWithAlign(this.id, obj.getValue(this.id), 'left', '98');
    return html;
  }
}

/**
 *  数値プロパティ編集のHTML
 */
function FramePropertyEditNumber(_caption, _id, _maxlength) {
  this.caption = _caption;
  this.id = _id;
  this.maxlength = '';
  if(_maxlength) {
    this.maxlength = _maxlength.toString();
  }
  FramePropertyEditNumber.prototype.getHtml = function(obj) {
    var html = '';
    html += propertyEditTextWithAlign(this.id, obj.getValue(this.id), 'right', '98', 'disableime' ,'framePropertyCheckNumberOnKeyPress', this.maxlength);
    return html;
  }
}

/**
 *  数値 + * プロパティ編集のHTML
 */
function FramePropertyEditFrameSize(_caption, _id) {
  this.caption = _caption;
  this.id = _id;
  FramePropertyEditFrameSize.prototype.getHtml = function(obj) {
    var html = '';
    html += propertyEditTextWithAlign(this.id, obj.getValue(this.id), 'right', '98', 'disableime' ,'framePropertyCheckNumberAstariskOnKeyPress', '4');
    return html;
  }
}

/**
 *  書込み禁止プロパティ編集のHTML
 */
function FramePropertyEditReadonly(_caption, _id) {
  this.caption = _caption;
  this.id = _id;
  FramePropertyEditReadonly.prototype.getHtml = function(obj) {
    var html = '';
    html += propertyEditTextWithAlign(this.id, obj.getValue(this.id), 'left', '98', 'readonly');
    return html;
  }
}

/**
 *  色プロパティ編集のHTML
 */
function FramePropertyEditColor(_caption, _id) {
  this.caption = _caption;
  this.id = _id;

  FramePropertyEditColor.prototype.getHtml = function(obj) {
    var html = '';
    html += propertyEditColor(this.id, obj.getValue(this.id));
    return html;
  }
}

/**
 *  イベントプロパティ編集のHTML
 */
function FramePropertyEditEvent(_caption, _id) {
  this.caption = _caption;
  this.id = _id;

  FramePropertyEditEvent.prototype.getHtml = function(obj) {
    var html = '';
    html += propertyEditTextWithButton(this.id, obj.getValue(this.id), 'doEditEvent_frame(\'' + this.id + '\');');
    return html;
  }
}

/**
 *  長い文字列プロパティ編集のHTML
 */
function FramePropertyEditLongString(_caption, _id) {
  this.caption = _caption;
  this.id = _id;

  FramePropertyEditLongString.prototype.getHtml = function(obj) {
    var html = '';
    html += propertyEditTextWithButton(this.id, obj.getValue(this.id), 
            'doEditLongString_frame(\'' + this.id + '\',\'' + this.caption + '\');');

    return html;
  }
}

/**
 *  インクルードファイルプロパティ編集のHTML
 */
function FramePropertyEditInclude(_caption, _id) {
  this.caption = _caption;
  this.id = _id;

  FramePropertyEditInclude.prototype.getHtml = function(obj) {
    var html = '';
    html += propertyEditButton(this.id, 'doEditJsfile_frame();', getLiteral('common.editbutton') + '...');
    return html;
  }
}

/**
 *  メタ情報プロパティ編集のHTML
 */
function FramePropertyEditMeta(_caption, _id) {
  this.caption = _caption;
  this.id = _id;

  FramePropertyEditMeta.prototype.getHtml = function(obj) {
    var html = '';
    html += propertyEditButton(this.id, 'doEditMeta_frame();', getLiteral('common.editbutton') + '...');
    return html;
  }
}

/**
 *  分割方向プロパティ編集のHTML
 */
function FramePropertyEditComboDirection(_caption, _id) {
  this.caption = _caption;
  this.id = _id;
  FramePropertyEditComboDirection.prototype.getHtml = function(obj) {
    var html = '';
    html += propertyEditCombo(this.id, obj.getValue(this.id), pref.valueoption.direction);
    return html;
  }
}

/**
 *  分割数プロパティ編集のHTML
 */
function FramePropertyEditComboDivide(_level, _id) {
  this.level = _level;
  this.caption = getLiteral('property.divisionlevel') + _level;
  this.id = _id;
  FramePropertyEditComboDivide.prototype.getHtml = function(obj) {
    var html = '';
    var option = new Object();
    var unit = getLiteral('divisions.unit');
    if(this.level > 1) {
      option['1'] = getLiteral('divisions.nodivisions');
    }
    option['2'] = '2' + unit;
    option['3'] = '3' + unit;
    option['4'] = '4' + unit;
    html += propertyEditCombo(this.id, obj.getValue(this.id), option);
    return html;
  }
}

/**
 *  スクロールプロパティ編集のHTML
 */
function FramePropertyEditComboScrolling(_caption, _id) {
  this.caption = _caption;
  this.id = _id;

  FramePropertyEditComboScrolling.prototype.getHtml = function(obj) {
    var html = '';
    html += propertyEditCombo(this.id, obj.getValue(this.id), pref.valueoption.scrolling);
    return html;
  }
}

/**
 *  スクロールプロパティ編集のHTML
 */
function FramePropertyEditCheckResize(_caption, _id) {
  this.caption = _caption;
  this.id = _id;
  FramePropertyEditCheckResize.prototype.getHtml = function(obj) {
    var html = '';
    html += propertyEditCheck(this.id, obj.getValue(this.id), 'noresize', '', getLiteral('framenoresize.noresize'));
    return html;
  }
}

/** プロパティ編集欄用テキスト
 *  
 */
function propertyEditTextWithAlign(_id, _value, _align, _width, _inputmode, _onkeypress, _maxLength) {

  var input = new HtmlTag('input');
  input.id       = _id;
  input.type     = 'text';
  input.value    = _value;
  input.onchange = 'onChangeProperty_frame(this.id, this.value);';
  input.onkeyup  = 'onKeyUpProperty_frame(this.id, this.value, event, \'number\');';
  input.onselectstart = 'onSelectStartEnableSelect(event)';

  if(_onkeypress) {
    input.onkeypress = 'return ' + _onkeypress + '(event);';
  }
  if(_maxLength) {
    input.maxlength = _maxLength;
  }
  input.style.fontSize  = '9pt';
  input.style.textAlign = _align;
  input.style.width     = _width;

  if(_inputmode && _inputmode == 'readonly') {
    input.readonly = true;
    input.style.cursor = 'default';
  }
  if(_inputmode && _inputmode == 'disableime') {
    input.style.imeMode = 'disabled';
  }
  
  return input.toString();
}

/** プロパティ編集欄用チェックボックス
 *  
 */
function propertyEditCheck(_id, _value, _valueOn, _valueOff, _text) {

  var input = new HtmlTag('input');
  input.id      = _id;
  input.type    = 'checkbox';
  input.value   = _valueOn;
  input.onclick = 'if(this.checked){onChangeProperty_frame(this.id, \'' + _valueOn + '\');}else{onChangeProperty_frame(this.id, \'' + _valueOff + '\');}"';
  input.style.fontSize  = '9pt';

  if(_value == _valueOn) {
    input.checked = true;
  }
  
  var label = new HtmlTag('label');
  label.FOR = _id;
  label.innerHTML = _text;
  
  return input + label;

}

/** プロパティ編集欄用コンボ
 *  
 */
function propertyEditCombo(_id, _value, _options) {

  var select = new HtmlTag('select');
  select.id      = _id;
  select.onchange = 'onChangeProperty_frame(this.id, this.value);';
  select.style.width    = '98px';
  select.style.fontSize = '9pt';
  select.style.imeMode  = 'disabled';
  for(var i in _options) {
    var option = new HtmlTag('option');
    option.value = i;
    if(i == _value) {
      option.selected = true;
    }
    option.innerHTML = _options[i];

    select.innerHTML += option;
  }

  return select.toString();  
}

/**
 * 色入力タイプのプロパティテーブル作成
 * @param  :strLabel    文字型 プロパティ表示名
 *          strTypeId   文字型 プロパティタイプID
 * @return :作成したHTML文字列
 */
function propertyEditColor(_id, _value){
  var rtnHTML  = '';
  
  // 属性値部分全体 table
  var table = new HtmlTag('table');
  table.cellspacing = '0';
  table.cellpadding = '0';
  table.width       = '98px';
  table.height      = '18px';
  table.bgcolor     = 'white';
  if(IMAGEURL_COLORTIPBG) {
    table.style.backgroundImage = getImageSrcUrl(IMAGEURL_COLORTIPBG);
  }
  if(pref.env.basecolor) {
    table.style.backgroundColor = pref.env.basecolor;
  } else {
    table['class'] = CLASSNAME_BASEBACKGROUNDCOLOR;
  }
  
  // 各 tr 作成用
  var tr = new HtmlTag('tr');

  // 色サンプルの上下隙間 td
  var td_filling = new HtmlTag('td');
  td_filling.height  = '1px';
  
  // 色サンプル部分 td
  var td_color = new HtmlTag('td');
  td_color.id        = 'fld_' + _id + '_span';
  td_color.width     = '100%';
  td_color.height    = '100%';
  td_color.innerHTML = '&nbsp;';
  td_color.onclick   = 'doEditColor_frame(\'' + _id + '\');';
  td_color.style.fontSize  = '1px';
  td_color.style.cursor    = 'default';
  td_color.style.border    = '1px  black solid';
  td_color.style.backgroundColor  = _value;
  
  // 色名 text
  var input = new HtmlTag('input');
  input.id    = 'fld_' + _id;
  input.type  = 'text';
  input.value = _value;
  input.onkeyup  = 'onKeyUpColorProperty_frame(this.id, this.value, event);';
  input.onchange = 'onChangeColorProperty_frame(this.id, this.value);';
  input.onselectstart = 'onSelectStartEnableSelect(event)';
  input.style.width     = '70px';
  input.style.fontSize  = '9pt';
  input.style.textAlign = 'left';
  input.style.imeMode   = 'disabled';

  // 色名部分 td
  var td_input = new HtmlTag('td');
  td_input.rowspan  = '3';
  td_input.style.fontSize  = '1px';
  td_input.innerHTML = input;

  // 背景色
  if(pref.env.basecolor) {
    td_filling.style.backgroundColor  = pref.env.basecolor;
    td_input.style.backgroundColor  = pref.env.basecolor;
  } else {
    td_filling['class']  = CLASSNAME_BASEBACKGROUNDCOLOR;
    td_input['class']  = CLASSNAME_BASEBACKGROUNDCOLOR;
  }
  
  // tableのなかみ設定
  table.innerHTML += tr.containing(td_filling + td_input);
  table.innerHTML += tr.containing(td_color);
  table.innerHTML += tr.containing(td_filling);
  
  return table.toString();
}

/**
 * eventタイプのプロパティテーブル作成
 * @param  :strLabel     文字型 プロパティ表示名
 *          strTypeId    文字型 プロパティタイプID
 * @return :作成したHTML文字列
 */
function propertyEditTextWithButton(_id, _value, _onclick){
  var input_text = propertyEditTextWithAlign('fld_' + _id, _value, 'left', '82px');

  var input_button = new HtmlTag('input');
  input_button.type     = 'button';
  input_button.id       = 'fld_' + _id + '_btn';
  input_button.value    = '...';
  input_button.onclick  = _onclick;
  input_button.style.width    = '16px';
  input_button.style.height   = '20px';
  input_button.style.fontSize = '9pt';

  return input_text + input_button;
}

/**
 * button入力タイプのプロパティテーブル作成
 * @param  :strLabel    文字型 プロパティ表示名
 *          strTypeId   文字型 プロパティタイプID
 *          strOnclick  文字型 onclick時の処理
 *          strValue    文字型 ボタンキャプション
 * @return :作成したHTML文字列
 */
function propertyEditButton(_id, _onclick, _label){
  var rtnHTML = '';
      rtnHTML += '<input type="button" id="fld_' + _id + '" style="width:100%; font-size:9pt;' + STYLE_PROPBUTTONCOLOR + '" onclick="' + _onclick + '" value="' + _label + '">';
  return rtnHTML;
}

/**
 * DataSetオブジェクトのカマシ
 */
function FramePageDataSet() {
  FramePageDataSet.prototype.getProperty = function(_propertyId) {
    
    if(_propertyId.indexOf('fld_') == 0) {
      _propertyId = _propertyId.substring(4);
    }
    if(_propertyId == 'jsfilename') {
      _propertyId = 'page.jsfilename';
    }
    if(_propertyId == 'meta') {
      _propertyId = 'page.meta';
    }

    if(m_operation.currentSelection) {
      return m_operation.currentSelection.getValue(_propertyId);
    } else {
      return m_rootFramePage.getValue(_propertyId);
    }
  }
  FramePageDataSet.prototype.setProperty = function(_propertyId, _value) {
    if(_propertyId.indexOf('fld_') == 0) {
      _propertyId = _propertyId.substring(4);
    }
    if(_propertyId == 'jsfilename') {
      _propertyId = 'page.jsfilename';
    }
    if(_propertyId == 'meta') {
      _propertyId = 'page.meta';
    }

    if(m_operation.currentSelection) {
      return m_operation.currentSelection.setValue(_propertyId, _value);
    } else {
      return m_rootFramePage.setValue(_propertyId, _value);
    }
  }
}

var currentPropertyTableOwner = null;
function setCurrentPropertyTableOwner(obj) {
  currentPropertyTableOwner = obj;
}

function getCurrentPropertyTableOwner() {
  return currentPropertyTableOwner;
}

var pagePropertyTableOwner = null;
function setPagePropertyTableOwner(obj) {
  pagePropertyTableOwner = obj;
}

function getPagePropertyTableOwner() {
  return pagePropertyTableOwner;
}

//
var uncommitedId = '';
var uncommitedValue = '';

function updatePropertyIfUncommited_frame(_id, _value) {
  if(uncommitedId != '') {
    onChangeProperty_frame(uncommitedId, uncommitedValue);
    return true;
  }
  return false;
}

function clearUncommited_frame() {
  uncommitedId = '';
  uncommitedValue = '';
}

var m_framePropertyCheck = new Object();
m_framePropertyCheck['number'] = function(_keyCode, _value) {
  if(isNaN(_value)) {
    return false;
  }
  return true;
}

function framePropertyCheckNumberAstariskOnKeyPress(_event) {
  var cmnEvent = validateCommonFramePageEvent(_event);
  if(cmnEvent.hasCharCode) {
    if(48 <= cmnEvent.charCode && cmnEvent.charCode < 58) {
      return true;
    } else if(cmnEvent.charCode == 42) {
      return true;
    }
  }
  if(cmnEvent.hasKeyCode) {
    return true;
  }

  if(48 <= cmnEvent.keyCode && cmnEvent.keyCode < 58) {
    return true;
  } else if(cmnEvent.keyCode == 42) {
    return true;
  }
  //window.status = cmnEvent.keyCode.toString();
  return false;
}

function framePropertyCheckNumberOnKeyPress(_event) {
  var cmnEvent = validateCommonFramePageEvent(_event);
  if(cmnEvent.hasCharCode) {
    if(48 <= cmnEvent.charCode && cmnEvent.charCode < 58) {
      return true;
    }
  }
  if(cmnEvent.hasKeyCode) {
    return true;
  }

  if(48 <= cmnEvent.keyCode && cmnEvent.keyCode < 58) {
    return true;
  }  
    
  return false;
}

function onKeyUpProperty_frame(_id, _value, _event, _checkId) {
  var cmnEvent = validateCommonFramePageEvent(_event);
  
  if(_checkId) {
/*
    switch(_checkId) {
    case 'object.width.edit':
    case 'object.height.edit':
      break;
    default:
      if(cmnEvent.keyCode != 13) {
        uncommitedId = _id;
        uncommitedValue = _value;
        return;
      }
    }
*/
  }

  if(cmnEvent.keyCode != 13) {
    uncommitedId = _id;
    uncommitedValue = _value;
    return;
  }
  onChangeProperty_frame(_id, _value);
}

function onKeyUpColorProperty_frame(_id, _value, _event, _checkId) {
  if(_event.keyCode < KEYCODE.DELETE && _event.keyCode != KEYCODE.BACKSPACE) return;
  onChangeColorProperty_frame(_id, _value);
}
function onChangeColorProperty_frame(_id, _value, _event, _checkId) {
  log.debug('onChangeColorProperty:enter (_id:'+_id + ')'); //@@

  //プロパティテーブルにセット
  if(!setElementStyleBackgroundColor(getDocumentElementById(_id + '_span'), _value)) {
    return;
  }
    
  onChangeProperty_frame(_id, _value);
}

function onChangeProperty_frame(_id, _value) {
  if(_id.indexOf('fld_') == 0) {
    _id = _id.substring(4);
  }
  var ids = _id.split('.');
  if(ids[0] == 'page') {
    if(pagePropertyTableOwner) {
      pagePropertyTableOwner = m_rootFramePage.getObject(pagePropertyTableOwner.id);
      var oldval = pagePropertyTableOwner.getValue(_id);
      if(oldval != _value) {
        var cmd = new FramePageUpdateValueCommand(pagePropertyTableOwner, _id, oldval, _value);
        m_undoManager.execute(cmd);
      }
    } else {
      alert('pagePropertyTableOwner is null.');
    }

  } else if(ids[0] == 'divide') {

    if(currentPropertyTableOwner) {
      var target = currentPropertyTableOwner.getTargetToDivide(ids[1]);
      var oldval = target.getValue('divide.edit');
      if(oldval != _value) {
        var cmd = new FramePageUpdateValueCommand(target, 'divide.edit', oldval, _value);
        m_undoManager.execute(cmd);
      }
    }    
  } else if(currentPropertyTableOwner) {
    
    var oldval = currentPropertyTableOwner.getValue(_id);
    if(oldval != _value) {
      var cmd = new FramePageUpdateValueCommand(currentPropertyTableOwner, _id, oldval, _value);
      m_undoManager.execute(cmd);
    }

  } else {
    alert('currentPropertyTableOwner is null.');
  }
  clearUncommited_frame();
}

/**
 * 色選択ダイアログオープン
 * @param  :strTypeId 文字型 色入力のTYPEID
 * @return :
 */
function doEditColor_frame(strTypeId){
//ダイアログへのパラメータ作成
  var objArg = new Object();
  objArg.userColors = m_userColors;
  try{
    var nowColor = getDocumentElementById('fld_' + strTypeId + '_span').style.backgroundColor;
  }catch(e){
    var nowColor = '';
  }
  if(!nowColor) nowColor = '';
  //16進数に変換
  if(nowColor != ''){
    nowColor = getHexColor(nowColor);
  }
  objArg.colorValue = nowColor;
  objArg.returnOk = onReturnOk;

  openColorDialog(objArg);

  function onReturnOk(rtn){

    //戻り値による処理
    if(rtn && rtn.isOk){
      //m_userColorsの初期化
      for(var i=0; i<m_userColors.length; i++){
        m_userColors[i] = '';
      }

      //作成した色をセット
      for(var i=0; i<rtn.userColors.length; i++){
        m_userColors[i] = rtn.userColors[i]
      }
      
      //色用プロパティテーブルにセット
      getPropertyEditElement(strTypeId).value = rtn.colorValue;

      //onChangeColorProperty('fld_' + strTypeId, rtn.colorValue);
      onChangeColorProperty_frame('fld_' + strTypeId, rtn.colorValue);
    }
  }
}

/**
 * インクルードするJavaScriptファイルの編集を行う
 * @param  :
 * @return :
 */
function doEditJsfile_frame(){
  JsFileArguments.prototype = CommonArguments.instance;

  var propertyId = 'jsfilename';

  //パラメータ作成
  var arg = new JsFileArguments();
  
  openJsfileDialog(arg);
  
  /** Cell */
  function JsFileArguments() {
    this.doOK = doOK;
    this.doCancel      = function () {};
    this.windowTitle  = getLiteral('dialog.jsfileedit.title');
    this.listTitle    = getLiteral('dialog.jsfileedit.listtitle');
    this.listWidth = 300;
    this.optionItems = getDataSet(m_selection.front).getProperty(propertyId);
    this.optionEdits    = [
      this.defineOptionEdit('filename',  getLiteral('dialog.jsfileedit.jsfilepath'),  'text', {'size':50})
    ];
    this.createOption = createOption;
    this.createEditValues = createEditValues;

    /*
     * 最初と、追加ボタン,置換ボタンを押したときに呼ばれる
     * @param obj 入力された内容オブジェクト {変数名:<値> , ... }
     * @param mode 最初'initialize' 追加のとき'add' 置換のとき'replace'
     * @existingList 実行後に追加されたもの以外に存在するもの [{value:<value>,text:<text>}, ...]
     * @return リストに追加するオプション {text:<リストに表示するテキスト>, value:<その値>}
     */
    function createOption(obj, mode, existingList) {

      //名前が空のときエラーとする
      if(obj.filename == '') {
        this.alert(getMessage('A0030'));
        return null;
      }

      //同一の名前があればエラーとする
      for(var listIndex = 0; listIndex < existingList.length; listIndex++){
        var opt = existingList[listIndex].value;
        if(opt == obj.filename){
          this.alert(getMessage('A0031'));
          return null;
        }
      }

      return {text:obj.filename, value:obj.filename};
    }
    
    /*
     * リスト内の１つが選択されたときに呼ばれる
     * @param opt 選ばれた値
     * @return 入力する場所に表示する内容オブジェクト {変数名:<値> , ... }
     */
    function createEditValues(opt) {
      return {filename:opt};
    }
    
    function doOK() {
      if(pagePropertyTableOwner) {
        var rtn = {};
        rtn.optionItems = [];
        var list = this.getListElement();
        for(var i=0; i < list.length; i++){
          rtn.optionItems[rtn.optionItems.length] = list.options[i].value;
        }

        var oldval = pagePropertyTableOwner.getValue('page.jsfilename');
        var newval = new Array();
        for(var i in rtn.optionItems) {
          newval[i] = rtn.optionItems[i];
        }
        if(oldval.toString() != newval.toString()) {
          var cmd = new FramePageUpdateValueCommand(pagePropertyTableOwner, 'page.jsfilename', oldval, newval);
          m_undoManager.execute(cmd);
        }
      }
    }
  }
}

/**
 * インクルードするJavaScriptファイルの編集を行う
 * @param  :
 * @return :
 */
function doEditMeta_frame(){
  MetaArguments.prototype = CommonArguments.instance;

  var propertyId = 'meta';

  //パラメータ作成
  var arg = new MetaArguments();
  
  openMetaDialog(arg);

  /** パラメータ */
  function MetaArguments() {
    this.doOK = doOK;
    this.doCancel      = function () {};
    this.windowTitle  = getLiteral('dialog.metaedit.title');
    this.listTitle    = getLiteral('dialog.metaedit.listtitle');
    this.listWidth = 300;
    this.optionItems = getDataSet(m_selection.front).getProperty(propertyId);
    this.optionEdits    = [
      this.defineOptionEdit('attrname',     getLiteral('dialog.metaedit.attrname'), 'radio', {'http-equiv':'http-equiv', 'name':'name'}),
      this.defineOptionEdit('attrvalue',    getLiteral('dialog.metaedit.attrval'),  'text', {'size':50}),
      this.defineOptionEdit('contentvalue', getLiteral('dialog.metaedit.value'),    'text', {'size':50})
    ];
    this.createOption = createOption;
    this.createEditValues = createEditValues;

    function createOption(obj, mode, existingList) {
      var optiontext = '(' + obj.attrname + ')' + obj.attrvalue + '::' + obj.contentvalue;
      var optionvalue = '(' + obj.attrname + ')' + this.toSaveValue(obj.attrvalue) + '::' + obj.contentvalue;
      return {text:optiontext, value:optionvalue};
    }

    function createEditValues(opt) {
      var pos = opt.indexOf('::');
      if(pos == -1) {
        return {attrname:'http-equiv', attrvalue:opt, contentvalue:opt};
      }
      var attribute = opt.substring(0, pos);
      var contentvalue = opt.substring(pos + 2);
      var pos1 = attribute.indexOf('(');
      var pos2 = attribute.indexOf(')');
      if(pos1 != 0 || pos2 == -1) {
        return {attrname:'http-equiv', attrvalue:attribute, contentvalue:contentvalue};
      }
      var attrname = attribute.substring(1, pos2);
      var attrvalue = this.toDispValue(attribute.substring(pos2 + 1));
      return {attrname:attrname, attrvalue:attrvalue, contentvalue:contentvalue};
    }
    
    function doOK() {

      if(pagePropertyTableOwner) {

        var rtn = {};
        rtn.optionItems = [];
        var list = this.getListElement();
        for(var i=0; i < list.length; i++){
          rtn.optionItems[rtn.optionItems.length] = list.options[i].value;
        }
        
        var oldval = pagePropertyTableOwner.getValue('page.meta');
        var newval = new Array();
        for(var i in rtn.optionItems) {
          newval[i] = rtn.optionItems[i];
        }
        if(oldval.toString() != newval.toString()) {
          var cmd = new FramePageUpdateValueCommand(pagePropertyTableOwner, 'page.meta', oldval, newval);
          m_undoManager.execute(cmd);
        }
      }
    }
  }
}

/**
 * 各種イベントの編集を行う
 * @param  :strType 文字型 イベント名称文字列
 * @return :
 */
function doEditEvent_frame(strType){
  var argObj = new Object();
  argObj.jsfilenames = new Array();
  var jsfiles = getDataSet(ELEMENTID_FIRSTFORM).getProperty('jsfilename');
  for(var i in jsfiles){
    argObj.jsfilenames[i] = jsfiles[i];
  }
  argObj.sourceCode  = getDataSet(m_selection.front).getProperty(strType);
  argObj.returnOk = onReturnOk;

  // 2003.05.29 読み込んだ項目定義を渡す(未読み込み時は空の配列)
  if(!m_itemDefinitionObject.empty){
    argObj.itemDefine  = m_itemDefinitionObject.itemDefineList;
  }else{
    argObj.itemDefine  = new Array();
  }

  var rtn = openEventDialog(argObj);

  function onReturnOk(rtn){

    if(rtn.isOk) {
      var cmdjs = null;
      var cmdev = null;

      // イベント
      if(pagePropertyTableOwner) {
        
        var oldval = pagePropertyTableOwner.getValue(strType);
        var newval = rtn.sourceCode;
        if(oldval.toString() != newval.toString()) {
          cmdev = new FramePageUpdateValueCommand(pagePropertyTableOwner, strType, oldval, newval);
        }
      }
            
      // jsファイル
      if(pagePropertyTableOwner) {
        var oldval = pagePropertyTableOwner.getValue('page.jsfilename');
        var newval = new Array();
        for(var i in rtn.jsfilenames) {
          newval[i] = rtn.jsfilenames[i];
        }
        if(oldval.toString() != newval.toString()) {
          cmdjs = new FramePageUpdateValueCommand(pagePropertyTableOwner, 'page.jsfilename', oldval, newval);
        }
      }

      // コマンドを実行
      if(cmdjs) {
        if(cmdev) {
          var cmd = new UndoableCommandSet();
          cmd.add(cmdjs);
          cmd.add(cmdev);
          cmd.presentationName = '';
          m_undoManager.execute(cmd);
        } else {
          cmdjs.presentationName = '';
          m_undoManager.execute(cmdjs);
        }
      } else if(cmdev) {
          cmdev.presentationName = '';
        m_undoManager.execute(cmdev);
      }

      //プロパティテーブルにセット
      getPropertyEditElement(strType).value = rtn.sourceCode;
    }
  }
}

/**
 * ファイル名、URLの編集を行う
 * @param  :strType  文字型 イベント名称日本語文字列
            strLabel 文字型 イベント名称日本語文字列
 * @return :
 */
function doEditLongString_frame(strType, strLabel){
  var argObj = new Object();
  argObj.propertyValue = getPropertyEditElement(strType).value;
  argObj.propertyName  = strLabel;
  argObj.returnOk = onReturnOk;
  argObj.target = currentPropertyTableOwner;
  argObj.objectId = getTargetObjectId(argObj.target);
  var rtn = openLongStringDialog(argObj);

  function onReturnOk(rtn){

    if(rtn.isOk) {
      if(m_rootFramePage.getObject(argObj.target.id) == null) {
        alert(getMessage('A0003', new Array(argObj.objectId)));
        return;
      }
        
      var oldval = argObj.target.getValue(strType);
      var newval = rtn.propertyValue;
      if(oldval.toString() != newval.toString()) {
        var cmd = new FramePageUpdateValueCommand(argObj.target, strType, oldval, newval);
        m_undoManager.execute(cmd);
      }

      //プロパティテーブルにセット
      if(argObj.target == currentPropertyTableOwner) {
        getPropertyEditElement(strType).value = rtn.propertyValue;
      }
    }
  }
}

// 一覧取得のための関数
function getTargetObjectId(obj) {
  if(obj.pageItem) {
    return obj.pageItem.pageItemId;
  } else {
    var p = obj.parent;
    var index = 0;
    for(var i in p.children) {
      if(p.children[i].isBorder) {
        continue;
      }
      index++;
      if(p.children[i] == obj) {
        return p.pageItem.pageItemId + '[' + index + ']';
      }
    }
  }
  return obj.id;
}

function createFramePageSaveHtml(_page) {
  var html = '';

  for(var pageItemId in _page.pageItems) {
    var pageItem = _page.pageItems[pageItemId];
    html += strInput('PAGELAYOUT.PAGEITEMID',       pageItemId);
    html += strInput('PAGELAYOUT.PAGEITEMTYPEID',   'form');
    html += strInput('PAGELAYOUT.PARENTPAGEITEMID', pageItem.parentPageItemId);
    
    // 2003.09.04 タグ対応
    pageItem = makeSavePageItem(pageItem);
    makeTagProperties(pageItem, PROPERTYIDPREFIX_TAG);
    for(var propertyId in pageItem.properties) {
      var property = pageItem.properties[propertyId];

      if(property.value && property.value != '') {
        html += strInput('PAGEITEMPROPERTY.PAGEITEMID', pageItemId);
        html += strInput('PAGEITEMPROPERTY.PROPERTYID', propertyId);
        html += strInput('PAGEITEMPROPERTY.VALUE',      property.value);
        html += strInput('PAGEITEMPROPERTY.ENABLE',     '0');
      }
    }
  }
  return html;
}

function makeSavePageItem(pageItem) {
  var savePageItem = new Object();
  savePageItem.parentPageItemId = pageItem.parentPageItemId;
  savePageItem.properties = new Object();
  for(var propertyId in pageItem.properties) {
    var property = pageItem.properties[propertyId];

    if(property.value && property.value != '') {
      savePageItem.properties[propertyId] = new Object();
      savePageItem.properties[propertyId].value = quotchange(property.value);
    }

    if(property.values && property.values.length > 0) {
      for(var i in property.values) {
        if(property.values[i] != '') {
          savePageItem.properties[propertyId + '-' + i] = new Object();
          savePageItem.properties[propertyId + '-' + i].value = quotchange(property.values[i]);
        }
      }
    }
  }
  for(var i in pageItem.frames) {
    var frame = pageItem.frames[i];
    for(var framePropertyId in frame) {
      if(framePropertyId == 'pageItem') {
        continue;
      }
      if(frame[framePropertyId] != '') {
        savePageItem.properties[framePropertyId + '-' + i] = new Object();
        savePageItem.properties[framePropertyId + '-' + i].value = quotchange(frame[framePropertyId]);
      }
    }
  }
  return savePageItem;
}

function strInput(_name, _value) {
  return '<input type="hidden" name="' + _name + '" value="' + _value + '">\n';
}

//


/**
 * 「保存」ボタン押下時の処理
 * @param  :
 * @return :
 */
function doCommandSave_frame(){
  // 新規のとき
  if(m_monitorEditStatus == 0) {
    doCommandSaveAs_frame();
    return;
  }
  window.saveObject = new SaveFramePageObject();
  window.saveObject.saveUpdate();
}

/**
 *「別名で保存」ボタン押下時の処理
 * @param  :
 * @return :
 */
function doCommandSaveAs_frame(){
  //カスタマイズ時使用不可
  if(m_monitorEditStatus == 2) return;
  window.saveObject = new SaveFramePageObject();
  window.saveObject.saveNew();
}

/**
 * 「保存」、「別名で保存」時に使用するデータを作成、保持するオブジェクトを生成する
 * @ param  :
 * @ return :
 */
function SaveFramePageObject() {
  // 保存値
  this.saveInfo = new Object();
  this.saveInfo.pageId    = '';
  this.saveInfo.pageName  = '';
  this.saveInfo.packageId = '';
  this.saveInfo.langId    = '';
  this.saveInfo.pageInfos = '';
  //2003/08/18 timestampValue追加(更新チェック用)
  this.saveInfo.timestampValue = '';

  // 重複チェック true:する false:しない
  this.uniqueCheckFlg = true;

  // 保存中メッセージウィンドウ
  this.savingMessage = null;

  // 新規保存
  SaveFramePageObject.prototype.saveNew = function() {
    if(this.savingMessage) {
      this.savingMessage.onblur = '';
      window.focus();
      this.savingMessage.close();
      this.savingMessage = null;
    }
    this.uniqueCheckFlg = true;
    this.saveInfo.isOk = false;
    //セッションからDISPLANGID取得
    this.saveInfo.dispLangId = getSessionData('DISPLANGID');

    openSaveAsDialog();
  }

  // 上書き保存
  SaveFramePageObject.prototype.saveUpdate = function() {
    if(this.savingMessage) {
      this.savingMessage.onblur = '';
      this.savingMessage.close();
      this.savingMessage = null;
    }
    this.uniqueCheckFlg = false;
    var rtn = new Object();
    rtn.pageId = m_loadPageVariable.pageId;
    //言語IDをpageIdから取得
    var tmpPos = rtn.pageId.lastIndexOf('_');
    if(tmpPos >= 0) {
      rtn.langId = rtn.pageId.substr(parseInt(tmpPos) + 1);
    }else{
      rtn.langId = '';
    }
    //rtn.pageName  = m_loadPageVariable.pageName[rtn.langId].value;
    rtn.pageName  = m_loadPageVariable.getPageName(rtn.langId);
    rtn.packageId = m_loadPageVariable.packageId;
    //ページ情報セット
    this.saveInfo.pageId    = rtn.pageId;
    this.saveInfo.pageName  = rtn.pageName;
    this.saveInfo.packageId = rtn.packageId;
    this.saveInfo.langId    = rtn.langId;
    this.saveInfo.timestampValue = m_loadPageVariable.timestampValue;

    this.savingMessage = openSavingDialog();
  }

  // submitする内容
  SaveFramePageObject.prototype.innerHTML = function() {
    if(parseInt(m_monitorEditStatus) == 2){
      var tmpProcessId = PROCESSID_CUSTOMPAGESAVE;
    }else{
      var tmpProcessId = PROCESSID_PAGESAVE;
    }

    var innerHtml = '';
    innerHtml += strInput('PROCESSID',   tmpProcessId);
    innerHtml += strInput('JSPID',       JSPID_SAVECOMPLETE);
    innerHtml += strInput('ERRORJSPID',  JSPID_SAVECOMPLETE);
    innerHtml += strInput('PROCESSMODE', '3');

    if(m_threadId != ''){
      innerHtml += '<input type="hidden" name="THREADID" value="' + m_threadId + '">';
    }

    //プロセスID選択時、作成モード設定
    var tmpFieldIdSourceClass = 0;
    var tmpFieldIdSource = '';
    if(m_itemDefinitionObject.empty == false){
      tmpFieldIdSource = m_itemDefinitionObject.itemDefine;
      tmpFieldIdSourceClass = 1;
    }
    innerHtml += strInput('STATEGROUP.FIELDIDSOURCE',      tmpFieldIdSource);
    innerHtml += strInput('STATEGROUP.FIELDIDSOURCECLASS', tmpFieldIdSourceClass);
    
    innerHtml += strInput('DELETEKEYS.PAGEID', this.saveInfo.pageId);
    innerHtml += strInput('DELETEKEYS.TIMESTAMPVALUE', this.saveInfo.timestampValue);

    innerHtml += strInput('PAGE.PAGEID', this.saveInfo.pageId);
    innerHtml += strInput('PAGE.PACKAGEID', this.saveInfo.packageId);
    innerHtml += strInput('PAGE.PAGECLASS', '1');

    innerHtml += strInput('PAGENAME.DISPLANGID', this.saveInfo.langId);
    innerHtml += strInput('PAGENAME.PROPERTYID', 'OFFICIALNAME');
    innerHtml += strInput('PAGENAME.NAMEVALUE', this.saveInfo.pageName);
     
    innerHtml += this.strSubmit;
    
    return innerHtml;
  }

  //「保存中」ウィンドウのinitで実行される関数
  SaveFramePageObject.prototype.createEditPageHtml = function() {

    //正常変換後
    this.strSubmit = createFramePageSaveHtml(m_loadPageVariable);
    return 1;

  }

  // 保存完了時に呼ばれるメソッド
  SaveFramePageObject.prototype.complete = function(newTimestampValue) {

    if(m_monitorEditStatus != 2) {

      //画面のステータス設定(更新)
      m_monitorEditStatus = 1;
      m_monitorId         = this.saveInfo.pageId;
      m_moitorName        = this.saveInfo.pageName;
      m_monitorModeString = getLiteral('editormode.edit');

      m_loadPageVariable.pageId    = this.saveInfo.pageId;
      m_loadPageVariable.packageId = this.saveInfo.packageId;
      m_loadPageVariable.timestampValue = newTimestampValue;

      //読込時とは異なる言語IDで保存した時の対処
      try{
        m_loadPageVariable.pageName[this.saveInfo.langId].value = this.saveInfo.pageName;
      }catch(e){
        m_loadPageVariable.pageName[this.saveInfo.langId] = new Object();
        m_loadPageVariable.pageName[this.saveInfo.langId].value = this.saveInfo.pageName;
      }
      m_loadPageVariable.editStatus = '1';

    }

    //画面にステータス表示
    setPropertyMonitorStatus(m_monitorId, m_moitorName, m_monitorModeString);
  }
}

/**
 * コマンド
 */
function FramePageUpdateValueCommand(_target, _id, _oldval, _newval, _cancelExecute) {
  this.arg = new Object();
  this.arg.target = _target;
  this.arg.targetId = _target.id;
  this.arg.id = _id;
  this.arg.oldval = _oldval;
  this.arg.newval = _newval;
  
  FramePageUpdateValueCommand.prototype.execute = function() {
    if(_cancelExecute) {
      return;
    }
    this.arg.target.setValue(this.arg.id, this.arg.newval);
  }

  FramePageUpdateValueCommand.prototype.undo = function() {
    //m_operation.currentSelection = null;
    this.arg.target = m_rootFramePage.getObject(this.arg.targetId);
    if(!this.arg.target) {
      alert('Undoできませんでした。' + this.arg.targetId);
      return;
    }
    this.arg.target.setValue(this.arg.id, this.arg.oldval);
    drawFramePropertyEdit(m_rootFramePage, 'm_rootFramePage');
    drawFramePropertyEdit(m_operation.currentSelection, 'm_operation.currentSelection');
  }

  FramePageUpdateValueCommand.prototype.redo = function() {
    //m_operation.currentSelection = null;
    this.arg.target = m_rootFramePage.getObject(this.arg.targetId);
    if(!this.arg.target) {
      alert('Redoできませんでした。' + this.arg.targetId);
      return;
    }
    this.arg.target.setValue(this.arg.id, this.arg.newval);
    drawFramePropertyEdit(m_rootFramePage, 'm_rootFramePage');
    drawFramePropertyEdit(m_operation.currentSelection, 'm_operation.currentSelection');
  }
}
