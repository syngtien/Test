/*
 * ヘルプ画面用ライブラリ
 * ヘルプ画面ページはこのjsファイルをインクルードすること。
 * このファイルの前にcommonutil.js, common.jsをインクルードすること。
 */

/** 呼び元画面のIDのセット先テキストボックスのID */
var destIdfield = "";
/** 呼び元画面のIDのセット先テキストボックスのID */
var destIdfieldSecond = "";
/** 呼び元画面のIDテキストボックスのID配列 */
var destIdfields = "";

/** 呼び元画面の名称のセット先テキストボックスのID */
var destNamefield = "";
/** 呼び元画面の名称のセット先テキストボックスのID */
var destNamefieldSecond = "";
/** 呼び元画面の名称テキストボックスのID配列 */
var destNamefields = "";

/** セットする名称のプロパティID */
var destNamepropaty = "";

/** セットする2つ目の名称のプロパティID */
var destNamepropatySecond = "";

//var locked = false;
//alert(window.opener);
if (window.opener && !window.opener.closed && window.opener.getIdFieldId){
	destIdfield = window.opener.getIdFieldId();
	destNamefield = window.opener.getNameFieldId();
	destNamepropaty = window.opener.getNamePropertyId();

	destIdfieldSecond = window.opener.getIdFieldIdSecond();
	destNamefieldSecond = window.opener.getNameFieldIdSecond();
	destNamepropatySecond = window.opener.getNamePropertyIdSecond();

	destIdfields = window.opener.getIdFieldIds();
	if (!isEmpty(destIdfields)) {
		if (isEmpty(destIdfields[0])) {
			destIdfield = "";
		} else {
			destIdfield = destIdfields[0];
		}
		if (destIdfields.length == 2 || isEmpty(destIdfields[1])) {
			destIdfieldSecond = "";
		} else {
			destIdfieldSecond = destIdfields[1];
		}
	}
	destNamefields = window.opener.getNameFieldIds();
	if (!isEmpty(destNamefields)) {
		var len = destNamefields.length / 2; //必ず割り切れるはず
		if (isEmpty(destNamefields[0])) {
			destNamefield = "";
			destNamepropaty = "";
		} else {
			destNamefield = destNamefields[0];
			destNamepropaty = "OFFICIALNAME";
		}
		if (len == 1 || isEmpty(destNamefields[1])) {
			destNamefieldSecond = "";
			destNamepropatySecond = "";
		} else {
			destNamefieldSecond = destNamefields[1];
			destNamepropatySecond = "OFFICIALNAME";
		}
	}
}


/* 
 * 呼び元の画面の該当箇所にデータ（IDと名称）をセットする。
 * 採用する名称プロパティIDが無い場合はofficialNameを採用する。
 * @param マスタのID
 * @param マスタの名称配列
 *            引数の指定は以下のように行う。
 *            new Array(propatyid, propatyid,propatyid･･･ , namevalue, namevalue･･･)
 *            配列の前半に名称のプロパティIDを入れる。後半に具体的な名称文字列を入れる。
 *            プロパティIDと名称文字列の個数は同じになっていることを前提とする。
 */
function setDataToOpener(id, names){
	if(!window.opener || window.opener.closed) {
		//既にopenerが閉じられていると思われる場合
		closeWindow();
		return;
	}
	if(!isEmpty(destIdfield)){
		opener.setValueById(destIdfield, id);
	}
	//opener.window.document.getElementById(destIdfield).value = id;
	//getFieldByIdWithDocument(destIdfield, opener.window.document).value = id;

	//alert(typeof(names));
	//プロパティIDがない または 引数の名称配列がない または セット先のテキストボックスのIDがない
	//場合は、名称をセットしない。
	if(!isEmpty(destNamepropaty) && !isEmpty(names) && !isEmpty(destNamefield)){
		var i=0;
		var len = names.length / 2; //必ず割り切れるはず
		var propatyid = "";
		//呼び元で指定されたプロパティIDを探して、あればそれに該当する名称を呼び元にセットする
		for (i=0; i<len;i++){
			if(destNamepropaty == names[i]){
				opener.setValueById(destNamefield, names[i + len]);
				//opener.window.document.getElementById(destNamefield).value = names[i + len];
				//getFieldByIdWithDocument(destNamefield, opener.window.document).value = names[i + len];
			}
		}
	}
//	opener.unlock();

   closeWindow();
}

/* 
 * 呼び元の画面の該当箇所にデータ（IDと名称）をセットする
 * 採用する名称プロパティIDが無い場合は名称のセットはしない。
 * @param マスタの1つ目のID
 * @param マスタの2つ目のID
 * @param マスタの1つ目の名称配列 
 *            引数の指定は以下のように行う。
 *            new Array(propatyid, propatyid,propatyid･･･ , namevalue, namevalue･･･)
 *            配列の前半に名称のプロパティIDを入れる。後半に具体的な名称文字列を入れる。
 *            プロパティIDと名称文字列の個数は同じになっていることを前提とする。
 * @param マスタの2つ目の名称配列
 *
 */
function setDataToOpenerTwoIds(firstId, secondId, firstNames, secondNames){
	if(!window.opener || window.opener.closed) {
		//既にopenerが閉じられていると思われる場合
		closeWindow();
		return;
	}
	if(!isEmpty(destIdfield)){
		opener.setValueById(destIdfield, firstId);
	}
	if(!isEmpty(destIdfieldSecond)){
		opener.setValueById(destIdfieldSecond, secondId);
	}
	//opener.window.document.getElementById(destIdfield).value = firstId;
	//opener.window.document.getElementById(destIdfieldSecond).value = secondId;
	//getFieldByIdWithDocument(destIdfield, opener.window.document).value = firstId;
	//getFieldByIdWithDocument(destIdfieldSecond, opener.window.document).value = secondId;

	var i=0;
	var len = 0;
	//alert(typeof(firstNames));	alert(typeof(secondNames));

	//alert(destNamefield);
	if(!isEmpty(destNamepropaty) && !isEmpty(firstNames) && !isEmpty(destNamefield)){ 
		len = firstNames.length / 2; //必ず割り切れるはず
		//alert(firstNames.length); alert(len);
		//alert(destNamepropaty);

		//呼び元で指定されたプロパティIDを探して、あればそれに該当する名称を呼び元にセットする
		for (i=0; i<len;i++){
			if(destNamepropaty == firstNames[i]){
				opener.setValueById(destNamefield, firstNames[i + len]);
				//opener.window.document.getElementById(destNamefield).value =  firstNames[i + len];
				//getFieldByIdWithDocument(destNamefield, opener.window.document).value = firstNames[i + len];
			}
		}
	}

	if(!isEmpty(destNamepropatySecond) && !isEmpty(secondNames) && !isEmpty(destNamefieldSecond)){ 
		len = secondNames.length / 2; //必ず割り切れるはず
		//alert(secondNames.length); alert(len);
		//alert(destNamepropatySecond);
		for (i=0; i<len;i++){
			if(destNamepropatySecond == secondNames[i]){
				opener.setValueById(destNamefieldSecond, secondNames[i + len]);
				//opener.window.document.getElementById(destNamefieldSecond).value =  secondNames[i + len];
				//getFieldByIdWithDocument(destNamefieldSecond, opener.window.document).value = secondNames[i + len];
			}
		}
	}

//	opener.unlock();

   closeWindow();
}

/* 
 * 呼び元の画面の該当箇所にデータ（IDと名称）をセットする
 * 採用する名称プロパティIDが無い場合は名称のセットはしない。
 * @param マスタのID配列
 *            引数の指定は以下のように行う。
 *            new Array(propatyid, propatyid,propatyid･･･ , value, value･･･)
 *            配列の前半に名称のプロパティIDを入れる。後半に具体的な値を入れる。
 *            プロパティIDと値の個数は同じになっていることを前提とする。
 * @param マスタの名称配列 
 *            引数の指定は以下のように行う。
 *            new Array(propatyid, propatyid,propatyid･･･ , namevalue, namevalue･･･)
 *            配列の前半に名称のプロパティIDを入れる。後半に具体的な名称値を入れる。
 *            プロパティIDと名称値の個数は同じになっていることを前提とする。
 */
function setDataToOpenerMultiIds(fieldIds, nameIds){
	if(!window.opener || window.opener.closed) {
		//既にopenerが閉じられていると思われる場合
		closeWindow();
		return;
	}
	var idLength = fieldIds.length / 2; //必ず割り切れるはず
	if (!isEmpty(destIdfields)) {
		var i=0;
		var j=0;
		var len = destIdfields.length / 2; //必ず割り切れるはず
		for (i=0; i < len; i++) {
			for (j=0; j < idLength; j++) {
				if (destIdfields[len+i] == fieldIds[j]) {
					opener.setValueById(destIdfields[i], fieldIds[idLength+j]);
					j = fieldIds.length - 1;
				}
			}
			if (j != fieldIds.length) {
				alert("Can not find requested idProperty(" +
				destIdfields[len+i] +
				").\nThis error may be caused by openHelp() definition.");
			}
		}
	} else {
		// 個数限定呼出方法でヘルプ画面が開かれているため、
		// 旧来の方式で設定を行う.(名称は、1つ目OFFICIALNAME,1つ目SHORTNAME,
		// 2つ目OFFICIALNAME,2つ目SHORTNAMEとみなす)
		var len = nameIds.length / 2; //必ず割り切れるはず
		var firstNames = "";
		if (len == 1) {
			firstNames = new Array("OFFICIALNAME", "SHORTNAME",
				nameIds[len], nameIds[len]);
		} else {
			firstNames = new Array("OFFICIALNAME", "SHORTNAME",
				nameIds[len], nameIds[len+1]);
		}
		if (len >= 4) {
			var secondNames = new Array("OFFICIALNAME", "SHORTNAME",
				nameIds[len+2], nameIds[len+3]);
			setDataToOpenerTwoIds(fieldIds[idLength], fieldIds[idLength + 1],
				firstNames, secondNames);
		} else {
			setDataToOpener(fieldIds[idLength], firstNames);
		}
		return;
	}
	
	var i=0;
	var j=0;
	var len = 0;
	if (!isEmpty(nameIds) && !isEmpty(destNamefields)){ 
		len = destNamefields.length / 2; //必ず割り切れるはず
		var nameLength = nameIds.length / 2; //必ず割り切れるはず

		// 呼び元で指定されたプロパティIDを探して、
		// あればそれに該当する名称を呼び元にセットする
		for (i=0; i < len; i++) {
			for (j=0; j < nameLength; j++) {
				if (destNamefields[len+i] == nameIds[j]) {
					opener.setValueById(destNamefields[i], nameIds[nameLength+j]);
					j = nameIds.length - 1;
				}
			}
			if (j != nameIds.length) {
				alert("Can not find requested nameProperty(" +
				destNamefields[len+i] +
				").\nThis error may be caused by openHelp() definition.");
			}
		}
	}

	closeWindow();
}

/**
 * formobj上のテーブル一覧に表示されているチェックボックスにチェックした行のidFiledNameとdataFieldName
 * をそれぞれカンマ区切り文字列にして、呼び元のフィールドにセットし、自画面を閉じる。
 * @param formobj フォームオブジェクト
 * @param checkboxName チェックボックスのname
 * @param idFiledName IDとして値を取得するフィールドのname
 * @param dataFieldName データとして値を取得するフィールドのname
 */
function setDataToOpenerMultiple(formobj, checkboxName, idFiledName, dataFieldName, delimiter){
	setDataToOpenerMultipleTwoIds(formobj, checkboxName, idFiledName, '', dataFieldName, '', delimiter);
}

function setDataToOpenerMultipleTwoIds(formobj, checkboxName, idFiledName
	     , secondIdFiledName, dataFieldName, secondDataFieldName, delimiter){
/**
	if(!formobj.elements[checkboxName]){
		//window.close();
		alert(checkboxName+" does not exist.");
		return;
	}

	if(!isEmpty(idFiledName) && !formobj.elements[idFiledName]){
		//window.close();
		alert(idFiledName+" does not exist.");
		return;
	}
	
	if(!isEmpty(secondIdFiledName) && !formobj.elements[secondIdFiledName]){
		//window.close();
		alert(secondIdFiledName+" does not exist.");
		return;
	}
	
	if(!isEmpty(dataFieldName) && !formobj.elements[dataFieldName]){
		//window.close();
		alert(dataFieldName+" does not exist.");
		return;
	}

	if(!isEmpty(secondDataFieldName) && !formobj.elements[secondDataFieldName]){
		//window.close();
		alert(secondDataFieldName+" does not exist.");
		return;
	}
 */

	var delim = ',';
	if(!isEmpty(delimiter)){
		delim = delimiter;
	}
	var idstr='';	var datastr='';
	var idstr2=''; var datastr2='';
	
	var listcount = 0;
	
	if(formobj.elements[checkboxName]){
		if(formobj.elements[checkboxName].length){    	
		  listcount=formobj.elements[checkboxName].length;
		}else{
		  listcount=1;
		}
	}
	     	
	var idfirst = true;	var datafirst = true;
	var idfirst2 = true; var datafirst2 = true;
	//取得元フィールドのnameと入れ先フィールドのnameが正しければ、文字列をつくる
	var idnameOk=(!isEmpty(idFiledName) && !isEmpty(destIdfield));
	var idname2Ok=(!isEmpty(secondIdFiledName) && !isEmpty(destIdfieldSecond));
	var datanameOk=(!isEmpty(dataFieldName) && !isEmpty(destNamefield));
	var dataname2Ok=(!isEmpty(secondDataFieldName) && !isEmpty(destNamefieldSecond));
	     	
	var idmap = new Object();var idmap2 = new Object();
	var namemap = new Object();var namemap2 = new Object();
	     	
	//1つでも正しければ、全件走査して文字列を作る
	if(idnameOk || idname2Ok || datanameOk || dataname2Ok){
		//チェックボックス分ループしてカンマ区切り文字列をつくる
		for(var i=1;i<=listcount;i++){
			if(document.getElementById(checkboxName+'_'+i+'_check')){
		  	if(document.getElementById(checkboxName+'_'+i+'_check').checked){
		  		if(idnameOk){
		  			var val = document.getElementById(idFiledName+'_'+i).value;
		  			//alert(idmap[val]);
		  			if(!idmap[val]){
			  			if(!idfirst){
			  				idstr += delim;
			  			}		  				
		  				idfirst = false;	
		    			idstr += val;
		  				idmap[val]=true;
		  			}
		  			//alert(document.getElementById(idFiledName+'_'+i).value);
		    	}
		    	if(datanameOk){
		    		var nameval = document.getElementById(dataFieldName+'_'+i).value; 
		    		if(!namemap[nameval]){
			    		if(!datafirst){
			  				datastr += delim;
			  			}
			  			datafirst = false;
			      	datastr += nameval;
		    			namemap[nameval]=true;
		    		}
		    		//alert(document.getElementById(dataFieldName+'_'+i).value);
		     	}
		  		
		  		if(idname2Ok){
		  			var val2 = document.getElementById(secondIdFiledName+'_'+i).value;
		  			if(!idmap2[val2]){
			  			if(!idfirst2){
			  				idstr2 += delim;
			  			}
			  			idfirst2 = false;
			    		idstr2 += val2;
		  				idmap2[val2]=true;
		  			}
		  			//alert(document.getElementById(secondIdFiledName+'_'+i).value);
		    	}
		    	if(dataname2Ok){
		    		var nameval2 = document.getElementById(secondDataFieldName+'_'+i).value;
		    		if(!namemap2[nameval2]){
			    		if(!datafirst2){
			  				datastr2 += delim;
			  			}
			  			datafirst2 = false;
			      	datastr2 += nameval2;
		    			namemap2[nameval2]=true;
		    		}
		    		//alert(document.getElementById(secondDataFieldName+'_'+i).value);
		     	}
				}
			}
		}
	}
	//alert(idstr+ " "+datastr);
	//チェックボックスにチェックされたときのみ、文字列をセットする
	if(!idfirst && idnameOk){
		window.opener.setValueById(destIdfield, idstr);
	}
	
	if(!datafirst && datanameOk){
		window.opener.setValueById(destNamefield, datastr);
	}
	
	if(!idfirst2 && idname2Ok){
		window.opener.setValueById(destIdfieldSecond, idstr2);
	}
	
	if(!datafirst2 && dataname2Ok){
		window.opener.setValueById(destNamefieldSecond, datastr2);
	}
	closeWindow();
}

/* 
 * formobj上の一覧テーブルで、チェックボックスにチェックした行のデータ（IDと名称）を
 * それぞれ区切り文字列にして、呼び元の画面の該当箇所にセットする
 * 採用する名称プロパティIDが無い場合は名称のセットはしない。
 * @param formobj フォームオブジェクト
 * @param checkboxName チェックボックスのname
 * @param fieldIds マスタのID配列
 *            引数の指定は以下のように行う。
 *            new Array(propatyid, propatyid,propatyid･･･ , value, value･･･)
 *            配列の前半に名称のプロパティIDを入れる。後半に具体的な値を入れる。
 *            プロパティIDと値の個数は同じになっていることを前提とする。
 * @param nameIds マスタの名称配列 
 *            引数の指定は以下のように行う。
 *            new Array(propatyid, propatyid,propatyid･･･ , namevalue, namevalue･･･)
 *            配列の前半に名称のプロパティIDを入れる。後半に具体的な名称値を入れる。
 *            プロパティIDと名称値の個数は同じになっていることを前提とする。
 * @param delimiter 区切りに使用する文字
 */
function setDataToOpenerMultipleMultiIds(formobj, checkboxName, fieldIds, nameIds, delimiter){
	var delim = ',';
	if(!isEmpty(delimiter)){
		delim = delimiter;
	}

	// 一覧行数の取得
	var listcount = 0;
	if (formobj.elements[checkboxName]) {
		if (formobj.elements[checkboxName].length) {
		  listcount = formobj.elements[checkboxName].length;
		} else {
		  listcount=1;
		}
	}

	// 値取得用変数の用意
	var idLength = fieldIds.length / 2; //必ず割り切れるはず
	var destFieldValues = new Array(idLength);
	for (i=0; i < idLength; i++) {
		destFieldValues[i] = "";
	}
	var destIdLength = destIdfields.length / 2; //必ず割り切れるはず
	var nameLength = 0;
	var destNameValues = new Array(1);
	var destNameLength = 0
	if (!isEmpty(nameIds) && !isEmpty(destNamefields)) { 
		nameLength = nameIds.length / 2; //必ず割り切れるはず
		destNameValues = new Array(nameLength);
		for (i=0; i < nameLength; i++) {
			destNameValues[i] = "";
		}
		destNameLength = destNamefields.length / 2; //必ず割り切れるはず
	}
	var existChecked = false;

	//一覧の各行をループして区切り文字列をつくる
	for (var i=1; i <= listcount; i++) {
		if (document.getElementById(checkboxName+'_' + i + '_check').checked) {
			existChecked = true;
			var j=0;
			for (j=0; j < idLength; j++) {
				if (!document.getElementById(fieldIds[idLength+j]+'_'+i)) {
					alert("Can not find requested idProperty(" +
					fieldIds[idLength+j] + ").\nThis error may be " +
					"caused by setDataToOpenerMultipleMultiIds().");
					return;
				}
				val = document.getElementById(fieldIds[idLength+j]+'_'+i).value;
				destFieldValues[j] += val;
				destFieldValues[j] += delim;
			}
			// 呼び元で指定されたプロパティIDを探して、
			// あればそれに該当する名称を呼び元にセットする
			for (j=0; j < nameLength; j++) {
				if (!document.getElementById(nameIds[nameLength+j]+'_'+i)) {
					alert("Can not find requested nameProperty(" +
					nameIds[nameLength+j] + ").\nThis error may be " +
					"caused by setDataToOpenerMultipleMultiIds().");
					return;
				}
				val = document.getElementById(nameIds[nameLength+j]+'_'+i).value;
				destNameValues[j] += val;
				destNameValues[j] += delim;
			}
		}
	}
	//チェックボックスにチェックされたときのみ、文字列をセットする
	if(existChecked){
		var i=0;
		var j=0;
		//【F000057】対応 destFieldValuesとdestNameValuesの最後のdelimを取り除く
		for (j=0; j < idLength; j++) {
		  destFieldValues[j] =
					 destFieldValues[j].substring(0, destFieldValues[j].length - 1);
		}
		for (j=0; j < nameLength; j++) {
		  destNameValues[j] =
					 destNameValues[j].substring(0, destNameValues[j].length - 1);
		}
		//【F000057】対応 destFieldValuesとdestNameValuesの最後のdelimを取り除く

		for (i=0; i < destIdLength; i++) {
			for (j=0; j < idLength; j++) {
				if (destIdfields[destIdLength+i] == fieldIds[j]) {
					//【F000057】対応 この部分の処理は上に移動して纏めて実行するように
					//destFieldValues[j] =
					// destFieldValues[j].substring(0, destFieldValues[j].length - 1);
					window.opener.setValueById(destIdfields[i], destFieldValues[j]);
				}
			}
		}
		for (i=0; i < destNameLength; i++) {
			for (j=0; j < nameLength; j++) {
				if (destNamefields[destNameLength+i] == nameIds[j]) {
					//【F000057】対応 この部分の処理は上に移動して纏めて実行するように
					//destNameValues[j] =
					//  destNameValues[j].substring(0, destNameValues[j].length - 1);
					window.opener.setValueById(destNamefields[i],destNameValues[j]);
				}
			}
		}
	}

	closeWindow();
}
