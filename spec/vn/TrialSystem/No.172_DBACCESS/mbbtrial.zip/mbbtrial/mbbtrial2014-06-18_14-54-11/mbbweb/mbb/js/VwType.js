/**
 * VwType
 * 項目タイプ表示（共通）
 */
LAST_MODIFIED('2005.02.08', '1.0.33');

/*
 * 全項目TYPEのTypeObject配列 配列
 */

//TypeObjectの生成
// 2003.05.13 VwMasterDataSet.jsのm_ publicInputTypeArrayから項目タイプを取得に変更

/** ViewObjectのインスタンス or ViewObjectのコンストラクタ */
var m_viewObjects = new Object();

/**
 * ViewObjectを登録する
 */
function registerViewObject(typeid, obj) {
  //obj.isConstructor = true;
  //m_viewObjects[typeid] = obj;
  //@@@
  m_viewObjects[typeid] = new ViewObjectWrapper(typeid, new obj(typeid));
}

/**
 * ViewObjectを取得する.
 * なければ生成する
 */
function getViewObject(typeid) {
  var viewObject = m_viewObjects[typeid];
  if(!viewObject) {
    alert('type "' + typeid + '" is not regstered.');
    return null;
  }
  
  if(viewObject.isConstructor) {
    m_viewObjects[typeid] = new ViewObjectWrapper(typeid, new viewObject());
    viewObject = m_viewObjects[typeid];
    //log.debug('ViewObject constructed.', [typeid]);
  }
  
  return viewObject;
}


/**
 * 各項目TYPE毎のtypeObject実装クラス
 * @param  :strType 文字型 項目TYPE文字列
 * @return :
 */

function ViewObjectWrapper(strType, targetObject){
  //property
  this.type = strType;
  /**/
  if(targetObject) {
    setCustomProperties(targetObject, strType);
  } else {
    alert('???' + strType);
  }
  /**/
  
  this.targetObj = targetObject;
  this.customProperties = targetObject.customProperties;

  //public method
  ViewObjectWrapper.prototype.createPropertyTable   = fnCreatePropertyTable;
  ViewObjectWrapper.prototype.setPropertyTable      = fnSetPropertyTable;
  ViewObjectWrapper.prototype.setDefaultProperty    = fnSetDefaultProperty;
  ViewObjectWrapper.prototype.getPropertiesHtml     = fnGetPropertiesHtml;
  ViewObjectWrapper.prototype.update                = fnUpdate;
  ViewObjectWrapper.prototype.repaint               = fnRepaint;

  //プロパティテーブル作成
  function fnCreatePropertyTable(elementId, cellElementId, dataset){
    var editHtml = dataset.getExtraProperty('editHtml/' + cellElementId);
    if(editHtml == '') {
      var strTblHead = '<table id="fld_createPropTable" border="1" cellspacing="0" cellpadding="0" width="200px" style="table-layout:fixed; font-size:9pt;">';
      if(!dataset) {
        alert('dataset is null!');
      }
      if(!dataset.type) {
        alert('dataset.type is null!');
      }
      var type = dataset.getProperty('type').toLowerCase();
      if(!type) {
        alert('type is null!');
      } else {
        //alert('type :' + type);
      }
      
      function targetCreatePropertyTable(elementId, cellElementId, type){
        propertyEditCreator.prepareElement(elementId, cellElementId, type);
        
        var rtnHTML  = '';

        var prefEdit = pref.editarea[type];
        
        for(var propid in prefEdit.enumerator()) {
          // @@
          var spc = prefEdit.get(propid);
          if(typeof(spc) == 'object') {
            addPropertyName(propid, spc[0]);
            spc = spc[1];
          }
          rtnHTML += propertyEditCreator.getHtml(propid, spc, type);
        }
        return rtnHTML;
      }

      var strTblBody = targetCreatePropertyTable(elementId, cellElementId, type);
      strTblBody += createCustomCheckProperty(elementId, cellElementId, this.targetObj.customProperties, this.targetObj.customPropertiesLiteral);
      
      var strTblFoot = '</table>';
      editHtml = strTblHead + strTblBody + strTblFoot;
      dataset.setExtraProperty('editHtml/' + cellElementId, editHtml);
    }
    
    getDocumentElementById('fld_showPropertyTable_div').innerHTML = editHtml;
    var elstyle = getDocumentElementById('fld_showPropertyTable_div_type').style;
    elstyle.fontSize='0pt';


    // ## カスタマイズ時：全プロパティ非表示時、「プロパティ」以下を全て非表示にする
    if(parseInt(m_monitorEditStatus) == 2){
      var tmpJudgeFlg = false;
      var docNodes = getDocumentElementById('fld_createPropTable').childNodes.item(0).childNodes;
      var childLen = docNodes.length;
      for(var i=0; i<childLen; i++){
        if(docNodes.item(i).style.display != 'none'){
          tmpJudgeFlg = true;
        }
      }
      if(!tmpJudgeFlg){
        getDocumentElementById('fld_property_head_td').style.display           = 'none';
        getDocumentElementById('fld_showPropertyTable_div').style.display      = 'none';
        getDocumentElementById('fld_showPropertyTable_div_type').style.display = 'none';
      }else{
        getDocumentElementById('fld_property_head_td').style.display           = '';
        getDocumentElementById('fld_showPropertyTable_div').style.display      = '';
        getDocumentElementById('fld_showPropertyTable_div_type').style.display = '';
      }

      if(elementId == ELEMENTID_FIRSTFORM) {
        //getDocumentElementById('fld_showPropertyTable_div').style.display = 'none';
      } else {
        //カスタマイズ可能時、disabled解除
        var tmpObjCustomSet = dataset.getCustomizableItems();
        if(tmpObjCustomSet.mobility){
          _setElementAttribute('fld_customize-mobility', 'disabled', false);
        }
        if(tmpObjCustomSet.visibility){
          _setElementAttribute('fld_customize-visibility', 'disabled', false);
        }
        if(tmpObjCustomSet.defaultvalue){
          _setElementAttribute('fld_customize-defaultvalue', 'disabled', false);
        }
        if(tmpObjCustomSet.maxlines){
          _setElementAttribute('fld_customize-maxlines', 'disabled', false);
        }
        getDocumentElementById('fld_showPropertyTable_div').style.display = '';
      }
      
    }
  }

  // 
  function _setElementAttribute(id, attname, value) {
    var element = getDocumentElementById(id);
    if(element && element[attname]) {
      element[attname] = value;
    }
  }

  //デフォルトプロパティセット
  function fnSetDefaultProperty(dataset){
    this.targetObj.setDefaultProperty(dataset);
  }

  //HTML文字列作成
  function fnGetPropertiesHtml(objDs){
    return this.targetObj.getPropertiesHtml(objDs);
  }
  
  function fnUpdate(propertyId, newValue, elementId, dataset, cellElementId, cellDataset, inf) {
    if(this.targetObj.setter && this.targetObj.setter[propertyId]) {
      // タイプ別のsetter
      return this.targetObj.setter[propertyId](newValue, elementId, dataset, cellElementId, cellDataset, inf);

    } else if(this.setter[propertyId]) {
      // 共通のsetter
      return this.setter[propertyId](newValue, elementId, dataset, cellElementId, cellDataset);

    } else {
      if(propertyId.indexOf('customize-') == 0) {
        // カスタマイズ
        if(newValue != 'enabled') {
          if(newValue != 'disabled') {
            return flags('disabled', 'modified');
          }
        }
      }
    }
    return flags(newValue);
  }

  function fnRepaint(elementId, dataset, cellElementId, cellDataset) {
    if(this.targetObj.repaint) {
      return this.targetObj.repaint(elementId, dataset, cellElementId, cellDataset);
    }
    return common_repaint(elementId, dataset, cellElementId, cellDataset);
  }

  this.setter = new Setter();
  function Setter() {
    Setter.prototype.visibility = _visibility;
    Setter.prototype.top = _top;
    Setter.prototype.left = _left;
    Setter.prototype.width = _width;
    Setter.prototype.height = _height;
    Setter.prototype.fieldvalue = _fieldvalue;
    Setter.prototype.fontsize = _fontsize;
    Setter.prototype.fontcolor = _fontcolor;
    Setter.prototype.fontstyle = _fontstyle;
    Setter.prototype.fontweight = _fontweight;
    Setter.prototype.fontfamily = _fontfamily;
    Setter.prototype.underline = _textdecoration;
    Setter.prototype.align = _align;
    Setter.prototype.backgroundcolor = _backgroundcolor;
    Setter.prototype.bordercolor = _bordercolor;
    Setter.prototype.style = _$repaint;

    // 表示
    function _visibility(newValue, elementId, dataset, cellElementId, cellDataset) {
      //非表示チェック時hidden
      
      //newValue = 'visible';
      //if(getDocumentElementById('fld_visibility').checked){
      if(newValue != 'hidden') {
        // @visible newValue = 'visible';
      }
      dataset.setProperty('visibility', newValue);
      
      //z-index保存
      var docNode = getDocumentElementById(elementId + '_span');
      var tmpZindex = docNode.style.zIndex;
      //setOuterHTML(docNode, dataset.getPropertiesHtml());
      setOuterHTML(docNode, getElementHtml(dataset));
      docNode = getDocumentElementById(elementId + '_span');
      docNode.style.zIndex = tmpZindex;
      docNode.style.border = pref.view.get('selectionborder');
      setResizeHandle(elementId);
      
      //カスタマイズ時：表示カスタマイズ自動チェック
      customizedVisibilityChecker(dataset, newValue, elementId);
      
      return flags(newValue, 'updated', 'reconstructed');
    }
    
    // 縦位置
    function _top(newValue, elementId, dataset, cellElementId, cellDataset) {
      if(newValue == '' || parseInt(newValue) < 0 || isNaN(newValue)) newValue = 0;
      newValue = checkElementPosition(parseInt(newValue), false, elementId);
      getDocumentElementById(elementId + '_span').style.top = newValue;

      //カスタマイズ時：移動カスタマイズ自動チェック(設定値変動時のみ)
      if(dataset.getProperty('top') != newValue){
        customizedMobilityChecker(dataset, newValue, dataset.getProperty('left'), elementId);
      }
      return flags(newValue, 'modified');
    }

    // 横位置
    function _left(newValue, elementId, dataset, cellElementId, cellDataset) {
      if(newValue == '' || parseInt(newValue) < 0 || isNaN(newValue)) newValue = 0;
      newValue = checkElementPosition(parseInt(newValue), true, elementId);
      getDocumentElementById(elementId + '_span').style.left = newValue;

      //カスタマイズ時：移動カスタマイズ自動チェック(設定値変動時のみ)
      if(dataset.getProperty('left') != newValue){
        customizedMobilityChecker(dataset, dataset.getProperty('top'), newValue, elementId);
      }
      return flags(newValue, 'modified');
    }
    
    // 幅
    function _width(newValue, elementId, dataset, cellElementId, cellDataset) {
      if(newValue != '' && newValue < 1) {
        newValue = 1;
        getDocumentElementById(elementId).style.width = newValue;
        return flags(newValue, 'resized', 'modified', 'border');
      }
      getDocumentElementById(elementId).style.width = newValue;
      return flags(newValue, 'resized', 'border');
    }
    
    // 高さ
    function _height(newValue, elementId, dataset, cellElementId, cellDataset) {
      if(newValue != '' && newValue < 1) {
        newValue = 1;
        getDocumentElementById(elementId).style.height = newValue;
        return flags(newValue, 'resized', 'modified');
      }
      getDocumentElementById(elementId).style.height = newValue;
      return flags(newValue, 'resized');
    }

    // 値
    function _fieldvalue(newValue, elementId, dataset, cellElementId, cellDataset) {
      getDocumentElementById(elementId).value = newValue;

      // 2003.05.15 mozillaにてinput type="text"使用の項目タイプにおいてvalue設定時にhtml文字列に反映されない問題の暫定対処
      //            DOMのsetAttributeメソッドで強制的にhtml文字列に組み込む
      getDocumentElementById(elementId).setAttribute('value', newValue);

      //カスタマイズ時：カスタマイズ自動チェック
      customizedDefaultValueChecker(dataset, newValue, 'fieldvalue', elementId);
      return flags(newValue);
    }
    
    // 文字のサイズ
    function _fontsize(newValue, elementId, dataset, cellElementId, cellDataset) {
      var val = '';
      if(newValue != '') {
        val = newValue + 'pt';
      }
      getDocumentElementById(elementId).style.fontSize = val;
      return flags(newValue, 'resized');
    }
    
    // 文字の色
    function _fontcolor(newValue, elementId, dataset, cellElementId, cellDataset) {
      setElementStyleFontColor(getDocumentElementById(elementId), newValue);
      return flags(newValue);
    }
    
    // 斜体
    function _fontstyle(newValue, elementId, dataset, cellElementId, cellDataset) {
      //if(getDocumentElementById('fld_fontstyle').checked){
      //  newValue = 'italic';
      //}else{
      //  newValue = '';
      //}
      getDocumentElementById(elementId).style.fontStyle = newValue;
      return flags(newValue);
    }

    // 文字の太さ
    function _fontweight(newValue, elementId, dataset, cellElementId, cellDataset) {
      getDocumentElementById(elementId).style.fontWeight = newValue;
      return flags(newValue, 'resized');
    }

    // フォント名
    function _fontfamily(newValue, elementId, dataset, cellElementId, cellDataset) {
      getDocumentElementById(elementId).style.fontFamily = newValue;
      return flags(newValue, 'resized');
    }

    // 下線
    function _textdecoration(newValue, elementId, dataset, cellElementId, cellDataset) {
      getDocumentElementById(elementId).style.textDecoration = newValue;
      return flags(newValue);
    }
    
    // 水平位置
    function _align(newValue, elementId, dataset, cellElementId, cellDataset) {
      getDocumentElementById(elementId).style.textAlign = newValue;
      return flags(newValue);
    }

    // 背景色
    function _backgroundcolor(newValue, elementId, dataset, cellElementId, cellDataset) {
      if(dataset.getProperty('visibility') != 'hidden'){
        setElementStyleBackgroundColor(getDocumentElementById(elementId), newValue);
      }
      return flags(newValue);
    }

    // 枠線の色
    function _bordercolor(newValue, elementId, dataset, cellElementId, cellDataset) {
      //if(dataset.getProperty('visibility') != 'hidden'){
      //  setElementStyleBackgroundColor(getDocumentElementById(elementId), newValue);
      //}
      setElementStyleBoderColor(getDocumentElementById(elementId), newValue);
      return flags(newValue);
    }
  }
}

/**
 * 複数フラグを保持するオブジェクトを返す
 * @param フラグ 
 */
function flags(_value) {
  var obj = new Object();
  var args = flags.arguments;
  obj.value = _value;
  obj.isFlags = true;
  for(var i = 1; i < args.length; i++) {
    var arg = args[i];
    switch(typeof(arg)) {
    case 'object':
      if(!arg) continue;
      if(arg.isOtherUpdates) {
        delete arg.isOtherUpdates;
        obj.otherUpdates = arg;
      }
      if(arg.flagName) {
        obj[arg.flagName] = arg;
        delete arg.flagName;
      }
      break;
    case 'string':
      if(arg == '') continue;
      obj[arg] = true;
      break;
    }
  }
  return obj;
}

function createOtherUpdates(propertyId, newValue, _otherUpdates) {
  if(!_otherUpdates) {
    _otherUpdates = new Object();
    // flags登録用
    _otherUpdates.isOtherUpdates = true;
  }
  _otherUpdates[propertyId] = newValue;
  return _otherUpdates;
}

/**
 * データ保持オブジェクトからプロパティ値を取得し、プロパティテーブルに書き込む
 * @param  :propertyId 文字型 プロパティタイプ名
 * @return :
 */
function fnSetPropertyTable(propertyId, objDS, elementId, cellElementId){

  var attVal;
  var uncheckValue = '';
  
  switch(propertyId){
    case 'type':
      var itemType = objDS.getProperty(propertyId);
      attVal = getLiteral('pageitemtype.' + itemType);
      break;
      
    case 'maxlength':
      attVal = objDS.getProperty(propertyId);
      break;
      
    case 'align':
      attVal = objDS.getProperty(propertyId);
      break;
    
//カスタマイズ

    case 'customize-visibility':
    case 'customize-mobility':
    case 'customize-defaultvalue':
      var editField = getPropertyEditElement(propertyId);
      if(editField) {
        attVal = objDS.getProperty(propertyId);
        if(attVal == 'enabled'){
          editField.checked = true;
        }else{
          editField.checked = false;
        }
      }
      return;

    case 'customize-maxlines':
      var editField = getPropertyEditElement(propertyId);
      if(editField) {
        var editFieldCustVisibility = getPropertyEditElement('customize-visibility');
        if(editFieldCustVisibility) {

          attVal = objDS.getProperty(propertyId);
          //ラインモード時のみ設定可能
          if(useMaxLines(objDS.getProperty('tablemode'))){
            editField.parentNode.parentNode.style.display = '';
            editFieldCustVisibility.parentNode.parentNode.childNodes.item(0).rowSpan = 2;
            if(attVal == 'enabled'){
              editField.checked = true;
            }else{
              editField.checked = false;
            }
          }else{
            editField.parentNode.parentNode.style.display = 'none';
            editFieldCustVisibility.parentNode.parentNode.childNodes.item(0).rowSpan = 1;
            attVal = 'disabled';
          }
        }
      }
      return;
      
//FORM(PAGE)
    case 'pageheight':
      attVal = objDS.getProperty(propertyId);
      if(attVal == ''){
        alert(propertyId + ' can not be null.');
      }
      break;
      
    case 'pagewidth':
      attVal = objDS.getProperty('pagewidth');
      if(attVal == ''){
        alert(propertyId + ' can not be null.');
      }
      break;
      
    case 'action':
      attVal = objDS.getProperty(propertyId);
      //actionのデフォルト値をconstから取得
      if(!attVal){
        attVal = pref.init.form.action;
      }
      break;
      
    case 'method':
      attVal = objDS.getProperty(propertyId);
      //methodのデフォルト値をconstから取得
      if(!attVal){
        attVal = pref.init.form.method;
      }
      break;
      
//PANEL
    case 'width':
      attVal = objDS.getProperty(propertyId).toString();
      //if(attVal == 0){
      //  attVal = 100;
      //}
      if(objDS.isType(TYPE.PANEL)){
        attVal = getDocumentElementById(elementId).offsetWidth;
      }
      break;
      
//LIST
      
    case 'size':
      attVal = objDS.getProperty(propertyId);
      if(attVal.length == 0){
        attVal = 2;
        getDocumentElementById(elementId).rows = attVal;
      }
      break;
      
      
//TABLE
      
    case 'tablemode':
      attVal = objDS.getProperty(propertyId);
      //log.debug(propertyId + '@@' + attVal);
      if(attVal == ''){
        attVal = 'MODE_SIMPLE';
      }

      // ##
      if(parseInt(m_monitorEditStatus) != 2){
        var editField = getDocumentElementById('fld_tablerows_tr');
        if(editField) {
          if(useTableRows(attVal)){
            editField.style.display = '';
          }else{
            editField.style.display = 'none';
          }
        }
        var editField = getDocumentElementById('fld_maxlines_tr');
        if(editField) {
          if(useMaxLines(attVal)){
            editField.style.display = '';
          }else{
            editField.style.display = 'none';
          }
        }        
        var editField = getDocumentElementById('fld_titlecols_tr');
        if(editField) {
          if(useTitles(attVal)){
            editField.style.display = '';
          }else{
            editField.style.display = 'none';
          }
        }        
        var editField = getDocumentElementById('fld_titlerows_tr');
        if(editField) {
          if(useTitles(attVal)){
            editField.style.display = '';
          }else{
            editField.style.display = 'none';
          }
        }        
      }
      break;
      
    case 'tablecols':
    case 'tablerows':
    //case 'maxlines':
      attVal = objDS.getProperty(propertyId);
      if(attVal.length == 0){
        attVal = 1;
      }
      break;
      
    case 'titlecols':
      attVal = objDS.getProperty(propertyId);
      //log.debug(propertyId + '@@' + attVal);
      var cornerdisplay = 'none';
      if(Number(attVal)) {
        setTableTitleColPropertyDisplay('');
        if(Number(objDS.getProperty('titlerows'))) {
          cornerdisplay = '';
        }

      } else {
        attVal = '';
        setTableTitleColPropertyDisplay('none');
      }

      var tmpElement = getDocumentElementById('fld_corner_tr');
      if(tmpElement) {
        tmpElement.style.display = cornerdisplay;
      }
      break;

    case 'titlerows':
      attVal = objDS.getProperty(propertyId);
      //log.debug(propertyId + '@@' + attVal);
      if(Number(attVal)) {
        setTableTitleRowPropertyDisplay('');
        if(useTitleRowVanishing(objDS.getProperty('tablemode'))) {
          setTableTitleRowVanishingPropertyDisplay('');
        } else {
          setTableTitleRowVanishingPropertyDisplay('none');
        }
      } else {
        attVal = '';
        setTableTitleRowPropertyDisplay('none');
        setTableTitleRowVanishingPropertyDisplay('none');
      }
      break;

    case 'captionalign':
      attVal = objDS.getProperty(propertyId);
      if(attVal.length == 0){
        attVal = 'top';
      }
      break;
      
    case 'cellrow':
    case 'cellcol':
      if(cellElementId.length != 0){
        attVal = getDataSet(cellElementId).getProperty(propertyId);
        if(!attVal) attVal = '';
        getDataSet(cellElementId).setProperty(propertyId, attVal);
      }else{
        attVal='';
      }
      break;
      
    case 'cellwidth':
      if(cellElementId.length != 0){
        attVal = getDataSet(cellElementId).getProperty(propertyId);
        if(attVal.length == 0){
          attVal = getDocumentElementById(cellElementId).offsetWidth;
        }
        getDataSet(cellElementId).setProperty(propertyId, attVal);
      }else{
        attVal='';
      }
      break;
      
    case 'cellheight':
      if(cellElementId.length != 0){
        attVal = getDataSet(cellElementId).getProperty(propertyId);
        if(attVal.length == 0){
          attVal = getDocumentElementById(cellElementId).offsetHeight;
        }
        getDataSet(cellElementId).setProperty(propertyId, attVal);
      }else{
        attVal='';
      }
      break;
      
    case 'cellbackgroundimage':
      if(cellElementId.length != 0){
        attVal = getDataSet(cellElementId).getProperty(propertyId);
        if(!attVal) attVal = '';
        getDataSet(cellElementId).setProperty(propertyId, attVal);
      }else{
        attVal='';
      }
      break;
      
    case 'cellbackgroundcolor':
    case 'cellbordercolor':
      if(cellElementId.length != 0){
        attVal = getDataSet(cellElementId).getProperty(propertyId);
        if(!attVal) attVal = '';
        getDataSet(cellElementId).setProperty(propertyId, attVal);
      }else{
        attVal='';
      }
      var editField = getDocumentElementById('fld_' + propertyId + '_span');
      if(editField) {
        setElementStyleBackgroundColor(editField, attVal);
      }
      break;
      
    case 'src':
      try{
        attVal = objDS.getProperty(propertyId);
      }catch(e){
        attVal = '';
      }
      if(objDS.isType(TYPE.BUTTON) || objDS.isType(TYPE.SUBMIT) || objDS.isType(TYPE.RESET)) {
        if(attVal != ''){
          setButtonImagePropertyDisplay('');
        }else{
          setButtonImagePropertyDisplay('none');
        }
      }
      break;

    case 'cellstyle':
      if(cellElementId.length != 0){
        attVal = getDataSet(cellElementId).getProperty(propertyId);
      }else{
        attVal='';
      }
      break;
      
    case 'cellvisibility':
      if(cellElementId.length != 0){
        attVal = getDataSet(cellElementId).getProperty(propertyId);
        uncheckValue = 'visible';
      }else{
        attVal='';
        uncheckValue = 'visible';
      }
      log.debug('cellvisibility:' + cellElementId + '/' + attVal);
      break;

    case 'visibility':
      attVal = objDS.getProperty(propertyId);
      uncheckValue = 'visible';
      break;

    default:
      attVal = objDS.getProperty(propertyId);
    break;
  }
  
  setPropertyEditValue(propertyId,'',objDS, attVal, uncheckValue);

  return;
}

/*
 *
 */
function setButtonImagePropertyDisplay(display) {
  var editField = getDocumentElementById('fld_imagewidth_tr');
  if(editField) {
    editField.style.display = display;
  }
  var editField = getDocumentElementById('fld_imageheight_tr');
  if(editField) {
    editField.style.display = display;
  }
  var editField = getDocumentElementById('fld_imageposition_tr');
  if(editField) {
    editField.style.display = display;
  }
}

/*
 * 見出しの属性欄の表示・非表示
 * @param display ''または'none'
 */
function setTableTitleColPropertyDisplay(display) {
  var tmpElement;
  tmpElement = getDocumentElementById('fld_titlecolborderwidth_tr');
  if(tmpElement) {
    tmpElement.style.display = display;
  }
  tmpElement = getDocumentElementById('fld_titlecolborderstyle_tr');
  if(tmpElement) {
    tmpElement.style.display = display;
  }
  tmpElement = getDocumentElementById('fld_titlecolbordercolor_tr');
  if(tmpElement) {
    tmpElement.style.display = display;
  }
  tmpElement = getDocumentElementById('fld_titlecolcolor_tr');
  if(tmpElement) {
    tmpElement.style.display = display;
  }
  tmpElement = getDocumentElementById('fld_titlecolstyle_tr');
  if(tmpElement) {
    tmpElement.style.display = display;
  }
}

/*
 * 見出しの属性欄の表示・非表示
 * @param display ''または'none'
 */
function setTableTitleRowPropertyDisplay(display) {
  var tmpElement;
  tmpElement = getDocumentElementById('fld_titlerowborderwidth_tr');
  if(tmpElement) {
    tmpElement.style.display = display;
  }
  tmpElement = getDocumentElementById('fld_titlerowborderstyle_tr');
  if(tmpElement) {
    tmpElement.style.display = display;
  }
  tmpElement = getDocumentElementById('fld_titlerowbordercolor_tr');
  if(tmpElement) {
    tmpElement.style.display = display;
  }
  tmpElement = getDocumentElementById('fld_titlerowcolor_tr');
  if(tmpElement) {
    tmpElement.style.display = display;
  }
  tmpElement = getDocumentElementById('fld_titlerowstyle_tr');
  if(tmpElement) {
    tmpElement.style.display = display;
  }
}

/*
 *
 */
function setTableTitleRowVanishingPropertyDisplay(display) {
  var tmpElement;
  tmpElement = getDocumentElementById('fld_titlerowvanishing_tr');
  if(tmpElement) {
    tmpElement.style.display = display;
  }
}

/**
*/
function onSelectStartEnableSelect(_e) {
  _e.cancelBubble = true;
  _e.returnValue = true;
  return _e.returnValue;
}

/**
 * プロパティ入力個所でのチェック
 * @param  :e オブジェクト エラーオブジェクト(NNのみ)
 * @return :
 */
function onKeyPressProperty(e){
  var inf = {};
  if(m_browserType.isIE){
    var keyCode = event.keyCode
    var element = event.srcElement;
  }else{
    if(e.charCode != 0) {
      keyCode = e.charCode;
    } else {
      keyCode = e.keyCode;
      if(e.keyCode == KEYCODE.ENTER) {
      } else {
        return true;
      }
    }
    element = e.target;
  }

  if(keyCode == KEYCODE.ENTER){
    doChangeProperty(element.id, element.value, m_selection.front, m_selection.cell, 'Enter key pressed.');
    return false;
  }

  if(element.additionalOnKeyPress) {
    return element.additionalOnKeyPress(keyCode, element.propertyId);
  }

  return true;
}

var propertyEditCreator = new PropertyEditCreator;
function PropertyEditCreator() {
  PropertyEditCreator.prototype.getHtml = _getHtml;
  PropertyEditCreator.prototype.prepareElement = _prepareElement;
  
  function _prepareElement(elementId, cellElementId, type){
    this.elementId = elementId;
    this.cellElementId = cellElementId;
    this.type = type;
    this.propertyEditType = getPropertyEditType(type);
  }
  
  var READONLYSTYLE = 'background-color:transparent;border:none;cursor:default;height:20px;';

  function _getHtml(propertyId, spcEditType){
    if(spcEditType == DISUSE || spcEditType == HIDDEN) {
      return '';
    }

    var editType = getDisplayEditType(this.type, propertyId, spcEditType);
    if(editType == EDITTYPE.CUSTOMIZE) {
      return '';
    }
    var id = this.propertyEditType.getId(propertyId);
    var fullLabelId = 'property.' + this.propertyEditType.getLabelId(propertyId);
    var inputElement;

    switch(editType) {
    case DISUSE:
    case HIDDEN:
    case EDITTYPE.CUSTOMIZE:
      return '';
    case EDITTYPE.TYPE:
      inputElement = createItemTypeTypeProperty(id, this.elementId, this.cellElementId);
      break;
    case EDITTYPE.TEXT:
      inputElement = createTextProperty(id, this.elementId, this.cellElementId, 'text-align:left; ime-mode:auto;');
      break;
    case EDITTYPE.NUMBER:
      inputElement = createTextProperty(id, this.elementId, this.cellElementId, 'text-align:right; ime-mode:disabled;', 'NUMBER');
      break;
    case EDITTYPE.ASCII:
      inputElement = createTextProperty(id, this.elementId, this.cellElementId, 'text-align:left; ime-mode:disabled;');
      break;
    case READONLY:
    case EDITTYPE.TEXT_READONLY:
      inputElement = createReadonlyTextProperty(id);
      break;
    case EDITTYPE.NUMBER_READONLY:
      inputElement = createReadonlyTextProperty(id, 'right');
      break;
    case EDITTYPE.LONGTEXT:
      inputElement = createLongStringProperty(id, this.elementId, this.cellElementId, fullLabelId);
      break;
    case EDITTYPE.LONGASCII:
      inputElement = createLongStringProperty(id, this.elementId, this.cellElementId, fullLabelId, 'disabled');
      break;
    case EDITTYPE.CHECK:
      var valueoption = getValueOption(id, this.type);
      if(valueoption) {
        inputElement = createCheckTypeProperty(id, this.elementId, this.cellElementId, valueoption);
      } else {
        alert(getMessage('P0001', [this.type, id]));
        inputElement = createTextProperty(id, this.elementId, this.cellElementId, 'text-align:left; ime-mode:auto;');
      }
      break;
    case EDITTYPE.CHECK_READONLY:
      var valueoption = getValueOption(id, this.type);
      if(valueoption) {
        inputElement = createCheckTypeProperty(id, this.elementId, this.cellElementId, valueoption, true);
      } else {
        alert(getMessage('P0001', [this.type, id]));
        inputElement = createReadonlyTextProperty(id);
      }
      break;
    case EDITTYPE.SELECT:
      var valueoption = getValueOption(id, this.type);
      if(valueoption) {
        inputElement = createSelectTypeProperty(id, this.elementId, this.cellElementId, valueoption);
      } else {
        alert(getMessage('P0002', [this.type, id]));
        inputElement = createTextProperty(id, this.elementId, this.cellElementId, 'text-align:left; ime-mode:auto;');
      }
      break;
    case EDITTYPE.COLOR:
      inputElement = createColorTypeProperty(id, this.elementId, this.cellElementId);
      break;
    case EDITTYPE.COLOR_READONLY:
      inputElement = createColorTypeProperty(id, this.elementId, this.cellElementId, true);
      break;
    case EDITTYPE.EVENT:
      inputElement = createEventTypeProperty(id, this.elementId, this.cellElementId);
      break;
    case EDITTYPE.LINK:
      inputElement = createLinkTypeProperty(id, this.elementId, this.cellElementId);
      break;
    case EDITTYPE.IMAGE:
      inputElement = createImageNameProperty(id, this.elementId, this.cellElementId, fullLabelId);
      break;
    case EDITTYPE.JSFILE:
      inputElement = createButtonTypeProperty(id, this.elementId, this.cellElementId, 'doEditJsfile()');
      break;
    case EDITTYPE.META:
      inputElement = createButtonTypeProperty(id, this.elementId, this.cellElementId, 'doEditMeta()');
      break;
    case EDITTYPE.OPTION:
      inputElement = createButtonTypeProperty(id, this.elementId, this.cellElementId, 'doEditOption(\'' + this.type + '\')');
      break;
    case EDITTYPE.PARAMETER:
      var onclick = 'doEditParameter(\'' + id + '\',\'' + fullLabelId + '\')';
      inputElement = createButtonTypeProperty(id, this.elementId, this.cellElementId, onclick);
      break;
    default:
      alert(getMessage('P0003', [this.type, id, editType]));
      inputElement = createTextProperty(id, this.elementId, this.cellElementId, 'text-align:left; ime-mode:auto;');
    }

    // tr要素作成
    var trId = 'fld_' + id + '_tr';
    var html = '';
    if(trId){
      html = '<tr id="' + trId + '"><td width="100px">';
    } else {
      html = '<tr><td width="100px">';
    }
    html += getLiteral(fullLabelId);

    html += '</td><td width="100px">' + inputElement + '</td></tr>';
    
    return html;

    /**
     * 文字列
     */
    function createReadonlyTextProperty(id, align){
      if(align) {
        return '<input type="text" readonly id="fld_' + id + '" style="' + READONLYSTYLE + 'width:98px; font-size: 9pt; text-align:' + align + ';">';
      } else {
        return '<input type="text" readonly id="fld_' + id + '" style="' + READONLYSTYLE + 'width:98px; font-size: 9pt; text-align:left;">';
      }
    }
    
    /**
     * 文字列
     */
    function createTextProperty(id, elementId, cellElementId, inputStyle, charCheckId){
      if(charCheckId) {
        return '<input type="text" id="fld_' + id + '" style="width:98px; font-size: 9pt; ' + inputStyle 
            + '" value="" onchange="onChangeProperty(this.id, this.value, \'' + elementId + '\',\'' + cellElementId 
            + '\')" onfocus="onFocusProperty(this.id, \'' + charCheckId + '\')" onkeypress="return onKeyPressProperty(event);" onselectstart="onSelectStartEnableSelect(event)">';
      } else {
        return '<input type="text" id="fld_' + id + '" style="width:98px; font-size: 9pt; ' + inputStyle 
            + '" value="" onchange="onChangeProperty(this.id, this.value, \'' + elementId + '\',\'' + cellElementId 
            + '\')" onfocus="onFocusProperty(this.id)" onkeypress="return onKeyPressProperty(event);" onselectstart="onSelectStartEnableSelect(event)">';
      }
    }
    
    /**
     * 長い文字列
     */
    function createLongStringProperty(id, elementId, cellElementId, strLabel, imeMode){
      if(!imeMode) {
        imeMode = 'auto';
      }
      var onclick = 'doEditLongString(\'' + id + '\',\'' + getLiteral(strLabel) + '\',null,null,\'' + imeMode + '\')"';
      return createTextButtonTypeProperty(id, elementId, cellElementId, onclick, imeMode);
    }
    
    /**
     * 色編集
     */
    function createColorTypeProperty(id, elementId, cellElementId, readonly){
      var bgcolorstyle = '';
      var bgcolorstyleattr = '';
      var bgcolorclassname = '';
      if(pref.env.basecolor) {
        bgcolorstyle = 'background-color:' + pref.env.basecolor + ';';
        bgcolorstyleattr = ' style="background-color:' + pref.env.basecolor + ';"';
      } else {
        bgcolorclassname = ' class="' + CLASSNAME_BASEBACKGROUNDCOLOR + '"';
      }
      var colortipstyleattr = '';
      if(IMAGEURL_COLORTIPBG) {
        colortipstyleattr = ' style="background-image:url(' + IMAGEURL_COLORTIPBG + ');"';
      }

      if(readonly) {
        var inputHtml  = '<input type="text" readonly id="fld_' + id
          + '" style="' + READONLYSTYLE + 'width:70px; font-size: 9pt; text-align:left;" value="">';

        var rtnHTML = '<table cellspacing="0" cellpadding="0" width="98px" height="18px" bgcolor="white"' + colortipstyleattr + '>'
          + '<tr><td height="1px"' + bgcolorstyleattr + bgcolorclassname + '></td>'
          + '<td rowspan="3" style="' + bgcolorstyle + 'font-size:1px;"' + bgcolorclassname + '>' + inputHtml + '</td>'
          + '</tr><tr><td width="100%" height="100%" onclick="" style="font-size:1px; background-color:white; border:1px gray solid;cursor:default;" id="fld_' + id + '_span">&nbsp;</td>'
          + '</tr><tr><td height="1px"' + bgcolorstyleattr + bgcolorclassname + '></td></tr></table>';

      } else {

        var inputHtml  = '<input type="text" id="fld_' + id
          + '" style="width:70px; font-size: 9pt; text-align:left; ime-mode:disabled;" value="" onchange="onChangeColorProperty(this.id, this.value, \''
          + elementId + '\',\'' + cellElementId + '\');" onfocus="onFocusColorProperty(this.id)" onkeypress="return onKeyPressProperty(event);" onselectstart="onSelectStartEnableSelect(event)">';

        var rtnHTML = '<table cellspacing="0" cellpadding="0" width="98px" height="18px" bgcolor="white"' + colortipstyleattr + '>'
          + '<tr><td height="1px"' + bgcolorstyleattr + bgcolorclassname + '></td>'
          + '<td rowspan="3" style="' + bgcolorstyle + 'font-size:1px;"' + bgcolorclassname + '>' + inputHtml + '</td>'
          + '</tr><tr><td width="100%" height="100%" onclick="doEditColor(\'' + id + '\')" style="font-size:1px; background-color:white; border:1px black solid;cursor:default;" id="fld_' + id + '_span">&nbsp;</td>'
          + '</tr><tr><td height="1px"' + bgcolorstyleattr + bgcolorclassname + '></td></tr></table>';
      }


      return rtnHTML;
    }

    /**
     * 選択
     */
    function createSelectTypeProperty(id, elementId, cellElementId, options){
      var rtnHTML = '<select id="fld_' + id + '" style="width:100%; font-size: 9pt;" onchange="onChangeProperty(this.id, this.value, \'' + elementId + '\',\'' + cellElementId + '\')">'
        + getOptionHtml(id, options, false) + '</select>';
      return rtnHTML;
    }
    
    /**
     * チェック
     */
    function createCheckTypeProperty(id, elementId, cellElementId, options, readonly){
      var value = '';
      var valueName = '';
      for(var val in options) {
        if(val == '') continue;
        valueName = options[val];
        if(valueName == '') continue;
        value = val;
        break;
      }

      if(readonly) {
        var rtnHTML = '<input disabled type="checkbox" id="fld_' + id + '" style="font-size: 9pt; vertical-align:bottom;" onclick="return false;" value="' + value + '"><span style="vertical-align:bottom;">';
        rtnHTML += valueName + '</span></td></tr>';
      } else {
        var rtnHTML = '<input type="checkbox" id="fld_' + id + '" style="font-size: 9pt; vertical-align:bottom;" onclick="onClickCheckboxProperty(this.id, \'' + value + '\', this.checked, \'' + elementId + '\',\'' + cellElementId + '\')" value="' + value + '"><span style="vertical-align:bottom;">';
        rtnHTML += '<label for="fld_' + id + '">' + valueName + '</label>';
        rtnHTML += '</span></td></tr>';
      }
      return rtnHTML;
    }

    /**
     * イベント
     */
    function createTextButtonTypeProperty(id, elementId, cellElementId, onclick, imeMode){
      if(!imeMode) {
        imeMode = 'auto'
      }
      var rtnHTML = '<input type="text" id="fld_' + id + '" style="width:82px; font-size: 9pt; ime-mode:' + imeMode + ';" value="" onchange="onChangeProperty(this.id, this.value, \'' + elementId + '\',\'' + cellElementId + '\')" onfocus="onFocusProperty(this.id)" onkeypress="return onKeyPressProperty(event);" onselectstart="onSelectStartEnableSelect(event)">';
      rtnHTML += '<input type="button" id="fld_' + id + '_btn" style="width:16px; height:20px; font-size: 9pt;' + STYLE_PROPBUTTONCOLOR + '" value="..." onclick="' + onclick + '">';
      
      return rtnHTML;
    }

    /**
     * 項目タイプ
     */
    function createItemTypeTypeProperty(id, elementId, cellElementId){
      var rtnHTML = '<input type="text" readonly id="fld_' + id + '" style="' + READONLYSTYLE + 'width:82px; font-size: 9pt; ime-mode:disabled;">'
        + '<input type="button" id="fld_' + id + '_btn" style="width:16px; height:20px; font-size: 9pt;' + STYLE_PROPBUTTONCOLOR + '" value="..." onclick="doEditItemType()">';
      return rtnHTML;
    }
    
    /**
     * 画像
     */
    function createImageNameProperty(id, elementId, cellElementId, strLabel){
      if(isCellPropertyId(id)){
        var targetElementId = cellElementId;
      }else{
        var targetElementId = elementId;
      }
      var onclick = 'doEditImageName(\'' + id + '\',\'' + getLiteral(strLabel) + '\',\'' + targetElementId + '\')"';
      return createTextButtonTypeProperty(id, elementId, cellElementId, onclick);
    }

    /**
     * イベント
     */
    function createEventTypeProperty(id, elementId, cellElementId){
      var onclick = 'doEditEvent(\'' + id + '\')';
      return createTextButtonTypeProperty(id, elementId, cellElementId, onclick);
    }

    /**
     * リンク
     */
    function createLinkTypeProperty(id, elementId, cellElementId){
      var onclick = 'doEditEvent(\'' + id + '\',true)';
      return createTextButtonTypeProperty(id, elementId, cellElementId, onclick);
    }

    /**
     * ボタン
     */    
    function createButtonTypeProperty(id, elementId, cellElementId, onclick){
      var rtnHTML = '<input type="button" id="fld_' + id + '" style="width:100%; font-size:9pt;' + STYLE_PROPBUTTONCOLOR + '" onclick="' + onclick + '" value="' + getLiteral('common.editbutton') + '..."></td></tr>';
      return rtnHTML;
    }
  }
}

/**
 * 選択肢の配列を取得する
 */
function getValueOption(propertyId, typeId) {
  if(typeId) {
    var valueoption = pref.valueoption[typeId + '$' + propertyId];
    if(valueoption) {
      return valueoption;
    }
  }
  var valueoption = pref.valueoption[propertyId];
  if(valueoption) {
    return valueoption;
  }
  return null;
}


/**
 * 作成済みの文字列を保存する
 */
var m_storedHtmlString = new Object();

/**
 * <select>の<option>部分文字列作成
 * @param  :strTypeId  文字型  文字列を保存するキー
 *          objData    配列型  optionの配列
 *          langFlg    ブール  getLiteralを使用するか
 * @return :作成したHTML文字列
 */
function getOptionHtml(strTypeId, objData, langFlg) {

  if(m_storedHtmlString[strTypeId]) {
    // 文字列はすでに作成済み
    return m_storedHtmlString[strTypeId];
  }

  var rtnHTML  = '';
  var tmpGetLiteral = getLiteral;
  if(!langFlg){
    tmpGetLiteral = function(key){return key;};
  }

  for(var i in objData){
    if(objData[i] == ''){
      rtnHTML += '<option value="' + i + '">　　　　　　　　　</option>';
    }else{
      rtnHTML += '<option value="' + i + '">' + tmpGetLiteral(objData[i]) + '</option>';
    }
  }

  // 文字列保存
  m_storedHtmlString[strTypeId] = rtnHTML;

  return rtnHTML;
}

function createCustomCheckProperty(elementId, cellElementId, properties, propertiesLiteral){
  var rtnHTML  = '';

  // ## カスタマイズ編集時は作成時にdisabledに設定しておく

  var tmpPropLen = properties.length;
  if(tmpPropLen > 0) {
    if(parseInt(m_monitorEditStatus) == 2){
      var click = 'setOrgValue(this.id)';
      var disabled = 'disabled';
      var pref = 'customized.';
    } else {
      var click = 'onClickCustomProperty(this.id, this.checked, \'' + elementId + '\',\'' + cellElementId + '\')';
      var disabled = '';
      var pref = 'customizable.';
    }
    for(var i=0; i<tmpPropLen; i++){
      if(i==0) {
        rtnHTML += '<tr><td rowspan="' + properties.length + '">' + getLiteral('property.customizable') + '</td>';
      } else {
        rtnHTML += '<tr>';
      }
      rtnHTML += createCustomizeEditArea(properties[i],getLiteral(pref + propertiesLiteral[i]),click, disabled);
      rtnHTML += '</tr>';
    }
  }
  return rtnHTML;

}

function createCustomizeEditArea(propertyid, checkname, onclick, disabled) {
  return '<td><input id="fld_' + propertyid + '" type="checkbox" style="vertical-align:bottom;" value="enable" onclick="' + onclick + '" ' + disabled + '>'
    + '<span style="vertical-align:bottom;"><label for="fld_' + propertyid + '">' + checkname + '</label></span></td>';
}

/**
 * エレメントの色を取得
 * @param  :objDs        オブジェクト DataSet
 *          numColorProp 数値型       背景色設定プロパティ(0:bgcolor,1:bgcolor)
 * @return :
 */
function getBgcolorType(objDs){
  if(objDs.getProperty('visibility') == 'hidden'){
    return pref.view.get('hiddencolor');
  }else{
    return objDs.getProperty('backgroundcolor');
  }
}

/**
 * エレメントの色を取得
 * @param  :objDs        オブジェクト DataSet
 *          numColorProp 数値型       背景色設定プロパティ(0:bgcolor,1:bgcolor)
 * @return :
 */
function getCellBgcolorType(objDs){
  if(objDs.getProperty('cellvisibility') == 'hidden'){
    return pref.view.get('hiddencolor');
  }else{
    return objDs.getProperty('cellbackgroundcolor');
  }
}
/**
 * エレメントonmouseover時のカーソル形状を決定する
 * @param  :objDs オブジェクト DataSet
 * @return :      文字型       カーソル形状
 */
function getCursorType(objDs){
  // ## カーソル形状取得 カスタマイズ編集時にカスタマイズ不可場合に矢印を使用
  var strCursor = 'pointer';
  if(parseInt(m_monitorEditStatus) == 2){
    if(!objDs.getItemCustomizable()){
      strCursor = 'default';
    }
  }
  return strCursor;
}

/**
 *
 */
function getImageSrcUrl(src) {
  if(src != '') {
    return 'url(' + src + ')';
  }
  return '';
}

/**
 * @param  _value    string 設定する値
 * @return 
 */
function containsTag(_value){
  if(-1 < _value.indexOf('<%') || -1 < _value.indexOf('%=') ||  -1 < _value.indexOf('%#')) {
    return true;
  }
  return false;
}

/**
 * スタイルに色を設定する
 * @param  _value    string 設定する値
 *          _tagcolor string 値がtagだった場合の色(option)
 * @return :
 */
function tagFree(_value, _valueForTag){
  if(containsTag(_value)) {
    // 値にタグが設定されていた
    if(_valueForTag) {
      return _valueForTag;
    } else {
      return '';
    }
  }
  return _value;
}

/**
 * スタイルに色を設定する
 * @param  :_element  object styleを設定するエレメント
 *          _propname string 設定するstyle属性名
 *          _value    string 設定する値
 *          _tagcolor string 値がtagだった場合の色(option)
 *          _errcolor string 値がエラーだった場合の色(option)
 * @return :エラーのときfalse
 */
function setElementStyleColor(_element, _propname, _value, _tagcolor, _errcolor){

  if(containsTag(_value)) {
    if(typeof(_tagcolor) == 'string') {
      _element.style[_propname] = _tagcolor;
    }
    return true;
  }
  try{
    _element.style[_propname] = _value;
  } catch(e) {
    if(typeof(_errcolor) == 'string') {
      _element.style[_propname] = _errcolor;
    }
    return false;
  }
  return true;
}

/**
 * 背景に色を設定する
 * @param  :_element  object styleを設定するエレメント
 *          _value    string 設定する値
 * @return :エラーのときfalse
 */
function setElementStyleBackgroundColor(_element, _value, _tagcolor){
  if(typeof(_tagcolor) == 'string') {
    return setElementStyleColor(_element, 'backgroundColor', _value, _tagcolor);
  } else {
    return setElementStyleColor(_element, 'backgroundColor', _value, '');
  }
}

/**
 * 文字に色を設定する
 * @param  :_element  object styleを設定するエレメント
 *          _value    string 設定する値
 * @return :エラーのときfalse
 */
function setElementStyleFontColor(_element, _value){
  return setElementStyleColor(_element, 'color', _value, '');
}

/**
 * 枠線に色を設定する
 * @param  :_element  object styleを設定するエレメント
 *          _value    string 設定する値
 * @return :エラーのときfalse
 */
function setElementStyleBoderColor(_element, _value, _tagcolor){
  if(typeof(_tagcolor) == 'string') {
    return setElementStyleColor(_element, 'borderColor', _value, _tagcolor);
  } else {
    return setElementStyleColor(_element, 'borderColor', _value, 'silver');
  }
}

/**
 * 縦、横位置変更時のチェック
 * @param  :numValue 数値型   変更後のエレメントのポジション
 *          boolLeft ブール値 true:横 false:縦
 * @return :
 */
function checkElementPosition(numValue, boolLeft, elementId){
  var rtnValue = numValue;
  if(rtnValue < 0) rtnValue = 0;
  if(!boolLeft) {
    rtnValue -= (rtnValue % DISPLAYROWHEIGHT);
  }
  return rtnValue;
}

/**
 * カスタマイズ設定を行わない時、VIEWPAGEINFOに登録されているデータを上書きする
 * @param  :
 * @return :
 */
function setOrgValue(fldId){
  
  if(m_monitorEditStatus != 2) return;
  
  // 更新するオブジェクトのリスト
  var list = getUpdateList(fldId.substr(4));
  // コマンドセット
  var cmdSet = new UndoableCommandSet();
  cmdSet.add(new CommandSelect(true));

  if(!getDocumentElementById(fldId).checked){
    // チェックをはずした
    
    switch(fldId.replace('fld_customize-', '')) {
    case 'visibility':

      // 更新
      for(var i = 0; i < list.length; i++) {
        var dataset = getDataSet(list[i].elementId);
        var originalvalue = dataset.getCustomProperty('visibility', 'originalvalue');
        if(originalvalue == 'hidden'){
          getDocumentElementById('fld_visibility').checked = true;
        }else{
          getDocumentElementById('fld_visibility').checked = false;
        }
        updateValuePerObject(list[i].elementId, list[i].cellElementId, 'fld_visibility', originalvalue, '', cmdSet);
      }
      break;
    
    case 'mobility':
      
      // 更新
      for(var i = 0; i < list.length; i++) {
        var dataset = getDataSet(list[i].elementId);
        var originaltop = dataset.getCustomProperty('top', 'originalvalue');
        var originalleft = dataset.getCustomProperty('left', 'originalvalue');
        updateValuePerObject(list[i].elementId, list[i].cellElementId, 'fld_top', originaltop, '', cmdSet);
        updateValuePerObject(list[i].elementId, list[i].cellElementId, 'fld_left', originalleft, '', cmdSet);
        updateValuePerObject(list[i].elementId, list[i].cellElementId, fldId, 'disabled', '', cmdSet);
      }
      break;

    case 'maxlines':
      
      // 更新
      for(var i = 0; i < list.length; i++) {
        var dataset = getDataSet(list[i].elementId);
        var originalvalue = dataset.getCustomProperty('maxlines', 'originalvalue');
        updateValuePerObject(list[i].elementId, list[i].cellElementId, 'fld_maxlines', originalvalue, '', cmdSet);
        updateValuePerObject(list[i].elementId, list[i].cellElementId, fldId, 'disabled', '', cmdSet);
      }
      break;

    default:
      
      // 更新
      for(var i = 0; i < list.length; i++) {
        var dataset = getDataSet(list[i].elementId);
        var tmpDefProp = dataset.getDefaultPropName();
        var originalvalue = dataset.getCustomProperty(tmpDefProp, 'originalvalue');
        //dataset.setProperty(tmpDefProp, originalvalue);
        updateValuePerObject(list[i].elementId, list[i].cellElementId, 'fld_' + tmpDefProp, originalvalue, '', cmdSet);
        updateValuePerObject(list[i].elementId, list[i].cellElementId, fldId, 'disabled', '', cmdSet);
      }
    }


  }else{

    // 更新
    for(var i = 0; i < list.length; i++) {
      updateValuePerObject(list[i].elementId, list[i].cellElementId, fldId, 'enabled', '', cmdSet);
    }

  }

  // Undo登録
  if(cmdSet && cmdSet.commands.length > 1) {
    cmdSet.add(new CommandSelect(false));
    m_undoManager.execute(cmdSet);
  }

  //プロパティテーブル更新
  //log.debug('updating property area. [VwType.js/setOrgValue]');
  m_selection.updatePropertyArea(fldId);

}

/**
 * outerHTML実装関数(NN対応)
 * param  :objEle  オブジェクト エレメントオブジェクト
 *         strHtml 文字型       入れ替えるHTML文字列
 * return :
 */
function setOuterHTML(objEle, strHtml){
  if(m_browserType.isIE){
    objEle.outerHTML = strHtml;
  }else{
    var objRng = objEle.ownerDocument.createRange();
    objRng.setStartBefore(objEle);
    if(strHtml.length != 0){
      var objDiff = objRng.createContextualFragment(strHtml);
      objEle.parentNode.replaceChild(objDiff, objEle);
    }else{
      objEle.parentNode.removeChild(objEle);
    }
  }
}

/**
 * オブジェクトを画面表示するためのHTML生成
 */
function getElementHtml(dataset) {

    var strCursor = 'pointer';
    var strHTML = '';
    strHTML += '<span id="' + dataset.getProperty('id') + '_span" ' 
      + getViewToolTipAttributeSpan(dataset) 
      + '" style="position:absolute; left: '
      + dataset.getProperty('left')
      + 'px; top:' + dataset.getProperty('top') + 'px; ';

    //カスタマイズ時
    if(m_monitorEditStatus == 2){
      if(!dataset.getItemCustomizable()){
        strCursor = 'default';
      }else{
        //カスタマイズ可時
        if(dataset.getCustomized()){
          //カスタマイズ済時
          strHTML += 'border:' + pref.view.get('customizedborder') + ';';
        }else{
          //未カスタマイズ時
          strHTML += 'border:' + pref.view.get('customizableborder') + ';';
        }
      }
    }
    if(dataset.getProperty('visibility') == 'hidden'){
      strHTML +=     'background-color:' + pref.view.get('hiddencolor') + ';';
    }
    strHTML +=      ' cursor:' + strCursor + ';">';
    strHTML += getViewObject(dataset.type.value).getPropertiesHtml(dataset);
    strHTML += '</span>';
    return strHTML;

  //return dataset.getPropertiesHtml();
}

/**
 * mozillaで 「"あ"」が「あ」になる現象の対処
 */
function nnQuotEscape(str, alignName, ds) {
  if(m_browserType.isNN && alignName) {
    if(str.length < 2) {
      return str;
    } else if(str.substring(0,1) == '"' && str.substring(str.length - 1) == '"') {
    } else if(str.substring(0,1) == '\'' && str.substring(str.length - 1) == '\'') {
    } else if(str.length < 12) {
      return str;
    } else if(str.substring(0,6) == '&quot;' && str.substring(str.length - 6) == '&quot;') {
    } else if(str.substring(0,6) == '&#039;' && str.substring(str.length - 6) == '&#039;') {
    } else {
      return str;
    }
    var align = ds.getProperty(alignName).toLowerCase();
    if(align == 'center') {
      str = ' ' + str + ' ';
    } else if(align == 'right') {
      str = ' ' + str;
    } else {
      str = str + ' ';
    }
  }
  return str;
}

/**
 * 文字列をhtml用にエスケープする
 */
function htmlEscape(str) {

  str = str.replace(/&/g, '&amp;');
  str = str.replace(/"/g, '&quot;');
  str = str.replace(/</g, '&lt;');
  str = str.replace(/>/g, '&gt;');
  str = str.replace(/'/g, '&#039;');
  
  return str;
}


/**
 * 再描画メソッド
 */
function common_repaint(elementId, dataset, cellElementId, cellDataset) {
  
  var span = getDocumentElementById(elementId + '_span');
  var zIndex = span.style.zIndex;
  
  //既存のHTMLを置換
  setOuterHTML(span, getElementHtml(dataset));

  span = getDocumentElementById(elementId + '_span');
  span.style.zIndex = zIndex;
    
  m_selection.remove(elementId);
  m_selection.add(elementId);
}

/**
 * 再描画メソッド(属性用)
 */
function _$repaint(newValue, elementId, dataset, cellElementId, cellDataset) {
  return flags(newValue, 'repaint');
}

/**
 *
 */
function getTextElementClassProperty(dataset) {
  return getElementClassProperty(dataset, 'style');
}

/**
 *
 */
function getNonTextElementClassProperty(dataset) {
  return getElementClassProperty(dataset, 'style');
}

/**
 *
 */
function getCellElementClassProperty(dataset) {
  return getElementClassProperty(dataset, 'cellstyle');
}

/**
 *
 */
function getElementClassProperty(dataset, propertyId) {
  var strStyle = dataset.getProperty(propertyId);
  return getClassNameFromStylePropertyValue(strStyle);
}

/**
 *
 */
function getClassNameFromStylePropertyValue(value) {
  if(value != '' && value.indexOf(':') == -1) {
    return value;
  }
  return '';
}

/**
 *
 */
function cancelStyle() {
  return 'margin:0px 0px 0px 0px;';
}

/**
 *
 */
function getPropertyEditElement(propertyId, noAlert) {
  var element = getDocumentElementById('fld_' + propertyId);
  
  if(!element) {
    log.warn(propertyId+ ' の属性欄はありません.')
    if(!noAlert) {
      alert(propertyId+ ' の属性欄はありません.');
    }
  }
  return element;
}

/**
 *
 */
function setPropertyEditValue(propertyId, type, objDS, value, uncheckValue) {
  if(!type) {
    type = objDS.getProperty('type');
  }
  //log.debug('setPropertyEditValue(' + [propertyId,type,value,uncheckValue] + ')');
  var editField = getPropertyEditElement(propertyId, true);
  if(editField) {
    var inputType = String(editField.type).toLowerCase();
    if(inputType == 'button') return;

    if(inputType == 'checkbox') {
      if(value == ''){
        editField.checked = false;
      }else if(uncheckValue && value == uncheckValue){
        editField.checked = false;
      }else {
        var valuroption = getValueOption(propertyId, type);
        if(!valuroption) {
          throw createError('pref.valueoption for ' + type + '.' + propertyId + ' is not defined.', 'VwType.js', 'setPropertyEditValue');
        }
        if(valuroption[value]) {
          editField.checked = true;
        } else {
          editField.checked = false;
        }
      }
    } else {

      var editTypeId = getPropertyEditType(type).getEditTypeId(propertyId);
      switch(editTypeId) {
      case 'select':
        if(editField.readOnly) {
          var cnv = pref.valueoption[propertyId];
          if(cnv && cnv[value]) {
            value = cnv[value];
          }
        } else {
        }
        break;
      case 'color':
        var editFieldSpan= getDocumentElementById('fld_' + propertyId + '_span');
        if(editFieldSpan) {
          setElementStyleBackgroundColor(editFieldSpan, value);
        }
        break;

      default:
        if(editField.readOnly) {
          var cnv = pref.valueoption[propertyId];
          if(cnv && cnv[value]) {
            value = cnv[value];
          }
        } else {
        }
      }
      //log.debug('editField.value = ' + value);
      editField.value = value;
    }
  }
}


/**
 * button用属性初期化
 */
function fnSetDefaultProperty_common(objDS){
  var editarea = pref.editarea[objDS.type.value];
  var init = pref.init[objDS.type.value];
  
  for(var i in init.enumerator()) {
    if(i == 'type') continue;
    if(editarea.get(i) == '') continue;
    objDS.setProperty(i,  init.get(i));
  }
}

function transferRows(dataset,start,end) {
  var dirs = 'rows';
  var opdirs = 'cols';
  var dirsize = dataset.getProperty(dirs);
  var opdirsize = dataset.getProperty(opdirs);

  var tableId = dataset.getProperty('id');

  var stationaryCells = {};
  for(var i = 1; i < opdirsize; i++) {
    var cellId = getCellId(tableId, start, i);
    stationaryCells[i] = getDataSet(cellId);
  }
}

/*
 * セルに属性値をコピーする
 */
function UndoTransferCellProperties(tableId, direction, selectedRowOrCol, shiftSize, copyRowOrCol, divided) {
  log.debug('UndoTransferCellProperties(' + tableId + ',' + direction + ',' + selectedRowOrCol + ',' + shiftSize + ')');

  // prototype設定
  if(!UndoTransferCellProperties.UndoTransferCellPropertiesInitialized) {
    var tablePropertyIds = pref.edit.table.enumerator(true);
    var cellPropertyIds = {};
    var divCellPropertyIds = {};
    for(var p in tablePropertyIds) {
      if(p == 'cellrow' || p == 'cellcol') continue;
      if(!isCellPropertyId(p)) continue;
      cellPropertyIds[p] = true;
      if(p == 'cellwidth' || p == 'cellheight') continue;
      divCellPropertyIds[p] = true;
    }

    UndoTransferCellProperties.prototype.propertyIds = cellPropertyIds;
    UndoTransferCellProperties.prototype.divPropertyIds = divCellPropertyIds;
    UndoTransferCellProperties.prototype.saveCells = _saveCells;
    UndoTransferCellProperties.prototype.restore = _restore;
    UndoTransferCellProperties.prototype.transferCell = _transferCell;
    UndoTransferCellProperties.prototype.transferCellDataSet = _transferCellDataSet;
    UndoTransferCellProperties.UndoTransferCellPropertiesInitialized = true;
  }
  
  // テーブルのID  
  this.tableId = tableId;

  // 挿入位置
  this.selected = Number(selectedRowOrCol);

  // 挿入された列数or行数
  this.shiftSize = Number(shiftSize);

  if(this.shiftSize == 0) {
    this.enlarge = _doNothing;
    this.shorten = _doNothing
    return;
  }

  // 挿入されたセルに設定する属性値のコピー元の行or列
  this.copy = Number(copyRowOrCol);
  
  // 分割されて各セルのサイズが設定済みであることを示す。
  // サイズの属性を上書きしない
  if(divided) {
    this.propertyIds = this.divPropertyIds;
  }

  var dataset = getDataSet(this.tableId);
  if(dataset == null) {
    throw createError('table "' + this.tableId + '" not exists.', 'VwType.js', 'UndoTransferCellProperties');
  }
  this.tablerows = getDesignTableRows(dataset);
  this.tablecols = dataset.getProperty('tablecols');
  //log.debug('UndoTransferCellProperties tablerows:' + this.tablerows + ' tablecols:' + this.tablecols);
  
  if(direction == 'col') {
    // 列の挿入or削除
    this.enlarge = _enlargeCols;
    this.shorten = _shortenCols
    this.initCellWidth = Number(pref.init.table.get('cellwidth'));
    if(isNaN(this.copy)) {
      if(0 < this.initCellWidth) {
        // 環境設定の列の幅を使用して新しいセルを追
        this.copy = 0;
      } else {
        // 選択されている列をコピーして新しいセルを追加
        this.copy = this.selected;
      }
    } else if(this.initCellWidth < 5) {
      this.initCellWidth = 5;
    }

    if(this.shiftSize > 0) {
      // 列の挿入

      this.copyCells = this.saveCells(1, this.tablerows, this.copy, this.copy);

    } else {
      // 列の削除

      this.shiftSize = - this.shiftSize;

      var colstart = this.selected;
      var colend = this.selected + this.shiftSize - 1;
      if(colend > this.tablecols) {
        colstart -= (colend - this.tablecols);
        colend = this.tablecols;
      }
      this.savedCells = this.saveCells(1, this.tablerows, colstart, colend);
    }

  } else {
    // 行の挿入or削除

    this.enlarge = _enlargeRows;
    this.shorten = _shortenRows
    this.initCellRows = Number(pref.init.table.get('cellrows'));
    if(isNaN(this.copy)) {
      if(0 < this.initCellRows) {
        // 環境設定の列の幅を使用して新しいセルを追
        this.copy = 0;
      } else {
        // 選択されている列をコピーして新しいセルを追加
        this.copy = this.selected;
      }
    } else if(this.initCellRows < 1) {
      this.initCellRows = 1;
    }

    if(this.shiftSize > 0) {
      // 行の挿入

      this.copyCells = this.saveCells(this.copy, this.copy, 1, this.tablecols);

    } else {
      // 行の削除

      this.shiftSize = - this.shiftSize;

      var rowstart = this.selected;
      var rowend = this.selected + this.shiftSize - 1;
      if(rowend > this.tablerows) {
        rowstart -= (rowend - this.tablerows);
        rowend = this.tablerows;
      }
      this.savedCells = this.saveCells(rowstart, rowend, 1, this.tablecols);
    }
  }
  
  /*
   * 削除されるセルを保存
   */
  function _saveCells(startrows, endrows, startcols, endcols) {
    //log.debug('UndoTransferCellProperties._saveCells(' + [startrows, endrows, startcols, endcols] + ')');
    var savedCells = {};
    for(var row = startrows; row <= endrows; row++) {
      savedCells[row] = {};
      for(var col = startcols; col <= endcols; col++) {
        var cellId = getCellId(this.tableId, row, col);
        var svdataset = new DataSet(cellId, TYPE.CELL);
        savedCells[row][col] = svdataset;
        if(row == 0) {
          cellId = getCellId(this.tableId, 1, col);
          var dataset = getDataSet(cellId);
          svdataset.setProperty('cellwidth', dataset.getProperty('cellwidth'));
          svdataset.setProperty('cellheight', this.initCellRows * DISPLAYROWHEIGHT);
        } else if(col == 0) {
          cellId = getCellId(this.tableId, row, 1);
          var dataset = getDataSet(cellId);
          svdataset.setProperty('cellwidth', this.initCellWidth);
          svdataset.setProperty('cellheight', dataset.getProperty('cellheight'));
        } else {
          var dataset = getDataSet(cellId);
          if(dataset == null) {
            throw createError('cell "' + cellId + '" not exists.', 'VwType.js', '_saveCells');
          }
          this.transferCellDataSet(dataset, svdataset);
        }
      }
    }
    return savedCells;
  }
  
  /*
   * 保存されているセルの属性値を戻す
   */
  function _restore() {
    //log.debug('UndoTransferCellProperties._restore()');
    if(!this.savedCells) {
      return;
    }
    for(var row in this.savedCells) {
      for(var col in this.savedCells[row]) {
        var cellId = getCellId(this.tableId, row, col);
        var dataset = getDataSet(cellId);
        if(dataset == null) {
          throw createError('cell "' + cellId + '" not exists.', 'VwType.js', '_restore');
        }
        this.transferCellDataSet(this.savedCells[row][col], dataset);
      }
    }
  }
  
  /*
   * 行方向にデータを移動する
   */
  function _enlargeRows() {
    //log.debug('UndoTransferCellProperties._enlargeRows()');
    for(var fromRow = this.tablerows - this.shiftSize; fromRow >= this.selected; fromRow--) {
      var toRow = fromRow + this.shiftSize;
      for(var col = 1; col <= this.tablecols; col++) {
        var fromCellId = getCellId(this.tableId, fromRow, col);
        var toCellId = getCellId(this.tableId, toRow, col);
        this.transferCell(fromCellId, toCellId);
      }
    }
    
    if(this.copyCells) {
      for(var toRow = this.selected + this.shiftSize - 1; toRow >= this.selected; toRow--) {
        if(toRow == this.copy) continue;
        for(var col = 1; col <= this.tablecols; col++) {
          var toCellId = getCellId(this.tableId, toRow, col);

          var dataset = getDataSet(toCellId);
          if(dataset == null) {
            throw createError('cell "' + toCellId + '" not exists.', 'VwType.js', '_enlargeRows');
          }
          try {
            var copyDataSet = this.copyCells[this.copy][col];
            if(copyDataSet == null) throw '';
          } catch (e) {
            //showObject(this.copyCells, 'this.copyCells',2);
            throw createError('this.copyCells[' + this.copy + '][' + col + '] not exists.', 'VwType.js', '_enlargeRows');
          }
          this.transferCellDataSet(copyDataSet, dataset);
        }
      }
    }

    this.restore();
  }

  /*
   * 行方向にデータを戻す
   */
  function _shortenRows() {
    //log.debug('UndoTransferCellProperties._shortenRows()');
    for(var row = this.selected + this.shiftSize; row <= this.tablerows; row++) {
      for(var col = 1; col <= this.tablecols; col++) {
        var fromCellId = getCellId(this.tableId, row, col);
        var toCellId = getCellId(this.tableId, row - this.shiftSize, col);
        this.transferCell(fromCellId, toCellId);
      }
    }
  }

  /*
   * 列方向にデータを移動する
   */
  function _enlargeCols() {
    //log.debug('UndoTransferCellProperties._enlargeCols()');
    /*
    for(var col = this.tablecols; col > this.selected; col--) {
      if(this.selected > col - this.shiftSize) {
        var fromCol = this.selected;
      } else {
        var fromCol = col - this.shiftSize;
      }
      for(var row = 1; row <= this.tablerows; row++) {
        var fromCellId = getCellId(this.tableId, row, fromCol);
        var toCellId = getCellId(this.tableId, row, col);
        this.transferCell(fromCellId, toCellId);
      }
    }
    */
    
    for(var fromCol = this.tablecols - this.shiftSize; fromCol >= this.selected; fromCol--) {
      var toCol = fromCol + this.shiftSize;
      for(var row = 1; row <= this.tablerows; row++) {
        var fromCellId = getCellId(this.tableId, row, fromCol);
        var toCellId = getCellId(this.tableId, row, toCol);
        this.transferCell(fromCellId, toCellId);
      }
    }
    
    if(this.copyCells) {
      for(var toCol = this.selected + this.shiftSize - 1; toCol >= this.selected; toCol--) {
        if(toCol == this.copy) continue;
        for(var row = 1; row <= this.tablerows; row++) {
          var toCellId = getCellId(this.tableId, row, toCol);

          var dataset = getDataSet(toCellId);
          if(dataset == null) {
            throw createError('cell "' + toCellId + '" not exists.', 'VwType.js', '_enlargeCols');
          }
          try {
            var copyDataSet = this.copyCells[row][this.copy];
            if(copyDataSet == null) throw '';
          } catch (e) {
            //showObject(this.copyCells, 'this.copyCells',2);
            throw createError('this.copyCells[' + row + '][' + this.copy + '] not exists.', 'VwType.js', '_enlargeCols');
          }
          this.transferCellDataSet(copyDataSet, dataset);
        }
      }
    }
    
    this.restore();
  }

  /*
   * 列方向にデータをもどす
   */
  function _shortenCols() {
    //log.debug('UndoTransferCellProperties._shortenCols()');
    for(var col = this.selected + this.shiftSize ; col <= this.tablecols; col++) {
      for(var row = 1; row <= this.tablerows; row++) {
        var fromCellId = getCellId(this.tableId, row, col);
        var toCellId = getCellId(this.tableId, row, col - this.shiftSize);
        this.transferCell(fromCellId, toCellId);
      }
    }
  }

  /*
   * セルの内容をコピーする
   * @param fromCellId コピー元セルID
   * @param toCellId   コピー先セルID
   */
  function _transferCell(fromCellId, toCellId) {
    var fromDataSet = getDataSet(fromCellId);
    if(fromDataSet == null) {
      throw createError('cell "' + fromCellId + '"(fromCellId) not exists.', 'VwType.js', 'transferCell');
    }
    var toDataSet = getDataSet(toCellId);
    if(toDataSet == null) {
      throw createError('cell "' + toCellId + '"(toCellId) not exists.', 'VwType.js', 'transferCell');
    }
    this.transferCellDataSet(fromDataSet, toDataSet);
  }
  
  /*
   * セルのデータセットをコピーする
   * @param fromDataSet コピーもと
   * @param toDataSet   コピー先
   */
  function _transferCellDataSet(fromDataSet, toDataSet) {
    if(fromDataSet == null) {
      throw createError('fromDataSet cannot be null.', 'VwType.js', 'transferCellDataSet');
    }
    if(toDataSet == null) {
      throw createError('toDataSet cannot be null.', 'VwType.js', 'transferCellDataSet');
    }
    //log.debug('UndoTransferCellProperties.transferCellDataSet(' + fromDataSet.id.value + ',' + toDataSet.id.value + ')');
    for(var p in this.propertyIds) {
      //log.debug('fromDataSet.getProperty(' + p + ') : ' + fromDataSet.getProperty(p));
      toDataSet.setProperty(p, fromDataSet.getProperty(p));
    }
  }

  function _doNothing() {
  }
}

/**
 * ツールチップを更新する
 */
function updateViewToolTipAttribute(elementId) {
  if(isCellId(elementId)) {
    return;
  }
  
  var element = getDocumentElementById(elementId + '_span');
  if(element) {
    var title = element.title;
    var newTitle = getViewToolTipText(getDataSet(elementId));
    if(title != newTitle) {
      element.title = newTitle;
    }
  }
}

/**
 * HTMLのツールチップ部分
 */
function getViewToolTipAttributeHtml(dataset) {
  return ' ';
}
/**
 * HTMLのツールチップ部分
 */
function getViewToolTipAttributeSpan(dataset) {
  var str = getViewToolTipText(dataset);
  if(str) {
    return ' title="' + str + '" ';
  }
  return ' ';
}

/**
 * ツールチップのテキスト
 */
function getViewToolTipText(dataset) {
  var type = dataset.getProperty('type');
  if(getViewToolTipText.formats == undefined) {
    getViewToolTipText.formats = {};
  }
  var format = getViewToolTipText.formats[type];
  if(format == undefined) {
    format = pref.view[type].get('tooltip');
    getViewToolTipText.formats[type] = format;
  }
  if(!format) {
    return '';
  }
  var strref = {tooltip:''};
  var pos = 0;
  var sepflg = false;
  var sep = '';
  while(pos < format.length) {
    var ch = format.charAt(pos);
    if(ch == '[') {
      pos = nextToBrackets(format, pos, strref);
      if(strref.id == '') {
        sepflg = true;
        sep = strref.text;
        strref.text == '';
      } else if(sepflg) {
        if(strref.tooltip && strref.text) {
          strref.tooltip += sep + strref.text;
        } else {
          strref.tooltip += strref.text;
        }
        sepflg = false;
        sep = '';
      } else {
        strref.tooltip += strref.text;
      }
    
    } else if(ch == '|') {
      if(strref.tooltip) {
        break;
      }
      pos++;
    } else {
      if(ch == '%') {
        pos = nextToPercent(format, pos, strref);
      } else {
        strref.text = ch;
        pos++;
      }

      if(sepflg) {
        if(strref.tooltip && strref.text) {
          strref.tooltip += sep + strref.text;
        } else {
          strref.tooltip += strref.text;
        }
        sepflg = false;
        sep = '';
      } else {
        strref.tooltip += strref.text;
      }
    }
    //log.debug('strref.tooltip:' + strref.tooltip + ' strref.text:' + strref.text);
  }
  
  function nextToBrackets(format, pos, strref) {
    strref.id = '';
    strref.attribute = '';
    pos++;
    var text = '';
    var rtntext = '';
    var textflg = true;
    while(pos < format.length) {
      var ch = format.charAt(pos);
      if(ch == '%') {
        pos = nextToPercent(format, pos, strref);
        text += strref.text;
        if(strref.id && !strref.attribute && !strref.text) {
          textflg = false;
        }
      } else if(ch == ']') {
        if(textflg) {
          rtntext = text;
        }
        pos++;
        break;
      } else if(ch == '|') {
        if(text) {
          rtntext = text;
          break;
        }
        textflg = true;
        pos++;
      } else {
        text += ch;
        pos++;
      }
    }
    strref.text = rtntext;
    return pos;
  }
  
  function nextToPercent(format, pos, strref) {
    var nextpos = format.indexOf('%', pos + 1);
    if(nextpos == -1) {
      strref.id = '';
      strref.attribute = '';
      strref.text = '';
      return format.length;
    }
    var id = format.substring(pos + 1, nextpos).toLowerCase();
    var att = '';
    var dotpos = id.indexOf('.');
    if(dotpos != -1) {
      att = id.substring(dotpos + 1);
      id = id.substring(0,dotpos);
    }
    if(id == 'itemid') {
      if(att == 'name') {
        id = 'itemname';
        att = '';
      } else {
        id = 'name';
      }
    }
    strref.id = id;
    strref.attribute = att;
    if(att == 'label' || att == 'caption') {
      if(id == 'itemname') {
       strref.text = getLiteral('property.itemname');
      } else if(id == 'id') {
       strref.text = 'ID';
      } else if(id == 'objectid') {
       strref.text = getLiteral('common.objectid');
      } else {
       strref.text = getLiteral('property.' + getPropertyEditType(type).getLabelId(id));
      }
    } else if(att == 'name') {
      if(pref.valueoption[id]) {
        var val = dataset.getProperty(id);
        strref.text = pref.valueoption[id][val];
        if(strref.text == undefined) {
          log.debug('[tooltip] pref.valueoption.' + id + '.' + val + ' not exists.');
          strref.text = val;
        }
      } else {
        log.debug('[tooltip] pref.valueoption.' + id + ' not exists.');
        strref.text = dataset.getProperty(id);
      }
    } else {
      if(att) {
        log.debug('[tooltip] <property>.' + att + ' not exists.(%' + id + '.' + att + '%)');
      }
      if(id == 'itemname'){
        strref.text = '';
        var name = dataset.getProperty('name');
        if(name && m_itemDefinitionObject.itemDefineDict) {
          if(m_itemDefinitionObject.itemDefineDict[name]) {
            strref.text = m_itemDefinitionObject.itemDefineDict[name];
          }
        }
      } else if(id == 'objectid') {
        strref.text = dataset.getProperty('id');
      } else {
        strref.text = dataset.getProperty(id);
      }
    }
    return nextpos + 1;
  }

  return strref.tooltip;
}

