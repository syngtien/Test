var drag = null;
var drag_td = null;
var drag_table = null;
var drag_td_index = null;
var drag_start_x = 0;
var drag_start_width = 0;
var drag_save_mouseup = null;
var drag_save_mousemove = null;
var drag_save_selectstart = null;

function th_dragstart(event) {
  if(!event){
    event=window.event;
  }
  var x=event.x;
  if(!x)x=event.clientX;
  var td=event.srcElement;
  if(!td)td=event.target;
  drag = td;
  drag_td = td.parentNode;
  while(drag_td.tagName!='TD'){
    if(!drag_td.parentNode)return;
    drag_td=drag_td.parentNode;
  }
  for(var i=0;i<drag_td.parentNode.childNodes.length;++i){
    if(drag_td.parentNode.childNodes[i]==drag_td) {
      drag_td_index=i;
      break;
    }
  }
  drag_table=drag_td.parentNode;
  while(drag_table.tagName!='TABLE'){
    if(!drag_table.parentNode)return;
    drag_table=drag_table.parentNode;
  }
  drag_start_x=event.x||event.clientX;
  drag_start_width=getValueFromStyle(drag_td.style.width);
  drag_save_mouseup=document.onmouseup;
  drag_save_mousemove=document.onmousemove;
  document.onmouseup=function(event){th_dragend(event);};
  document.onmousemove=function(event){th_dragmove(event);}
}
function th_dragend() {
  drag = null;
  drag_td = null;
  document.onmouseup=drag_save_mouseup;
  document.onmousemove=drag_save_mousemove;
  drag_table.onselectstart=drag_save_selectstart;
}
function th_dragmove(event) {
  if(drag == null) {
    return;
  }
  if(!drag_table.onselectstart){
    drag_table.onselectstart=function(){return false;};
  }
  if(!event){
    event=window.event;
  }
  if((event.button||event.which)!=1) {
    th_dragend();
    return;
  }
  var x = event.x||event.clientX;
  var rbw=3;
  var neww = drag_start_width + (x - drag_start_x);
  var minw=rbw;
  if(drag_td_index==0){
    minw=rbw+1;
  }
  if(neww>=minw){
    var childs = getTableRows(drag_table);
    for(var i=0; i<childs.length;++i){
      var line = childs[i];
      var td=line.childNodes[drag_td_index];
      td.style.width=neww+'px';
      var table=td.getElementsByTagName('table')[0];
      if(table){
        var tds=table.getElementsByTagName('td');
        tds[0].style.width=(neww-minw)+'px';
      }
    }
  }
}
function getValueFromStyle(v) {
  if(v.match('px$')){
    return Number(v.replace('px',''));
  }
  try{
    return Number(v);
  }catch(e){
  }
  return v;
}
function getTableRows(table) {
  if(table&&table.childNodes&&table.childNodes[0].tagName=='TBODY'){
    return table.childNodes[0].childNodes;
  }else if(table.rows){
    return table.rows;
  }
}

var totalLines=0;
function setscroll(sbid,tableid,lines) {
  var table=document.getElementById(tableid);
  var rows=getTableRows(table);
  var lineHeight=24;
  var sb=document.getElementById(sbid);
  var virtualHeight=(lineHeight*lines)<<0;
  sb.style.height=(((lineHeight+1)*lines)<<0) + 'px';
  totalLines=lines;
}

var lastScTop=0;
var lastStartRec=0;
var saveOnScroll=null;
var debug=false;

function doscroll(item,tableid){
  if(item.onscroll){
    saveOnScroll=item.onscroll;
    item.onscroll=null;
  }
  var table=document.getElementById(tableid);
  var rows=getTableRows(table);
  var lineHeight=24;
  var virtualHeight=item.getElementsByTagName('div')[0].offsetHeight;
  var realScrollTop=item.scrollTop;
  var direction=0;
  if(realScrollTop<lastScTop){
    direction=1;
  } else if(realScrollTop>lastScTop){
    direction=2;
  }else{
    if(saveOnScroll){
      item.onscroll=saveOnScroll;
    }
    return;
  }
  var startRec=(((realScrollTop+lineHeight-1)/lineHeight)<<0) + 1;
  var maxRec=(virtualHeight/lineHeight)<<0;
  var maxStartRec=maxRec-rows.length+2;
  if(startRec==lastStartRec){
    if(direction==1&&startRec>1){
      startRec--;
    }else if(direction==2&&startRec<maxStartRec){
      startRec++;
    }else{
      if(saveOnScroll){
        item.onscroll=saveOnScroll;
      }
      return;
    }
  }
  var scTop = (startRec-1)*lineHeight;
  if(debug){
    var debugInfo = document.getElementById('debuginfo');
    var info='direction='+direction+',virtualHeight='+virtualHeight+',realScrollTop='+realScrollTop+',maxRec='+maxRec+',startRec='+startRec+',maxStartRec='+maxStartRec+',scTop='+scTop+',lastScTop='+lastScTop+',lastStartRec='+lastStartRec;
    if(debugInfo.textContent) {
      debugInfo.textContent=info;
    } else if(debugInfo.tagName=='TEXTAREA') {
      debugInfo.value=info+'\n'+debugInfo.value;
    } else if(debugInfo.innerText) {
      debugInfo.innerText=debugInfo.innerText+info+'\n';
    }
  }
  
  if(startRec!=maxStartRec){
    item.scrollTop=scTop;
  }
  if(saveOnScroll){
    item.onscroll=saveOnScroll;
  }
  lastScTop=scTop;
  if(startRec==maxStartRec){
    lastScTop=realScrollTop;
  }
  lastStartRec=startRec;
  
  var lineInfo = document.getElementById('lineInfo');
  if(lineInfo){
    var info=startRec+'/'+maxRec;
    if(lineInfo.textContent) {
      lineInfo.textContent=info;
    } else if(lineInfo.innerText) {
      lineInfo.innerText=info;
    }
  }
  
  var xmlhttp;
  try {
    xmlhttp = new ActiveXObject('Msxml2.XMLHTTP');
  } catch (e) {
    try {
      xmlhttp = new ActiveXObject('Microsoft.XMLHTTP');
    } catch (E) {
      xmlhttp = false;
    }
  }
  if (!xmlhttp && typeof XMLHttpRequest!='undefined') {
    xmlhttp = new XMLHttpRequest();
  }
  xmlhttp.open('POST', 'appcontroller', true);
  xmlhttp.setRequestHeader('Content-Type' , 'application/x-www-form-urlencoded');
  var postdata = 'PROCESSID=&PAGEID=&JSPID=jsp/PageElementHelper&CLASSNAME=sample1.QueryTable&body=1&skipCount='+(startRec-1)+'&tableId='+getFieldValue('tableId')+'&viewRows='+getFieldValue('viewRows');
  xmlhttp.onreadystatechange = function() 
  {
    if (xmlhttp.readyState==4) {
      if (xmlhttp.status==200) {
        var xmldoc=xmlhttp.responseXML;
        var table=document.getElementById('resizelist');
        var rows=getTableRows(table);
        var xmlRows=xmldoc.getElementsByTagName('tr');
        if(!xmlRows){
          return;
        }
        for(var i=1,len=rows.length;i<len;++i){
          var cells;
          if(!rows[i]){
            continue;
          }
          cells=rows[i].getElementsByTagName('table');
          var rowid=0;
          for(var j=0,len=cells.length;j<len;++j){
            var val='';
            var xmlRow=xmlRows[i-1];
            if(xmlRow&&xmlRow.childNodes[j]){
              val=getTextNode(xmlRow.childNodes[j]);
              if(val==null) val='';
            }
            if (j==0) {
              rowid=val;
            }
            var cell=cells[j].getElementsByTagName('span')[0];
            if(cell&&cell.textContent) {
              cell.textContent=val;
            }else{
              if(cell.childNodes[0]&&cell.childNodes[0].nodeName=='INPUT'){
                cell.childNodes[1].nodeValue=val;
                var chk=false;
                var id;
                if(xmlRow&&xmlRow.childNodes[j+1]&&xmlRow.childNodes[j+1].childNodes[0].nodeName=='input'){
                  if(getCheckValue(xmlRow.childNodes[j+1])=='1'){
                    chk=true;
                  }
                  id=getCheckId(xmlRow.childNodes[j+1]);
                }
                cell.childNodes[0].checked=chk;
                cell.childNodes[0].setAttribute('id',id);
              }else{
                cell.innerText=val;
              }
            }
          }
          var rowclass='line-even';
          if(rowid%2==1){
            rowclass='line-odd'
          }
          for(var j=0,len=cells.length;j<len;++j){
            var td=cells[j].getElementsByTagName('td')[0];
            var className=td.className;
            td.className=className.replace(/line\-(even|odd)/,rowclass);
          }
        }
      }
    }
  }
  xmlhttp.send(encodeURI(postdata));
  
}
function getTextNode(node) {
  if(node.nodeName=='#text'){
    return node.nodeValue;
  }
  if(node.childNodes){
    for(var i=0;i<node.childNodes.length;++i){
      if(node.childNodes[i].nodeName=='#text'){
        return node.childNodes[i].nodeValue;
      }
    }
  }
  return null;
}
function getCheckValue(node) {
  if(node.nodeName=='input'){
    return node.getAttribute('value')=='1';
  }
  if(node.childNodes){
    for(var i=0;i<node.childNodes.length;++i){
      if(node.childNodes[i].nodeName=='input'){
        return node.childNodes[i].getAttribute('value')=='1';
      }
    }
  }
  return false;
}
function getCheckId(node) {
  if(node.nodeName=='input'){
    return node.getAttribute('id');
  }
  if(node.childNodes){
    for(var i=0;i<node.childNodes.length;++i){
      if(node.childNodes[i].nodeName=='input'){
        return node.childNodes[i].getAttribute('id');
      }
    }
  }
  return null;
}
function doCheckStore(className, id, value) {
  var xmlhttp;
  try {
    xmlhttp = new ActiveXObject('Msxml2.XMLHTTP');
  } catch (e) {
    try {
      xmlhttp = new ActiveXObject('Microsoft.XMLHTTP');
    } catch (E) {
      xmlhttp = false;
    }
  }
  if (!xmlhttp && typeof XMLHttpRequest!='undefined') {
    xmlhttp = new XMLHttpRequest();
  }
  xmlhttp.open('POST', 'appcontroller', true);
  xmlhttp.setRequestHeader('Content-Type' , 'application/x-www-form-urlencoded');
  var postdata = 'PROCESSID=&PAGEID=&JSPID=jsp/sample1/SessionStore&CLASSNAME='+className+'&INDEX='+id+'&VALUE='+value;
  xmlhttp.onreadystatechange = function() 
  {
  }
  xmlhttp.send(encodeURI(postdata));
}
