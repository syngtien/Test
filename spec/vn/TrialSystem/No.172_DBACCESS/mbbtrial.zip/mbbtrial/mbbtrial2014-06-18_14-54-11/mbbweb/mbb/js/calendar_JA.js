
var objCalendar = null;

/**
 * カレンダー画面を開く。
 * @param fieldId カレンダー上で選択した日付をセットするテキストボックスのID
 */
function calendarHelpJS(fieldId) {
	var x=0;
	var y=0;
	x = parseInt((window.screen.width - 210)/2);
	y = parseInt((window.screen.height - 250)/2);
	var win = window.open("", "", "width=210,height=250,screenX="+x+",screenY="+y+",left="+x+",top="+y);
	objCalendar = new Calendar("objCalendar", "opener", fieldId, win);

	objCalendar.disp(0, 0, 0);

}

function calendarHelp(fieldId) {
	var x=0;
	var y=0;
	var width = 200;
	var height = 220;
	x = parseInt((window.screen.width - width)/2);
	y = parseInt((window.screen.height - height)/2);
	var params = 'ID=' + fieldId;
	var win = window.open('appcontroller?APPLICATIONID=SysCalendarHelpAp&' + params, 'calendar', 'scrollbars=no,width=' + width + ',height=' + height + ',screenX=' + x + ',screenY=' + y + ',left=' + x + ',top=' + y);
}

/**
 * カレンダー画面を開く。
 * @param fieldId カレンダー上で選択した日付をセットするテキストボックスのID
 * @param dayClassNameFieldId カレンダー上で選択した日付に対する曜日をセットするテキストボックスのID
 */
function calendarHelp2(fieldId, dayClassNameFieldId) {
	var x=0;
	var y=0;
	var width = 200;
	var height = 220;
	x = parseInt((window.screen.width - width)/2);
	y = parseInt((window.screen.height - height)/2);
	var params = 'ID=' + fieldId;
	if (dayClassNameFieldId != null) {
	  params += '&DAYCLASSNAME=' + dayClassNameFieldId;
	}
	var win = window.open('appcontroller?APPLICATIONID=SysCalendarHelpAp&' + params, 'calendar', 'scrollbars=no,width=' + width + ',height=' + height + ',screenX=' + x + ',screenY=' + y + ',left=' + x + ',top=' + y);
}
/**
 *
 */
function Calendar(name, own, fieldId, obj) {
//	alert(fieldId);
	this.name = name;
	this.own = own;
	this.fieldId = fieldId;
	this.obj = obj;

	this.crntYear = 0;
	this.crntMonth = 0;
	this.crntDay = 0;
	this.crntMonthDay = 0;
	this.crntStartDay = 0;
	this.head = "<html><head>\n"
		+ '<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">\n'
		+ '<link rel="stylesheet" type="text/css" href="./css/calendar.css">\n'
		+ '<title>カレンダー</title>\n';
	this.style = '<style>\n'
		+ 'a.a_move {\n'
		+ ' text-decoration: none;\n'
		+ ' color: #00007f;\n'
		+ '}\n'
		+ 'a.a_day {\n'
		+ '  text-decoration: none;\n'
		+ '  color: #000000;\n'
		+ '}\n'
		+ 'a.a_sat {\n'
		+ '  text-decoration: none;\n'
		+ '  color: blue;\n'
		+ '}\n'
		+ 'a.a_sun {\n'
		+ '  text-decoration: none;\n'
		+ '  color: red;\n'
		+ '}\n'
		+ 'a.a_today {\n'
		+ '  text-decoration: none;\n'
		+ '  color: #000000;\n'
		+ '}\n'
		+ '.cal_back {\n'
		+ '  color: #000000;\n'
		//+ '  background-color: #efeff7;\n'
		+ '  text-align: center;\n'
		+ '}\n'
		
		+ '.cal_head {\n'
		+ '  color: #00007f;\n'
		+ '  background-color: #d7d7ef;\n'
		+ '  text-align: center;\n'
		+ '}\n'
		
		+ '.cal_sun {\n'
		+ '  color: #df0000;\n'
		//+ '  background-color: #efeff7;\n'
		+ '  text-align: center;\n'
		+ '}\n'
		
		+ '.cal_sat {\n'
		+ '  color: #0000df;\n'
		//+ '  background-color: #efeff7;\n'
		+ '  text-align: center;\n'
		+ '}\n'
		
		+ '.cal_today {\n'
		+ '  color: #ffffff;\n'
		+ '  background-color: #99cc00;\n'
		+ '  text-align: center;\n'
		+ '}\n'
		+ '</style>\n';
	this.script = '<script language="JavaScript1.3">\n'
	+ 'function setDate(yyyy,mm,dd){\n'
	+ '  var mmstr = "" + mm;\n'
	+ '  var ddstr = "" + dd;\n'
	+ '  if (mmstr.length==1) mmstr = "0" + mmstr;\n'
	+ '  if (ddstr.length==1) ddstr = "0" + ddstr;\n'
	+ '  var _ret;\n'
	+ '  if (window.opener.document.getElementById)\n'
	+ '    _ret = window.opener.document.getElementById("' + this.fieldId + '");\n'
	+ "  else\n"
	+ '    _ret = window.opener.document.all("' + this.fieldId + '");\n'
	+ '  _ret.value = "" + yyyy + mmstr + ddstr;\n'
	+ '  if (_ret.onchange) _ret.onchange();\n'
	+ '  window.close();\n'
	+ '}\n'
	+ 'function doOnLoad(){\n'
	+ '  var today = document.getElementById("today");\n'
	+ '  if(today)today.focus();\n'
	+ '}\n'
	+ '</script>\n';
	this.headend = '</head><body onload="doOnLoad()">';
	this.foot = '</body></html>';
	return this;
}

Calendar.prototype.disp = function (yyyy, mm, dd) {
	this.setCrnt(yyyy, mm, dd);
	this.writeCal();
}

Calendar.prototype.dispPrev = function () {
	this.setCrntPrev();
	this.writeCal();
}

Calendar.prototype.dispNext = function () {
	this.setCrntNext();
	this.writeCal();
}

Calendar.prototype.writeCal = function () {
	var d = this.obj.document;
	var str = "";
	var i, w;

	// 変数の設定
	var weekHead = new Array('日','月','火','水','木','金','土');

	var today = new Date();
	var thisYear = today.getYear();
	if (thisYear < 1900) { 
		thisYear = thisYear + 1900; 
	}
	var thisMonth = today.getMonth();
	var thisDay = today.getDate();

	// HTMLヘッダの表示
	d.open();
	if (this.head) {
		d.writeln(this.head);
		d.writeln(this.style);
		d.writeln(this.script);
		d.writeln(this.headend);
	}

	// カレンダタイトルの表示
	str += '<table border="2" align="center"><tr>\n';
	str += '<th class="cal_head">';
	str += '<a class="a_move" href="javascript:';
	str += this.own + '.' + this.name + '.dispPrev();">《</a>';
	str += '</th>\n';
	str += '<th colspan="5" class="cal_head">';
	str += this.crntYear + '年' + (this.crntMonth + 1) + '月';
	str += '</th>\n';
	str += '<th class="cal_head">';
	str += '<a class="a_move" href="javascript:';
	str += this.own + '.' + this.name + '.dispNext();">》</a>';
	str += '</th>\n';

	// 曜日タイトルの表示
	str += '</tr>\n<tr>\n';
	str += '<th class="cal_sun">' + weekHead[0] + '</th>\n';
	for (i=1; i<6; i++) {
		str += '<th class="cal_back">' + weekHead[i] + '</th>\n';
	}
	str += '<th class="cal_sat">' + weekHead[6] + '</th>\n';

	// カレンダの表示
	str += '</tr>\n<tr>\n';

	// 月初の空白表示
	for (i = 0; i < this.startDay; i++) {
		str += '<td>&nbsp;</td>\n';
	}
	var para = "";
	var a_classname = "";
	// 1ヶ月の表示
	for (i = 1, w = this.startDay; i <= this.crntMonthDay; i++, w++) {
		// 週単位の改行
		if (w > 6) {
			w = 0;
			str += '</tr>\n</tr>\n';
		}
		// 今日の色分け表示
		if ((i == thisDay)
				&& (this.crntMonth == thisMonth)
				&& (this.crntYear == thisYear)) {
			str += '<td class="cal_today">\n';
			para = "setDate(" + this.crntYear + "," + (this.crntMonth+1) + "," + i +");";
			str += '<span class="linkbutton"><a id="today" class="a_today" href="javascript:' + para + '">' + i + '</a></span>\n</td>\n';

		} else {
			// 曜日による色分け表示
			if (w == 0) {
				str += '<td class="cal_sun">\n';
				a_classname = "a_sun";
			} else if (w == 6) {
				str += '<td class="cal_sat">\n';
				a_classname = "a_sat";
			} else {
				str += '<td class="cal_back">\n';
				a_classname = "a_day";
			}
			para = "setDate(" + this.crntYear + "," + (this.crntMonth+1) + "," + i +");";
			str += '<span class="linkbutton"><a class="' + a_classname + '" href="javascript:' + para + '">' + i + '</a></span>\n</td>\n';
			str += '</td>\n';

		}
	}

	// 月末の空白表示
	for (; w < 7; w++) {
		str += '<td>&nbsp;</td>\n';
	}

	str += '</tr>\n</table>\n';

	// カレンダの表示
	d.writeln(str);

	// HTMLフッタの表示
	if (this.foot) {
		d.writeln(this.foot);
	}
	d.close();
}

Calendar.prototype.setCrnt = function (yyyy, mm, dd) {
	var monthDay = new Array(31,28,31,30,31,30,31,31,30,31,30,31);

	var today = new Date();
	var thisYear = today.getYear();
	if (thisYear < 1900) { 
		thisYear = thisYear + 1900; 
	}
	var thisMonth = today.getMonth();
	var thisDay = today.getDate();

//alert(this.crntYear+'/'+(this.crntMonth+1) + ', ' + yyyy+'/'+mm);

	// 年変換
	if ((typeof(yyyy) == 'undefined') || (yyyy < 1970) || (yyyy > 9999)) {
		this.crntYear = thisYear;
	} else {
		this.crntYear = yyyy;
	}

	// 月変換（0-11）
	if ((typeof(mm) == 'undefined') || (mm < 1) || (mm > 12)) {
		this.crntMonth = thisMonth;
	} else {
		this.crntMonth = mm - 1;
	}
	// うるう年変換
	if (this.crntMonth == 1){
		if (this.crntYear % 4 == 0) {
			this.crntMonthDay = 29;
			if (this.crntYear % 100 == 0) {
				this.crntMonthDay = 28;
				if (this.crntYear % 400 == 0) {
					this.crntMonthDay = 29;
				}
			}
		} else {
			this.crntMonthDay = monthDay[this.crntMonth];
		}
	} else {
		this.crntMonthDay = monthDay[this.crntMonth];
	}

	// 日変換
	if ((typeof(dd) == 'undefined') || (dd < 1) || (dd > this.crntMonthDay)) {
		this.crntDay = thisDay;
	} else {
		this.crntDay = dd;
	}

	// 開始曜日の設定
	var d1 = new Date(this.crntYear + '/' + (this.crntMonth + 1) + '/01');
	this.startDay = d1.getDay();
}

Calendar.prototype.setCrntPrev = function () {
	// 前月のカレンダ表示
	var yyyy = this.crntYear;
	var mm = this.crntMonth;
	var dd = this.crntDay;

	if (mm < 1) {
		yyyy--;
		mm = 12;
	}

	this.setCrnt(yyyy, mm, dd);
}

Calendar.prototype.setCrntNext = function () {
	// 翌月のカレンダ表示
	var yyyy = this.crntYear;
	var mm = this.crntMonth + 2;
	var dd = this.crntDay;

	if (mm > 12) {
		yyyy++;
		mm = 1;
	}

	this.setCrnt(yyyy, mm, dd);
}

