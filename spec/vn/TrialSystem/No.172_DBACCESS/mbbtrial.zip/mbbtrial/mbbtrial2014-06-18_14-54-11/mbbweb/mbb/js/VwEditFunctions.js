/**
 * VwEditFunctions
 * マウスイベント処理
 */
LAST_MODIFIED('2005.02.08', '1.0.33');

/** エレメントのマウスによる移動時の修正高さ(px) */
var MOUSEMOVEHEIGHT = DISPLAYROWHEIGHT * 1;

/** エレメントのカーソルキーによる移動時の移動高さ(px) */
var ARROWKEYHEIGHT = DISPLAYROWHEIGHT * 1;

//////
//global

/**
 * カーソルの元座標 数値型
 */
var m_orgMouseX;
var m_orgMouseY;

/**
 * ドラッグ時の座標計算
 */
var m_dragManager = new DragManager();

/**
 * マウスの左ボタンステータス(0:UP,1:DOWN) 数値型
 */
var m_statusMouse = 0;

/**
 * zIndexの最大値(table,panel以外)
 */
var m_maxzIndex = '';

/**
 * 範囲選択中
 */
var m_selecting = false;

/**
 * 移動中
 */
var m_dragging = false;

/**
 * ブラウザ識別フラグ オブジェクト
 * isIE true
 *      false
 * isNN true
 *      false
 */
var m_browserType = new BrowserType();
function BrowserType() {
  if(navigator.appName == 'Microsoft Internet Explorer'){
    this.isIE = true;
    this.isNN = false;
  }else if(navigator.appName == 'Netscape'){
    this.isIE = false;
    this.isNN = true;
  }else{
    this.isIE = false;
    this.isNN = false;
  }

  if(-1 < navigator.userAgent.indexOf('MSIE 5.0')){
    this.isIE5 = true;
  }
  var pos = navigator.userAgent.indexOf('Gecko');
  if(-1 < pos){
    this.gecko = Number(navigator.userAgent.substring(pos+6,pos+14));
  }
}

//////
//function

/**
 * ドキュメントにイベントを設定
 * @param  :
 * @return :
 */
function setMouseEvent(){
  var objDoc = getDocumentElementById(ELEMENTID_FIRSTFORM);
  objDoc.onmouseup    = funcOnMouseUp;
  objDoc.onmousemove  = funcOnMouseMove;
  objDoc.onmousedown  = funcOnMouseDown;
  
  var body = document.body;
  if(body) {
    body.onkeydown = funcOnKeyDown;
    body.onselectstart = function() {return false};
    body.style.cursor = 'default';
  }
}

/**
 * イベントオブジェクトを返す
 * @param  :e イベントオブジェクト(IE以外)
 * @return :  イベントオブジェクト
 */
function getEventObj(e){
  if(m_browserType.isIE){
    return event;
  }else{
    return e;
  }
}

/**
 * 範囲選択のエレメントID
 */
var DRAGSELECTELEMENTID = 'fld_ranger'
/**
 * 範囲選択のエレメントを取得
 */
function getDragSelectElement() {
  return document.getElementById(DRAGSELECTELEMENTID);
}


/**
 * 範囲選択の枠HTML
 */
function getRangeHtml(_top, _left, _width, _height) {
  if(m_browserType.isNN){
    _left += m_propTblWidth;
  }
  
  if(!m_rangeHtmlParts) {
    m_rangeHtmlParts = [
      '<div id="' + DRAGSELECTELEMENTID + '" style="top:',
      'px; left:',
      'px; width:',
      'px; height:',
      'px; border:' + pref.view.selectedareaborder + '; position:absolute; z-index:1000000;"></div>'
    ];
  }
  return m_rangeHtmlParts[0] + _top + 
         m_rangeHtmlParts[1] + _left + 
         m_rangeHtmlParts[2] + _width + 
         m_rangeHtmlParts[3] + _height + 
         m_rangeHtmlParts[4];
/*
  var html = '<div id="' + DRAGSELECTELEMENTID + '"'
  + ' style="width:' + _width + 'px; height:' + _height + 'px;'
  + ' top:' + _top  + 'px; left:' + _left + 'px;'
  + ' border:1px red dotted; position:absolute; z-index:1000000;"></div>';

  return html;
*/
}
var m_rangeHtmlParts;

/**
 * マウスボタン押下時の処理
 * @param  :e オブジェクト イベントオブジェクト
 * @return :
 */
function funcOnMouseDown(e){

  //ロード時のタイムラグ対処
  if(typeof(m_statusMouse) == 'undefined') return;

  //範囲選択の初期化
  if(getDragSelectElement()){
    setOuterHTML(getDragSelectElement(), '');
  }

  //イベントオブジェクト設定
  var objEvent = getEventObj(e);

  //mousedownした時のカレントを取得
  var curEvtSrc = (m_browserType.isIE)?objEvent.srcElement : objEvent.target;
  var curIdSet  = getCurrentElement(curEvtSrc);

  //設定中のプロパティを更新する
  //回避できないエラー
  //m_currentElementが変更したのにm_focusedPropIdが変わっていない時
  //プロパティテーブルにm_focusedPropIdが無い場合が起こる
  if(m_focusedPropId != ''){
    try{
      var newValue = getDocumentElementById(m_focusedPropId).value;
      if(m_focusedPropValue != newValue) {
        doChangeProperty(m_focusedPropId, newValue, m_selection.front, m_selection.cell, 'onMouseDown');
      }
    } catch(e) {
    }
    m_focusedPropId = '';
  }

  // 開いているメニューを閉じる
  if(m_menuBar) {
    m_menuBar.close();
  }

  if(objEvent.altKey){
    changeResizeHandleDisplayMode();
  }
  
  // 現在の選択
  var front = m_selection.front;
  
  // あとで比較する状態
  m_selection.savePoint();

  if(objEvent.ctrlKey) {
    // ctrl + クリック時
    if(m_selection.has(curIdSet.id)) {
      // 選択解除
      m_selection.remove(curIdSet.id);
    } else {
      // 追加
      m_selection.add(curIdSet.id, curIdSet.td);
    }
  } else {
    // クリック時

    if(objEvent.shiftKey) {
      if(curIdSet.id == m_selection.front && m_selection.length() == 1) {
        // 親を選択
        var parentIds = getParentElementId(curIdSet.id);
        if(parentIds != null) {
          curIdSet = parentIds;
        }
      }
    }

    if(!m_selection.has(curIdSet.id)) {
      // 今まで選択されていたものを解除
      m_selection.removeAll();
    }
    m_selection.add(curIdSet.id, curIdSet.td);
  }

  if(curIdSet.id == ELEMENTID_FIRSTFORM) {
    // 範囲選択開始
    
    //カスタマイズ時は範囲選択使用不可
    if(m_monitorEditStatus == 2){
      //マウスステータスをUPに設定
      m_statusMouse = 0;
    }else{
      //マウスステータスをDOWNに設定
      m_statusMouse = 1;
      //ドラッグ開始位置(範囲選択)
      m_orgMouseX = objEvent.clientX - m_propTblWidth + document.body.scrollLeft;
      m_orgMouseY = objEvent.clientY + document.body.scrollTop;

      m_selecting = true;
    }

  } else if(curIdSet.id == m_selection.front) {
    // 移動
    
    if(m_monitorEditStatus == 2 && !getDataSet(curIdSet.id).getCustomizableItems().mobility) {
      //移動不可
    } else {
      //移動開始座標のセット(数値で取得)
      var tmpCurPrtNode = getDocumentElementById(curIdSet.id + '_span');

      //クリックしたポインタの座標(数値で取得)
      m_orgMouseX = objEvent.clientX + document.body.scrollLeft;
      m_orgMouseY = objEvent.clientY + document.body.scrollTop;
      
      //m_dragManager.setStartingLocation(curIdSet.id, tmpCurPrtNode.offsetLeft, tmpCurPrtNode.offsetTop);
      m_dragManager.setStartPoint(m_orgMouseX, m_orgMouseY, (tmpCurPrtNode.offsetLeft % pref.operation.get('snap')));
      var tmpPageWidth  = getDataSet(ELEMENTID_FIRSTFORM).getProperty('pagewidth');
      var tmpPageHeight = getDataSet(ELEMENTID_FIRSTFORM).getProperty('pageheight');
      m_dragManager.setLimitPoint(tmpPageWidth, tmpPageHeight);
      
      for(var id in m_selection.elements) {
        //移動カスタマイズのチェック
        if(m_monitorEditStatus == 2 && !getDataSet(id).getCustomizableItems().mobility) continue;
        
        var tmpCurPrtNode = getDocumentElementById(id + '_span');
        m_dragManager.setStartingLocation(id, tmpCurPrtNode.offsetLeft, tmpCurPrtNode.offsetTop);
      }
      
      m_dragging = true;

      setzIndex();
    }
  }

  if(m_selection.changed()) {

    //log.debug('updating property area. [VwEditFunctions.js/funcOnMouseDown]');
    m_selection.updatePropertyArea();

    if(m_selection.front == ELEMENTID_FIRSTFORM){
      m_menuBar.disableMenuItem('EDIT', 'CUT');
      m_menuBar.disableMenuItem('EDIT', 'COPY');
      m_menuBar.disableMenuItem('EDIT', 'DELETE');
    } else if(m_selection.save.front == ELEMENTID_FIRSTFORM){
      m_menuBar.enableMenuItem('EDIT', 'CUT');
      m_menuBar.enableMenuItem('EDIT', 'COPY');
      m_menuBar.enableMenuItem('EDIT', 'DELETE');
    }
  }

  return;
}

/**
 * 親オブジェクトを取得する
 */
function getParentElementId(childElementId) {
  var childTop = parseInt(getDataSet(childElementId).getProperty('top'));
  var childLeft = parseInt(getDataSet(childElementId).getProperty('left'));
  var parentTdId = '';
  for(var i = 0; i < m_addElementArray.length; i++) {
    var parentId = m_addElementArray[i];
    if(parentId == childElementId) continue;
    var dataset = getDataSet(parentId);
    if(dataset) {
      if(dataset.isType(TYPE.TABLE)) {
        if(isInTable(dataset)) {
          return {id:parentId, td:parentTdId};
        }
      } else if(dataset.isType(TYPE.PANEL)) {
        if(isInPanel(dataset)) {
          return {id:parentId, td:''};
        }
      }
    }
  }
  return null;

  function isInTable(ds) {
    var _top = parseInt(ds.getProperty('top'));
    if(_top > childTop) return false;
    var _left = parseInt(ds.getProperty('left'));
    if(_left > childLeft) return false;
    
    var maxrows = getDesignTableRows(ds);
    for(var row = 1; row <= maxrows; row++) {
      parentTdId = getCellId(parentId, row,1);
      var tdds = getDataSet(parentTdId);
      var tdheight = parseInt(tdds.getProperty('cellheight'));
      if(_top + tdheight > childTop) {
        break;
      }
      _top += tdheight;
    }
    if(row > maxrows) return false;
    var maxcols = parseInt(ds.getProperty('tablecols'));
    for(var col = 1; col <= maxcols; col++) {
      parentTdId = getCellId(parentId, row, col);
      var tdds = getDataSet(parentTdId);
      var tdwidth = parseInt(tdds.getProperty('cellwidth'));
      if(_left + tdwidth > childLeft) {
        break;
      }
      _left += tdwidth;
    }
    if(col > maxcols) return false;
    return true;
  }

  function isInPanel(ds) {
    var _top = parseInt(ds.getProperty('top'));
    if(_top > childTop) return false;
    var _left = parseInt(ds.getProperty('left'));
    if(_left > childLeft) return false;
    var _width = parseInt(ds.getProperty('width'));
    if(_left + _width <= childLeft) return false;
    var _height = parseInt(ds.getProperty('height'));
    if(_top + _height <= childTop) return false;
    return true;
  }
}

/**
 * 
 */
function changeResizeHandleDisplayMode() {
  if(m_monitorEditStatus == 2) return;

  var prog = new WindowStatusProgressRatio(m_selection.length(), getMessage('S0008'));
  
  if(!m_displayResizeHandle) {
    // リサイズハンドルを表示するに切り替え
    m_displayResizeHandle = true;
    for(var id in m_selection.elements) {
      prog.update();
      setResizeHandle2(id);
    }
  } else {
    // リサイズハンドルを表示しないに切り替え
    m_displayResizeHandle = false;
    for(var id in m_selection.elements) {
      prog.update();
      removeResizeHandle(id);
    }
  }
  
  prog.release();
}

/**
 * マウスボタン離時の処理
 * @param  :
 * @return :
 */
function funcOnMouseUp(e){

  //ロード時のタイムラグ対処
  if(typeof(m_statusMouse) == 'undefined') return;

  var objEvent = getEventObj(e);
  
  //m_selecting = false;
  
  if(m_resizingByHandleInfo) {
    return resizeByHandleEnd(objEvent);
  }

  // あとで比較する状態
  m_selection.savePoint();
  
  //範囲選択時
  if(m_selecting){
    if(!getDragSelectElement()){
      //document.getElementById(ELEMENTID_FIRSTFORM).innerHTML += getRangeHtml(0,0,0,0);
      m_selecting = false;
      return;
    }

    //マウスステータスをUPに設定
    m_statusMouse = 0;

    //範囲選択の座標情報を数値で取得
    var area = new Object()
    var rangeNodeStyle = getDragSelectElement().style;
    area.top      = parseInt(rangeNodeStyle.top.replace('px', ''));
    area.width    = parseInt(rangeNodeStyle.width.replace('px', ''));
    area.height   = parseInt(rangeNodeStyle.height.replace('px', ''));
    if(m_browserType.isIE){
      area.left = parseInt(rangeNodeStyle.left.replace('px', ''));
    }else{
      area.left = parseInt(rangeNodeStyle.left.replace('px', '')) - m_propTblWidth;
    }
    area.right = area.left + area.width;
    area.bottom = area.top + area.height;
    
    var progressBar = new WindowStatusProgressBar(m_addElementArray.length);
    
    for(var i = 0; i < m_addElementArray.length; i++) {
      progressBar.update();
      var dataset     = getDataSet(m_addElementArray[i]);
      if(!dataset.isType(TYPE.FORM) && !dataset.isType(TYPE.CELL)){
        var top  = parseInt(dataset.getProperty('top'));
        var left = parseInt(dataset.getProperty('left'));
        //Y座標チェックs
        if((area.top <= top) && ((area.bottom) >= top)){
          //X座標のチェック
          if((area.left <= left) && ((area.right) >= left)){
            m_selection.add(m_addElementArray[i]);
          }
        }
      }
    }
    progressBar.release();
    
    //範囲選択HTML削除
    setOuterHTML(getDragSelectElement(), '');
    rangeNodeStyle.visibility = 'hidden';
    rangeNodeStyle.top = area.top;
    rangeNodeStyle.left = area.left;
    rangeNodeStyle.width = 0;
    rangeNodeStyle.height = 0;

    m_selecting = false;

  }

  if(m_dragging) {  
    //マウスカーソルの移動距離を取得
    var moveToX  = objEvent.clientX + document.body.scrollLeft;
    var moveToY = objEvent.clientY + document.body.scrollTop;
    m_dragManager.setDragPoint(moveToX, moveToY);
    
    //コマンド作成
    var objCmdSet = new UndoableCommandSet(getLiteral('command.move'));

    for(var id in m_selection.elements) {
      if(!m_dragManager.draggingObjects[id]) continue;
      moveObjectForMouseUp(id, objEvent.shiftKey, objCmdSet);
    }
    
    if(objCmdSet.commands.length > 0) {
      m_undoManager.execute(objCmdSet);
    }

    //z-index調整
    setzIndex();

    m_dragging = false;
  }  
/**/

  if(m_selection.changed()) {

    //log.debug('updating property area. [VwEditFunctions.js/funcOnMouseUp]');
    m_selection.updatePropertyArea();

    if(m_selection.front == ELEMENTID_FIRSTFORM){
      m_menuBar.disableMenuItem('EDIT', 'CUT');
      m_menuBar.disableMenuItem('EDIT', 'COPY');
      m_menuBar.disableMenuItem('EDIT', 'DELETE');
    } else if(m_selection.save.front == ELEMENTID_FIRSTFORM){
      m_menuBar.enableMenuItem('EDIT', 'CUT');
      m_menuBar.enableMenuItem('EDIT', 'COPY');
      m_menuBar.enableMenuItem('EDIT', 'DELETE');
    }
  }
}

/**
 * マウスボタン離時の処理
 * @param  :
 * @return :
 */
function moveObjectForMouseUp(objectId, gridFlg, objCmdSet) {
  var objDS     = getDataSet(objectId);
  var parentDoc = getDocumentElementById(objectId).parentNode;

  parentDoc.style.position = 'absolute';

  //プロパティテーブルにセットする値
  var drop = m_dragManager.getDropLocation(objectId, gridFlg);
  
  // 位置更新
  parentDoc.style.left = drop.x;
  parentDoc.style.top = drop.y;

  // 属性欄更新
  if(objectId == m_selection.current.front) {

    getDocumentElementById('fld_left').value = drop.x;
    getDocumentElementById('fld_top').value = drop.y;
  }

  //undo&redo用にmousedown時のtop&leftを取得
  var beforeLeft = parseInt(objDS.getProperty('left'));
  var beforeTop = parseInt(objDS.getProperty('top'));

  // 属性値更新
  objDS.setProperty('left', drop.x);
  objDS.setProperty('top', drop.y);

  // 移動後の属性値
  var afterLeft = parseInt(objDS.getProperty('left'));
  var afterTop  = parseInt(objDS.getProperty('top'));

  //(座標移動があったときのみ)
  if(beforeLeft != afterLeft || beforeTop != afterTop){

    //undo&redo用
    var objParam = createMoveUndoParam(objectId, beforeLeft, beforeTop, afterLeft, afterTop);
    var cmdMove = createActionCommand(objParam);
    objCmdSet.add(cmdMove);

    //カスタマイズ時、「移動」カスタマイズ可能、「移動設定」自動チェック
    customizedMobilityChecker(objDS, afterTop, afterLeft, objectId);
  }
}

/**
 * マウス移動時の処理
 * @param  :
 * @return :
 */
function funcOnMouseMove(e){

  //ロード時のタイムラグ対処
  if(typeof(m_statusMouse) == 'undefined') return;

  //ロード時のタイムラグ対処
  if(!m_statusMouse) m_statusMouse = 0;

  //イベントオブジェクト取得
  var objEvent = getEventObj(e);

  if(m_resizingByHandleInfo) {
    return resizeByHandleMove(objEvent);
  }
  
  m_dblClickValid = false;
  
  //範囲選択時
  
  if(m_selecting) {
    
    //現在のマウスカーソル位置
    var tmpNowMouseX = objEvent.clientX - m_propTblWidth + document.body.scrollLeft;
    var tmpNowMouseY = objEvent.clientY + document.body.scrollTop;
    //カーソルの移動距離を取得
    var moveWidth  = tmpNowMouseX - m_orgMouseX;
    var moveHeight = tmpNowMouseY - m_orgMouseY;
//    m_dragManager.setDragPoint(tmpNowMouseX, tmpNowMouseY);
    
    //移動距離がない場合は戻す
    if(moveWidth == 0 && moveHeight == 0) return;

    //カーソル移動距離から範囲選択のtop,left,width,heightを生成(マイナス方向時は移動方向に対してカーソルから10px大きいサイズ)
    //left,width
    var strSetWidth = Math.abs(parseInt(moveWidth));
    if(moveWidth < 0){
      var strSetLeft  = (parseInt(tmpNowMouseX) - 10);
    }else{
      var strSetLeft  = m_orgMouseX;
    }
    //top,height
    var strSetHeight = Math.abs(parseInt(moveHeight));
    if(moveHeight < 0){
      var strSetTop    = (parseInt(tmpNowMouseY) - 10);
    }else{
      var strSetTop    = m_orgMouseY;
    }

    //範囲選択の有無
    if(!getDragSelectElement()){
      getDocumentElementById(ELEMENTID_FIRSTFORM).innerHTML += getRangeHtml(strSetTop,strSetLeft,strSetWidth,strSetHeight);
    } else {
      if(m_browserType.isIE){
      //IE
        var objRangeDoc = getDragSelectElement();
        objRangeDoc.style.visibility = 'visible';
        objRangeDoc.style.width  = strSetWidth;
        objRangeDoc.style.height = strSetHeight;
        objRangeDoc.style.top    = strSetTop;
        objRangeDoc.style.left   = strSetLeft;
      }else{
      //IE以外
        var objRangeDoc = getDragSelectElement();
        var strSetStyle  = 'width:' + strSetWidth + 'px; height:' + strSetHeight + 'px; top:';
            strSetStyle += strSetTop + 'px; left:' + (parseInt(strSetLeft) + m_propTblWidth) + 'px; border:' + pref.view.selectedareaborder + '; position:fixed; z-index:1000000;';
        objRangeDoc.setAttribute('style',strSetStyle);
      }
    }
    return;
  }

  if(m_dragging) {
    //カーソルの移動先
    var moveToX  = objEvent.clientX + document.body.scrollLeft;
    var moveToY = objEvent.clientY + document.body.scrollTop;
    m_dragManager.setDragPoint(moveToX, moveToY);

    for(var id in m_selection.elements) {
      if(!m_dragManager.draggingObjects[id]) continue;
      moveObjectForMouseMove(id, objEvent.shiftKey);
    }
  }
}

/**
 * マウス移動時の処理
 * @param  :
 * @return :
 */
function moveObjectForMouseMove(objectId, gridFlg) {
  var parentDoc = getDocumentElementById(objectId).parentNode;

  parentDoc.style.position = 'absolute';

  //プロパティテーブルにセットする値
  var drop = m_dragManager.getDropLocation(objectId, gridFlg);
  
  parentDoc.style.left = drop.x;
  parentDoc.style.top = drop.y;

  if(objectId == m_selection.current.front) {

    //共通プロパティセット
    try {
      getDocumentElementById('fld_left').value = drop.x;
      getDocumentElementById('fld_top').value = drop.y;
    } catch(e) {
    }
  }

}

/**
 * キー押下時の処理
 * @param  :e オブジェクト イベントオブジェクト(IE以外)
 * @return :
 */
function funcOnKeyDown(e, _option){
  if(e) {
    e.cancelBubble = true;
  }
  var objEvent = getEventObj(e);
  objEvent.cancelBubble = true;

  var editable = false;
  if(objEvent.srcElement && objEvent.srcElement.isContentEditable) {
    editable = true;
  } else if(objEvent.target) {
    //showObject(objEvent.target);
    if(objEvent.target.tagName == 'INPUT' &&
       objEvent.target.type == 'text' &&
       !objEvent.target.readOnly) {
      editable = true;
    }
  }

  var selectable = false;
  if(objEvent.srcElement) {
    if(objEvent.srcElement.tagName == 'SELECT' &&
       objEvent.srcElement.size <= 0) {
      selectable = true;
    }
    //showObject(objEvent.srcElement);

  } else if(objEvent.target) {
    if(objEvent.target.tagName == 'SELECT' &&
       objEvent.target.size <= 0) {
      selectable = true;
    }
    //showObject(objEvent.target);
  }
  
  //if(_option == 'selectable') {
  //  selectable = true;
  //}
  
  if(objEvent.ctrlKey) {
    switch(objEvent.keyCode) {
//    case KEYCODE.H:
//      changeLocatePropertyTable();
//      objEvent.keyCode = 0;
//      objEvent.returnValue  = false;
//      return objEvent.returnValue;

    case KEYCODE.N:
      doCommandNew();
      return keyEventProcessed(objEvent);

    case KEYCODE.O:
      doCommandOpen();
      return keyEventProcessed(objEvent);

    case KEYCODE.S:
      if(m_menuBar.documentDirty) {
        doCommandSave();
      }
      return keyEventProcessed(objEvent);

    case KEYCODE.F:
      doCommandFind();
      return keyEventProcessed(objEvent);
  
    case KEYCODE.D:
      if(objEvent.shiftKey && objEvent.altKey) {
        openVariableFinder();
        return keyEventProcessed(objEvent);
      }

    case KEYCODE.L:
      if(objEvent.shiftKey && objEvent.altKey) {
        log.open();
        return keyEventProcessed(objEvent);
      }

    default:
      if(editable) {
        objEvent.returnValue  = true;
        return objEvent.returnValue;
      }
    }

    switch(objEvent.keyCode) {
    case KEYCODE.Z:
      doCommandUndo();
      return keyEventProcessed(objEvent);

    case KEYCODE.Y:
      doCommandRedo();
      return keyEventProcessed(objEvent);

    default:
      if(selectable) {
        objEvent.returnValue  = true;
        return objEvent.returnValue;
      }
    }

    switch(objEvent.keyCode) {
    case KEYCODE.V:
      doCommandPaste();
      return keyEventProcessed(objEvent);

    default:
      if(_option == 'selectcopy') {
        objEvent.returnValue  = true;
        return objEvent.returnValue;
      }
    }

    switch(objEvent.keyCode) {
    case KEYCODE.X:
      doCommandCut();
      return keyEventProcessed(objEvent);

    case KEYCODE.C:
      doCommandCopy();
      //objEvent.keyCode = 0;
      objEvent.returnValue = true;
      return objEvent.returnValue;

    case KEYCODE.A:
      if(m_monitorEditStatus == 2 || m_pageClass == '1') {
        return keyEventProcessed(objEvent);
      }
      doCommandSelectAll();
      return keyEventProcessed(objEvent);
    }
  }

  if(editable || selectable) {
    objEvent.returnValue  = true;
    return objEvent.returnValue;
  }  

  switch(objEvent.keyCode) {
  case KEYCODE.BACKSPACE:
      return keyEventProcessed(objEvent);

  case KEYCODE.DELETE:
    doCommandDelete(objEvent.shiftKey);
      return keyEventProcessed(objEvent);

  //case KEYCODE.PAGEUP:
  //case KEYCODE.PAGEDOWN:
  //case KEYCODE.END:
  //case KEYCODE.HOME:
  case KEYCODE.ARROWWEST:
  case KEYCODE.ARROWNORTH:
  case KEYCODE.ARROWEAST:
  case KEYCODE.ARROWSOUTH:
    if(objEvent.shiftKey && objEvent.ctrlKey) {
      objEvent.returnValue  = true;
    } else {
      moveElement(objEvent.keyCode, objEvent.ctrlKey);
      return keyEventProcessed(objEvent);
    }
    return objEvent.returnValue;

  case KEYCODE.TAB:
    if(_option == 'property') {
      objEvent.returnValue  = true;
    } else {
      jumpItem(objEvent.shiftKey);
      return keyEventProcessed(objEvent);
    }
    return objEvent.returnValue;

  }

  objEvent.returnValue  = true;
  return objEvent.returnValue;

  /*
   * システムのデフォルトの処理をさせない
   */
  function keyEventProcessed(evt) {
    evt.returnValue  = false;
    try{
      evt.keyCode = 0;
    }catch(e){}
    return false;
  }
}

/**
 * カーソルキーでのエレメントの移動
 * @param  :code    数値型   キーコード
 *          ctrlKey ブール値 ctrlKeyの押下状態
 * @return :
 */
function moveElement(code, ctrlKey){
  if(m_selection.front == ELEMENTID_FIRSTFORM) return;

     
  //ctrlKey押下時は横移動サイズを10pxにする
  var tmpSideStep = pref.operation.get('arrow');
  if(ctrlKey){
    tmpSideStep = pref.operation.get('ctrlarrow');
  }

  //一括コマンド作成
  var objCmdSet = new UndoableCommandSet(getLiteral('command.move'));
  objCmdSet.add(new CommandSelect(true, false));

  for(var curId in m_selection.elements){
    var objDS = getDataSet(curId);
    //移動カスタマイズのチェック
    if(m_monitorEditStatus == 2 && !objDS.getCustomizableItems().mobility) continue;

    var docNode    = getDocumentElementById(curId);
    var objPrtDoc  = docNode.parentNode;
    var nowPosTop  = parseInt(objPrtDoc.style.top.replace('px', ''));
    var nowPosLeft = parseInt(objPrtDoc.style.left.replace('px', ''));
    var pageDS     = getDataSet(ELEMENTID_FIRSTFORM);
    var pageHeight = parseInt(pageDS.getProperty('pageheight'));
    var pageWidth  = parseInt(pageDS.getProperty('pagewidth'));
    
    switch(code){
    case KEYCODE.PAGEUP:  //PageUp
      objPrtDoc.style.top = 0;
      break;
    case KEYCODE.PAGEDOWN:  //PageDown
      objPrtDoc.style.top = pageHeight - docNode.offsetHeight;
      break;
    case KEYCODE.END:  //End
      objPrtDoc.style.left = pageWidth - docNode.offsetWidth;
      break;
    case KEYCODE.HOME:  //Home
      objPrtDoc.style.left = 0;
      break;
    case KEYCODE.ARROWWEST:  //left
      if(nowPosLeft - tmpSideStep < 0) {
        objPrtDoc.style.left = 0;
      } else {
        objPrtDoc.style.left = nowPosLeft - tmpSideStep;
      }
      break;
    case KEYCODE.ARROWNORTH:  //up
      if(nowPosTop - ARROWKEYHEIGHT < 0) {
        objPrtDoc.style.top = 0;
      } else {
        objPrtDoc.style.top = nowPosTop - ARROWKEYHEIGHT;
      }
      break;
    case KEYCODE.ARROWEAST:  //right
      objPrtDoc.style.left = nowPosLeft + tmpSideStep;
      break;
    case KEYCODE.ARROWSOUTH:  //down
      objPrtDoc.style.top = nowPosTop + ARROWKEYHEIGHT;
      break;
    }

    referOffset(curId);

    var tmpSetLeft  = parseInt(objPrtDoc.style.left.replace('px', ''));
    var tmpSetTop = parseInt(objPrtDoc.style.top.replace('px', ''));

    //プロパティウィンドウにセット
    if(curId == m_selection.current.front) {
      getDocumentElementById('fld_top').value  = tmpSetTop;
      getDocumentElementById('fld_left').value = tmpSetLeft;
    }
    
    //DataSetにプロパティセット
    objDS.setProperty('top', tmpSetTop);
    objDS.setProperty('left', tmpSetLeft);
    // undo&redo
    var objParam = createMoveUndoParam(curId, nowPosLeft, nowPosTop, tmpSetLeft, tmpSetTop);
    var cmd = createActionCommand(objParam);
    objCmdSet.add(cmd);

    //z-index調整
    //setzIndex();

    //カスタマイズ時、「移動」カスタマイズ可能、originalvalueと移動後の座標が違う時、「移動設定」自動チェック
    customizedMobilityChecker(objDS, tmpSetTop, tmpSetLeft,curId);

  }

  //undo&redo
  objCmdSet.add(new CommandSelect(false, false));
  m_undoManager.execute(objCmdSet);
}

/**
 * 矢印キーで移動時に押しっぱなしにしている間も表示されるように
 */
function referOffset(objectId){
  var tmpEleWidth = getDocumentElementById(objectId).offsetWidth;
  var tmpEleHeight = getDocumentElementById(objectId).offsetHeight;
}

/**
 * 配置されているエレメントのzIndexの最大値を取得する
 * @param  :numType 数値型 0:table,panel以外 1:table,panel
 * @return :zIndex最大値(table,panel時は自身のzIndex)
 */
function getMaxzIndex(numType){
  var zIdx = 0;
  if(numType == 0){
    var tmpAddEleLen = m_addElementArray.length;
    var tmpZidx = 0;
    for(var i=1; i<tmpAddEleLen; i++){
      try{
        if(getDocumentElementById(m_addElementArray[i] + '_span').style.zIndex){
          tmpZidx = getDocumentElementById(m_addElementArray[i] + '_span').style.zIndex;
        }
      }catch(e){
        tmpZidx = 10001;
      }
      if(zIdx < tmpZidx){
        zIdx = tmpZidx;
      }
    }
    if(zIdx < 10000){
      zIdx = parseInt(zIdx) + 10000;
    }
  }else{
    var objDS = getDataSet(m_selection.front);
    if(parseInt(objDS.getProperty('top')) + parseInt(objDS.getProperty('left')) < 0){
      zIdx = 0;
    }else{
      zIdx = parseInt(objDS.getProperty('top')) + parseInt(objDS.getProperty('left'));
    }
  }
  return parseInt(zIdx);
}

/**
 * 選択項目にzIndexを付加する
 * @param  :
 * @return :
 */
function setzIndex(){

  if(m_selection.front == ELEMENTID_FIRSTFORM) return;

  //前後関係矯正処理(table、panelは1～10000、その他のエレメントは10000～)
  //配置エレメントの初回クリック時にzIndexの最大値を保存
  //２回目以降は最大値をインクリメントして使用
  var objDS   = getDataSet(m_selection.front);
  var docNode = getDocumentElementById(m_selection.front + '_span');
  if(!objDS.isType(TYPE.PANEL) && !objDS.isType(TYPE.TABLE)){
    //table,panel以外
    if(m_maxzIndex == ''){
      var tmpMaxIdx = parseInt(getMaxzIndex(0)) + 1;
      docNode.style.zIndex = tmpMaxIdx;
      m_maxzIndex = tmpMaxIdx;
    }else{
      docNode.style.zIndex = parseInt(m_maxzIndex) + 1;
      m_maxzIndex = parseInt(m_maxzIndex) + 1;
    }
  }else{
    //table,panel
    docNode.style.zIndex = getMaxzIndex(1);
  }
}

/**
 * m_currentElement及びm_currentTdObjectを検索
 * @param  :evtSrc ノード event.srcElement(e.target)
 * @return :rtnObj オブジェクト id(m_currentElement)
 *                              td(m_currentTdObjectId)
 */
function getCurrentElement(evtSrc){
  var rtnObj = new Object();
      rtnObj.id = '';
      rtnObj.td = '';

  if(evtSrc.id == DRAGSELECTELEMENTID){
    rtnObj.id = ELEMENTID_FIRSTFORM;
    rtnObj.td = '';
  }else if(evtSrc.id == ELEMENTID_FIRSTFORM){
    rtnObj.id = ELEMENTID_FIRSTFORM;
    rtnObj.td = '';
  }else{
    //検索用ノード
    try{
      var tmpSerchEleNode = evtSrc;
    }catch(err){
      var tmpSerchEleNode = null;
    }
    if(!tmpSerchEleNode){
      rtnObj.id = ELEMENTID_FIRSTFORM;
    }else{
      //レイヤ用SPANノード検索：検索条件は親のIDがELEMENTID_FIRSTFORM(ループ回数は編集用HTMLの最大階層数：決め打ち)
      for(var i=0; i<10; i++){
        try{
          var pageId = tmpSerchEleNode.parentNode.id;
        }catch(err){
          var pageId = '';
        }
        if(pageId == ELEMENTID_FIRSTFORM){
          rtnObj.id = tmpSerchEleNode.id.replace('_span', '');
          break;
        }else{
          //tdwidth,tdheightからの遷移時
          try{
            tmpSerchEleNode = tmpSerchEleNode.parentNode;
          }catch(e){}
        }
      }
      if(!rtnObj.id || rtnObj.id == ''){
        rtnObj.id = ELEMENTID_FIRSTFORM;
      }
    }

    //TABLE時セル取得
    if(getDataSet(rtnObj.id).isType(TYPE.TABLE)){
      try{
        var tmpTdSerchEleNode = evtSrc;
        //最下層のTDノード検索：検索条件はinnerHTMLが&nbsp;
        for(var i=0; i<10; i++){
          if(tmpTdSerchEleNode.innerHTML == '&nbsp;'){
            break;
          }else{
            tmpTdSerchEleNode = tmpTdSerchEleNode.childNodes.item(0);
          }
        }
        rtnObj.td = tmpTdSerchEleNode.parentNode.parentNode.parentNode.id;
      }catch(err){
      }

      //エラー対処(セルを指定できない時)
      if(!rtnObj.td || rtnObj.td.match(rtnObj.id) == null){
        rtnObj.td = getCellId(rtnObj.id);
      }
    }
  }
  return rtnObj;
}

/**
 * オブジェクトの移動位置を計算する機能
 */
function DragManager() {
  
  // ドラッグ開始時のポインタの座標
  this.startX = 0;
  this.startY = 0;
  // ドラッグ中のポインタの座標
  this.dragX = 0;
  this.dragY = 0;
  // ドラッグ開始時からの移動距離
  this.moveX = 0;
  this.moveY = 0;
  // ドラッグ開始時からの移動距離で吸着された位置
  this.moveXg = 0;
  this.moveYg = 0;
  // 移動中のオブジェクトの座標を保持する
  this.draggingObjects = new Object();
  // 吸着する位置
  this.snapX = 0;
  this.snapY = 0;
  // 移動範囲の制限
  //this.limitX = 100;
  //this.limitY = 100;
  
  // 吸着する範囲(px)
  var SNAPWIDTH = pref.operation.get('snap');
  var PLAY = pref.operation.get('play');
  DragManager.prototype.setStartPoint = _setStartPoint;
  DragManager.prototype.setLimitPoint = _setLimitPoint;
  DragManager.prototype.setDragPoint = _setDragPoint;
  DragManager.prototype.isMoved = _isMoved;
  DragManager.prototype.setStartingLocation = _setStartingLocation;
  DragManager.prototype.getStartingLocation = _getStartingLocation;
  DragManager.prototype.getDropLocation = _getDropLocation;
  
  // ドラッグ開始位置を設定(MouseDown時)
  function _setStartPoint(x,y,snapX,snapY) {
    this.startX = x;
    this.startY = y;
    this.moveX = 0;
    this.moveY = 0;
    this.moveXg = 0;
    this.moveYg = 0;
    this.snapX = snapX;
    //this.snapY = snapY;
  }

  // 移動範囲の制限を設定(MouseDown時?)
  function _setLimitPoint(x,y) {
    this.limitX = x;
    this.limitY = y;
  }
  
  // ドラッグ中のポインタの座標を設定(MouseMove時)
  function _setDragPoint(x,y) {
    this.dragX = x;
    this.dragY = y;
    this.moveX = x - this.startX;
    this.moveY = y - this.startY;

    // 吸着
    var tmpWidth = this.moveX + (SNAPWIDTH / 2) + this.snapX;
    this.moveXg = Math.floor(tmpWidth / SNAPWIDTH) * SNAPWIDTH - this.snapX;

    // 吸着
    var tmpHeight = this.moveY + (MOUSEMOVEHEIGHT / 2) + this.snapY;
    this.moveYg = Math.floor(tmpHeight / MOUSEMOVEHEIGHT) * MOUSEMOVEHEIGHT - this.snapY;

  }

  // ポインタが移動しているか（位置補正をしないための判定に使用）
  function _isMoved() {
    if(this.moveX <= PLAY && 
       this.moveX >= -PLAY && 
       this.moveY <= PLAY && 
       this.moveY >= -PLAY) {
      return false;
    }
    return true;
  }

  // オブジェクトごとの移動前の位置を登録
  function _setStartingLocation(id,x,y) {
    this.draggingObjects[id] = new Object();
    this.draggingObjects[id].x = x;
    this.draggingObjects[id].y = y;
  }
  
  // オブジェクトごとの移動前の位置を取得
  function _getStartingLocation(id) {
    return this.draggingObjects[id];
  }

  // ドロップした場合のオブジェクトの配置される位置をかえす
  // gridFlg:個々に吸着
  function _getDropLocation(id, gridFlg) {

    var ob = this.getStartingLocation(id);
    if(!this.isMoved()) {
      return ob;
    }
    var drop = new Object();
    if(gridFlg) {
      // 吸着
      var tmpWidth = ob.x + this.moveX + (SNAPWIDTH / 2);
      drop.x = Math.floor(tmpWidth / SNAPWIDTH) * SNAPWIDTH;

      // 吸着
      var tmpHeight = ob.y + this.moveY + (MOUSEMOVEHEIGHT / 2);
      drop.y = Math.floor(tmpHeight / MOUSEMOVEHEIGHT) * MOUSEMOVEHEIGHT;
    } else {
      drop.x = ob.x + this.moveXg;
      drop.y = ob.y + this.moveYg;
    }
    // 領域から出た場合の補正処理
    if(drop.x < 0){
      drop.x = 0;
    }

    // 領域から出た場合の補正処理
    if(drop.y < 0){
      drop.y = 0;
    }

    return drop;
  }
}

/**
 * オブジェクトにリサイズボックス（ハンドル）を表示する
 * @param  :elementId 画面項目ID
 */
function setResizeHandle(elementId) {
  if(m_monitorEditStatus == 2) return;
  if(!m_displayResizeHandle) return;
  setResizeHandle2(elementId);
}

var m_displayResizeHandle = pref.view.get('defaultresize');

/**
 * オブジェクトにリサイズボックス（ハンドル）を表示する
 * @param  :elementId 画面項目ID
 */
function setResizeHandle2(elementId) {
  var element = getDocumentElementById(elementId);
  var dataset = getDataSet(elementId);
  var left = parseInt(dataset.getProperty('left'));
  var top = parseInt(dataset.getProperty('top'));
  
  var width = element.offsetWidth;
  var height = element.offsetHeight;
  var x = left + width;
  var y = top + height;
  var type = getDataSet(elementId).getProperty('type');
  
  var xLeft   = getResizeHandleLocationBase();
  var xCenter = getResizeHandleLocationHalf(width);
  var xRight  = getResizeHandleLocationFull(width);
  var yTop    = getResizeHandleLocationBase();
  var yMiddle = getResizeHandleLocationHalf(height);
  var yBottom = getResizeHandleLocationFull(height);
  
  switch(type) {
  case TYPE.FORM:
//  case TYPE.TABLE:
  case TYPE.HIDE:
    return;

  case TYPE.HR:
    var html = _setAResizeHandle(elementId, xRight, yMiddle, 'e')
             + _setAResizeHandle(elementId, xLeft,  yMiddle, 'w');
    if(html != '') {
      getDocumentElementById(elementId + '_span').innerHTML += html;
    }
    break;

  default:
    var html = _setAResizeHandle(elementId, xLeft,   yTop, 'nw')
             + _setAResizeHandle(elementId, xCenter, yTop, 'n')
             + _setAResizeHandle(elementId, xRight,  yTop, 'ne')
             + _setAResizeHandle(elementId, xLeft,  yMiddle, 'w')
             + _setAResizeHandle(elementId, xRight, yMiddle, 'e')
             + _setAResizeHandle(elementId, xLeft,   yBottom, 'sw')
             + _setAResizeHandle(elementId, xCenter, yBottom, 's')
             + _setAResizeHandle(elementId, xRight,  yBottom, 'se');
    if(html != '') {
      getDocumentElementById(elementId + '_span').innerHTML += html;
    }
    
  }

  function _setAResizeHandle(_elementId, _left, _top, _direction) {
    var _dir = _direction; // se,s,ws,w,wn,n,en,e
    
    if(getDocumentElementById(getResizeHandleId(_elementId, _dir))) return '';

    var html = '<input type="text" readonly'
      + ' id="' + getResizeHandleId(_elementId, _dir) + '"'
      + ' style="'
      + 'position:absolute;'
      + 'left:' + _left + ';'
      + 'top:' + _top + ';'
      + 'font-size:1px;'
      + 'width:6px;'
      + 'height:6px;'
      + 'overflow:hidden;'
      + 'backgroundColor:white;'
      + 'border:1px solid black;'
      + 'cursor:' + _dir + '-resize;"'
      + ' onmousedown="resizeByHandleStart(event, \'' + _elementId + '\',\'' + _dir + '\');"'
      + ' onmousemove="resizeByHandleMove(event, \'' + _elementId + '\');"'
      + ' onmouseup="resizeByHandleEnd(event, \'' + _elementId + '\');"'
      + '>';
    //getDocumentElementById(_elementId + '_span').innerHTML += html;
    return html;
  }
}

/**
 * リサイズハンドルの座標を取得する
 */
function getResizeHandleLocationBase() {
  return -1;
  //return -6;
}
/**
 * リサイズハンドルの座標を取得する
 */
function getResizeHandleLocationHalf(siz) {
  return parseInt(siz / 2) - 2;
  //return parseInt(siz / 2) - 3;
}
/**
 * リサイズハンドルの座標を取得する
 */
function getResizeHandleLocationFull(siz) {
  return siz - 4;
  //return siz;
}
 
/**
 * オブジェクトからリサイズボックス（ハンドル）を取り除く
 */
function removeResizeHandle(elementId) {
  var parent = getDocumentElementById(elementId + '_span');
  _removeAResizeHandle(parent, elementId, 'se');
  _removeAResizeHandle(parent, elementId, 's');
  _removeAResizeHandle(parent, elementId, 'sw');
  _removeAResizeHandle(parent, elementId, 'e');
  _removeAResizeHandle(parent, elementId, 'w');
  _removeAResizeHandle(parent, elementId, 'ne');
  _removeAResizeHandle(parent, elementId, 'n');
  _removeAResizeHandle(parent, elementId, 'nw');

  function _removeAResizeHandle(_parent, _elementId, _dir) {
    var res = getDocumentElementById(getResizeHandleId(_elementId, _dir));
    if(res) {
      _parent.removeChild(res);
    }
  }
}

/**
 * ハンドルのidを取得する
 */
function getResizeHandleId(_elementId, _direction) {
  return _elementId + '.resizehandle.' + _direction;
}

/**
 * グローバル変数
 */
var m_resizingByHandleInfo = null;

/**
 * サイズ変更中の情報を保持するオブジェクト
 */
function ResizingByHandleInfo(_event, _direction) {
  this.startX = _event.clientX + document.body.scrollLeft;
  this.startY = _event.clientY + document.body.scrollTop; 
  this.moveX = 0;
  this.moveY = 0;
  this.direction = _direction;
  this.length = 0;
  this.elementInfos = new Object();

  ResizingByHandleInfo.prototype.addElementInfo = _addElementInfo;
  ResizingByHandleInfo.prototype.removeElementInfo = _removeElementInfo;
  
  function _addElementInfo(elementId) {
    var aInfo = new Object();
    aInfo.originalTop = 0;
    aInfo.originalLeft = 0;
    aInfo.originalWidth = 0;
    aInfo.originalHeight = 0;
    aInfo.currentTop = 0;
    aInfo.currentLeft = 0;
    aInfo.currentWidth = 0;
    aInfo.currentHeight = 0;
    aInfo.fldIdTop = 'fld_top';
    aInfo.fldIdLeft = 'fld_left';
    aInfo.fldIdWidth = 'fld_width';
    aInfo.fldIdHeight = 'fld_height';
    aInfo.handles = new Object();
    aInfo.element = null;
    aInfo.updateElementId = elementId;
    aInfo.updateTdElementId = '';
    aInfo.minHeight = 1;
    aInfo.modHeight = 5;
    this.elementInfos[elementId] = aInfo;
    this.length++;
    return aInfo;
  }
  
  function _removeElementInfo(elementId) {
    delete this.elementInfos[elementId];
  }
}

/**
 * リサイズ開始イベントハンドラ
 */
function resizeByHandleStart(_event, elementId, _direction) {
  // 吸着する範囲(px)
  var SNAPWIDTH = pref.operation.get('snap');
  
  var inf = new ResizingByHandleInfo(_event, _direction);
  
  for(var id in m_selection.elements){
    _addElement(inf, id);
  }
  m_resizingByHandleInfo = inf;

  _event.cancelBubble = true;
  return _event.returnValue;

  function _addElement(_inf, _elementId) {
    var ainf = _inf.addElementInfo(_elementId);
    var element = getDocumentElementById(_elementId);
    var dataset = getDataSet(_elementId);
    var type = dataset.getProperty('type');
    switch(type) {
    case TYPE.PANEL:
      ainf.fldIdWidth = 'fld_width';
      ainf.fldIdHeight = 'fld_height';
      ainf.minHeight = DISPLAYROWHEIGHT;
      ainf.modHeight = MOUSEMOVEHEIGHT;
      break;
    case TYPE.COMBO:
      ainf.minHeight = 5;
      break;
    case TYPE.RADIO:
    case TYPE.CHECK:
      //ainf.minHeight = 20;
      break;
    case TYPE.HR:
      ainf.fldIdTop = '';
      ainf.fldIdHeight = '';
      break;
    case TYPE.TABLE:
      ainf.fldIdWidth = 'fld_resizewidth';
      ainf.fldIdHeight = 'fld_resizeheight';
      ainf.minHeight = DISPLAYROWHEIGHT;
      ainf.modHeight = MOUSEMOVEHEIGHT;
      // updateTdElementIdの設定
      if(m_selection.current.cell != '') {
        if(m_selection.current.front == _elementId) {
          ainf.updateTdElementId = m_selection.current.cell;
        } else {
          var maxcol = dataset.getProperty('tablecols');
          var maxrow = getDesignTableRows(dataset);
          if(isCellId(m_selection.current.cell, m_selection.current.front)) {
            var row = getRowFromCellId(m_selection.current.cell);
            var col = getColFromCellId(m_selection.current.cell);
            if(maxrow < row) {
              row = maxrow;
            }
            if(maxcol < col) {
              col = maxcol;
            }
            ainf.updateTdElementId = getCellId(_elementId, row, col);
          } else {
            ainf.updateTdElementId = getCellId(_elementId, maxrow, maxcol);
          }
        }
      } else {
      
        var maxcol = dataset.getProperty('tablecols');
        var maxrow = getDesignTableRows(dataset);
        ainf.updateTdElementId = getCellId(_elementId, maxrow, maxcol);
      }
      break;
    case TYPE.HIDE:
      _inf.removeElementInfo(_elementId);
      return;
    }
    ainf.element = element;
    ainf.dataset = dataset;
    ainf.type = type;
    ainf.handles.n = getDocumentElementById(getResizeHandleId(_elementId,'n'));
    ainf.handles.ne = getDocumentElementById(getResizeHandleId(_elementId,'ne'));
    ainf.handles.e = getDocumentElementById(getResizeHandleId(_elementId,'e'));
    ainf.handles.se = getDocumentElementById(getResizeHandleId(_elementId,'se'));
    ainf.handles.s = getDocumentElementById(getResizeHandleId(_elementId,'s'));
    ainf.handles.sw = getDocumentElementById(getResizeHandleId(_elementId,'sw'));
    ainf.handles.w = getDocumentElementById(getResizeHandleId(_elementId,'w'));
    ainf.handles.nw = getDocumentElementById(getResizeHandleId(_elementId,'nw'));
    // 保持している値(Undoのため)
    ainf.originalTopValue = dataset.getProperty(ainf.fldIdTop.substr(4));
    ainf.originalLeftValue = dataset.getProperty(ainf.fldIdLeft.substr(4));
    ainf.originalWidthValue = dataset.getProperty(ainf.fldIdWidth.substr(4));
    ainf.originalHeightValue = dataset.getProperty(ainf.fldIdHeight.substr(4));
    // 座標計算のためのもと座標
    ainf.originalTop = parseInt(ainf.originalTopValue);
    ainf.originalLeft = parseInt(ainf.originalLeftValue);
    ainf.originalWidth  = element.offsetWidth;
    ainf.originalHeight = element.offsetHeight;
    
    // 新しい値(mouseUp時にこの値で更新)
    ainf.currentTop   = ainf.originalTopValue;
    ainf.currentLeft  = ainf.originalLeftValue;
    ainf.currentWidth   = ainf.originalWidth;
    ainf.currentHeight  = ainf.originalHeight;

    ainf.maxTop  = ainf.originalTop + ainf.originalHeight - 1;
    ainf.maxLeft = parseInt((ainf.originalLeft + ainf.originalWidth - 1) / SNAPWIDTH) * SNAPWIDTH;

  }  
}

/**
 * リサイズ中イベントハンドラ
 */
function resizeByHandleMove(_event) {
  // 吸着する範囲(px)
  var SNAPWIDTH = pref.operation.get('snap');

  if(!m_resizingByHandleInfo) return;
  var inf = m_resizingByHandleInfo;
  
  var moveX = _event.clientX + document.body.scrollLeft - inf.startX;
  var moveY = _event.clientY + document.body.scrollTop - inf.startY; 
  if(inf.moveX == moveX && inf.moveY == moveY) {
    _event.cancelBubble = true;
    return _event.returnValue;
  }
  inf.moveX = moveX;
  inf.moveY = moveY;
  
  var progressBar = new WindowStatusProgressBar(inf.length);
  
  for(var elementId in inf.elementInfos) {
    var ainf = inf.elementInfos[elementId];
    
    progressBar.update();
    
    switch(inf.direction) {
    case 'n':
      var n = _n(inf, ainf);
      _updateTopHeight(ainf , n, elementId);
      break;

    case 'ne':
      var n = _n(inf, ainf);
      _updateTopHeight(ainf , n, elementId);
      var e = _e(inf, ainf, _event);
      _updateWidth(ainf, e.width);
      break;

    case 'e':
      var e = _e(inf, ainf, _event);
      _updateWidth(ainf, e.width);
      break;

    case 'se':
      var s = _s(inf, ainf, _event);
      _updateHeight(ainf, s.height);
      var e = _e(inf, ainf, _event);
      _updateWidth(ainf, e.width);
      break;

    case 's':
      var s = _s(inf, ainf, _event);
      _updateHeight(ainf, s.height);
      break;

    case 'sw':
      var s = _s(inf, ainf, _event);
      _updateHeight(ainf, s.height);
      var w = _w(inf,ainf,_event);
      _updateLeftWidth(ainf , w, elementId);
      break;

    case 'w':
      var w = _w(inf,ainf,_event);
      _updateLeftWidth(ainf , w, elementId);
      break;

    case 'nw':
      var n = _n(inf, ainf);
      _updateTopHeight(ainf , n, elementId);
      var w = _w(inf,ainf,_event);
      _updateLeftWidth(ainf , w, elementId);
      break;

    default:
      alert('Unknown direction:' + inf.direction);
    }

    if(ainf.notreconstructed) {
      reconstruct(elementId,ainf.dataset);
    } else {
      validateResizeHandleLocation(elementId);
    }
  }
  
  progressBar.release();
  
  _event.cancelBubble = true;
  return _event.returnValue;

  /* 再描画 */
  function reconstruct(elementId, dataset) {
    var span = getDocumentElementById(elementId + '_span');
    setOuterHTML(span, getElementHtml(dataset));

    span = getDocumentElementById(elementId + '_span');
    span.style.zIndex = parseInt(dataset.getProperty('top')) + parseInt(dataset.getProperty('left'));

    span = getDocumentElementById(elementId + '_span');
    span.style.border = pref.view.get('selectionborder');

    if(m_selection.has(elementId)) {
      setResizeHandle(elementId);
    }
/*
    if(rtn.border) {
      // spanのborder再描画
      var spanStyle = getDocumentElementById(id + '_span').style;
      var border = spanStyle.border;
      spanStyle.border = 'none';
      spanStyle.border = border;
    }
*/
  }
  
  /* 座標計算メソッド */
  
  function _w(inf, ainf, _event) {
    var w = new Object();
    w.left = ainf.originalLeft + inf.moveX + (SNAPWIDTH / 2);
    if(!_event.ctrlKey) {
      w.left = parseInt(w.left - (w.left % SNAPWIDTH));
    } else {
      w.left = parseInt(w.left);
    }
    if(w.left < 0) {
      w.left = 0;
    }
    w.width = ainf.originalWidth + ainf.originalLeft - w.left;
    if(w.width < 1) {
      if(!_event.ctrlKey) {
        w.left = ainf.maxLeft;
        w.width = ainf.originalWidth + ainf.originalLeft - w.left;
      } else {
        w.left = ainf.originalLeft + ainf.originalWidth - 1;
        w.width = 1;
      }
    }
    return w;
  }
  
  function _e(inf, ainf, _event) {
    var e = new Object();
    e.width = ainf.originalWidth + inf.moveX + (SNAPWIDTH / 2);
    if(!_event.ctrlKey) {
      e.width = parseInt(e.width - ((ainf.originalLeft + e.width) % SNAPWIDTH));
    } else {
      e.width = parseInt(e.width);
    }
    if(e.width < 1) {
      if(!_event.ctrlKey) {
        e.width = SNAPWIDTH - ((ainf.originalLeft) % SNAPWIDTH);
      } else {
        e.width = 1;
      }
    }
    return e;
  }
  
  function _s(inf, ainf, _event) {
    var s = new Object();
    s.height = ainf.originalHeight + inf.moveY + (ainf.modHeight / 2);
    if(!_event.ctrlKey) {
      s.height = parseInt(s.height - ((ainf.originalHeight + s.height) % SNAPWIDTH));
    } else {
      s.height = parseInt(s.height);
    }
    if(s.height < ainf.minHeight) {
      if(!_event.ctrlKey) {
        s.height = ainf.minHeight + ((ainf.originalTop + ainf.minHeight) % ainf.modHeight);
      } else {
        s.height = ainf.minHeight;
      }
    }
    return s;
  }
  
  function _n(inf, ainf) {
    var n = new Object();
    n.top = parseInt(ainf.originalTop + inf.moveY + (MOUSEMOVEHEIGHT / 2));
    n.top = n.top - (n.top % MOUSEMOVEHEIGHT);
    if(n.top < 0) {
      n.top = 0;
    }
    n.height = ainf.originalHeight + ainf.originalTop - n.top;
    if(n.height < ainf.minHeight) {
      n.top = ainf.maxTop;
      n.height = ainf.originalHeight + ainf.originalTop - n.top;
    }
    
    return n;
  }

  /* 座標更新メソッド */

  function _updateWidth(_ainf, newWidth) {
    if(_ainf.fldIdWidth == '') return;
    if(newWidth < 1) newWidth = 1;

    var id = _ainf.updateElementId;
    var tdid = _ainf.updateTdElementId;
    var nextTdid = tdid;
    //log.debug('_updateWidth ' + id + '/' + tdid);
    
    //updateValuePerObject(id, tdid, _ainf.fldIdWidth, _ainf.currentWidth, null, null);
    var rtn = getViewObject(_ainf.type).update(_ainf.fldIdWidth.substr(4), newWidth, id, _ainf.dataset, tdid, null, _ainf.colInfo);
    _ainf.currentWidth = rtn.value;
    if(!rtn.updated) {
      // datasetは更新されていないので更新
      _ainf.dataset.setProperty(_ainf.fldIdWidth.substr(4), _ainf.currentWidth);
    }

    if(id == m_selection.current.front) {
      var shouldupdate = true;
      if(tdid != '') {
        shouldupdate = isSameCol(tdid, m_selection.current.cell);
      }
      if(shouldupdate) {
        if(rtn.modifiedField) {
          getDocumentElementById(rtn.modifiedField).value = rtn.modifiedValue;
        } else {
          var fld = getDocumentElementById(_ainf.fldIdWidth);
          if(fld) {
            fld.value = _ainf.currentWidth;
          }
        }
      }
    }

    if(rtn.modifiedField) {
      _ainf.modifiedWidthField = rtn.modifiedField;
      _ainf.modifiedWidthValue = rtn.modifiedValue;

      if(!_ainf.modifiedOriginalWidthValue) {
        _ainf.modifiedOriginalWidthValue = rtn.modifiedOriginalValue;
      }

      if(_ainf.colInfo && _ainf.colInfo.maxcols > 1) {
        var colnum = _ainf.colInfo.order[_ainf.colInfo.order.index];
        if(!_ainf.colInfo.modifiedValues[colnum]) {
          _ainf.colInfo.modifiedValues[colnum] = new Object();
          _ainf.colInfo.modifiedValues[colnum].originalWidth = _ainf.modifiedOriginalWidthValue;
          _ainf.colInfo.modifiedValues[colnum].originalWidth = _ainf.modifiedOriginalWidthValue;
        }
      }

      if(rtn.limited) {
        // 隣のセルを広げる
        if(_ainf.colInfo && _ainf.colInfo.maxcols > 1) {
          if(_ainf.colInfo.previous(_ainf)) {
            _updateWidth(_ainf, newWidth);
            return;
          }
        }
      }
      
      if(newWidth < rtn.value) {
        // 隣のセルを縮める
        if(!_ainf.colInfo) {
          _ainf.colInfo = new ColInfo(_ainf, 1);
        }
        if(_ainf.colInfo.maxcols > 1) {
          if(_ainf.colInfo.next(_ainf)) {
            _updateWidth(_ainf, newWidth);
            return;
          }
        }
      }
    }
    
    if(rtn.border) {
      // spanのborder再描画
      var spanStyle = getDocumentElementById(id + '_span').style;
      var border = spanStyle.border;
      spanStyle.border = 'none';
      spanStyle.border = border;
    }

    if(rtn.reconstructed) {
      if(m_selection.has(elementId)) {
        setResizeHandle(elementId);
      }
    } else if(rtn.resized) {
      // サイズが変更されたのでリサイズハンドルの位置を修正
      if(m_selection.has(elementId)) {
        validateResizeHandleLocation(elementId);
      }
    }
  }

  function _updateHeight(_ainf, newHeight) {
    if(_ainf.fldIdHeight == '') return;
    if(newHeight < 1) newHeight = 1;
    //_ainf.currentHeight = newHeight;
    var id = _ainf.updateElementId;
    var tdid = _ainf.updateTdElementId;
    var rtn = getViewObject(_ainf.type).update(_ainf.fldIdHeight.substr(4), newHeight, id, _ainf.dataset, tdid, null, _ainf.rowInfo);
    _ainf.currentHeight = rtn.value;
    if(!rtn.updated) {
      // datasetは更新されていないので更新
      _ainf.dataset.setProperty(_ainf.fldIdHeight.substr(4), _ainf.currentHeight);
    }

    if(id == m_selection.current.front) {
      var shouldupdate = true;
      if(tdid != '') {
        shouldupdate = isSameRow(tdid, m_selection.current.cell);
      }
      if(shouldupdate) {
        if(rtn.modifiedField) {
          getDocumentElementById(rtn.modifiedField).value = rtn.modifiedValue;
        } else {
          var fld = getDocumentElementById(_ainf.fldIdHeight);
          if(fld) {
            fld.value = _ainf.currentHeight;
          }
        }
      }
    }

    if(rtn.modifiedField) {
      _ainf.modifiedHeightField = rtn.modifiedField;
      _ainf.modifiedHeightValue = rtn.modifiedValue;

      if(!_ainf.modifiedOriginalHeightValue) {
        _ainf.modifiedOriginalHeightValue = rtn.modifiedOriginalValue;
      }

      if(_ainf.rowInfo && _ainf.rowInfo.maxrows > 1) {
        var rownum = _ainf.rowInfo.order[_ainf.rowInfo.order.index];
        if(!_ainf.rowInfo.modifiedValues[rownum]) {
          _ainf.rowInfo.modifiedValues[rownum] = new Object();
          _ainf.rowInfo.modifiedValues[rownum].originalHeight = _ainf.modifiedOriginalHeightValue;
        }
      }

      if(rtn.limited) {
        // 隣のセルを広げる
        if(_ainf.rowInfo && _ainf.rowInfo.maxrows > 1) {
          if(_ainf.rowInfo.previous(_ainf)) {
            _updateHeight(_ainf, newHeight);
            return;
          }
        }
      }
      
      if(newHeight < rtn.value) {
        // 隣のセルを縮める
        if(!_ainf.rowInfo) {
          _ainf.rowInfo = new RowInfo(_ainf, 1);
        }
        if(_ainf.rowInfo.maxrows > 1) {
          if(_ainf.rowInfo.next(_ainf)) {
            _updateHeight(_ainf, newHeight);
            return;
          }
        }
      }
    }

    if(rtn.reconstructed) {
      if(m_selection.has(elementId)) {
        setResizeHandle(elementId);
      }
    } else if(rtn.resized) {
      // サイズが変更されたのでリサイズハンドルの位置を修正
      if(m_selection.has(elementId)) {
        validateResizeHandleLocation(elementId);
      }
    }
  }

  /**
   *
   */
  function _updateLeftWidth(_ainf,w,elementId){
    var tdid = _ainf.updateTdElementId;
    var rtn = getViewObject(_ainf.type).update(_ainf.fldIdWidth.substr(4), w.width, elementId, _ainf.dataset, tdid, null, _ainf.colInfo);

    _ainf.currentWidth = rtn.value;

    if(!rtn.updated) {
      // datasetは更新されていないので更新
      _ainf.dataset.setProperty(_ainf.fldIdWidth.substr(4), _ainf.currentWidth);
    }

    if(elementId == m_selection.current.front) {
      var shouldupdate = true;
      if(tdid != '') {
        shouldupdate = isSameCol(tdid, m_selection.current.cell);
      }
      if(shouldupdate) {
        if(rtn.modifiedField) {
          getDocumentElementById(rtn.modifiedField).value = rtn.modifiedValue;
        } else {
          getDocumentElementById(_ainf.fldIdWidth).value = _ainf.currentWidth;
        }
      }
    }

    if(rtn.modifiedField) {
      _ainf.modifiedWidthField = rtn.modifiedField;
      _ainf.modifiedWidthValue = rtn.modifiedValue;
      if(!_ainf.modifiedOriginalWidthValue) {
        _ainf.modifiedOriginalWidthValue = rtn.modifiedOriginalValue;
      }

      if(_ainf.colInfo && _ainf.colInfo.maxcols > 1) {
        var colnum = _ainf.colInfo.order[_ainf.colInfo.order.index];
        if(!_ainf.colInfo.modifiedValues[colnum]) {
          _ainf.colInfo.modifiedValues[colnum] = new Object();
          _ainf.colInfo.modifiedValues[colnum].originalWidth = _ainf.modifiedOriginalWidthValue;
        }
      }

      if(rtn.limited) {
        // 隣のセルを広げる
        if(_ainf.colInfo && _ainf.colInfo.maxcols > 1) {
          if(_ainf.colInfo.previous(_ainf)) {
            _updateLeftWidth(_ainf,w,elementId);
            return;
          }
        }
      }
      
      if(w.width < rtn.value) {
        // 隣のセルを縮める
        if(!_ainf.colInfo) {
          _ainf.colInfo = new ColInfo(_ainf, -1);
        }
        if(_ainf.colInfo.maxcols > 1) {
          if(_ainf.colInfo.next(_ainf)) {
            _updateLeftWidth(_ainf,w,elementId);
            return;
          }
        }
      }
    }

    if(rtn.reconstructed) {
      // エレメントの参照を再取得
      _ainf.element = getDocumentElementById(elementId);
    }

    if(_ainf.element.offsetWidth) {
      var offset = _ainf.element.offsetWidth;
      if(_ainf.currentWidth < offset) {
        _ainf.currentWidth = offset;
      }
    }
    w.left = w.left + w.width - _ainf.currentWidth;
    var rtn2 = getViewObject(_ainf.type).update(_ainf.fldIdLeft.substr(4), w.left, elementId, _ainf.dataset, tdid);

    _ainf.currentLeft = rtn2.value;

    if(!rtn2.updated) {
      // datasetは更新されていないので更新
      _ainf.dataset.setProperty(_ainf.fldIdLeft.substr(4), _ainf.currentLeft);
    }

    if(rtn.reconstructed) {
      if(m_selection.has(elementId)) {
        setResizeHandle(elementId);
      }
    } else if(rtn.resized) {
      // サイズが変更されたのでリサイズハンドルの位置を修正
      if(m_selection.has(elementId)) {
        validateResizeHandleLocation(elementId);
      }
    }

    if(elementId == m_selection.current.front) {
      if(rtn2.modifiedField) {
        getDocumentElementById(rtn2.modifiedField).value = rtn2.modifiedValue;
      } else {
        getDocumentElementById(_ainf.fldIdLeft).value = _ainf.currentLeft;
      }
    }
  }

  /**
   *
   */
  function _updateTopHeight(_ainf,n,elementId){
    var tdid = _ainf.updateTdElementId;
    var rtn = getViewObject(_ainf.type).update(_ainf.fldIdHeight.substr(4), n.height, elementId, _ainf.dataset, tdid, null, _ainf.rowInfo);
    if(rtn.reconstructed) {
      // エレメントの参照を再取得
      _ainf.element = getDocumentElementById(elementId);
    }

    _ainf.currentHeight = rtn.value;
    
    if(!rtn.updated) {
      // datasetは更新されていないので更新
      _ainf.dataset.setProperty(_ainf.fldIdHeight.substr(4), _ainf.currentHeight);
    }

    if(elementId == m_selection.current.front) {
      var shouldupdate = true;
      if(tdid != '') {
        shouldupdate = isSameRow(tdid, m_selection.current.cell);
      }
      if(shouldupdate) {
        if(rtn.modifiedField) {
          getDocumentElementById(rtn.modifiedField).value = rtn.modifiedValue;
        } else {
          getDocumentElementById(_ainf.fldIdHeight).value = _ainf.currentHeight;
        }
      }
    }
    
    if(rtn.modifiedField) {
      _ainf.modifiedHeightField = rtn.modifiedField;
      _ainf.modifiedHeightValue = rtn.modifiedValue;

      if(!_ainf.modifiedOriginalHeightValue) {
        _ainf.modifiedOriginalHeightValue = rtn.modifiedOriginalValue;
      }

      if(_ainf.rowInfo && _ainf.rowInfo.maxrows > 1) {
        var rownum = _ainf.rowInfo.order[_ainf.rowInfo.order.index];
        if(!_ainf.rowInfo.modifiedValues[rownum]) {
          _ainf.rowInfo.modifiedValues[rownum] = new Object();
          _ainf.rowInfo.modifiedValues[rownum].originalHeight = _ainf.modifiedOriginalHeightValue;
        }
      }

      if(rtn.limited) {
        // 隣のセルを広げる
        if(_ainf.rowInfo && _ainf.rowInfo.maxrows > 1) {
          if(_ainf.rowInfo.previous(_ainf)) {
            _updateTopHeight(_ainf,n,elementId);
            return;
          }
        }
      }
      
      if(n.height < rtn.value) {
        // 隣のセルを縮める
        if(!_ainf.rowInfo) {
          _ainf.rowInfo = new RowInfo(_ainf, -1);
        }
        if(_ainf.rowInfo.maxrows > 1) {
          if(_ainf.rowInfo.next(_ainf)) {
            _updateTopHeight(_ainf,n,elementId);
            return;
          }
        }
      }
    }


    if(n.height != _ainf.element.offsetHeight){
      n.top = n.top + n.height - _ainf.element.offsetHeight;
      n.height = _ainf.element.offsetHeight + (n.top % DISPLAYROWHEIGHT);
      rtn = getViewObject(_ainf.type).update(_ainf.fldIdHeight.substr(4), n.height, elementId, _ainf.dataset, tdid);
    }
    var rtn2 = getViewObject(_ainf.type).update(_ainf.fldIdTop.substr(4), n.top, elementId, _ainf.dataset, tdid);

    _ainf.currentTop = rtn2.value;

    if(!rtn2.updated) {
      // datasetは更新されていないので更新
      _ainf.dataset.setProperty(_ainf.fldIdTop.substr(4), _ainf.currentTop);
    }
    
    if(rtn.reconstructed) {
      if(m_selection.has(elementId)) {
        setResizeHandle(elementId);
      }
    } else if(rtn.resized) {
      // サイズが変更されたのでリサイズハンドルの位置を修正
      if(m_selection.has(elementId)) {
        validateResizeHandleLocation(elementId);
      }
    }

    if(elementId == m_selection.current.front) {
      if(rtn2.modifiedField) {
        getDocumentElementById(rtn2.modifiedField).value = rtn2.modifiedValue;
      } else {
        getDocumentElementById(_ainf.fldIdTop).value = _ainf.currentTop;
      }
    }
  }

  /*
   * @param start 開始列・開始行
   * @param max 最大列数・最大行数
   * @param dir ドラッグの方向 +1:下方向・右方向  -1:上方向・左方向
   */
  function getTdOrder(start, max, dir) {
    var order = new Array();
    order[0] = start;
    var i;
    for(i = start; 1 <= i && i <= max; i += dir) {
      order[order.length] = i;
    }
    for(i = start - dir; 1 <= i && i <= max; i -= dir) {
      order[order.length] = i;
    }
    order.index = 0;
    return order;
  }

  function Parts(cellid) {
    var splt = cellid.split('-');
    this.head = splt[0] + '-';
    this.row = splt[1];
    this.col = splt[2];

    Parts.prototype.setRow = function(row) {
      this.row = row;
      return this;
    }
    Parts.prototype.setCol = function(col) {
      this.col = col;
      return this;
    }
    Parts.prototype.get = function() {
      return this.head + this.row + '-' + this.col;
    }
  }

  /**
   * セルの伸び縮み情報
   */
  function RowInfo(_ainf, dir) {

    this.maxrows = getDesignTableRows(_ainf.dataset);
    if(this.maxrows > 1) {
      var tdid = _ainf.updateTdElementId;
      this.parts = new Parts(tdid);
      this.modifiedValues = new Object();
      var tdnum = Number(getDataSet(tdid).getProperty('cellrow'));
      this.order = getTdOrder(tdnum, this.maxrows, dir);
    }
    
    RowInfo.prototype.next = function(_ainf) {
      if(this.order.index + 1 < this.order.length) {
        this.change(_ainf, 1);
        return true;
      }
      return false;
    }

    RowInfo.prototype.previous = function(_ainf) {
      if(this.order.index > 0) {
        this.change(_ainf, -1);
        return true;
      }
      return false;
    }

    RowInfo.prototype.change = function(_ainf, inc) {
        
      var tdnum = this.order[this.order.index];
      if(!this.modifiedValues[tdnum]) {
        this.modifiedValues[tdnum] = new Object();
        this.modifiedValues[tdnum].originalHeight = _ainf.modifiedOriginalHeightValue;
      }
      this.modifiedValues[tdnum].height = _ainf.modifiedHeightValue;
      
      this.order.index += inc;
      var nexttdnum = this.order[this.order.index];
      if(this.modifiedValues[nexttdnum]) {
        _ainf.modifiedOriginalHeightValue = this.modifiedValues[nexttdnum].originalHeight;
      } else {
        delete _ainf.modifiedOriginalHeightValue;
      }

      _ainf.updateTdElementId = this.parts.setRow(nexttdnum).get();
      if(_ainf.colInfo) {
        _ainf.colInfo.parts.setRow(nexttdnum);
      }
    }
  }

  /**
   * セルの伸び縮み情報
   */
  function ColInfo(_ainf, dir) {
    
    this.maxcols = Number(_ainf.dataset.getProperty('tablecols'));
    if(this.maxcols > 1) {
      var tdid = _ainf.updateTdElementId;
      this.parts = new Parts(tdid);
      this.modifiedValues = new Object();
      var tdnum = Number(getDataSet(tdid).getProperty('cellcol'));
      this.order = getTdOrder(tdnum, this.maxcols, dir);
    }

    ColInfo.prototype.next = function(_ainf) {
      if(this.order.index + 1 < this.order.length) {
        this.change(_ainf, 1);
        return true;
      }
      return false;
    }

    ColInfo.prototype.previous = function(_ainf) {
      if(this.order.index > 0) {
        this.change(_ainf, -1);
        return true;
      }
      return false;
    }

    ColInfo.prototype.change = function(_ainf, inc) {
        
      var tdnum = this.order[this.order.index];
      if(!this.modifiedValues[tdnum]) {
        this.modifiedValues[tdnum] = new Object();
        this.modifiedValues[tdnum].originalWidth = _ainf.modifiedOriginalWidthValue;
      }
      this.modifiedValues[tdnum].width = _ainf.modifiedWidthValue;
      this.order.index += inc;
      var nexttdnum = this.order[this.order.index];
      if(this.modifiedValues[nexttdnum]) {
        _ainf.modifiedOriginalWidthValue = this.modifiedValues[nexttdnum].originalWidth;
      } else {
        delete _ainf.modifiedOriginalWidthValue;
      }
      _ainf.updateTdElementId = this.parts.setCol(nexttdnum).get();
      if(_ainf.rowInfo) {
        _ainf.rowInfo.parts.setCol(nexttdnum);
      }
    }
  }
}

/**
 * リサイズ終了イベントハンドラ
 */
function resizeByHandleEnd(_event) {
  if(!m_resizingByHandleInfo) return;

  var inf = m_resizingByHandleInfo;

  var cmdSet = new UndoableCommandSet(getLiteral('command.resize'));
  cmdSet.add(new CommandSelect(true,false));
  
  if(inf.direction.charAt(0) == 'n') {
    // top+height
    for(var _id in inf.elementInfos) {
      var ainf = inf.elementInfos[_id];
      if(ainf.originalTopValue != ainf.currentTop) {
        var cmd = new UndoPropertyEdit(_id, ainf.updateTdElementId, ainf.fldIdTop.substr(4), ainf.originalTopValue, ainf.currentTop);
        cmdSet.add(cmd);
      }
      if(ainf.modifiedHeightField) {
        var cmd = new UndoPropertyEdit(_id, ainf.updateTdElementId, ainf.modifiedHeightField.substr(4), ainf.modifiedOriginalHeightValue, ainf.modifiedHeightValue);
        cmdSet.add(cmd);
        var currRow = Number(getRowFromCellId(ainf.updateTdElementId));
        if(ainf.rowInfo && ainf.rowInfo.modifiedValues) {
          for(var rownum in ainf.rowInfo.modifiedValues) {
            if(rownum == currRow) continue;
            var vals = ainf.rowInfo.modifiedValues[rownum];
            if(vals.originalHeight != vals.height) {
              var cellid = ainf.rowInfo.parts.setRow(rownum).get();
              var cmd = new UndoPropertyEdit(_id, cellid, ainf.modifiedHeightField.substr(4), vals.originalHeight, vals.height);
              cmdSet.add(cmd);
            }
          }
        }
      } else {
        if(ainf.originalHeightValue != ainf.currentHeight) {
          var cmd = new UndoPropertyEdit(_id, ainf.updateTdElementId, ainf.fldIdHeight.substr(4), ainf.originalHeightValue, ainf.currentHeight);
          cmdSet.add(cmd);
        }
      }
    }
  } else if(inf.direction.charAt(0) == 's') {
    // top
    for(var _id in inf.elementInfos) {
      var ainf = inf.elementInfos[_id];
      if(ainf.modifiedHeightField) {
        var cmd = new UndoPropertyEdit(_id, ainf.updateTdElementId, ainf.modifiedHeightField.substr(4), ainf.modifiedOriginalHeightValue, ainf.modifiedHeightValue);
        cmdSet.add(cmd);
        var currRow = Number(getRowFromCellId(ainf.updateTdElementId));
        if(ainf.rowInfo && ainf.rowInfo.modifiedValues) {
          for(var rownum in ainf.rowInfo.modifiedValues) {
            if(rownum == currRow) continue;
            var vals = ainf.rowInfo.modifiedValues[rownum];
            if(vals.originalHeight != vals.height) {
              var cellid = ainf.rowInfo.parts.setRow(rownum).get();
              var cmd = new UndoPropertyEdit(_id, cellid, ainf.modifiedHeightField.substr(4), vals.originalHeight, vals.height);
              cmdSet.add(cmd);
            }
          }
        }
      } else {
        if(ainf.originalHeightValue != ainf.currentHeight) {
          var cmd = new UndoPropertyEdit(_id, ainf.updateTdElementId, ainf.fldIdHeight.substr(4), ainf.originalHeightValue, ainf.currentHeight);
          cmdSet.add(cmd);
        }
      }
    }
  }

  if(inf.direction == 'w' || inf.direction.charAt(1) == 'w') {
    // left+width
    for(var _id in inf.elementInfos) {
      var ainf = inf.elementInfos[_id];
      if(ainf.originalLeftValue != ainf.currentLeft) {
        var cmd = new UndoPropertyEdit(_id, ainf.updateTdElementId, ainf.fldIdLeft.substr(4), ainf.originalLeftValue, ainf.currentLeft);
        cmdSet.add(cmd);
      }
      if(ainf.modifiedWidthField) {
        var cmd = new UndoPropertyEdit(_id, ainf.updateTdElementId, ainf.modifiedWidthField.substr(4), ainf.modifiedOriginalWidthValue, ainf.modifiedWidthValue);
        cmdSet.add(cmd);
        var currCol = Number(getColFromCellId(ainf.updateTdElementId));
        if(ainf.colInfo && ainf.colInfo.modifiedValues) {
          for(var colnum in ainf.colInfo.modifiedValues) {
            if(colnum == currCol) continue;
            var vals = ainf.colInfo.modifiedValues[colnum];
            if(vals.originalWidth != vals.width) {
              var cellid = ainf.colInfo.parts.setCol(colnum).get();
              var cmd = new UndoPropertyEdit(_id, cellid, ainf.modifiedWidthField.substr(4), vals.originalWidth, vals.width);
              cmdSet.add(cmd);
            }
          }
        }
      } else {
        if(ainf.originalWidthValue != ainf.currentWidth) {
          var cmd = new UndoPropertyEdit(_id, ainf.updateTdElementId, ainf.fldIdWidth.substr(4), ainf.originalWidthValue, ainf.currentWidth);
          cmdSet.add(cmd);
        }
      }
    }
  } else if(inf.direction == 'e' || inf.direction.charAt(1) == 'e'){
    // left
    for(var _id in inf.elementInfos) {
      var ainf = inf.elementInfos[_id];
      if(ainf.modifiedWidthField) {
        var cmd = new UndoPropertyEdit(_id, ainf.updateTdElementId, ainf.modifiedWidthField.substr(4), ainf.modifiedOriginalWidthValue, ainf.modifiedWidthValue);
        cmdSet.add(cmd);
        var currCol = Number(getColFromCellId(ainf.updateTdElementId));
        if(ainf.colInfo && ainf.colInfo.modifiedValues) {
          for(var colnum in ainf.colInfo.modifiedValues) {
            if(colnum == currCol) continue;
            var vals = ainf.colInfo.modifiedValues[colnum];
            if(vals.originalWidth != vals.width) {
              var cellid = ainf.colInfo.parts.setCol(colnum).get();
              var cmd = new UndoPropertyEdit(_id, cellid, ainf.modifiedWidthField.substr(4), vals.originalWidth, vals.width);
              cmdSet.add(cmd);
            }
          }
        }
      } else {
        if(ainf.originalWidthValue != ainf.currentWidth) {
          var cmd = new UndoPropertyEdit(_id, ainf.updateTdElementId, ainf.fldIdWidth.substr(4), ainf.originalWidthValue, ainf.currentWidth);
          cmdSet.add(cmd);
        }
      }
    }
  }

  if(cmdSet.commands.length > 1) {
    cmdSet.add(new CommandSelect(false,false));
    m_undoManager.execute(cmdSet);
  }

  m_resizingByHandleInfo = null;

  _event.cancelBubble = true;
  return _event.returnValue;
}

/** 
 * srcが読み込まれるのを待つ
 */
function delayCall(elementId, call, interval) {
  var element = getDocumentElementById(elementId);
  if(element.complete) {
    window.status = 'complete';
    eval(call);
  } else if(typeof(element.complete) != 'boolean') {
    window.status = 'no prop complete';
    eval(call);
  } else {
    window.status = 'not complete';
    setTimeout('delayCall(\'' + elementId + '\',"' + call + '",' + interval + ')', interval);
  }
}

/**
 * オブジェクトのサイズの変更に応じてハンドルの位置を更新
 */
function validateResizeHandleLocation(elementId) {

  var element = getDocumentElementById(elementId);
  var handle = element.resizeHandles;
  if(!handle) {
    handle = new Object();
    handle.n  = getDocumentElementById(getResizeHandleId(elementId, 'n'));
    handle.ne = getDocumentElementById(getResizeHandleId(elementId, 'ne'));
    handle.w  = getDocumentElementById(getResizeHandleId(elementId, 'w'));
    handle.e  = getDocumentElementById(getResizeHandleId(elementId, 'e'));
    handle.sw = getDocumentElementById(getResizeHandleId(elementId, 'sw'));
    handle.s  = getDocumentElementById(getResizeHandleId(elementId, 's'));
    handle.se = getDocumentElementById(getResizeHandleId(elementId, 'se'));
    element.resizeHandles = handle;
  }
  
  var fw = getResizeHandleLocationFull(element.offsetWidth);
  var hw = getResizeHandleLocationHalf(element.offsetWidth);
  var fh = getResizeHandleLocationFull(element.offsetHeight);
  var hh = getResizeHandleLocationHalf(element.offsetHeight);
  
  if(handle.n ) {handle.n.style.left  = hw;}
  if(handle.ne) {handle.ne.style.left = fw;}
  if(handle.w ) {handle.w.style.top   = hh;}
  if(handle.e ) {handle.e.style.left  = fw; handle.e.style.top  = hh;}
  if(handle.sw) {handle.sw.style.top  = fh;}
  if(handle.s ) {handle.s.style.left  = hw; handle.s.style.top  = fh;}
  if(handle.se) {handle.se.style.left = fw; handle.se.style.top = fh;}
}
